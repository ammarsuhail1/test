import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

import { NEVER } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';

import * as rg4js from 'raygun4js';

import { environment } from '@env/environment';

@Injectable()
export class EnvService {

  constructor(private http: HttpClient) {}
  
  public init() {
    return this.http.get(`/assets/config/env.json`)
    .pipe(
      tap((env: any) => {
        env = env.Setting;
        for (const prop in env)
          if (prop in environment.Setting)
            environment.Setting[prop] = env[prop];
        
          if (environment.production) {
            rg4js('apiKey', env.raygunAPIKey);
            rg4js('setVersion', env.raygunVersion);
            rg4js('enableCrashReporting', true);
            rg4js('enablePulse', true);
            rg4js('logContentsOfXhrCalls', true);
          }
      }),
      catchError(error => NEVER)
    )
    .toPromise();
  }
}

export const envInitializer = (env: EnvService) => {
  return () => env.init();
}