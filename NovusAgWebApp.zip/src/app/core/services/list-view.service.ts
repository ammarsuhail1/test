import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { ApiLmkService } from './api-lmk.service';
import { Observable } from 'rxjs';
import { GridPermissions } from '../models/grid-permissions.model';
import { map } from 'rxjs/operators';
import { sortBy } from 'lodash';
import {GridConfiguration} from '../models';
import {environment} from '@env/environment';
import {HttpClient} from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class ListviewService {

  notesShowData = [];
  constructor(
    private http: HttpClient,
    private api: ApiService,
    private lmkapi: ApiLmkService
  ) { }

  GridConfig(objGridData) {
    const { ProcessName, GridGuid, ViewName } = objGridData;
    return this.api.get(`listview/gridConfig?processName=${ProcessName}&gridGuid=${GridGuid}&viewName=${encodeURIComponent(ViewName)}`);
  }

  GridData(userData: any, isWF = true) {
    if (isWF) {
      return this.api.post('listview/getprocessdata', userData);
    } else {
      return this.lmkapi.post('listview/getprocessdata', userData);
    }
  }

  DMOData(ProcessName: string, dmoName: string) {
    
    return this.api.get('listview/getDmoFilterData/' + ProcessName + '/' + dmoName).pipe(
      map((list: {DataValue: string}[]) => sortBy(list, ['DataValue']))
    );
  }

  sendGridConfig(gridData: any) {
    return this.api.post(`listview/gridConfig`, gridData);
  }

  stateList(processData) {
    return this.api.get('listview/getState/' + processData);
  }

  stageList(processData) {
    return this.api.get('application/applicationwfstages' + "?processName=" + processData + "&timeZone=" + "0");
  }

  dmoList(processData) {
    return this.api.get(`listview/getDmo/` + processData);
  }
  dmoListOrderByDMO(processData,CanvasType?:any) {
    // default set adminview
    if(CanvasType === null || CanvasType === undefined) {
      CanvasType = 'AdminView';
    }
    return this.api.get(`listview/getDmo/` + processData + '?isSortByDMO=true' + '&CanvasType='+CanvasType);
  }

  deleteGridData(id: string){
    return this.api.deleteGrid('application/deleteTransaction?TransactionIDs=' + id);
  }
  ExportToExcel(userData: any) {
     if(userData.ProcessName == 'announcement'){
      return this.api.postGetFile(`listview/ExportToExlAnncmntData`, userData, 'blob');
     }
     else{
      return this.api.postGetFile(`listview/exportToExcel`, userData, 'blob');
     }
  }
  ExportToPDF(userData: any) {
    return this.api.postGetFile(`listview/ExportToPDF`, userData, 'blob');
  }
  ExportFileWithEndPointURL(userData: any, url) {
    return this.api.postGetFileWithEndPoint(url, userData, 'blob');
  }
  deleteGridConfigData(configData){
    return this.api.deleteGrid(`listview/deleteGridConfig` + "?processName=" + configData.ProcessName + "&gridGuid=" + configData.GridGuid + "&viewName=" + configData.ViewName);
  }
  GetDataFromIceAPI(url: string, resultType: any) {
    return this.api.GetDataFromIceAPI(url, resultType);
  }
   userActionPermission(params?: any): Observable<GridPermissions> {
    return this.api.get('listview/GetUserActionPermission', params);
 }
  // listview/exportToExcel

  noteMessage(id){
    return this.api.get(`application/comment/` + null + '/' + null + "?transactionId=" + id)
  }
  sendNoteMessage(message){
    return this.api.post(`application/postcomment`, message);
  }

  userList(userData){
    return this.api.get(`formview/getUsername` + "?processName=" + userData.processname + "&searchText=" + userData.searchtext);
  }
  UploadFile(formData: FormData, params?: any) {
    return this.api.UploadFile('application/bulkUploadnew', formData, params);
  }
   uploadFiles(url: string, formData: FormData) {
    return this.api.post(url , formData);
  }

  downloadFile(downloadRequiredata) {
    return this.api.postGetFile(`application/downloadFileDiscussionBoard?transctionID=` + downloadRequiredata.transactionid + '&fileID='
     + downloadRequiredata.fileid, downloadRequiredata, 'blob');
  }
  UpdateCell(applicationObj){
    return this.api.post(`application/updateapplication`, applicationObj);
  }
  getProcess() {
    return this.api.get('application/processList');
  }

  getAllQuickMind(processname) {
    return this.api.get('quickmind/getallqmind' + '?processName=' + processname);
  }

  deleteQuickmind(processName , id) {
    return this.api.delete('quickmind/deleteqmind', '?processName=' + processName + '&qminds=' + id);
  }
  GridDatalmk(userData: any) {
    return this.lmkapi.post('crmsales/salesProcessData', userData);
  }
  resetGridConfg(model: any) {
    return this.api.post(`listview/resetGridConfig`, model);
  }

  saveProgramRule(programRuleMapping: any) {
    return this.api.post(`Product/saveProgramRules`, programRuleMapping);
  }

  public getRecordsCount(config: GridConfiguration) {
    const url = `${environment.Setting.WFApiUrl}/listview/getProcessDataCount`;
    return this.http.post<any>(url, config, {headers: {noSpinner: 'noSpinner'}}).pipe(
      map(res => +res.RecordsCount)
    );
  }
}
