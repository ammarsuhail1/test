import { Injectable } from '@angular/core';
import { ApiESaleyardService } from './api-e-saleyard.service';

@Injectable({
  providedIn: 'root'
})
export class ContentManagerService {

  constructor(private api: ApiESaleyardService) { }

  getContentManagerList(bodyData) {
    return this.api.post('ContentManager/getContentManager', bodyData);
  }

  AddOrUpdate(data) {
    return this.api.post(`ContentManager/addEditContentManager`, data);
  }
  getAsset() {
    return this.api.get(`ContentManager/getAsset`);
  }

  deleteData(id: string) {
    return this.api.delete('contentmanager/deleteContentManager?dataID=' + id, null);
  }
  UploadFile(formData: FormData) {
    return this.api.UploadFile('contentmanager/uploadDocumentContentManager', formData);
  }
  ChangeUserStatus(userId) {
    return this.api.post(`contentmanager/changeStatus?dataID=` + userId, null);
  }
  uploadFile(url: string, formData: FormData) {
    return this.api.post(url, formData);
  }
  getContentManagerByid(bodyData) {
    return this.api.post('ContentManager/getContentManagerByID', bodyData);
  }

  getFile(fileData) {
    return this.api.postGetFile('contentmanager/downloadDocumentContentManager?dataID=' + fileData.dataID +
    '&fileID=' + fileData.fileID + '&controlName=' + fileData.controlName, null, 'blob');
  }
}
