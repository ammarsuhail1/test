import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { FormGroup } from '@angular/forms';

import { EMPTY, of } from 'rxjs';
import { map, tap, catchError, switchMap } from 'rxjs/operators';

import { ApiService } from './api.service';
import { UtilityService } from './utility.service';
import { DmoControlService } from './dmo-control.service';

import { environment } from '@env/environment';
import { GridConfiguration, GridResponse, UpdateJSON } from '../models';
import * as projectModels from '../models/project';
import {  BaseDmo } from '../models/dmos';
import { UserDetail } from '@app/core/models/user-detail';
import { PricingGrid } from '../models/project';
import { AuthenticationService } from './authentication.service';
import { Observable } from 'rxjs';

@Injectable({providedIn: 'root'})
export class NovusService {
  private readonly _baseUrl = environment.Setting.ProjectApiUrl;

  constructor(
    private http: HttpClient, 
    private api: ApiService,
    private auth: AuthenticationService,
    private utility: UtilityService,
    private dmoControl: DmoControlService,
    private userDetail: UserDetail
  ) {}


  /* BOOKING */
  /** Synchronizes the latest bookings data with Agvance database
   * since the last refresh was performed.
   * 
   * Returns `true` if sync was successful
  */
  public syncBookingsData() {
    const path = `Booking/syncManualBookingsData`;
    return this._postrequest<boolean>(path, null, {appName: 'Bookings_Manager'});
  }


  /* CONTRACTS */
  private _exportContractsToFile(config: GridConfiguration, type: 'pdf' | 'excel') {
    const path = `Contracts/exportTo${type}`;
    return this._postrequest<Blob>(path, config, null, 'Blob');
  }


  public getBulkUploadTemplate(parentTransactionId: string) {
    const path = `Contracts/getReleaseBulkUploadTemplate/${parentTransactionId}`;
    return this._postrequest<Blob>(path, {}, null, 'Blob');
  }

  /** Custom api to retrieve grid data in Contracts app 
   *  specifically for Fertilizer Admins (Division Admins) `nagdivisionadmin`
   */
  public getContractsGridData(config: GridConfiguration) {
    const path = `Contracts/getContractsProcessData`;
    return this._postrequest<GridResponse<any>>(path, config);
  }

  public changeParentState(parentTransactionId: string) {
    const path = `Contracts/changeParentState?pTrnsctnID=${parentTransactionId}`;
    return this._postrequest<null | 'Success'>(path, {});
  }

  public bulkUploadReleases(formData: FormData, processName: string) {
    const accessToken = localStorage.getItem('AccessToken');
    const url = `${this._baseUrl}/Contracts/releaseBulkUpload`;
    return this.http.post(url, formData, {headers: {accessToken, processName}});
  }

  public deleteContractsData(transactionIds: string[]) {
    const path = `Contracts/deleteContractsData`;
    return this._postrequest<boolean>(path, {trnsctnIds: transactionIds});
  }

  /** Checks the `FilledYN` value. Returns boolean
   * 
   * It's run only when Contracts state is closed:
   * - Name - `NAG_WF_SCM_CLOSED_Closed`
   * - GUID - `nagwfscmclosedclosed`
   */
  public updateContractsStateToPOClosed(transactionId: string) {
    const path = `Contracts/updateContractsStateToPOClosed`;
    return this._postrequest<boolean>(path, null, {trnsctnId: transactionId});
  }

  /** 
   * When called updates the following dmos in Contracts:
   * - Quantity Exposed: `NAG_SCM_AV_CT_OD_Ex`
   * - Quantity Committed: `NAG_SCM_AV_CT_OD_Co`
   * - Quantity Shipped: `NAG_SCM_AV_CT_OD_Sh`
   * - Repl Cost: `NAG_SCM_AV_Repl`
   * - +/- Position: `NAG_SCM_AV_Pos`
  */
  public updateOtherContractsDetails(transactionId: string, payload: projectModels.OtherContractDetails) {
    const path = `Contracts/updateOtherContractsDetails`;
    return this._postrequest<boolean>(path, payload, {trnsctnId: transactionId});
  }

  /**
   * Checks if a release is valid for a given contract.
   * 
   * Returns "Success" message if a release is valid.
   * 
   * @param transactionId - contract transaction ID if action === 'create', otherwise release transaction ID is used
   * @param releaseNumber - if contract contains a release 
   * with the same release number, this call will return an appropriate message
   * @param quantity - if release quantity exceeds the total contract quantity,
   * this call will return an appropriate message
   */
  public validateRelease(transactionId: string, releaseNumber: string, quantity: string, action: 'create' | 'update') {
    const path = action === 'create' ? `Contracts/validateRelease` : `Release/validateReleaseDataByTransId`;
    const params = {
      releaseNum: releaseNumber.trim(),
      quantity,
    };
    if (action === 'create')
      params['pTrnsctnID'] = transactionId;
    else if (action === 'update') {
      params['trnsctnId'] = transactionId;
    }
    return this._postrequest<{Message: string}>(path, null, params);
  }

  public getPricingManagerInfoByContractNumber(contractNumber: string) {
    const path = `Contracts/getContractDetailsByContractNo`;
    return this._getrequest<projectModels.PricingManagerInfoResponse>(path, {contractNumber});
  }


  /* CUSTOMER */
  public getCustomerCredit(customerId: string) {
    const path = `Customer/getCustomerCreditByCustId/${customerId}`;
    return this._getrequest<projectModels.CustomerCredit>(path, null, {noSpinner: 'noSpinner'}).pipe(
      catchError(err => EMPTY)
    );
  }

  /** Synchronizes the selected records of 
   * Customer Credit Master data with Agvance database
   * since the last refresh was performed.
   * 
   * Returns `true` if sync was successful
  */
  public syncCustomerCreditMaster(selectedRecords: string[]) {
    const path = `Customer/syncCustomerCreditLimitMasterData`;
    return this._postrequest<boolean>(path, selectedRecords);
  }


  /* DASHBOARD */
  public getLLCViewData(payload: projectModels.LLCViewPayload) {
    const path = `Dashboard/getLLCViewData`;
    return this._postrequest<projectModels.LLCViewResponse>(path, payload);
  }

  public getLLCViewFiscalYear() {
    const path = `Dashboard/getLLCViewFiscalYear`;
    return this._getrequest<projectModels.LLCFiscalYear>(path);
  }

  public getLLCViewIncomeStatementDetails(body: projectModels.IncomeStatementPayload) {
    const path = `Dashboard/getllcviewincomestatementdetails`;
    return this._postrequest<projectModels.IncomeStatementResponse>(path, body);
  }

  public llcViewExportToExcel(payload: projectModels.IncomeStatementPayload) {
    const path = `Dashboard/llcViewIncomeDetailsExport`;
    return this._postrequest(path, payload, null, 'Blob');
  }


  /* FPR */
  public getFPRQuantityData(fprNumber: string) {
    const path = `FertilizerPurchase/getReleaseFPRQuantityData`;
    return this._getrequest<
    {
      QuantityFulfilled: string,
      QuantityRemaining: string,      
      RemainingLoads: string,
      FulfilledLoads: string,
    }[]
    >(path, {fprNumber}, {noSpinner: 'noSpinner'}).pipe(
      map(res => res[0]),
      catchError(_ => of({
        QuantityFulfilled: '',
        QuantityRemaining: '',
        RemainingLoads: '',
        FulfilledLoads: '',
      })),
    );
  }

  public updateFPRQuantityMetrics(transactionId: string, form: FormGroup) {
    const path = `FertilizerPurchase/updateFPRQuantityMetrics`;
    const data = {
      NAG_LM_FV_FPR: form.get('NAG_LM_FV_FPR').value,
      NAG_LM_FV_LD_DT_Quantity: form.get('NAG_LM_FV_LD_DT_Quantity').value,
    }
    const payload = this.utility.generateUpdateJson(transactionId, data, 'Release_Manager');
    return this._postrequest<boolean>(path, payload);
  }

  public getFPRAssociatedContracts(transactionId: string, config: GridConfiguration) {
    const path = `FertilizerPurchase/getFPRAssociatedContracts`;
    return this._postrequest<GridResponse<any>>(path, config, {fprTrnsctnid: transactionId});
  }

  public getFPRDataForBulkUpdate(transactionId: string) {
    const path = `FertilizerPurchase/getFPRDataForBulkUpdate`;
    return this._getrequest<projectModels.FPRDataForBulkUpdate[]>(path, {trnsctnId: transactionId});
  }

  public updateFPREntryState(fprNumber: string) {
    const path = `FertilizerPurchase/updateFPRStateOnQuantityFulfilled`;
    return this._getrequest<boolean>(path, { fprNumber });
  }


  /* LOCATION */
  /** Fetches the full list of locations */
  public getLocations() {
    const path = `Location/getLocationData`;
    return this._getrequest<projectModels.LocationData[]>(path, null, {noSpinner: 'noSpinner'});
  }

  /* NOVUS MARGIN */
  public getDuplicateMarginRecordStatus(formValue: any) {
    const path = `NovusMargin/getDuplicateMarginRecordStatus`;
    const payload = {
      productID: formValue.NAG_MAR_FV_PID,
      marginType: formValue.NAG_MAR_FV_MDT_DT_MT,
      effectiveFrom: formValue.NAG_MAR_FV_MDT_DT_EF,
      effectiveTo: formValue.NAG_MAR_FV_MDT_DT_ET,
      timeZone: +this.auth.currentUserValue.TimeZone,
    };
    payload.effectiveFrom = payload.effectiveFrom ? payload.effectiveFrom.split(' ')[0] :payload.effectiveFrom;
    payload.effectiveTo = payload.effectiveTo ? payload.effectiveTo.split(' ')[0] :payload.effectiveTo;
    return this._postrequest<boolean>(path, payload);
  }

  /* PRICING */
  public deactivatePricingManagerEntriesState(transactionId: string) {
    const path = `Pricing/updatePricingManagerStateToInactive`;
    return this._postrequest<boolean>(path, null, {trnsctnId: transactionId});
  }

  /* PRODUCTS - NAG_Onboarded_Products */
  public createProductInstance(transactionIds: string[]) {
    const path = `Product/createProductInstances`;
    return this._postrequest<boolean>(path, transactionIds);
  }
  
  public deactivateProductMaster(transactionId: string) {
    const path = `Product/deactivateProductMaster/${transactionId}`;
    return this._postrequest<boolean>(path, null);
  }

  public changeIncentivesStateToAccruing(transactionId: string) {
    const path = `Product/changeIncentivesStateToAccruing/${transactionId}`;
    return this._postrequest<boolean>(path, null);
  }

  public getIncentiveSales(transactionId: string, config: GridConfiguration) {
    const path = `Product/getSalesData`;
    return this._postrequest<GridResponse<projectModels.IncentiveSale>>(path, config, {transactionId});
  }

  public updateIncentiveDiscountPerAcre(transactionId: string) {
    const path = `Product/updateIncentiveDiscountPerAcre/${transactionId}`;
    return this._postrequest<any>(path, null);
  }

  public getRelatedIncentives(transactionId: string, config: GridConfiguration) {
    const path = `Product/getRelatedIncentivesData/${transactionId}`;
    return this._postrequest<GridResponse<projectModels.RelatedIncentive>>(path, config);
  }

  public createRelatedIncentive(transactionId: string, data: any, dmos: any[]) {
    const path = `Product/saveDeleteRelatedIncentives/${transactionId}`;
    const sanitized = this.dmoControl.sanitizeFormValue(dmos, data);
    const payload = {
      relIncentiveID: '0',
      incentiveID: sanitized.NAG_INC_AV_IID,
      incentiveName: sanitized.NAG_INC_FV_ID_Name,
      offeredBy: sanitized.NAG_INC_AV_ID_De_OB,
      effectiveFrom: sanitized.NAG_INC_AV_ID_De_EF,
      effectiveTo: sanitized.NAG_INC_AV_ID_De_ET,
      discountPer: sanitized.NAG_INC_AV_ID_De_D,
      discountDol: sanitized.NAG_INC_AV_ID_De_DA,
      thresholdMet: sanitized.NAG_INC_FV_TMet,
      state: sanitized.WFOSDISPNAME,
      action: 'ADD',
    };
      
    return this._postrequest<number>(path, payload);

  }

  public deleteRelatedIncentive(transactionId: string, data: any) {
    const path = `Product/saveDeleteRelatedIncentives/${transactionId}`;
    const payload = {
      relIncentiveID: data.RelIncentiveID,
      action: 'DELETE',
    };
    return this._postrequest<boolean>(path, payload);
  }

  public updateRelatedIncentiveData(transactionId: string) {
    const path = `Product/updateRelatedIncentiveData/${transactionId}`;
    return this._postrequest<boolean>(path, null);
  }

  public distributorExists(formValue: any) {
    const path = `Product/checkDistributorExists`;
    const payload = {
      productCode: formValue.NAG_DCA_FV_PRID || '',
      distributorID: formValue.NAG_DCA_FV_LOCIDID || '',
      monthCostUpdate: formValue.NAG_DCA_FV_MFCU || '',
    };
    return this._postrequest<boolean>(path, payload);
  }

  public bulkUploadDistributorCost(processName: string, uploadFile: FormData) {
    const path = `Product/distributorCostBulkUpload`;
    return this._postrequest<any>(path, uploadFile, {processName});
  }

  public bulkUploadDistributor(uploadFile: FormData) {
    const path = `Product/distributorbulkupload`;
    return this._postrequest<any>(path, uploadFile);
  }

  /* PURCHASE ORDER */
  /** Fetch purchase order details from AgVance api */
  public getPODetails(poNumber: string) {
    const path = `PurchaseOrder/getPurchaseOrderDetails?poNumber=${poNumber}`;
    return this._getrequest<projectModels.PurchaseOrderAgvance>(path, null, {noSpinner: 'noSpinner'});
  }


  /* RELEASE */
  /** Sends a delivery ticket generated from the form
   * to the Agvance system
   * on "Create Delivery Ticket" trigger (NAG_WF_LM_Open_AIT)
   */
  public postDeliveryTicketToAgvance(form: FormGroup) {
    const path = `Release/postDeliveryTicketToAgvance`;
    const ticket: projectModels.DeliveryTicket = {
      TicketNumber: 0,
      LocationID: form.get('NAG_LM_AV_LC_Ldet_LID').value,
      TicketDate: new Date().toISOString().split('T')[0],
      GrowerID: '',
      TicketType: form.get('NAG_LM_FV_TT').value,
      ShipTo: '',
      TicketSplitAdd: [
        {
          CustomerID: form.get('NAG_LM_AV_LC_LDet_Op').value === 'Customer' ? form.get('NAG_LM_AV_LC_Cdet_CID').value : form.get('NAG_LM_AV_LC_RL_ID').value,
          SplitPercentage: 100,
        }
      ],
      TicketDetailAdd: [
        {
          DepartmentID: form.get('NAG_LM_AV_LC_Dept').value,
          ProductID: form.get('NAG_LM_AV_RD').value,
          Quantity: form.get('NAG_LM_AV_LD_PD_AP').value,
          UnitPrice: form.get('NAG_LM_AV_CD_PriceF').value==""? 0:form.get('NAG_LM_AV_CD_PriceF').value,
        }
      ],
    };
    return this._postrequest<projectModels.DeliveryTicketResponse>(path, ticket);
  }

  /** Sends a purchase receipt generated from the form
   * to the Agvance system
   * on "Transfer Inventory" trigger (NAG_WF_LM_TI_TI)
   * for Assigned Location
   * 
   * Returns a ticket number if successful
  */
  public createPurchaseReceiptForAssginedLocation(form: FormGroup) {
    const path = `Release/postPurchaseReceiptToAgvance`;
    const quantity = parseFloat(form.get('NAG_LM_AV_LD_PD_AP').value);
    const { TimeZone } = this.userDetail;
    const dateFormat = environment.Setting.dateFormat;
    const ticketDate = this.dmoControl.getUserDateTime(new Date().toISOString(), dateFormat, TimeZone * (-1));

    const receipt: projectModels.PurchaseReceipt = {
      VendorID: '500337',
      Shipdate: ticketDate,
      TicketNumber: form.get('NAG_LM_FV_LD_DT_Load_Num').value + '-T',
      FreightType: 'ED',
      FreightVendorID: form.get('NAG_LM_AV_PD_FVI').value,
      FreightTotalDollars: form.get('NAG_LM_AV_RD_PD_TF').value,
      UseAgvanceAddons: false,
      ReceiptDetail: [
        {
          DepartmentID: form.get('NAG_LM_AV_LC_Dept').value,
          ProductID: form.get('NAG_LM_AV_RD').value,
          ProductDescription: form.get('NAG_LM_AV_LD_DT_P').value,
          Quantity: quantity,
          Cost: form.get('NAG_LM_AV_LC_LDet_Price').value,
          PONumber: '',
          POLineItem: 0,
          // Lotnum: '1',
        },
      ],
    };
    return this._postrequest<projectModels.DeliveryTicketResponse>(path, receipt);
  }

  /** Sends a purchase receipt generated from the form
   * to the Agvance system
   * on "Transfer Inventory" trigger (`NAG_WF_LM_TI_TI`)
   * for Division Location (Negative quantity)
   * 
   * Returns a ticket number if successful
  */
  public createNegativePurchaseReceiptForDivisionLocation(form: FormGroup, parentData: any) {
    const path = `Release/postPurchaseReceiptDivLocToAgvance`;
    const quantity = parseFloat(form.get('NAG_LM_AV_LD_PD_AP').value);
    const { TimeZone } = this.userDetail;
    const dateFormat = environment.Setting.dateFormat;
    const ticketDate = this.dmoControl.getUserDateTime(new Date().toISOString(), dateFormat, TimeZone * (-1));
    const cost = parentData.nagscmavpopdcost.RLTYPDMOVAL;

    const receipt: projectModels.PurchaseReceipt = {
      VendorID: '500337',
      Shipdate: ticketDate,
      TicketNumber: form.get('NAG_LM_FV_LD_DT_Load_Num').value + '-F',
      FreightType: 'ED',
      FreightVendorID: '',
      FreightTotalDollars: 0,
      UseAgvanceAddons: form.get('NAG_FV_LM_RD_ChargeArea').value !== 'None',
      ReceiptDetail: [
        {
          DepartmentID: form.get('NAG_LM_AV_CD_Out').value,
          ProductID: form.get('NAG_LM_AV_RD').value,
          ProductDescription: form.get('NAG_LM_AV_LD_DT_P').value,
          Quantity: quantity * (-1),
          Cost: cost,
          PONumber: '',
          POLineItem: 0,
          // Lotnum: '0',
        },
      ],
      ReceiptAddOn: form.get('NAG_FV_LM_RD_ChargeArea').value !== 'None' ? [
        {
          Vendor: '500337',
          LineItem: '1',
          Rate: form.get('NAG_LM_AV_AO_R').value,
          CalculateAs: 'F',
          ApplyTo: 'A',
          ChargeId: form.get('NAG_LM_AV_AO_Charge').value,
          GlAccount: form.get('NAG_LM_AV_AO_GL').value,
        }
      ] : null
    };

    return this._postrequest<projectModels.DeliveryTicketResponse>(path, receipt);
  }
  
  /** Sends a purchase receipt generated from the form
   * to the Agvance system
   * on "Transfer Inventory" trigger (`NAG_WF_LM_TI_TI`)
   * for Division Location (Positive quantity)
   * 
   * Returns a ticket number if successful
  */
  public createPositivePurchaseReceiptForDivisionLocation(form: FormGroup, parentData: any) {
    const path = `Release/postPurchaseReceiptDivLocToAgvance`;
    const quantity = parseFloat(form.get('NAG_LM_AV_LD_PD_AP').value);
    const { TimeZone } = this.userDetail;
    const dateFormat = environment.Setting.dateFormat;
    const ticketDate = this.dmoControl.getUserDateTime(new Date().toISOString(), dateFormat, TimeZone * (-1));
    const cost = parentData.nagscmavpopdcost.RLTYPDMOVAL;

    const receipt: projectModels.PurchaseReceipt = {
      VendorID: parentData.nagscmavpopdven.RLTYPDMOVAL,
      Shipdate: ticketDate,
      TicketNumber: form.get('NAG_LM_FV_LD_DT_Load_Num').value,
      FreightType: 'ED',
      FreightVendorID: '',
      FreightTotalDollars: 0,
      UseAgvanceAddons: false,
      ReceiptDetail: [
        {
          DepartmentID: form.get('NAG_LM_AV_CD_Out').value,
          ProductID: form.get('NAG_LM_AV_RD').value,
          ProductDescription: form.get('NAG_LM_AV_LD_DT_P').value,
          Quantity: quantity,
          Cost: cost,
          PONumber: form.get('NAG_LM_AV_LD_CD_PO').value,
          POLineItem: 1,
          // Lotnum: '0',
        },
      ],
    };

    return this._postrequest<projectModels.DeliveryTicketResponse>(path, receipt);
  }

  public checkBulkUpdatePermission(transactionIds: string[], processName?: string) {
    processName =  processName || sessionStorage.getItem('processName');
    const payload: projectModels.BulkUpdateCheckPayload = {
      ProcessName: processName,
      TrnsctnIds: transactionIds,
      IsRecordSelect: false,
    };
    const path = `Release/releaseBulkUpdate`;
    return this._postrequest<any>(path, payload, {noSpinner: 'noSpinner'});
  }

  /** Updates customer credit in master table on two events: 
   * - Customer Assgined: @param triggerName === NAG_LM_OPEN_Cust_CA;
   *  ```customer available credit - (quantity * customer price)```
   * 
   * 
   * - Received: @param triggerName === NAG_LM_OPEN_Open_Del;
   *  ```customer available credit + (quantity * customer price)```
   * 
   * Returns `true` if successful
  */
  public updateCustomerCredit(transactionId: string, triggerName: string) {
    const path = `Release/updateCustCreditOnRelease/${transactionId}/${triggerName}`;
    return this._postrequest<boolean>(path, null);
  }

  /** Fetches Additional Fee value from Pricing Manager based on the 
   * @param payload:
   *- ProductID	         
    - VendorID	           
    - AssignedLocationID	 
    - ShipToDepartmentID	 
    - ShippingTerminalID	 
    - Region	             
    - ReleaseNumber	     
    - CustomerID	         
    - VendorContractNumber*/
  public getLocationPriceByParams(payload: projectModels.LocationPricePayload) {
    const path = `Release/getReleaseAdditionalFee`;
    return this._postrequest<{AdditionalFee: string}>(path, payload, {noSpinner: 'noSpinner'});
  }

  /** Updates the selected records and upon success
   * returns a response containing information about
   * releases that failed to be validated
   * and did not pass the credit check
  */
  public bulkUpdateReleases(payload: projectModels.BulkUpdateSavePayload, triggerName: string, processName?: string) {
    processName = processName || sessionStorage.getItem('processName');
    const path = `Release/releaseBulkUpdateSave`;
    return this._postrequest<projectModels.BulkUpdateSaveResponse>(path, payload, {processName, triggerName});
  }

  public revertReleaseToPrevState(transactionId: string) {
    const path = `Release/resetReleaseDataOnRevert`;
    return this._postrequest<boolean>(path, null, {trnsctnId: transactionId});
  }

  public createRelease(form: FormGroup, payload: UpdateJSON) {
    payload.IsBulkUpload = true;
    payload = {
      ...(payload as any),
      IsBulkUpload: true,
      releaseNumberDetails: {
        Start: form.get('NAG_LM_FV_LD_RN_S').value,
        Increment: +form.get('NAG_LM_FV_LD_RN_I').value || 0,
        Count: +form.get('NAG_LM_FV_LD_RN_Ct').value || 0,
      }
    }
    const path = `Release/insertReleaseApplication`;
    return this._postrequest<any>(path, payload);
  }

  /** 
   * @param transactionId  == Contract transaction id 
   * 
   * Called any time when Pull Start date or Pull end date are changed
  */
  public updateReleasesDatesByContract(transactionId: string) {
    const path = `Release/updateReleaseDateByContract`;
    return this._postrequest<boolean>(path, null, {trnsctnId: transactionId});
  }


  /* VENDOR */
  /** Fetches Available credit limit
   * 
   * Returns `0` for invalid or non-existent vendor ids
   */
  public getVendorAvailableCreditLimit(vendorID: string) {
    const path = `Vendor/getAvailableVendorCreditLimit`;
    return this._getrequest<any>(path, {vendorID}).pipe(
      map(response => response[0]['Available Credit Limit'] as number),
    );
  }

  /** Fetches the following contract details:
   * - Quantity Shipped
   * - Quantity Committed
   * - Quantity Exposed
  */
  public getReleaseQuantities(transactionId: string) {
    const path = `Vendor/getReleaseQuantityByState`;
    return this._getrequest<{
      QtyCommitted: number;
      QtyExposed: number;
      QtyShipped: number;
    }[]>(path, {pTrnsctnID: transactionId}, {noSpinner: 'noSpinner'})
      .pipe(map(response => response[0]));
  }

  /** 
   * Updates vendor's available credit limit on two events:
   * - Contract creation: triggerName === NAG_SCM_NEW_New_Create;
   * - PO Associated: triggerName === NAG_SCM_OPEN_Pending_PO;
   * - Contract close: triggerName === NAG_SCM_CLOSED_Closed_Cp;
   */
  public updateVendorAvailableCreditLimit(vendorId: string, prepay: number, triggerName: string, transactionId?: string) {
    const path = `Vendor/updateVendorAvailableCreditLimit`;
    const queryParams = { vendorId, triggerName, prepay, trnsctnId: transactionId };
    return this._postrequest<boolean>(path, null, queryParams);
  }

  public updateMarginProductDetails(transactionId: string) {
    const path = `Product/updatemarginproductdetails`;

    return this._postrequest(path, null, { transactionId: transactionId });
  }

  public updateVendorAvailableCreditLimitByContracts(transactionIds: string[]) {
    const path = `Vendor/updateVendorAvailableCreditByContract`;
    const body = {
      trnsctnIds: transactionIds,
      triggerName: 'NAG_SCM_CLOSED_Closed_Cp',
    };
    return this._postrequest(path, body);
  }


  /* USER */

  public getRoles(payload: projectModels.RoleGridConfig) {
    const path = `User/getRoleDetails`;
    return this._postrequest<projectModels.RoleGridResponse>(path, payload);
  }

  public toggleRoleStatus(roleID: string) {
    const path = `User/updateRoleStatus`;
    return this._postrequest(path, null, {roleID});
  }

  /** Fetches all users with a specified role */
  public getUsersByRole(roleName: string) {
    const path = `User/getUsersByRoleName`;
    return this._getrequest<{UserName: string, EmailAddress: string}[]>(path, {roleName})
      .pipe(map(roles => roles.filter(role => role.UserName !== 'nag_system_admin')));
  }

  /** Fetches user profile */
  public getUserProfile(UserName: string) {
    const path = `User/getUserDetails`;
    return this._postrequest<any>(path, { UserName }, {noSpinner: 'noSpinner'}).pipe(
      map(response => response.data.Users),
    );
  }

  /** Fetches data for Location Access app */
  public getUserLocations(config: GridConfiguration) {
    const path = `User/getUserLocationsData`;
    return this._postrequest<GridResponse<projectModels.UserLocation>>(path, config, {noSpinner: 'noSpinner'})
      .pipe(map(this._excludeDevAccountsFromResponse));
  }

  private _excludeDevAccountsFromResponse(res: GridResponse<projectModels.UserLocation>): GridResponse<projectModels.UserLocation> {
    const hiddenAccounts = environment.Setting.excludedAccounts;
    const records = res.Data;
    const updated = [];
    let count = 0;
    records.forEach(record => {
      const found = hiddenAccounts.find(userName => record.USERNAME === userName);
      if (!found)
        updated.push(record);
      else 
        count++;
    });
    return {
      ...res,
      Data: updated,
      RecordsCount: (+res.RecordsCount - count).toString(),
    }

  }

  public getUserLocation(usernames: string[]) {
    const config = this.utility.generateGridConfig({
      ProcessName: 'Location_Access',
      ColumnList: 'USERID,USERNAME,FIRSTNAME,LASTNAME,EMAILID,LOCATIONID',
    });
    const filter = this.utility.generateGridFilter('Column_Filter', 'USERNAME');

    filter.GridConditions = usernames
      .map(username => this.utility
      .generateGridCondition('EQUAL', username));
      
    config.GridFilters.push(filter);
    return this.getUserLocations(config).pipe(
      map(response => response.Data),
    );
  }

  /** Fetches all users from Location Access based on Location id */
  public getUsersByLocationId(locationId: string) {
    const config = this.utility.generateGridConfig({
      ProcessName: 'Location_Access',
      ColumnList: 'USERID,USERNAME,FIRSTNAME,LASTNAME,EMAILID,LOCATIONID',
    });
    config.GridFilters.push(this.utility.generateGridFilter('Column_Filter', 'LOCATIONID', 'CONTAINS', locationId));
    return this.getUserLocations(config).pipe(
      map(response => response.Data),
    );
  }

  public getNovusLocations(): Observable<string[]> {
    const userName = this.auth.currentUserValue.UserName;
    const path = `User/getNovusLocationsByUserId/${userName}`;
    return this._getrequest<any>(path).pipe(map(res => res.UserLocations))
  }

  /** Saves multiple location ids as a string */
  public saveUserLocations(UserID: string, LocationIDs: string) {
    const path = `User/saveUserLocationsData`;
    return this._postrequest<boolean>(path, { UserID, LocationIDs } );
  }


  // a temporary solution which will be improved once the base functionality is confirmed
  public tempGRIDCONFIGforLOCATIONACCESS() {
    return {
      "ViewName": "View 1",
      "IsDefaultView": true,
      "IdentityField": "USERNAME",
      "Columns": {
        "USERID": {
          "DisplayName": "User Id",
          "Type": "TextBox"
        },
        "USERNAME": {
          "DisplayName": "Username",
          "Type": "TextBox"
        },
        "FIRSTNAME": {
          "DisplayName": "First Name",
          "Type": "TextBox"
        },
        "LASTNAME": {
          "DisplayName": "Last Name",
          "Type": "TextBox"
        },
        "EMAILID": {
          "DisplayName": "Email",
          "Type": "TextBox"
        },
        "LOCATIONID": {
          "DisplayName": "Location Id",
          "Type": "DropDownList"
        },
        
      },
      "ColumnList": "USERID,USERNAME,FIRSTNAME,LASTNAME,EMAILID,LOCATIONID",
      "SortColumn": "",
      "SortColumnCaption": "Select...",
      "SortDirection": "",
      "SortDirectionCaption": "Select...",
      "PageSize": 10,
      "DMOFilters": [],
      "StateFilters": [],
      "StageFilters": [],
      "CustomFilters": {},
      "DetailViewMode": "ShowInPopUp",
      "OldViewName": "View 1"
    }
  }

  public deleteUserDownstreamRecords(appName: string, transactionIds: string) {
    const path = `User/deleteUserDownstreamRecord`;
    return this._postrequest<any>(path, null, {appName, transactionIds});
  }

  /** Fetches the list of columns for users grid */
  public getUsersGridColumns() {
    const path = `User/getUserColumns`;
    return this._postrequest<{DisplayName: string, Name: string}[]>(path, null);
  }

  /** Exports the users grid data to excel or pdf */
  public exportUsersGridToFile(config: projectModels.UserGridExportPayload, type: 'pdf' | 'excel') {
    const path = `User/exportTo${type}`;
    return this._postrequest<any>(path, config, null, 'Blob');
  }


  /* UTILITY */
  /** Fetches an array of dmos to be updated in selected records on the grid.
   * @param processName is optional. If nothing is provided, 
   * process name from sessionStorage is picked up
   */
  public getBatchUpdateDetails(processName?: string) {
    const path = `Utility/getBatchUpdateDetails`;
    processName = processName || sessionStorage.getItem('processName');
    return this._getrequest<BaseDmo[]>(path, { processName });
  }

  public getDmoMappings(processName?: string, canvasType: string = 'AdminView', sort: boolean = true) {
    processName = processName || sessionStorage.getItem('processName');
    const path = `Utility/getDmo/${processName}`;
    return this._getrequest<any>(path, {CanvasType: canvasType, isSortByDMO: sort});
  }

  public getZoneExportData(exportData: any) {
    return this._postrequest<any>(`zone/getzoneexportdata`, exportData);
  }

  /** Export the grid data to indicated type and save it */
  public exportCustomAppToFile(config: any, type: 'pdf' | 'excel') {
    if (config.ProcessName === 'Supply_Chain_Manager')
      return this._exportContractsToFile(config, type);
    const path = type === 'pdf' ? `Utility/exportToPDF` : `Utility/exportToExcel`;
    const payload = {
      ProcessName: config.ProcessName,
      ColumnList: config.ColumnList,
      SortColumn: config.SortColumn || '-1',
      SortOrder: config.SortOrder || '-1',
      TimeZone: new Date().getTimezoneOffset(),
      GridFilters: config.GridFilters || [],
      TransactionIDs: config.TransactionIDs || '',
      TransactionID: config.TransactionID || '',
      UserIds: config.UserIds || '',
    };
    return this._postrequest<Blob>(path, payload, null, 'Blob')
  }

  public updateUserDownstreamRecords(processName: string, form: FormGroup, data?: any) {
    const path = data ? `User/UpdateUserDownstreamRecord` : `User/insertUserDownstreamRecord`;
    if (processName !== 'NVS_MD_RegionMstr' && DOWNSTREAM_APPS[processName]) {
      const setup = this._setupObjectToUpdateDownstreamRecords(processName, form.value, data);
      const params = data
      ?  {
          AppName: setup.masterArea,
          KeyValueCode: setup.dmoCode,
          PreviousValue: setup.prevParentCode,
          Currentvalue: setup.currentParentCode,
      }
      :  {
          downstreamAppName: setup.masterArea,
          downstreamEntity: setup.dmoCode
      };
      return this._postrequest<boolean>(path, null, params);
    }
    return EMPTY;
  }

  public updateDownstreamRecords(processName: string, form: FormGroup) {
    const path = `Utility/updateDownstreamRecords`;
    if (processName !== 'NVS_MD_STORAGE' && DOWNSTREAM_APPS[processName]) {
      const {masterArea, dmoCode, modifiedDmovalue} = this._setupObjectToUpdateDownstreamRecords(processName, form.value);
      if (dmoCode && modifiedDmovalue) {
        return this._postrequest<boolean>(path, null, {masterArea, dmoCode, modifiedDmovalue});
      }
    }
    return EMPTY;
  }
  
  private _setupObjectToUpdateDownstreamRecords(masterArea: string, form: any, data: any = {}) {
    let dmoCode = form[DOWNSTREAM_APPS[masterArea]['dmoCode']];
    let modifiedDmovalue = form[DOWNSTREAM_APPS[masterArea]['modifiedDmovalue']];
    const prevDmoValue = data[DOWNSTREAM_APPS[masterArea]['prevParentCode']];
    let prevParentCode = prevDmoValue ? (prevDmoValue.DMOVAL || '').split('~~~')[0] : '';
    const currDmoValue = form[DOWNSTREAM_APPS[masterArea].currentParentCode];
    let currentParentCode = currDmoValue ? currDmoValue.ddOptionKey : '';
    return { masterArea, dmoCode, modifiedDmovalue, prevParentCode, currentParentCode };
  }

  
  /* ZONE */
  public getZoneBulkUploadTemplate() {
    const path = `Zone/getZoneBulkUploadTemplate/Nag_Zone`;
    return this._postrequest<Blob>(path, null, null, 'Blob');
  }

  public bulkUploadZone(doc: FormData) {
    const path = `Zone/zoneebulkupload`;
    return this._postrequest(path, doc, {processName: 'NAG_Zone'});
  }

  /* BASE */
  private _getrequest<T>(path: string, parameters?: any, httpHeaders?: any) {
    const headers = this._setHeaders(httpHeaders);
    const params = this.api.setParams(parameters);
    const url = `${this._baseUrl}/${path}`;
    return this.http.get<T>(url, {headers, params});
  } 

  private _postrequest<T>(path: string, body: any, parameters?: any, responseType?: any) {
    const headers = this._setHeaders(parameters);
    const params = this.api.setParams(parameters);
    const url = `${this._baseUrl}/${path}`;
    return this.http.post<T>(url, body, {headers, params, responseType });
  }

  private _setHeaders(headers: any) {
    return new HttpHeaders(headers)
  }

  public checkBulkRevetPermission(transactionIds: string[], processName?: string) {
    processName =  processName || sessionStorage.getItem('processName');
    const payload: projectModels.BulkRevertCheckPayload = {
      ProcessName: processName,
      TrnsctnIds: transactionIds
    };
    const path = `Release/getreleasebulkrevertactive`;
    return this._postrequest<any>(path, payload, {noSpinner: 'noSpinner'});
  }

  public GetRleaseBulkRevertDMOS(transactionIds: string[], processName?: string) {
    processName =  processName || sessionStorage.getItem('processName');
    const payload: projectModels.BulkRevertCheckPayload = {
      ProcessName: processName,
      TrnsctnIds: transactionIds
    };
    const path = `Release/getreleasebulkrevertdmos`;
    return this._postrequest<any>(path, payload);
  }
 public bulkRevertReleases(payload: projectModels.BulkRevertSavePayload, triggerName: string, processName?: string) {
  processName = processName || sessionStorage.getItem('processName');
  const path = `Release/releasesreverttolocassign`;
  return this._postrequest<projectModels.BulkRevertSaveResponse>(path, payload, {processName, triggerName});
}

public GetAssociateProgramDmos(transactionIds: string[], processName?: string) {
  processName =  processName || sessionStorage.getItem('processName');
  const payload: projectModels.BulkRevertCheckPayload = {
    ProcessName: processName,
    TrnsctnIds: transactionIds
  };
  const path = `Product/getassociateprogramdmos`;
  return this._postrequest<any>(path, payload);
}

public AssociateProductToProgram(payload: projectModels.BulkRevertSavePayload,  processName?: string) {
  processName = processName || sessionStorage.getItem('processName');
  const path = `Product/productassociatetoprogram`;
  return this._postrequest<projectModels.AssociateProgramResponse>(path, payload, {processName});
}

  public GetAssignMarkupDmos(transactionIds: string[], processName?: string) {
    processName = processName || sessionStorage.getItem('processName');
    const payload: projectModels.BulkRevertCheckPayload = {
      ProcessName: processName,
      TrnsctnIds: transactionIds
    };
    const path = `Product/getassignmarkupdmos`;
    return this._postrequest<any>(path, payload);
  }

  public AssignProductToMarkup(payload: projectModels.BulkRevertSavePayload, processName?: string) {
    processName = processName || sessionStorage.getItem('processName');
    const path = `Product/productassigntomarkup`;
    return this._postrequest<projectModels.AssociateProgramResponse>(path, payload, { processName });
  }

  getInentiveColumns(ProcessName: string) {
    const path = `Product/getIncentiveDmo/${ProcessName}`;
    return this._getrequest<any>(path, {});
  }

  getIncentivEndPoint(ExportType: string): string {
    if (ExportType === 'excel') {
   return this._baseUrl + '/Product/exportToExcel';
    } else {
   return this._baseUrl + '/Product/exportToPDF';
    }
  }

  public getProductPricingGrid(transactionId: string) {    
    return this._postrequest<PricingGrid>(`Product/getProductDiscountedAnchor/${transactionId}`, null);        
  }

  getProgramInentiveColumns(ProcessName: string) {
    const path = `Product/getProgramIncentiveDmo/${ProcessName}`;
    return this._getrequest<any>(path, {});
  }

  updateProductMargins(transactionId: string) {
    return this._postrequest<boolean>(`Product/updateproductmargins`, null, { transactionId: transactionId });
  }

  getProgIncentivEndPoint(ExportType: string): string {
    if (ExportType === 'excel') {
   return this._baseUrl + '/Product/exportToExcelProgIcentive';
    } else {
   return this._baseUrl + '/Product/exportToPDFProgIcentive';
    }
  }

  getPricingGridEndPoint(ExportType: string): string {
    if (ExportType === 'excel') {
      return `${this._baseUrl}/Product/exportToExcelPricingGrid`;
    } else {
      return `${this._baseUrl}/Product/exportToPDFPricingGrid`;
    }
  }

  public syncNovusLocationMasterData() 
  {
    const path = `NovusLocation/syncnovuslocationdata`;
    return this._postrequest<boolean>(path, null, null);
  }

  public syncNovusProductMasterData() 
  {
    //const path = `NovusProduct/SyncNovusProductData`;
    const path = `NovusProduct/importnovusproductdata`;
    return this._postrequest<boolean>(path, null, {noSpinner: 'noSpinner'});
  }

  public syncNovusVendorMasterData() 
  {
    const path = `NovusVendor/syncnovusvendordata`;
    return this._postrequest<boolean>(path, null, {noSpinner: 'noSpinner'});
  }
  
  public saveProgramRule(programRuleMapping: any) {    
    const path = `Product/saveProgramRules`;
    return this._postrequest<projectModels.ProgramRuleResponse>(path, programRuleMapping);
  }

  public GetProgramRules(transactionId:string) { 
    const path = `Product/getProgramRules/${transactionId}`;
    return this._postrequest<any>(path, null, {headers: {noSpinner: 'true'}});
  }

  public DeleteProgramRules(transactionId:string) { 
    const path = `Product/deleteProgramRules/${transactionId}`;
    return this._postrequest<projectModels.ProgramRuleResponse>(path, null, {headers: {noSpinner: 'true'}});
  }

  public GetIncentiveCondRulesData(transactionId:string) { 
    const path = `Product/getProgIncConditionRules/${transactionId}`;
    return this._postrequest<any>(path, null, {headers: {noSpinner: 'true'}});
  }

  public SaveIncentiveConditionRules(IncentiveConditionRule: any) {    
    const path = `Product/saveProgIncentiveConditionRules`;
    return this._postrequest<projectModels.ProgramRuleResponse>(path, IncentiveConditionRule);
  }

  public DeleteProgIncConditionRules(transactionId:string, IncCondRuleId:string) { 
    const path = `Product/deleteProgIncConditionRules/${transactionId}/${IncCondRuleId}`;
    return this._postrequest<projectModels.ProgramRuleResponse>(path, null, {headers: {noSpinner: 'true'}});
  }

  public GetIncentiveConditionRules(transactionId:string) { 
    const path = `Product/getIncentiveConditionRules/${transactionId}`;
    return this._postrequest<any>(path, null, {headers: {noSpinner: 'true'}});
  }

  public saveIncentiveConditionRule(IncentiveConditionRule: any) {    
    const path = `Product/saveIncentiveConditionRule`;
    return this._postrequest<projectModels.ProgramRuleResponse>(path, IncentiveConditionRule);
  }

  public DeleteIncConditionRules(transactionId:string, IncCondRuleId:string) { 
    const path = `Product/deleteIncConditionRules/${transactionId}/${IncCondRuleId}`;
    return this._postrequest<projectModels.ProgramRuleResponse>(path, null, {headers: {noSpinner: 'true'}});
  }

  public syncProgramRules(transactionId:string) {
    const path = `Product/syncProdProgramRules/${transactionId}`;
    return this._postrequest<any>(path, null, {noSpinner: 'noSpinner'});
  }

  public syncProgramRulesCount(transactionId: string) {
    const path = `Product/syncProdProgramRulesCount/${transactionId}`;
    return this._getrequest<number>(path);
  }

  public getProductSyncInfo(transactionId: string) {
    const path = `Product/syncproductinfo/${transactionId}`;
    return this._getrequest<any>(path);
  }
  
  public bulkSaveIncentiveConditionRule(IncentiveConditionRule: any) {    
    const path = `Product/bulkSaveIncentiveConditionRule`;
    return this._postrequest<projectModels.ProgramRuleResponse>(path, IncentiveConditionRule);
  }

  public bulkDelIncentiveConditionRule(transactionId:string, IncCondRuleId:string) { 
    const path = `Product/bulkDelIncentiveConditionRule/${transactionId}/${IncCondRuleId}`;
    return this._postrequest<projectModels.ProgramRuleResponse>(path, null, {headers: {noSpinner: 'true'}});
  }

  public GetBulkIncentiveConditionRules(bulkUpdateUniqueID:string) { 
    const path = `Product/getBulkIncentiveConditionRules/${bulkUpdateUniqueID}`;
    return this._postrequest<any>(path, null, {headers: {noSpinner: 'true'}});
  }

  public BulkDeleteIncentiveConditionRule(IncentiveConditionRule: any) { 
    const path = `Product/bulkDeleteIncentiveConditionRule`;
    return this._postrequest<projectModels.ProgramRuleResponse>(path, IncentiveConditionRule, {headers: {noSpinner: 'true'}});
  }

  public syncNovusProfitCenterData() {
    const path = `NovusLocation/syncnovusprofitcenterdata`;
    return this._postrequest<boolean>(path, null, { noSpinner: 'noSpinner' });
  }

  ExportProductRecordsToExcel(userData: any) {
    return this._postrequest<Blob>(`Product/exportProductRecords`, userData, null, 'blob');
  }

  public bulkUploadProduct(formData: FormData, processName: string) {
    const url = `${this._baseUrl}/Product/productPricebulkupload`;
    return this.http.post(url, formData, { headers: { processName } });
  }

  public CopyProgramIncentiveCondition(sourceTrnsctnID: string, destTrnsctnID: string) {
    const url = `Product/copyProgramIncentiveCondition/${sourceTrnsctnID}/${destTrnsctnID}`;
    return this._postrequest<projectModels.ProgramRuleResponse>(url, null);
  }

  public syncVendorMasterData() 
  {
    const path = `Vendor/syncmanualvendorsdata`;
    return this._postrequest<boolean>(path, null, null);
  }

  public validateDistributor(data: any) {
    const url = `Product/validatedistributor`;
    return this._postrequest<boolean>(url, null, { vendorId: data.vendorId });
  }

  public updateProductPricingGrid(transactionIds: string[], params?: any) {
    const url = `Product/updateProductPricingGrid`;

    return this._postrequest<boolean>(url, transactionIds, params);
  }

  public batchUpdateProducts(data: any) {
    const url = `Product/batchupdateproducts`;

    return this._postrequest(url, data);
  }
}

export const DOWNSTREAM_APPS = {
  NVS_MD_RegionMstr: {dmoCode: 'DMOREGION_RegnCode', modifiedDmovalue: 'DMOREGION_RegnNam', prevParentCode: '', currentParentCode: ''},
  NVS_MD_SUBREGION: {dmoCode: 'DMOSRegion_SRegionCode', modifiedDmovalue: 'DMOSRegion_SRegionDscr', prevParentCode: 'dmosregionregion', currentParentCode: 'DMOSRegion_Region'},
  NVS_MD_TERRITORY: {dmoCode: 'DMOTERIRORY_TMCode', modifiedDmovalue: 'DMOTERIRORY_TMName', prevParentCode: 'dmoterirorytmsregion', currentParentCode: 'DMOTERIRORY_TMSRegion'},
  NVS_MD_PROFITCENTER: {dmoCode: 'DMOPFC_PFCCode', modifiedDmovalue: 'DMOPFC_PFCNam', prevParentCode: 'dmopfcpfctrty', currentParentCode: 'DMOPFC_PFCTRTY'},
  NVS_MD_Location: {dmoCode: 'DMOLCN_LMCode', modifiedDmovalue: 'DMOLCN_LMName', prevParentCode: 'dmolocationpfc', currentParentCode: 'DMOLOCATION_PFC'},
  NVS_MD_STORAGE: {dmoCode: 'DMOSTORAGE_SMCode', modifiedDmovalue: 'DMOSTORAGE_SMName', prevParentCode: 'dmostoragesmlcn', currentParentCode: 'DMOSTORAGE_SMLCN'},
}
