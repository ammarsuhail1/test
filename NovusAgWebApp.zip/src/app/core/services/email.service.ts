import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

import { Email } from '../models/email.model';
import { UserProfile } from '../models/user-profile.model';
import * as templates from '../templates';

import { environment } from '@env/environment';

@Injectable({providedIn: 'root'})
export class EmailService {

  private _url = `${environment.Setting.ProjectApiUrl}/Utility/mailLogNotification`;

  constructor( private http: HttpClient ) {}

  sendEmail(type: EmailType, to: string[], data?: any) {
    let emailBodyHtml: string;
    let emailSubect:string = type;
    if (type === 'Credit Limit Exceeded') {
      emailBodyHtml = templates.creditLimitExceeded(data);
    }

    const email: Email = {
      MailSubject: emailSubect,
      MailBody: emailBodyHtml,
      MailFrom: 'novus@c2m.net',
      MailTo: to,
      IsSMS: 0,
      TrnsctnId: 0,
    };

    if (type === 'Password Updated') {
      email.MailSubject = '';
      email.MailBody = '';
      email.MailFrom = '';
      email.MailKey = 'Update_Password';
      email.MailFrom = 'no-reply@email.plasmacomp.com';
      email.TradingName = '';
      return this.http.post(this._url, email, {headers: {accessToken: ''}});
      // return this.http.post(this._url, email, {headers: {accessToken: ''}});
    }

    return this.http.post(this._url, email);
  }

  private _setHeaders() {
    const accessToken = localStorage.getItem('AccessToken');
    return {
      headers: new HttpHeaders({accessToken})
    } 
  }


}

type EmailType =
| 'Account Suspended'
| 'Account Reactivated'
| 'Credit Limit Exceeded'
| 'Password Updated'