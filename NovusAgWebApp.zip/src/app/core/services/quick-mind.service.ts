import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { of, BehaviorSubject } from 'rxjs';
import { filter, map, debounceTime, distinctUntilChanged, switchMap, exhaustMap } from 'rxjs/operators';
import {ActivatedRoute} from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class QuickMindService {

  private processName: string;
  private _searchText = new BehaviorSubject<string>('');

  public updateSearchText(searchText: string) {
    this._searchText.next(searchText);
  }
  

  searchtxt: string;
  constructor(private api: ApiService, private route: ActivatedRoute) { 
    this.processName = this.route.snapshot.queryParamMap.get('from');
    sessionStorage.setItem('AppName', this.processName);
  }

  getQuickMindSearch() {
    return this._searchText.pipe(
      debounceTime(1000),
      distinctUntilChanged(),
      map(value => value.trim()),
      filter(value => value.length > 0),
      exhaustMap(value => {
        return this.api
        .get('quickmind/getsearchqmind?processName=' + this.processName + '&searchText=' + value)
      }),
    );
  }
  /**
   * add new reoced or updete existing record.
   * @param data data is a model for save or update on remote.
   * @param processName processName in which data you want to save.
   */
  AddOrUpdate(data, processName) {
    return this.api.post('quickmind/saveqmind?processName=' + processName, data);
  }
}
