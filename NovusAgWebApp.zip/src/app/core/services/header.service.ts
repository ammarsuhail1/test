import { Injectable, Output, EventEmitter } from '@angular/core';
import { ApiService } from './api.service';
import { Router, ActivationEnd, ActivatedRoute } from '@angular/router';
import { filter, tap, debounceTime, pluck, distinctUntilChanged, skipWhile, map } from 'rxjs/operators';
import {Subject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HeaderService {

  private _processName = new Subject<string>();
  Count: number;
  constructor(private api: ApiService, private router: Router, private route: ActivatedRoute) {
    this.router.events.pipe(
      filter(event => event instanceof ActivationEnd),
      tap((e: ActivationEnd) => this._updateProcessName(e)),
      debounceTime(300),
      pluck('snapshot', 'params', 'process_name'),
      filter(processName => !!processName),
      skipWhile(processName => processName === 'announcement'),
      distinctUntilChanged(),
      tap(processName => this.CheckNotificationCount(processName as string))
    ).toPromise();
   }

  @Output() change: EventEmitter<number> = new EventEmitter();

  get CountValue(): number {
    return parseInt(sessionStorage.getItem('NotificationCount'));
  }

  get processName() {
    return this._processName.asObservable();
  }

  private _updateProcessName(event: ActivationEnd) {
    const path = location.pathname.toLowerCase();
    if (path.includes('quickmindlist')) {
      this._processName.next('QuickMind');
    } else if (path.includes('announcement')) {
      this._processName.next('Annoucement');
    } else if (path.includes('users/roles')) {
      this._processName.next('Manage Role');
    } else if (path.includes('users/')) {
      this._processName.next('Manage Users');
    } else if (path.includes('process_control')) {
      this._processName.next(event.snapshot.params.process_name);
    }
  }

  CheckNotificationCount(processName?: string) {
    this.getNotificationCount(processName).subscribe(
      Result => {
        sessionStorage.setItem('NotificationCount', Result);
        this.Count = Result;
        this.change.emit(Result);
      }
    )
  }

  getNotificationCount(processName?: string) {
    return this.api.get('application/getAnnouncementNotificationCount?processName=' + processName);
  }

  getNotification(flag, pageFrom) {
    return this.api.get('application/getAnnouncements?processName=' + sessionStorage.AppName + '&flag=' + flag +
     '&pageSize=10&pageFrom=' + pageFrom).pipe(
       map(res => {
        return res.map(item => {
          const description = item.Description.replace(/<[^>]*(>|$)|&nbsp;|&zwnj;|&raquo;|&laquo;|&gt;/g, ' ');
          return {...item, Description: description};
        })
       }),
     );
  }
  readNotification(Key: string) {
    this.Count = this.Count - Key.split(',').length;
    sessionStorage.setItem('NotificationCount', this.Count.toString());
    return this.api.deleteGrid('application/markAsRead?processName=' + sessionStorage.AppName + '&announcementIDs=' + Key);
  }
}
