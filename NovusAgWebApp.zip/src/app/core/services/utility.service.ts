import { Injectable } from '@angular/core';
import { GridConfiguration, Condition, GridCondition, FilterType, GridFilter } from '..';
import { GridConfig, UpdateJSON, ConditionObject } from '../models';
import { UserDetail } from '@app/core/models/user-detail';

@Injectable({providedIn: 'root'})
export class UtilityService {
  constructor(private userDetail: UserDetail) {}

  public generateGridConfig(config: GridConfiguration): GridConfiguration {
    config.PageNumber = config.PageNumber || 0;
    config.PageSize = config.PageSize || 99;
    config.SortColumn = config.SortColumn || '-1';
    config.SortOrder = config.SortOrder || 'Asc';
    config.TimeZone = config.TimeZone || new Date().getTimezoneOffset();
    config.ViewName = config.ViewName || 'View 1';
    config.GridFilters = config.GridFilters || [];
    return config;
  }

  public generateGridCondition(condition: Condition, value: string): GridCondition {
    return {Condition: condition, ConditionValue: value}
  };

  public generateGridFilter(
    filterType: FilterType,
    dataField: string, 
    condition?: Condition, 
    conditionValue?: string,
    operator: 'And' | 'Or' = 'Or'): GridFilter {
    const filter: GridFilter = {
      DataField: dataField,
      LogicalOperator: operator,
      FilterType: filterType,
      GridConditions: []
    };
    if (condition && conditionValue) {
      filter.GridConditions.push(this.generateGridCondition(condition, conditionValue));
    };
    return filter;
  }

  public genereateConditionObject(obj: ConditionObject): ConditionObject {
    return {
      Name: obj.Name,
      IsEnable: obj.IsEnable !== null ? obj.IsEnable : true,
      IsVisible: obj.IsVisible !== null ? obj.IsVisible : true,
      IsRequired: obj.IsRequired !== null ? obj.IsRequired : true,
      isHideFromStageState: obj.isHideFromStageState !== null ? obj.isHideFromStageState : false,
      ...obj,
    }
  }

  public generateUpdateJson(
      transactionId: string, 
      data: {[key: string]: any},
      processName?: string,
      triggerName?: string,
    ): UpdateJSON {
    const { UserName } = this.userDetail;
    return {
      Identifier: {
        Name: null, 
        Value: null,
        TrnsctnID: transactionId,
      },
      ProcessName: processName || sessionStorage.getItem('processName'),
      StateType: 'Normal',
      TriggerName: triggerName || 'Save Data',
      UniqueConstraints: '',
      UserName,
      Data: [data]
    }
  }

  public generateGridSettings(set: GridConfig): GridConfig {
    return {
      ProcessName: set.ProcessName || '',
      ViewName: set.ViewName || '',
      GridGuid: set.GridGuid || 'MCompContainer',
      PageSize: set.PageSize || '10',
      PageNumber: set.PageNumber || '0',
      PageCount: set.PageCount || '0',
      ShowSelectAll: set.ShowSelectAll || false,
      TimeZone: set.TimeZone || new Date().getTimezoneOffset().toString(),
      ColumnList: set.ColumnList || '',
      LstGridFilter: set.LstGridFilter || [],
      HasGlobalSearch: set.HasGlobalSearch !== null ? set.HasGlobalSearch : true,
      LazyLoad: set.LazyLoad || false,
      IsSubProcess: set.IsSubProcess,
      HideDeleteActionIcon: set.HideDeleteActionIcon,
      HideDisplayName: set.HideDisplayName,
      ShowBulkUpdateButton: set.ShowBulkUpdateButton,
      ParentTransactionId: set.ParentTransactionId,
      ParentDmoValue: set.ParentDmoValue,
      ChildDmoGuid: set.ChildDmoGuid,
      CanAddNewRow: set.CanAddNewRow,
      TriggerName: set.TriggerName || '',
      DmoColumnName: set.DmoColumnName || '',
      IsOtherAPICall: set.IsOtherAPICall,
      IsDrillDown: set.IsDrillDown,
      SortColumn: set.SortColumn || '-1',
      SortOrder: set.SortOrder || '-1',
      Actions: this._setDefaultGridSettingActions(set),
      Visiblility: this._setDefaultGridSettingVisibility(set),
    }
  }

  private _setDefaultGridSettingActions(set: GridConfig) {
    const Actions = {};
    if (!set.Actions) {
      Actions['Delete'] = true;
      Actions['Edit'] = true;
      Actions['More'] = true;
      Actions['Select'] = true;
    } else {
      Actions['Delete'] = set.Actions.Delete !== null ? set.Actions.Delete : true;
      Actions['Edit'] = set.Actions.Edit !== null ? set.Actions.Edit : true;
      Actions['More'] = set.Actions.More !== null ? set.Actions.More : true;
      Actions['Select'] = set.Actions.Select !== null ? set.Actions.Select : true;
    }
    return Actions;
  }
  
  private _setDefaultGridSettingVisibility(set: GridConfig) {
    const Visiblility = {};
    if (!set.Visiblility) {
      Visiblility['StateFilters'] = true;
    } else {
      Visiblility['StateFilters'] = set.Visiblility.StateFilters !== null ? set.Visiblility.StateFilters : true;
    }
    return Visiblility;
  }

}
