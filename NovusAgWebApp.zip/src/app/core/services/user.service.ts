import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from '../models/user';
import { environment } from '@env/environment';
import { Observable, throwError } from 'rxjs';
import { retry, catchError, map } from 'rxjs/operators';
import { UserEntity } from '../models';
import {AuthenticationService} from './authentication.service';

@Injectable({ providedIn: 'root' })
export class UserService {
    constructor(
        private http: HttpClient,
        private auth: AuthenticationService,
    ) { }

    getAll() {
        return this.http.get<User[]>(`${environment.Setting["WFApiUrl"]}/users`);
    }

    getById(id: number) {
        return this.http.get(`${environment.Setting["WFApiUrl"]}/users/${id}`);
    }

    register(user: User) {
        return this.http.post(`${environment.Setting["WFApiUrl"]}/users/register`, user);
    }

    update(user: User) {
        return this.http.put(`${environment.Setting["WFApiUrl"]}/users/${user.UserId}`, user);
    }

    delete(id: number) {
        return this.http.delete(`${environment.Setting["WFApiUrl"]}/users/${id}`);
    }


    getDataByBody(url: string, data?: any): Observable<any> {
        const webUrl = `${environment.Setting["C2M_Console_API_URL"]}/${url}`;
        var body = JSON.stringify(data);
        return  this.http.post(webUrl, body,{ headers: new HttpHeaders({ 'Accept': 'application/json', 'Content-Type': 'application/json' }) }).pipe(retry(0), catchError(this.handleError));
    }

    AddUpdateUser(data?: UserEntity): Observable<any> {
        const webUrl = `${environment.Setting["ProjectApiUrl"]}/user/AddUser`;
        const httpAllOptions = { headers: new HttpHeaders({ "AccessToken":localStorage.getItem('AccessToken'),"Content-Type":"application/json" }) }
        return  this.http.post(webUrl,data,httpAllOptions).pipe(retry(0), catchError(this.handleError));
    }

    updateUserProfile(data?: any): Observable<any> {
        const webUrl = `${environment.Setting["ProjectApiUrl"]}/user/saveUserDetail`;
        const httpAllOptions = { headers: new HttpHeaders({ "AccessToken":localStorage.getItem('AccessToken'),"Content-Type":"application/json" }) }
        return  this.http.post(webUrl,data,httpAllOptions).pipe(retry(0), catchError(this.handleError));
    }

    async GetRoleList(url: string, data?: any) {
        const webUrl = `${environment.Setting["C2M_Console_API_URL"]}/${url}`;
        var body = JSON.stringify(data);
        return await  this.http.post(webUrl, body,{ headers: new HttpHeaders({ 'Accept': 'application/json', 'Content-Type': 'application/json' }) }).toPromise().catch(this.handleError);
    }

    public getUserRoles() {
        const url = `${environment.Setting.C2M_Console_API_URL}/getRoleList`;
        const body = {
            AccessToken: this.auth.currentUserValue.token,
            PolicyBundleId: '1',
            UserId: this.auth.currentUserValue.UserId,
        };
        return this.http.post<any>(url, body).pipe(
            map(res => {
                if (res.code === '200' && res.data.UserRoleInfo.PolicyInfo) {
                    return res.data.UserRoleInfo.PolicyInfo.map(role => ({item_id: role.item_id, item_text: role.item_text['#cdata-section']}))
                }
                return []
            }),
        );
    }

    public getUserProfile(userName: string): Observable<any> {
        const url = `${environment.Setting["ProjectApiUrl"]}/user/GetUserDetails`;
        return this.http.post(url,{UserName: userName}).pipe(catchError(this.handleError));
    }

    // GetUserDetails(url: string,data?: any): Observable<any> {
    //     const webUrl = `${environment.Setting["ProjectApiUrl"]}/${url}`;
    //     const body=JSON.stringify(data);
    //     const httpAllOptions = { headers: new HttpHeaders({ "AccessToken":localStorage.getItem('AccessToken'),"Content-Type":"application/json" }) }
    //     return this.http.post(webUrl,body,httpAllOptions).pipe(retry(0), catchError(this.handleError));
    // }

    async GetDropdownDetails(url: string) {
        const webUrl = `${environment.Setting["ProjectApiUrl"]}/${url}`;
        const httpAllOptions = { headers: new HttpHeaders({ "AccessToken":localStorage.getItem('AccessToken'),"Content-Type":"application/json" }) }
        return await this.http.post(webUrl,null,httpAllOptions).toPromise().catch(this.handleError);
    }

    async UploadFile(url: string, formData: FormData) {
        const webUrl = `${environment.Setting["C2M_Console_API_URL"]}/${url}`;
        return await this.http.post(webUrl, formData).pipe(retry(0), catchError(this.handleError)).toPromise();
    }
    async getCascadingDropdown(bodyData?: any)  {
        const webUrl = `${environment.Setting["WFApiUrl"]}/${"listview/getprocessdata"}`;
        const body=JSON.stringify(bodyData);
        const httpAllOptions = { headers: new HttpHeaders({ "AccessToken":localStorage.getItem('AccessToken'),"Content-Type":"application/json",'Accept': 'application/json', }) }
        return await this.http.post(webUrl, body,httpAllOptions).toPromise().catch(this.handleError);
    }
    handleError(error) {
        let errorMessage = '';
        if (error.error instanceof ErrorEvent) {
            //client side error
            errorMessage = `Error: ${error.error.message}`;
        }
        else {
            // server-side error
            errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        }

        return throwError(errorMessage);
    }
}
