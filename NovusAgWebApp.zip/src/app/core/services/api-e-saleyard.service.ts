import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { environment } from '@env/environment';
import { catchError, retry } from 'rxjs/operators';
import { UserDetail } from '@app/core/models/user-detail';

@Injectable({
  providedIn: 'root'
})
export class ApiESaleyardService {

  endpoint = environment.Setting.ProjectApiUrl;
  endpointC2m = environment.Setting.C2M_Console_API_URL;
  constructor(private http: HttpClient, 
              private userDetail: UserDetail) { }

  setHeaders() {
    const accessToken = localStorage.getItem('AccessToken');
    const processName = sessionStorage.getItem('AppName');
    let headers;
    if (processName) {
      headers = new HttpHeaders({ accessToken, processName });
    } else {
      headers = new HttpHeaders({ accessToken });
    }
    return headers;
  }

  settingHeaders(head) {
    const accessToken = localStorage.getItem('AccessToken');
    let headers = new HttpHeaders({ accesstoken: accessToken});
    if (head) {
      for (const i in head) {
        if (head[i] != null) {
          headers = headers.append(i, head[i]);
        }
      }
    }
    return headers;
  }

  setParams(parameters) {
    let params = new HttpParams();
    if (parameters) {
      for (const i in parameters) {
        if (parameters[i] != null) {
          params = params.append(i, parameters[i]);
        }
      }
    }
    return params;
  }

  get(url: string, parameters?: any): Observable<any> {
    const headers = this.setHeaders();
    const params = this.setParams(parameters);

    return this.http.get<any>(`${this.endpoint}/${url}`, { headers, params });
  }

  post(url: string, data?: any, parameters?: any): Observable<any> {
    const headers = this.setHeaders();
    const params = this.setParams(parameters);
    return this.http.post<any>(`${this.endpoint}/${url}`, data, { headers, params });
  }

  postUserDelete(url: string, user, apiEndpoint): Observable<any> {
    // const accessToken = localStorage.getItem('AccessToken');
    // const headers = new HttpHeaders({ AccessToken: accessToken, username: user });
    // const params = this.setParams(parameters);
    // return this.http.post<any>(`${this.endpointC2m}/${url}`, null, { headers, params });

   // const accessToken = localStorage.getItem('AccessToken');
    const headers = new HttpHeaders({username: user, apiEndpoint:apiEndpoint });    
    return this.http.post<any>(`${this.endpoint}/${url}`,{body:null}, { headers });
  }
  postWithHeader(url: string, UserName, Status): Observable<any> {
    const AccessToken = this.userDetail.token;
    return this.http.post<any>(`${this.endpointC2m}/${url}`, { AccessToken, UserName, Status }, {});
  }
  postGetFile(url: string, data: any, resultType: any): Observable<any> {
    const Headers = this.setHeaders();
    return this.http.post<any>(`${this.endpoint}/${url}`, data, { headers: Headers, responseType: resultType });
  }
  delete(url: string, objectId: string): Observable<any> {
    const headers = this.setHeaders();
    if (objectId === null) {
      return this.http.delete(`${this.endpoint}/${url}`, { headers });
    } else {
      return this.http.delete(`${this.endpoint}/${url}/${objectId}`, { headers });
    }
  }
  UploadFile(url: string, formData: FormData): Observable<any> {
    const Headers = this.setHeaders();
    return this.http.post<any>(`${this.endpoint}/${url}`, formData, { headers: Headers });
  }

 //add by sanju  on 11-Nov-2019
  postC2M(url: string, data?: any): Observable<any> {
    const weburl=`${this.endpointC2m}/${url}`;
    var body = JSON.stringify(data);
    return this.http.post(weburl, body,{ headers: new HttpHeaders({ 'Accept': 'application/json', 'Content-Type': 'application/json' }) }).pipe(retry(0), catchError(this.handleError));
  }

   //add by sanju  on 11-Nov-2019
  async GetExportData(url: string, data?: any) {
    const weburl=`${this.endpointC2m}/${url}`;
    var body = JSON.stringify(data);
    return await  this.http.post(weburl, body,{ headers: new HttpHeaders({ 'Accept': 'application/json', 'Content-Type': 'application/json' }) }).toPromise().catch(this.handleError);
  }


  handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
        //client side error
        errorMessage = `Error: ${error.error.message}`;
    }
    else {
        // server-side error
        errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
    }
    //window.alert(errorMessage);
    return throwError(errorMessage);
}

}
