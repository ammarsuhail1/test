import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { User } from '../models/user';
import { environment } from '@env/environment';
import { ApiService } from './api.service';
import { UserDetail } from '../models/user-detail';
import { MessageService } from './message.service';
import { AlternateUser } from '..';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    private currentUserSubject: BehaviorSubject<User>;
    public currentUser: Observable<User>; 
    
    private _alternateUsers: BehaviorSubject<AlternateUser[]> = new BehaviorSubject([]);

    constructor(private http: HttpClient, private msg: MessageService, private api: ApiService,) {
        //this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
       // this.currentUser = this.currentUserSubject.asObservable();       
       
       const AccessToken = localStorage.getItem('AccessToken');
       if (AccessToken) {
           const aToken = AccessToken.split('.');
           if (aToken.length > 1) {
               const currentuserDetail = new UserDetail();
               this.currentUserSubject = new BehaviorSubject<User>(currentuserDetail);
               this.currentUser = this.currentUserSubject.asObservable();
           } else {
               this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
               this.currentUser = this.currentUserSubject.asObservable();
           }
           this.getAlternateUsers().subscribe();
       } else {
           this.logout();
       }      
    }

    public get currentUserValue(): User {
        return this.currentUserSubject.value;
    }

    get alternateUsers$() {
        return this._alternateUsers.asObservable();
    }

    login(username: string, password: string) {
        const httpHeader = new HttpHeaders({ UserName: username, Password: password });
        const objHttpHeader = { headers: httpHeader };
        
        return this.http.post<any>(environment.Setting.ProjectApiUrl+"/User/Token", {}, objHttpHeader)
            .pipe(
                map(res => {
                    if (res && res.accessToken) {
                        // store user details and jwt token in local storage to keep user logged in between page refreshes
                        const aToken = res.accessToken.split('.');
                        const userDetail = JSON.parse(atob(aToken[1]));
                        const offset = new Date().getTimezoneOffset();
                        const currentUser =JSON.parse(userDetail.User);
                        currentUser.TimeZone = offset;
                        userDetail.User = JSON.stringify(currentUser);
                        localStorage.setItem('AccessToken', res.accessToken);                                     
                        this.currentUserSubject.next(new UserDetail());
                        return true;
                    }
                    else if (res && res.AcessToken && res.User  && res.User.Message === undefined) { // To handle V1 version 
                        // store user details and jwt token in local storage to keep user logged in between page refreshes
                    
                        const offset = new Date().getTimezoneOffset();
                        res.User.TimeZone = offset;
                        const Role = res.User.Roles.join(',');
                        res.User.Roles = Role;
                        localStorage.setItem('currentUser', JSON.stringify(res.User));
                        localStorage.setItem('AccessToken', res.AcessToken);                                      
                        this.currentUserSubject.next(res.User);
                        return true;
                    }
                    else if (res && res[0] !== undefined && res[0].ISLOCKEDOUT === true) {
                        this.msg.showMessage('Fail', { body: 'Your account is locked due to entering the wrong password three times. Please check your email.' });
                        return false;
                    }
                    else if (res && res.User.Message) {
                        this.msg.showMessage('Fail', { body: 'Your account is locked due to entering the wrong password three times. Please check your email.' });
                        return false;
                    }
                }),
                tap(loggedIn => {
                    if (loggedIn) {
                        this.getAlternateUsers().subscribe();
                    }
                })
            );
    }

    private getAlternateUsers() {
        const url = `${environment.Setting.ProjectApiUrl}/user/getOutOfOfficeUserDetail`;
        return this.http.get<{OutOfOfficeUsers: AlternateUser[]}>(url).pipe(
            map(res => res.OutOfOfficeUsers),
            tap(users => this._alternateUsers.next(users)),
        );
    }

    getUserProfile(data: any) {
        //return this.api.user_post('GetUserProfile', data);
        const headers = 'api/GetUserProfile';
        return this.api.post_ice('user/icewebapi', data,headers);
    }

    sendCodeForResetPassword(data: any) {
        //return this.api.user_post('SendCodeForResetPassword', data);
        const headers = 'api/SendCodeForResetPassword';
        return this.api.post_ice('user/icewebapifpwd', data, headers);
    }

    resetPasswordByCode(data: any) {
        const headers = 'api/ResetPasswordByCode';
        //return this.api.post_ice('user/icewebapi', data, headers);
        return this.api.post_ice('user/icewebapifpwd', data, headers);
        //return this.api.user_post('ResetPasswordByCode', data);
    }

    updatePassword(currentPassword: string, newPassword: string,emailAddress:string) {        
        const data = {
          EmailAddress: emailAddress,
          Password: currentPassword,
          NewPassword: newPassword,
          AccessToken: this.currentUserSubject.value.token //localStorage.getItem('AccessToken')
        }
        return this.api.user_post('ChangeAccountPassword', data).toPromise();
    }

    logout() {
        // remove user from local storage to log user out
        localStorage.clear();
        sessionStorage.clear();
        if(this.currentUserSubject == undefined) {
            this.currentUserSubject = new BehaviorSubject<User>(null);
            this.currentUser = this.currentUserSubject.asObservable();
        }
        this.currentUserSubject.next(null);
        this._alternateUsers.next([]);
    }
}
