import { Injectable } from '@angular/core';
import { AbstractControl, FormArray } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { CurrencyPipe, formatCurrency, formatPercent } from '@angular/common';

import {  Observable, of, EMPTY, BehaviorSubject, forkJoin } from 'rxjs';
import { map, debounceTime, distinctUntilChanged, filter, catchError, withLatestFrom, tap, switchMap, first } from 'rxjs/operators';

import { DmoControlService } from './dmo-control.service';
import { NgbDateFRParserFormatter } from './ngb-date-fr-parser-formatter';
import { NovusService } from './novus.service';
import { UtilityService } from './utility.service';

import { environment } from '@env/environment';
import { Condition, GridCondition, FilterType, GridFilter, GridConfiguration, GridResponse, SearchResponse} from '..';
import { VCLMItem, CCLMItem, InventoryItem, PurchaseOrderMaster, UserLocation } from '../models/project';
import { DmoType } from '../models/dmos';
import { AlternateUser, User } from '../models';
import { UserDetail } from '@app/core/models/user-detail';
import { AuthenticationService } from './authentication.service';


const CALCULATION_DEBOUNCE = 300;
const SEARCH_INPUT_DEBOUNCE = 1000;
const DROPDOWN_DEBOUNCE = 0;

@Injectable({providedIn: 'root'})
export class SearchService {
  private _timezone = new Date().getTimezoneOffset();
  private _locationAdmins = new BehaviorSubject<Array<{UserName: string, EmailAddress: string}>>([]);

  constructor(
    private http: HttpClient,
    private dcs: DmoControlService,
    private ngbDate: NgbDateFRParserFormatter,
    private currency: CurrencyPipe,
    private novus: NovusService,
    private utility: UtilityService,
    private user: UserDetail,
    private auth: AuthenticationService,
    ) {
      this.novus.getUsersByRole('NAG_Location_Admin').subscribe(res => this._locationAdmins.next(res))
  }

  public getCustomerCreditStatusByCustomerId(customerId: string) {
    const config = this.utility.generateGridConfig({
      ColumnList: 'nagccmavdtdtstatus',
      ProcessName: 'Customer_Credit_Master',
    });
    config.GridFilters.push(this.utility.generateGridFilter('Column_Filter', 'nagccmavdtdtcid', 'EQUAL', customerId));
    return this._request<{nagccmavdtdtstatus: string}>(config);
  }

  public getPricingManagerEntriesByContractNumber(contractNumber: string) {
    const config = this.utility.generateGridConfig({
      ProcessName: 'Customer_Product_Manager',
      ColumnList: 'nagcpafvvcn'
    });
    config.GridFilters.push(this.utility.generateGridFilter('Column_Filter', 'nagcpafvvcn', 'EQUAL', contractNumber));
    return this._request<any>(config).pipe(
      map(response => response.Data)
    );
  }
  
  public getDepartmentIdByLocationId(id: string) {
    const config = this.utility.generateGridConfig({
      ProcessName: 'Address_Master',
      ColumnList: 'nagbmadravdtdeptid',
      SortColumn: 'nagbmadravdtdeptid',
      PageSize: -1,
      IsColumnListOnly: true,
      IsDistinct: true,
    });
    config.GridFilters.push(this._generateGridFilter('Column_Filter', 'nagbmadravdtlocid', 'EQUAL', id));
    return this._request<{nagbmadravdtdeptid: string}>(config).pipe(
      map(response => response.Data.map(item => item.nagbmadravdtdeptid)),
    );
  }

  /** Fetches Department IDs from Departments (Address Master) based on
   *  @param productId
   *  @param locationId
   */
  getDepartmentIdsFromDepartments(productId: string, locationId: string) {
    const config = this._generateGridConfig({
      ProcessName: 'Address_Master',
      ColumnList: 'nagbmadravdtdeptid',
      SortColumn: 'nagbmadravdtdeptid',
      IsColumnListOnly: true,
      IsDistinct: true,
      PageSize: -1,
    });
    const productIdFilter = this._generateGridFilter('Column_Filter', 'nagbmadravdtprodid', 'EQUAL', productId);
    const locationIdFilter = this._generateGridFilter('Column_Filter', 'nagbmadravdtlocid', 'EQUAL', locationId);
    config.GridFilters = [productIdFilter, locationIdFilter];
    return this._request<{nagbmadravdtdeptid: string}>(config).pipe(
      map(response => response.Data.map(item => item.nagbmadravdtdeptid))
    );
  }

  public getFPRRecordsByFPRNumber(number: string) {
    const config = this.utility.generateGridConfig({
      ColumnList: 'nagfprfvfpdtfid',
      ProcessName: 'Fertilizer_Purchase_Request_Manager',
    });
    config.GridFilters.push(this.utility.generateGridFilter('Column_Filter', 'nagfprfvfpdtfid', 'EQUAL', number));
    return this._request<any>(config);
  }

  getReleaseNumbersByContractNumber(contractNumber: string) {
    const config = this.utility.generateGridConfig({
      ProcessName: 'Release_Manager',
      ColumnList: 'naglmfvlddtloadnum',
    });
    const filter = this.utility.generateGridFilter('Column_Filter', 'naglmavldcdcn', 'EQUAL', contractNumber);
    config.GridFilters.push(filter);
    return this._request<{naglmfvlddtloadnum: string}>(config).pipe(
      map(data => data.Data.map(entry => entry.naglmfvlddtloadnum)),
    )
  }

  /** Fetches Location details from Inventory Department (Departments_Master)
   * based on the Department Id: 
   * - Address (Street)
   * - City/State
   * - Zip
  */
  public getInventoryDepartmentDetailsByDepartmentId(id: string) {
    const config = this._generateGridConfig({
      ProcessName: 'Departments_Master',
      ColumnList: 'dpfvdeptdetadd,dpfvdeptdetcs,dpfvdeptdetzip',
    });
    config.GridFilters.push(this._generateGridFilter('Column_Filter', 'dpfvdeptdetdid', 'EQUAL', id));
    return this._request<any>(config).pipe(
      map(response => response.Data[0]),
    )
  }
  

  public getPurchaseOrderDetails(number: string) {
    const config = this._generateGridConfig({
      ProcessName: 'Purchase_Order',
      ColumnList: COLUMN_LIST.purchaseOrderDetails.toString(),
    });
    config.GridFilters.push(this._generateGridFilter('Column_Filter', 'nagpomavdtdtponum', 'EQUAL', number));
    return this._request<PurchaseOrderMaster>(config).pipe(
      map(response => response.Data[0]),
    );
  }

  public getBookingIdsOnProductChange(product: string) {
    const config = this._generateGridConfig({
      ProcessName: 'Bookings_Manager',
      ColumnList: 'nagbmavdtdtbookguid,nagbmavdtdtprod',
      PageSize: -1,
      SortColumn: 'nagbmavdtdtbookguid'
    });
    config.GridFilters.push(this._generateGridFilter('Column_Filter', 'nagbmavdtdtprod', 'EQUAL', product));
    return this._request<any>(config).pipe(
      map(response => response.Data.map(booking => booking.nagbmavdtdtbookguid)),
    );
  }


  public locationBasedFilter(processName?: string, dmoGuid?: string) {
    processName = processName || sessionStorage.getItem('processName');
    if (!dmoGuid) {
      if (processName === 'Fertilizer_Purchase_Request_Manager')
        dmoGuid =  'nagfprfvfpdtlnum';
      else if (processName === 'Supply_Chain_Manager')
        dmoGuid = 'nagscmfvlocid';
      else if (processName === 'Release_Manager')
        dmoGuid = 'naglmavlcldetlid';
      else if (processName === 'Bookings_Manager') 
        dmoGuid = 'nagbmavdtdtbookloc'
    }
    const { UserName } = this.user;
    return this.auth.alternateUsers$.pipe(
      first(),
      map(users => [...users.map(user => user.OutOfOfficeUserName), UserName]),
      switchMap(usernames => this.novus.getUserLocation(usernames)),
      withLatestFrom(this.auth.alternateUsers$),
      map(([locations, altUsers]) => {
        
        //if (processName === 'Supply_Chain_Manager' && this.user.hasRole('nagsystemadmin') && this.user.hasRole('nagdivisionadmin')) {
        //if(this.user.hasRole('nagsystemadmin') || this.user.hasRole('nagfertilizermanager'))
        if(processName === 'Supply_Chain_Manager'){          
          if (!this.user.hasRole('nagfertilizermanager') && this.user.hasRole('nagdivisionadmin')) {
            const mainUserLocations = locations.find(location => location.USERNAME === UserName);
            const parsedLocations = this._parseUserLocations(mainUserLocations);
            return this._customizedFilterForFertilizerAdminsInContractsApp(parsedLocations, altUsers);
          }
        }
        
        const parsedLocations = locations.map(location => this._parseUserLocations(location));
        const allLocations = Array.from(new Set(parsedLocations.flat(1)));
        const filter = this.utility.generateGridFilter('Column_Filter', dmoGuid);
        const conditions = allLocations.map(location => this.utility.generateGridCondition('CONTAINS', location));
        filter.GridConditions = conditions;
        return filter;
      }),
    );
  }

  public locationBasedFilterForProductApps(processName: string) {
    const dmoGuid = LOCATION_FILTER_DATA[processName]; 
    if (!dmoGuid) {
      return of(null);
    }

    return this.auth.alternateUsers$.pipe(
      first(),
      map(users => users.map(user => user.OutOfOfficeUserName)),
      switchMap(usernames => {
        if (usernames.length > 0) {
          return forkJoin([this.novus.getUserLocation(usernames), this.novus.getNovusLocations()])
        }
        return forkJoin([of([]), this.novus.getNovusLocations()])
      }),
      map(([altUsers, locations]) => {
        const altUsersLocations = altUsers.map(loc => this._parseUserLocations(loc));
        const allLocations = Array.from(new Set(altUsersLocations.flat(1)));
        allLocations.push(...locations);
        return Array.from(new Set(allLocations));
      }),
      map(locations => {
        const filter = this.utility.generateGridFilter('Column_Filter', dmoGuid);
        const conditions = locations.map(location => this.utility.generateGridCondition('CONTAINS', location));
        filter.GridConditions = conditions;
        return filter;
      })
    );
  }

  private _parseUserLocations(location: UserLocation) {
    return location.LOCATIONID.split(',').filter(id => id.trim().length > 0);
  }

  private _customizedFilterForFertilizerAdminsInContractsApp(locations: string[], altUsers: AlternateUser[]) {
    const { UserId } = this.user;
    const userIds = [UserId, ...altUsers.map(user => user.OutOfOfficeUserId)];
    const primaryConds = this._generateCustomFilterConditions('nagscmfvctdtda1', userIds);
    const supportConds = this._generateCustomFilterConditions('nagscmfvctdtda2', userIds);
    const locConditions = this._generateCustomFilterConditions('nagscmfvlocid', locations);
  
    const filter = {
      DataField: '',
      FilterType: 'Customize_Filter',
      LogicalOperator: 'Or',
      GridConditions: [...primaryConds, ...supportConds, ...locConditions],
    }
    return filter;
  }

  private _generateCustomFilterConditions(guid: string, ids: Array<string | number>) {
    return ids.map(id => ({
      Condition: 'CONTAINS',
      ConditionValue: id,
      ColumnName: guid,
    }))
  }

  /* GRID VIEW NOVUS SPECIFIC FILTERS */

  public contractsDrilldownFilters({state, vendor}) {
    const stateFilter = this._generateGridFilter('State_Filter', state, 'EQUAL', state);
    const vendorFilter = this._generateGridFilter('Column_Filter', 'nagscmfvctdtvname', 'EQUAL', vendor);
    return [stateFilter, vendorFilter];
  }
  public releaseDrilldownFilters({state, customer}) {
    let stateFilter: GridFilter;
    if (state === 'Prepaid')
      stateFilter = this._generateGridFilter('Column_Filter', 'naglmavcdpre', 'EQUAL', 'Yes');
    else
      stateFilter = this._generateGridFilter('Column_Filter', 'WFODISPNAME', 'EQUAL', state);
    
    const customerFilter = this._generateGridFilter('Column_Filter', 'naglmavlccdetcust', 'EQUAL', customer);
    return [stateFilter, customerFilter];
  }

  // public async loggedInUserBookingsFilter() {
  //   const { UserName } = this._user;
  //   const { LOCATIONID } = await this.novus.getUserLocation([UserName]).pipe(map(res => res[0])).toPromise();
  //   const filter = this.utility.generateGridFilter('Column_Filter', 'nagbmavdtdtbookloc');
  //   LOCATIONID.split(',').forEach(locationId => {
  //     filter.GridConditions.push(this.utility.generateGridCondition('EQUAL', locationId))
  //   });
  //   return [filter];

  // }

  /** Grid filter applied only to Regional Fertilizer Managers.
   * 
   * The filter shows only Contracts created by the logged in RFM
   */
  public regionalFertilizerManagerFilter() {
    const { UserName } = this.user;
    const filter = this.utility.generateGridFilter('Column_Filter', 'nagscmfvctdthidrequ');
    if (this.user.hasRole('nagregionalfertilizermanager') && !this.user.hasRole('nagsystemadmin')) {
      filter.GridConditions.push(this.utility.generateGridCondition('EQUAL', UserName));
    }
    return filter;
  }
  
  // public async divisionAdminFilter() {
  //   const { FirstName, LastName, UserName, UserId } = this._user;
  //   // const value = `${FirstName} ${LastName}(${UserName})`;
  //   const filter = this._generateGridFilter('MyRecord', 'nagscmfvctdtda1-nagscmfvctdtda2', 'EQUAL', UserId);
  //   const divisionAdmins = JSON.parse(sessionStorage.getItem('divisionAdmins')) || await this.novus.getUsersByRole('NAG_Division_Admin').toPromise();
  //   if (divisionAdmins.find(admin => admin.UserName === UserName))
  //     return [filter];
  //   return [];
  // }
  
  public async locationAdminFilter() {
    const {UserName } = this.user;
    const filter = this._generateGridFilter('Column_Filter', 'naglmavlcldetlm');
    const isFertilizer = this.user.hasRole('nagfertilizermanager') || this.user.hasRole('nagdivisionadmin');
    const locationAdmins = JSON.parse(localStorage.getItem('locationAdmins')) || await this.novus.getUsersByRole('NAG_Location_Admin').toPromise();
    if (locationAdmins.find(admin => admin.UserName === UserName) && !isFertilizer) {
      // filter.GridConditions.push({Condition: 'EQUAL', ConditionValue: value});
      const locationFilter = await this.locationBasedFilter().toPromise();
      if (locationFilter.GridConditions.length === 0)
        return;
      return locationFilter;
    }
    return filter; 
  }



  private _generateGridCondition(condition: Condition, value: string): GridCondition {
    return {Condition: condition, ConditionValue: value}
  };

  private _generateGridFilter(
    filterType: FilterType,
    dataField: string, 
    condition?: Condition, 
    conditionValue?: string,
    operator: 'And' | 'Or' = 'Or'): GridFilter {
    const filter: GridFilter = {
      DataField: dataField,
      LogicalOperator: operator,
      FilterType: filterType,
      GridConditions: []
    };
    if (condition && conditionValue) {
      filter.GridConditions.push(this._generateGridCondition(condition, conditionValue));
    };
    return filter;
  }

  private _generateGridConfig(config: GridConfiguration): GridConfiguration {
    config.PageNumber = config.PageNumber || 0;
    config.PageSize = config.PageSize || 99;
    config.SortColumn = config.SortColumn || '-1';
    config.SortOrder = config.SortOrder || 'Asc';
    config.TimeZone = config.TimeZone || this._timezone;
    config.ViewName = config.ViewName || 'View 1';
    config.GridFilters = config.GridFilters || [];
    return config;
  }


  // Temporarily public for Custom Form Actions Service 
  public _populateFormField(control: AbstractControl, value: any, emitEvent: boolean = false, type: DmoType = 'TextBox', name?: string) {
    if (control && value !== null) {
      if (isDate(value) || (type === 'StaticDateBox' || type === 'DateWithCalendar' || type === 'DateTimeBox')) {
        const format = 'MM/dd/yyyy HH:mm:ss';
        const convertToLocal = type && type !== 'StaticDateBox';
        value = this.dcs.getUserDateTime(value, format, this.user.TimeZone, convertToLocal);
        value = this.ngbDate.parse(value)
      }

      if (type === 'CheckBoxList') {
        this._populateCheckBoxList(control as FormArray, value, emitEvent, name);
      } else {
        control.patchValue(value, {emitEvent});
      }
      control.markAsDirty();
    }
  }

  private _populateCheckBoxList(control: FormArray, value: string, emitEvent: boolean, name: string) {
    const dmo = this.dcs.dmos.find(d => d.Name === name);
    const options = (dmo.Options as string).split(',');
    options.map((option, index) => {
      if (value && value.split('|').includes(option)) {
        control.at(index).patchValue(true);
      } else {
        control.at(index).patchValue(false);
      }
    });
  }

  public search<T>(config: GridConfiguration) {
    const url = `${environment.Setting.WFApiUrl}/listview/getProcessData`;
    return this.http.post<GridResponse<T>>(url, config);
  }

  private _request<T>(config: GridConfiguration, noSpinner?: boolean): Observable<GridResponse<T>> {
    const url = `${environment.Setting.WFApiUrl}/listview/getProcessData`;
    return this.http.post<GridResponse<T>>(url, config, {headers: {noSpinner: 'true'}});
    // return this.listView.GridData(config) as Observable<GridResponse<T>>;
  }


  // Client specific custom api
  public getVendorCreditLimitManager(config: GridConfiguration): Observable<GridResponse<VCLMItem>> {
    const url = `${environment.Setting.ProjectApiUrl}/vendor/getVendorCreditLimitManagerData`;
    const accessToken = localStorage.getItem('AccessToken');
    return this.http.post<GridResponse<VCLMItem>>(url, config, {headers: {accessToken, noSpinner: 'noSpinner'}}).pipe(
      map(response => this._transformSummary(response, 'vendorCreditLimitSummary')),
      map(response => {
        return {
          ...response,
          Data: response.Data.map(item => {
            const { RowNumber, ...rest } = item;
            return rest as VCLMItem;
          }),
        }
      }),
      map(response => {
        const updData = response.Data.map(item => {
          const updItem = {nagvcavdtdtv: item.nagvcavdtdtv};
          Object.entries(item).forEach(entry => {
            let value = entry[1];
            if (entry[0] !== 'nagvcavdtdtv') {
              value = parseFloat(value);
              if (value >= 0)
                updItem[entry[0]] = '$' + this.currency.transform(value, '', '');
              else
                updItem[entry[0]] = '-' + '$' + this.currency.transform(Math.abs(value), '', '');
            }
          })
          return updItem;
        });
        const updResponse: GridResponse<VCLMItem> = {...response, Data: (updData as VCLMItem[])};
        return updResponse;
      })
    );
  }

  public getInventoryManager(config: GridConfiguration): Observable<GridResponse<InventoryItem>> {
    const url = `${environment.Setting.ProjectApiUrl}/inventory/getInventoryDataAndSummary`;
    const accessToken = localStorage.getItem('AccessToken');
    return this.http.post<GridResponse<InventoryItem>>(url, config, {headers: {accessToken}}).pipe(
      map((response: any) => {
        const { 
          AvgCostPerTon, 
          TotalCostPaid, 
          OutstandingInventory,
          AvgPricePerTon,
          PlusMinusPosition,
           ...rest } = response.inventoryDataSummary[0];
        const header = { 
          AvgCostPerTon, 
          TotalCostPaid,
          OutstandingInventory,
          AvgPricePerTon,
          PlusMinusPosition,
        };
        response.inventoryDataSummary[0] = rest;
        return {...response, header };
      }),
      map(response => this._transformSummary(response, 'inventoryDataSummary')),
    );
  }

  public getCustomerCreditLimitManager(config: GridConfiguration): Observable<GridResponse<CCLMItem>> {
    const url = `${environment.Setting.ProjectApiUrl}/customer/getCustomerCreditLimitManagerData`;
    const accessToken = localStorage.getItem('AccessToken');
    return this.http.post<GridResponse<CCLMItem>>(url, config, {headers: {accessToken}}).pipe(
      map(response => this._transformSummary(response, 'customerCreditLimitSummary')),
      map(response => {
        return {
          ...response,
          Data: response.Data.map(item => {
            const { RowNumber, ...rest } = item;
            return rest as CCLMItem;
          }),
        }
      }),
      map(response => {
        const updData = response.Data.map(item => {
          const updItem = { nagccavdtdtc1: item.nagccavdtdtc1 };
          Object.entries(item).forEach(entry => {
            let value = entry[1];
            if (entry[0] !== 'nagccavdtdtc1') {
              value = parseFloat(value);
              if (value >= 0)
                updItem[entry[0]] = '$' + this.currency.transform(value, '', '');
              else
                updItem[entry[0]] = '-' + '$' + this.currency.transform(Math.abs(value), '', '');
            }
          })
          return updItem;
        });
        const updResponse: GridResponse<CCLMItem> = {...response, Data: (updData as CCLMItem[])};
        return updResponse;
      })
    );
  }

  private _transformSummary<T>(response: GridResponse<T>, prop: string): GridResponse<T> {
    const summary = (response as any)[prop][0];
    const modSummary = [];
    Object.entries(summary).forEach(entry => {
      const modItem = {}
      modItem[entry[0].replace(/([a-z])([A-Z])/g, '$1 $2')] = entry[1];
      modSummary.push(modItem)
    });
    return {
      ...response,
      summary: modSummary
    } as GridResponse<T>;
  }

  public getNovusMargins(config: GridConfiguration) {
    const url = `${environment.Setting.ProjectApiUrl}/NovusMargin/getNovusMarginsData`;
    return this.http.post<GridResponse<any>>(url, config);
  }
  
  public getProductActiion<T>(config: GridConfiguration, noSpinner?: boolean): Observable<GridResponse<T>> {    
    const url = `${environment.Setting.ProjectApiUrl}/product/getproductaction`;
    return this.http.post<GridResponse<T>>(url, config);
  }  

  public GetProductIncentiveSubGridData<T>(config: GridConfiguration, transactionId: string): Observable<GridResponse<T>> {
    const url = `${environment.Setting.ProjectApiUrl}/Product/getProductIncentiveSubGridData/${transactionId}`;
    return this.http.post<GridResponse<T>>(url, config).pipe(
      map(response => {
        const discountSum = (response as any).DiscountSum[0];
        //discountSum.TotalDiscountPercentage = formatPercent(discountSum.TotalDiscountPercentage / 100, 'en-US');
        //discountSum.TotalDiscount = formatCurrency(discountSum.TotalDiscount, 'en-US', '$')
        return {
          ...response,
          DiscountSum: [discountSum]
        }
      }),
      map(response => this._transformSummary(response, 'DiscountSum'))
    );
  }

  public GetProductPricingGrid<T>(config: GridConfiguration, transactionId: string): Observable<GridResponse<T>> {
    const url = `${environment.Setting.ProjectApiUrl}/Product/getProductPricingGrid/${transactionId}`;
    return this.http.post<GridResponse<T>>(url, config, {headers: {noSpinner: 'true'}});    
  }

  // public GetProductPricingGridMargin<T>(config: GridConfiguration, transactionId: string): Observable<GridResponse<T>> {
  //   const url = `${environment.Setting.ProjectApiUrl}/Product/GetProductPricingGridMargin/${transactionId}`;
  //   return this.http.post<GridResponse<T>>(url, config, {headers: {noSpinner: 'true'}});
  // }

  public GetProgramIncentiveSubGridData<T>(config: GridConfiguration, transactionId: string): Observable<GridResponse<T>> {
    const url = `${environment.Setting.ProjectApiUrl}/Product/getProgramIncentiveSubGridData/${transactionId}`;
    return this.http.post<GridResponse<T>>(url, config);
  }

  public getAssociatedProductInstances(config: GridConfiguration, transactionId: string) {
    const url = `${environment.Setting.ProjectApiUrl}/Product/getAssociatedProductInstances/${transactionId}`;
    return this.http.post<GridResponse<any>>(url, config);
  }
}

const COLUMN_LIST = {
  purchaseOrderDetails: [
    'nagpomavdtdtponum','nagpomavdtdtprod','nagpomavdtdtpid',
    'nagpomavdtdtpend','nagpomavdtdtpstart','nagpomavdtdtquant',
    'nagpomavdtdttype','nagpomavdtdtunit','nagpomavdtdtven',
    'nagpomavdtdtdtype','nagpomavdtdtfrate','nagpomavdtdtdreq',
    'nagpomavdtdtpdloc', 'nagpomavdtdtvid', 'nagpomavdtdtcost',
    'nagpomavdtdtfilledyn', 'nagpomavdtdtpdeptid', 'nagpomavdtdtpdeptnam',
    'nagpomavdtdtlocid', 'nagpomavdtdtlocname', 'nagpomavdtdtvconn',
  ],
  vendorDetailsInContractsForm: [
    'nagvdmavdtdtvid','nagvdmavdtdtvname','nagvdmavdtdtcredit','nagvdmavdtdtacredit'
  ],
  locationDetails: [
    'naglomavdtdtlid','naglomavdtdtname','naglomavdtdtcity',
    'naglomavdtdtstate','naglomavdtdtreg','naglomavdtdtsub',
  ],

}

function customPipeforDropdownField(source: Observable<any>) {
  return source.pipe(
    debounceTime(SEARCH_INPUT_DEBOUNCE),
    distinctUntilChanged(),
    filter(value => value && value.trim().length > 0),
    map(value => value.trim()),
  );
}

function isDate(value: string) {
  // Expecting date in format: "4/29/2020 12:00:00 AM"
  if (typeof value !== 'string')
    return false;
  if (value.split(' ').length === 1)
    return false;
  return  value.match(/[\/:]/) && !!new Date(value).getDate();
}

const LOCATION_FILTER_DATA = {
  NAG_Onboarded_Products: 'nagpravlocid',
  NAG_Incentives: 'nagincavpilid',
  Product_Actions: 'nagpravlocid',
  NAG_Zone: 'nagznfvlocid',
  NAG_Margin: 'nvsbmogfvprdctlocid',
}
