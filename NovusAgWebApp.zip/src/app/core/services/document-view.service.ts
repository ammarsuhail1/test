import { Injectable,EventEmitter, Output } from '@angular/core';
import { ApiService } from './api.service';
import { map, filter, tap } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class DocumentViewService {
  public isAttachmentGridView:boolean=false;
  constructor(
    private api: ApiService,
    private route: ActivatedRoute,
  ) { }

  @Output() callData: EventEmitter<number> = new EventEmitter();

  getTreeData(){
    this.callData.emit();
  }

  // public hasActiveAndFeaturedImage(transactionID: string) {
  //   const payload = {
  //     DocumentID: "0",
  //     ProcessName: this.route.snapshot.params.process != undefined ? this.route.snapshot.params.process : sessionStorage.getItem('AppName'),
  //     TransactionID: transactionID,
  //     TimeZone: new Date().getTimezoneOffset(),
  //     // IsActive: "1",
  //   };
  //   return this.FolderTree(payload).pipe(
  //     map(data => {
  //       delete data[0];
  //       return data;
  //     }),
  //     map(data => Object.values(data)), /* Turn object to array to manipulate it further */
  //     map(nestedListOfItems => nestedListOfItems[0] as any[] || []), /* Flatten nested files and folders */
  //     map(items => items.filter(item => item.Type !== '0')), /* Remove all 'folder' items and keep files */ 
  //     map((files: any[]) => { /* The purpose of this transformation is to set featured file first*/
  //       if (files.length > 0) {
  //         const featured = files.find(item => item.IsFeatured === 1);
  //         const active = files.find(item => item.IsActive === 1);
  //         if (featured)
  //           return {featured: !!featured.IsFeatured, active: !!featured.IsActive};
  //         else if (!featured && active)
  //           return {featured: false, active: true};
  //         else
  //           return {featured: false, active: false};
  //       } else 
  //         return {featured: false, active: false};
  //     }),
  //   ).toPromise();
  // }

  FolderTree(objFolderData) {
    return this.api.post(`documentView/getTree`, objFolderData);
  }

  UpdateDocuments(updateDocument: any) {
    return this.api.post('documentView/updateDocument', updateDocument);
  }

  CreateFolder(createFolder) {
    return this.api.post('documentView/createFolder', createFolder);
  }

  CreateDocumentTree(createDocument: any) {
    return this.api.post(`documentView/documentList`, createDocument);
  }
  UploadFile(url: string, formData: FormData) {
    return this.api.UploadFile(url, formData);
  }
  DeleteFile(url: string, formData: FormData) {
    return this.api.DeleteFile(url, formData);
  }
  downloadfile(url: string, formData: FormData) {
    return this.api.postGetFile(url, formData, 'blob');
  }
  setActive(transactionID, DocID, status) {
    return this.api.post('documentView/SetActiveDocument?documentID=' + DocID + '&transactionID=' + transactionID + '&status=' + status, null);
  }
  setFeatured(transactionID, DocID) {
    return this.api.post('documentView/SetFeaturedDocuments?documentID=' + DocID + '&transactionID=' + transactionID, null);
  }
}
