import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { ApiESaleyardService } from './api-e-saleyard.service';
import { map } from 'rxjs/operators';
import { UserListResponse, UserGridInfo } from '../models';
import { environment } from '@env/environment';

@Injectable({
  providedIn: 'root'
})
export class UserManagementService {

  constructor(private api: ApiESaleyardService) { }

  getUserList(bodyData) {
    return this.api.post('listview/getUsers', bodyData);
  }
  deleteUser(userName: string) {
    const apiEndpoint = 'api/DeleteUser';
    return this.api.postUserDelete('user/icewebapi', userName, apiEndpoint);
  }
  ChangeUserStatus(UserName, Status) {
    return this.api.postWithHeader('SetUserStatus', UserName, Status);
  }
  getColumns() {
    return this.api.post('listview/getColumns', null);
  }

  getUserColumns() {
    return this.api.post('listview/GetUserColumns', null);
  }

  getUserEndPoint(ExportType: string): string {
    if (ExportType === 'excel') {
   return this.api.endpoint + '/user/exportToExcel';
    } else {
   return this.api.endpoint + '/user/exportToPDF';
    }
  }

  getEndPoint(ExportType: string): string {
    if (ExportType === 'excel') {
      return this.api.endpoint + '/listview/exportToExcel';
    } else {
      return this.api.endpoint + '/listview/exportToPDF';
    }
  }
  getUserGridList(bodyData) {
    return this.api.postC2M('GetAllManageUserList', bodyData).pipe(
      map(this._normalizeUserGridListResponse),
      map(this._excludeDevAccountFromUserGridListResponse)
    );
  }

  // add by sanju for get all data for export 
  GetExportData(bodyData) {
    return this.api.GetExportData('GetAllManageUserList', bodyData);
  }

  private _normalizeUserGridListResponse(response: UserListResponse) {
    if (!response.data) {
      const data = {UserInfo: {ManageUsers: []}};
      response.data = data;
      response.totalrecords = 0;
    }
    const users = Array.isArray(response.data.UserInfo.ManageUsers)
      ? response.data.UserInfo.ManageUsers
      : [response.data.UserInfo.ManageUsers];
    const normalized = {
      ...response,
      data: {
        UserInfo: {
          ManageUsers: users
        },
      },
    };
    return normalized;
  }

  private _excludeDevAccountFromUserGridListResponse(response: UserListResponse): UserListResponse {
    const hiddenAccounts = environment.Setting.excludedAccounts;
    const users = response.data.UserInfo.ManageUsers as Array<UserGridInfo>;
    if (users.find(user => hiddenAccounts.some(username => username === user.UserName))) {
      return {
        ...response,
        data: {
          UserInfo: {
            ManageUsers: (response.data.UserInfo.ManageUsers as UserGridInfo[])
              .filter(user => !hiddenAccounts.some(username => username === user.UserName))
          },
        },
        totalrecords: response.totalrecords - 1,
      };
    }
    return response;
  }

}
