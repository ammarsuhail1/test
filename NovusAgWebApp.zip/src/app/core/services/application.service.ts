import { Injectable, Output, EventEmitter } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';
import { tap } from 'rxjs/operators';
import { AppList } from '../models';

import { ApiService } from './api.service';
import {BulkTriggerValidationResponse, BulkTriggerData, BulkUpdateSavePayload} from '../models/project';

@Injectable({
  providedIn: 'root'
})
export class ApplicationService {

  checkValidation: Subject<boolean> = new Subject();

  private _appList = new BehaviorSubject<AppList>(null);

  get appList$() {
    return this._appList.asObservable();
  }

  constructor(private api: ApiService) { }

  checkValidations() {
    this.checkValidation.next(true);
  }

  getProcess(): Observable<AppList> {
    return this.api.get('application/process').pipe(
      tap(appList => this._appList.next(appList))
    );
  }

  public getAppInfo(processName?: string) {
    processName = processName || sessionStorage.getItem('processName');
    processName = decodeURIComponent(processName);
    const appList = this._appList.getValue();
    const apps = Object.values(appList).flat();
    return apps.find(app => app.Name === processName) || null;
  }

  insertApplication(data) {    
    return this.api.post('application/insertapplication', data);
  }

  updateApplication(data) {
    return this.api.post('application/updateapplication', data);
  }

  getApplicationData(identifierName = null, identifierValue = null, view: string, transactionId?: string) {
    return this.api.get('application/applicationdata' + '/' + identifierName + '/' + identifierValue + '/' + view, {transactionId});
  }
  getLogData(identifierName = null, identifierValue = null, transactionId?: string, pageSize = 10, pageNumber = 1) {
    return this.api.get('application/activitylog' + '/' + identifierName + '/' + identifierValue, {transactionId, pageSize, pageNumber});
  }

  getHistoryLogData(identifierName = null, identifierValue = null, transactionId?: string, pageSize = 10, pageNumber = 1) {
    return this.api.get('application/historylog' + '/' + identifierName + '/' + identifierValue, {transactionId, pageSize, pageNumber});
  }

  getNotificationLogData(identifierName = null, identifierValue = null, transactionId?: string, pageSize = 10, pageNumber = 1) {
    return this.api.get('application/emaillog' + '/' + identifierName + '/' + identifierValue, {transactionId, pageSize, pageNumber});
  }

  gettempDate() {
    return this.api.get('application/getAnnouncements?processName=driver&flag=all&pageSize=20&pageFrom=0');
  }

  getTopCornerDetail(identifierName = null, identifierValue = null, canvasType: string, transactionId?: string) {
    return this.api.get('application/gettopcornerdetail' + '/' + identifierName + '/' + identifierValue + '/' + canvasType, {transactionId});
  }

  getBatchUpdateDetails(processName: string) {
    return this.api.get('application/getBatchUpdateDetails', {processName});
  }

  batchUpdate(data, processName: string) {
    return this.api.post('application/batchUpdate', data, {processName});
  }

  public validateBulkTrigger(transactionIds: string[]): Observable<BulkTriggerValidationResponse> {
    return this.api.post(`application/bulkTriggerValidation`, {TransactionID: transactionIds});
  }

  public getBulkTriggerData(processName: string, stateID: string): Observable<BulkTriggerData> {
    return this.api.post(`application/bulkTriggerData`, null, {processName, stateID});
  }

  public batchUpdateV2(processName: string, triggerName: string, data: BulkUpdateSavePayload): Observable<boolean> {
    return this.api.post(`application/batchUpdate`, data, {processName, triggerName});
  }


  checkSubProcessRecordCount(subprocessrecordcount){
    return this.api.post('application/RecordCountByState' , subprocessrecordcount);
  }

  getGridDmogDataMapping(params: any) {
    return this.api.get('application/getGridDmogDataMapping', params);
  }

  getGridDmogData(params: any) {
    return this.api.post('application/getGridDmogData', params);
  }

  insertUpdateGridDmogData(params: any) {
    return this.api.post('application/InsertUpdateGridDmogData', params);
  }

  deleteGridDmogData(ids: any) {
    return this.api.deleteGrid('application/deleteGridDmogData?dataIDs=' + ids.toString());
  }

  getBulkLogData(bodyData: any) {
    return this.api.post('application/getBulkUploadLog',bodyData);
  }

  DownloadBulkLog(ProcessName: any) {
    return this.api.postGetFile('application/getBulkUploadTemplate/'+ ProcessName,null,'Blob', {ProcessName});
  }

  DownloadBulkUploadErrorLog(FileName: any) {
    return this.api.postGetFile('application/DownloadBulkUploadErrorLog/'+ FileName,null,'Blob');
  }
   ValidateUniqueDmoValue(data) {
    return this.api.post('application/validateuniquedmovalue', data);    
  }
  deleteGridData(id: string){
    return this.api.deleteGrid('application/deleteTransaction?TransactionIDs=' + id);
  }
  getDisplayNameByProcessName(ProcessName:any){
    return this.api.get(`application/getDisplayNameByProcessName/${ProcessName}`,null);
  }  
}
