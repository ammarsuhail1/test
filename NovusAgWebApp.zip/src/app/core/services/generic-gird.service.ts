import { Injectable } from '@angular/core';
import { ApiService } from './api.service';
import { IHeaderMap } from '../models/plasmaGridInterface';

@Injectable({
  providedIn: 'root'
})
export class GenericGirdService {
 config: any =  {
  header: {
    columns: {},
    action: false,
  },
  paging: true
  };
  gridData: any = {};
  gridCount: any = {};
  gridColumn: any = {};
  gridId: string;
  isChangeLog:boolean = false;
  constructor(private api: ApiService) { }

  bindGenricGrid(url, gridId) {
    this.gridId = gridId;
    return this.api.get(url).subscribe(
      Result => {
        this.gridData = Result;
      }
    );
  }

 
  getBidsColumns() {
    return this.api.postForLMK('bidding/getBidsColumns', null);
  }

  getEndPoint(ExportType: string): string {
    if (ExportType === 'excel') {
   return this.api.LMKendpoint + '/bidding/exportToExcelBidsHistory';
    } else {
   return this.api.LMKendpoint + '/bidding/exportToPDFBidsHistory';
    }
  }
}
