import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot,  Router, RouterStateSnapshot } from '@angular/router';

import { Observable, of } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';

import { ApplicationService, MessageService } from '../services';

import { AppList } from '../models';

@Injectable({providedIn: 'root'})
export class ProcessGuard implements CanActivate {

  constructor(
    private app: ApplicationService, 
    private router: Router,
    private msg: MessageService,
  ) {}
  
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    const process = route.paramMap.get('process_name') || '';
    return this.app.appList$.pipe(
      switchMap(appList => appList ? of(appList) : this.app.getProcess()),
      map(appList => {
        let exists = false;
        Object.values(appList).forEach(type => type.forEach(app => {
          if ((app.Name.toLowerCase() === process.toLowerCase()) ||(app.Name === 'Manage Users' && state.url.startsWith('/users')))
            exists = true;
        }));
        return exists;
      }),
      tap(exists => {
        if (!exists) {
          this.router.navigate(['app_list']);
          this.msg.showMessage('Warning', {header: 'Access Denied', body: 'You do not have permissions to access that app'});
        } else {
          sessionStorage.clear()
        }
      })
    )
  }
}
