import { environment } from '@env/environment';

export const creditLimitExceeded = (data: any) => {
  const { releaseValue, customerName, avCreditLimit,
          contractNumber, vendorName, location,
          locationManager, productDescription, quantityOfLoad,
          pickupDate, shippingTerminal} = data;
  const releaseUrl = `${environment.Setting.webUrlRoot}/${location.hash}`;
  return `
    <div>
      <p>Hello, a release with value ${releaseValue} has been assigned to customer ${customerName}.</p>
      <p> The customer's available credit limit is ${avCreditLimit}.</p>

      <p><a href="${releaseUrl}">Click here</a> to open the release manager grid and check the details.</p>
    </div>
    <table>
      <tbody>
        <tr>
          <td>Contract Record ID:</td>
          <td>${contractNumber}</td>
        </tr>
        <tr>
          <td>Vendor Name:</td>
          <td>${vendorName}</td>
        </tr>
        <tr>
          <td>Location:</td>
          <td>${location}</td>
        </tr>
        <tr>
          <td>Location Manager:</td>
          <td>${locationManager}</td>
        </tr>
        <tr>
          <td>Product Description:</td>
          <td>${productDescription}</td>
        </tr>
        <tr>
          <td>Quantity of Load:</td>
          <td>${quantityOfLoad}</td>
        </tr>
        <tr>
          <td>Pickup Date:</td>
          <td>${pickupDate}</td>
        </tr>
        <tr>
          <td>Shipping Terminal:</td>
          <td>${shippingTerminal}</td>
        </tr>
      </tbody>
    </table>
  `
}