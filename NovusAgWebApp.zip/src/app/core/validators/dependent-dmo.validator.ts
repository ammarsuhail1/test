import { AbstractControl, ValidatorFn } from '@angular/forms';

export function dependentDmoValidator(sourceControl: AbstractControl, expression: boolean): ValidatorFn {
    if (expression) {
      sourceControl.setErrors(null);
      return null;
    } else {
      sourceControl.setErrors({dependentDmo: true});
    }

}