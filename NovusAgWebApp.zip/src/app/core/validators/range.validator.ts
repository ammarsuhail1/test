import { FormGroup, ValidatorFn } from '@angular/forms';

export function rangeValidator(dmo: any): ValidatorFn {
  return (form: FormGroup) => {
    const fromControl = form.get(dmo.Name + 'From');
    const toControl = form.get(dmo.Name + 'To');

    const from = +fromControl.value;
    const to = +toControl.value;

    if (from !== null && to !== null && from < to) {
      fromControl.setErrors(null);
      toControl.setErrors(null);
      return null;
    }

    fromControl.setErrors({range: true});
    toControl.setErrors({range: true});
    return {range: true};
  }
}