import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class UserDetail {
    constructor() {        
        const AccessToken = localStorage.getItem('AccessToken');
        try {
            if (AccessToken) {
                const aToken = AccessToken.split('.');
                let currentUser: any;
                const offset = new Date().getTimezoneOffset();
                let userDetail: any;
                if (aToken.length > 1) {
                    userDetail = JSON.parse(atob(aToken[1]));
                    currentUser = JSON.parse(userDetail.User);
                } else {
                    currentUser = JSON.parse(localStorage.getItem('currentUser'));
                }
                this.TimeZone = offset;
                this.UserName = currentUser.UserName;
                this.UserId = currentUser.UserId;
                this.FirstName = currentUser.FirstName;
                this.LastName = currentUser.LastName;
                this.Language = currentUser.Language;
                this.GroupId = currentUser.GroupId;
                this.ListRole = currentUser.Roles;
                this.Roles = currentUser.Roles;
                (currentUser.Roles as string[]).forEach(role => this.roles[role] = true);
                this.FullName = currentUser.FirstName + ' ' + currentUser.LastName;
                this.token = userDetail.AcessToken;
                this.RefreshToken = userDetail.RefreshToken;
                this.isAuthenticate = true;
            } else {
                this.isAuthenticate = false;
            }
        }
        catch (err) {
            localStorage.clear();
            sessionStorage.clear();               
            this.isAuthenticate = false;       
          }
    }
    
    UserId: string;
    UserName: string;
    Password: string;
    FirstName: string;
    LastName: string;
    FullName: string;
    TimeZone: number;
    Language: string;
    ListRole: any[];
    token: string;
    RefreshToken: string;
    GroupId: string;
    isAuthenticate: boolean;
    Roles: any;
    private roles: {[key: string]: true} = {};

    public hasRole(role: string) {
        return this.roles[role]
    }
}
