export interface CustomerCredit {
  CustomerID: string;
  CustomerName: string;
  City: string;
  State: string;
  ZipCode: string;
  CreditLimit: string; // Total Credit
  AvailableCredit: string;
}