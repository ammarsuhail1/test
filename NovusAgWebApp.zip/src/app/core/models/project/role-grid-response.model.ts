export interface RoleGridResponse {
  Data:         {
    RoleInfo: {
      ManageRoles: Role[];
    }
  };
  RecordsCount: string;
  Begin:        string;
  End:          string;
  PageNumber:   string;
}


export interface Role {
  PolicyID:       number;
  PolicyName:     string;
  PolicyFrndName: string;
  Status:         'Active' | 'Inactive';
  CreatedDate:    string;
  ModifyDate:     string;
  PolicyGuid:     string;
}
