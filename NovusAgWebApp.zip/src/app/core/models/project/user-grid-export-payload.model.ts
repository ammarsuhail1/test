import { UserGridItem } from './user-grid-item.model';
import { GridFilter } from '../plasmaGridInterface';

export interface UserGridExportPayload {
    UserIds: string;
    // GroupIds: string;
    ColumnList: string;
    SearchName?: string;
    ManageUsers: UserGridItem[];
    SortColumn: string;
    SortOrder: string;
    GridFilters: GridFilter[];
    ViewName: string;
    columns: any[];
    configFor: string;
}