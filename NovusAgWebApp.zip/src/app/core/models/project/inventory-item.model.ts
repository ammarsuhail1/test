/** Inventory Manager App Item */
export interface InventoryItem {
  RowNumber?: string;
  /** Vendor Name */ 
  naginavdtdtv: string;
  /** Terminal */
  naginavdtdtt: string;
  /** PO Number */
  naginavdtdtp: string;
  /** Contract Number */
  naginavdtdtc: string;
  /** Product Name */
  naginavdtdtr: string;
  /** Product Id */
  naginavdtdti: string;
  /** Date ??? */
  naginavdtdts: string;
  /** Price */
  naginavdtdtpr: string;
  /** Tons Ordered */
  naginavdtdto: string;
  /** Tons Shipped */
  naginavdtdtsh: string;
  /** Tons Committed */
  naginavdtdtco: string;
  /** Tons Exposed */
  naginavdtdtex: string;
  /** Repl. Cost */
  naginavdtdtrc: string;
  /**+/- Position */
  naginavdtdtpos: string;
}