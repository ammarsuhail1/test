import { AutoCompleteSearchBoxDmo } from '../dmos';

export interface BulkUpdateCheckPayload {
  ProcessName: string;
  TrnsctnIds: string[];
  IsRecordSelect: boolean;
}

export interface BulkUpdateSavePayload {
  TransactionID: string[];
  BatchUpdate: Array<{
    DMOGUID: string;
    DATAVALUE: string;
    DATATEXT: string;
  }>;
}

export interface BulkUpdateCheckResponse {
  Result: boolean;
  Data: AutoCompleteSearchBoxDmo[];
  Triggers: Array<{ Name: string; DisplayName: string }>;
  CreditCheckResult: Array<{ ReleaseNumber: string; ReleaseStatus: 'Pass' | 'Fail' }>;
}

export interface BulkUpdateSaveResponse {
  code: number;
  statuscode: number;
  status: string;
  message: string;
  result: {
    TotalCount: number;
    ErrorCount: number;
    ErrorLog: number;
    PassCount: number;
    ValidationFailed: string;
    CreditCheckFailed: string;
  }
}

export interface BulkTriggerValidationResponse {
  Result: boolean,
  StateID: string,
}

export interface BulkTriggerData {
  Triggers: Array<{Name: string, DisplayName: string}>,
  Data: AutoCompleteSearchBoxDmo[],
}

export interface BulkRevertCheckPayload {
  ProcessName: string;
  TrnsctnIds: string[];  
}

export interface BulkRevertSavePayload {
  TrnsctnIds: string[]; 
}

export interface BulkRevertSaveResponse {
  Result: number;
  ReleaseNumbers:any;
}

export interface AssociateProgramResponse {
  Result: number;
  SuccussRows: number;
  Products:any[];
}

export interface ProgramRuleResponse {
  status: string;  
  resultDetails:any[];
}
