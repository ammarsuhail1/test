export interface LocationPricePayload {
  ProductID:	          string;
  VendorID:	            string;
  AssignedLocationID:	  string;
  ShipToDepartmentID:	  string;
  ShippingTerminalID:	  string;
  Region:	              string;
  ReleaseNumber:	      string;
  CustomerID:	          string;
  VendorContractNumber:	string;
}