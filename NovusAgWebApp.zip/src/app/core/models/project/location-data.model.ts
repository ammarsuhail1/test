export interface LocationData {
  LocationID: string;
  LocationName: string;
  City: string;
  State: string;
  Region: string;
  SubRegion: string;
}