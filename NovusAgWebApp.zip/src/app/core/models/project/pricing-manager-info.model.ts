export interface PricingManagerInfoResponse {
  code: number;
  statuscode: number;
  status: 'Success' | 'Error',
  message: 'Success' | 'Error',
  result: string | PricingManagerInfo[];
}

export interface PricingManagerInfo {
  ContractNumber: string,
  ProductName: string,
  ProductID: string,
  VendorName: string,
  VendorID: string,
  Region: string,
  ContractPrice: string,
}

export interface PricingGrid {
  costAfterDiscount: number;
  discountAnchorValue: number;  
  TotalDiscounts: number;
}