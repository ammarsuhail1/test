export interface IncentiveSale {
  productid: string,
  productname: string,
  locationid: string,
  locationname: string,
  department: string,
  quantity: string,
  billunit: string,
  sales: string,
  invdate: string,
}