/** Customer Credit Limit Manager App Item */
export interface CCLMItem {
  RowNumber?: string;
  /** Customer Name */
  nagccavdtdtc1: string;
  /** Prepaid */
  nagccavdtdtc2: string;
  /** Open State */
  nagccavdtdtc3: string;
  /** Pulled State */
  nagccavdtdtc4: string;
  /** Closed State */
  nagccavdtdtc5: string;
  /** Open Credit */
  nagccavdtdtc6: string;
  /** Credit Limit */
  nagccavdtdtc7: string;
}