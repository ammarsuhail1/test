import { GridFilter } from "../plasmaGridInterface";

export interface IncomeStatementPayload { 
  year: string;
  month: string;
  reportCategory: string;
  accountCategory: string;
  parameterType: string;
  regions:string;
  territory:string;
  locations: string;
  pageNo: number;
  pageSize: number;
  sortColumn: string;
  gridFilters: GridFilter[];
}

export interface IncomeStatementResponse {
  Data: IncomeStatement[];
  RecordsCount: number;
}

export type IncomeStatement = {
  UniqueId:        string;
  JEnum:           string;
  LineItem:        string;
  DebCred:         string;
  AcctId:          string;
  Detail:          string;
  Location:        string;
  LocationID:      string;
  Region:          string;
  Territory:       string;
  LocationName:    string;
  LineAmount:      string;
  TotalAmount:     string;
  Quantity:        string;
  Date:            string;
  Type:            string;
  Reference:       string;
  CustomerId:      string;
  CustomerName1:   string;
  CustomerName2:   string;
  VendorId:        string;
  VendorName:      string;
  Source:          string;
  UserName:        string;
  Description:     string;
  FiscalMonth:     string;
  FiscalMonthName: string;
  FiscalDate:      string;
  FiscalYear:      string;
  TranDate:        string;
  GLAccountID:     string;
  GLAccountName:   string;
  AccountCategory: string;
  ReportCategory:  string;
}
