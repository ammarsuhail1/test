/** Vendor Credit Limit Manager App Item */
export interface VCLMItem {
  RowNumber?: string;
  /** Vendor Name */
  nagvcavdtdtv: string;
  /** Pending PO */
  nagvcavdtdtp1: string;
  /** Open PO */
  nagvcavdtdtp2: string;
  /** Open Credit */
  nagvcavdtdtp3: string;
  /** Credit Limit */
  nagvcavdtdtp4: string;
  /** Prepay */
  nagvcavdtdtp5: string;
}