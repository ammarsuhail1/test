export interface UserLocation {
  RowNumber: string;
  USERID: string;
  USERNAME: string;
  FIRSTNAME: string;
  LASTNAME: string;
  EMAILID: string;
  LOCATIONID: string;
}