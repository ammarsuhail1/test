export interface PurchaseReceipt {
  /** 
   * - Should always be `500337` For Assgined Location and Division Location (Negative Quantity)
   * - Should be the value of Vendor Id  from the parent contract (`NAG_SCM_AV_PO_PD_Ven`) 
   * for Division Location (Positive Quantity)
  */
  VendorID:             '500337' | string;
  /** 
   * - Release Number + `'-T`' for Assigned Location Purchase Receipt
   * - Release Number + `'-F`' for Division Location Negative Purchase Receipt
   * - Release Number for Division Location Positive Purchase Receipt
   */
  TicketNumber:         string;
  /** Date formatted as ISO string without time*/
  Shipdate:             string;
  /** Freight Type accepts two values
   * - `AD` : Actual total dollars
   * - `ED` : Estimated total dollars
   */
  FreightType:         'AD' | 'ED';
  /** - Freight Vendor ID from Release Manager for Assgined Location Purchase Receipt
   * - Empty string for Division Location Purchase Receipt
   */
  FreightVendorID:      string;
  /** - Freight from Release Manager for Assgined Location Purchase Receipt
  * - `0` for Division Location Purchase Receipt
  */
  FreightTotalDollars:  number;
  UseAgvanceAddons:     boolean;
  ReceiptDetail:        ReceiptDetail[];
  ReceiptAddOn?:        ReceiptAddOn[];
}

export interface ReceiptDetail {
  /** Corresponds to the Outbound Department Id*/
  DepartmentID:        string;
  ProductID:           string;
  /** Corresponds to the Product Name */
  ProductDescription?: string;
  /** Corresponds to Quantity Pulled (`NAG_LM_AV_LD_PD_AP`)
   * It's value is positive for Division Location (Positive quantity)
   * and negative for Division Location (Negative quantity)
   */
  Quantity?:           number;
  /** 
   * - Contract price from PO details of parent contract
   * for Division Location Purchase Receipt
   * - Location price from Release Manager
   * for Assgined Location Purchase Receipt */
  Cost:                string;
  Lotnum?:             string;
  /**
   * - PO Number value for Division Location (Positive quantity)
   * - Empty string for Division Location (Negative quantity) 
   * - Empty string for Assigned Location (Positive quantity) 
   */
  PONumber?:           string;
  POLineItem?:         number;
}

interface ReceiptAddOn {
  LineItem:     string;
  Rate?:        number;
  CalculateAs?: string;
  ApplyTo?:     string;
  GlAccount?:   string;
  Vendor?:      '500337';
  ChargeId:     string;
}