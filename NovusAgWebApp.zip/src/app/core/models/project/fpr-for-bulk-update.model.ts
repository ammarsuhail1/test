export interface FPRDataForBulkUpdate {
  FPRNumber: string;
  LocationName: string;
  LocationID: string;
  DepartmentID: string;
}