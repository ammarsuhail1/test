export interface UserGridItem {
  FirstName: string,
  UserName: string,
  LastName: string,
  EmailAddress: string,
  Phone: string,
  Status: string,
  DateLastModified: string,
  DateRegistered: string
}