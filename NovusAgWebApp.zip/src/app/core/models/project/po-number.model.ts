export interface PurchaseOrderAgvance {
  PONumber: string;
  VendorID: string;
  VendorName: string;
  TypeofContract: string;
  PullStartDate: string;
  PullEndDate: string;
  ProductName: string;
  ProductID: string;
  Quantity: string;
  Unit: string;
  Cost: string;
  FreightRate: string;
  DeliveryType: string;
  DateRequested: string;
  PickupDelivLocation: string;
  FilledYN: 'True' | 'False';
  PrepaidYN?: string | null;
  CompanyWide?: string | null;
  DropShip?: string | null;
  Generic?: string | null;
  DepartmentID: string;
  DepartmentName: string;
  LocationID: string;
  LocationName: string;
  Contractnumber: string; 
}

export interface PurchaseOrderMaster {
  nagpomavdtdtponum: string;
  nagpomavdtdtprod: string;
  nagpomavdtdtpid: string;
  nagpomavdtdtpend: string;
  nagpomavdtdtpstart: string;
  nagpomavdtdtquant: string;
  nagpomavdtdttype: string;
  nagpomavdtdtunit: string;
  nagpomavdtdtven: string;
  nagpomavdtdtdtype: string;
  nagpomavdtdtfrate: string;
  nagpomavdtdtdreq: string;
  nagpomavdtdtpdloc: string;
  nagpomavdtdtvid: string;
  nagpomavdtdtcost: string;
  nagpomavdtdtfilledyn: 'True' | 'False';
  nagpomavdtdtpdeptid: string;
  nagpomavdtdtpdeptnam: string;
  nagpomavdtdtlocid: string;
  nagpomavdtdtlocname: string;
  nagpomavdtdtvconn: string;
}