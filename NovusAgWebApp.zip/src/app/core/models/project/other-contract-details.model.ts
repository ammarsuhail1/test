export interface OtherContractDetails {
  QtyShipped: number;
  QtyCommitted: number;
  QtyExposed: number;
  Position: number;
  ReplCost?: number;
}