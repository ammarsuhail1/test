export interface RelatedIncentive {
  TRNSCTNID: string,
  RelIncentiveID: string,
  IncentiveID: string,
  IncentiveName: string,
  OfferedBy: string,
  EffectiveFrom: string,
  EffectiveTo: string,
  DiscountPer: string,
  DiscountDol: string,
  ThresholdMet: string,
  State: string,
}