export interface DeliveryTicket {
  TicketNumber:            number;
  LocationID:              number;
  TicketDate:              string;
  /** Mapped to Customer Id */
  GrowerID?:               string;
  FieldID?:                string;
  FieldGUID?:              string;
  Comments?:               string;
  MiniBulkTF?:             boolean;
  TicketType:              'Pickup' | 'Delivered';
  ShipVia?:                string;
  County?:                 string;
  Territory?:              string;
  /** Mapped to Customer Name */
  ShipTo:                  string;
  AdditionalComments?:     string;
  ControlNumber?:          string;
  SalesmanID?:             string;
  CustomAppliedTF?:        boolean;
  LoadedTF?:               boolean;
  CustomerPONumber?:       string;
  CropID?:                 string;
  FederalPermit?:          string;
  OnHoldTF?:               boolean;
  Acres?:                  number;
  AuthorizedAgent?:        string;
  RePackedTF?:             boolean;
  UnitType?:               string;
  ADPriority?:             number;
  LoadedDate?:             string;
  ADDateRequested?:        string;
  ADTimeRequested?:        string;
  AssignedToUserID?:       string;
  Signature?:              string;
  SignatureDateTimeStamp?: string;
  TicketSplitAdd:          TicketSplit[];
  TicketDetailAdd:         TicketDetail[];
  TicketApplicatorAdd?:    TicketApplicator[];
}

interface TicketApplicator {
  ApplicatorID?: string;
  VehicleID?:    string;
  Acres?:        number;
}

interface TicketDetail {
  DepartmentID:          string;
  ProductID:             string;
  ProductDescription?:   string;
  /** Corresponds to Quantity Pulled (`NAG_LM_AV_LD_PD_AP`) */
  Quantity?:             number;
  CropCode?:             string;
  LotNumber?:            string;
  /** Corresponds to Customer Price (`NAG_LM_AV_CD_PriceF`) */
  UnitPrice?:            number;
  ShipFromLocation?:     string;
  ShipFromDepartmentID?: string;
  PickedYN?:             boolean;
  PickedAmount?:         number;
  BackOrder?:            boolean;
  ContainerID?:          string;
}

interface TicketSplit {
  CustomerID:        string;
  SplitPercentage:   100;
  SplitPercentage2?: number;
  SplitPercentage3?: number;
}

export interface DeliveryTicketResponse {
  Status: 'OK' | 'Error';
  /** - Delivery ticket number if status is OK
   * - Error message if status is Error
   */
  Message: string;
}