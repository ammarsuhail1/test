export type SelectedCell = {
  plreportcategory: string;
  accountcategory: string;
  lineamount_Sum: number;
  month: number;
  type: LLCSection;
  column: LLCColumn;
}

export type LLCColumn = 'Actuals' | 'Budget' | 'Prior Year' | '% Sales Actual' | 'Variance To Budget' | 'Variance PY';

export type LLCSection = 'mtd' | 'ytd';

export type LLCViewPayload = {
  currentYear: number;
  priorYear: number;
  month: number;
  regions: string;
  territory: string;
  locations: string;
}

export type LLCViewResponse = Array<DataObject>;

export type LLCFiscalYear = {
  CurrentYear: string;
  MonthClosed: string;
  FiscalYearMonths: {
    FiscalYear: string;
    Months: string[];
  }[];
}

type DataObject = {
  ReportCategory: Category;
}

type Category = {
  Name: string;
  AccountCategory: Array<SubCategory>;
};


type SubCategory = {
  Name: string;
  Sections: {
    monthToDate: Section,
    yearToDate: Section,
  };
};

type Section = {
  actuals: number;
  budget: number;
  priorYear: number;
  salesActual: number;
  varianceToBudget: number;
  variancePY: number;
};

