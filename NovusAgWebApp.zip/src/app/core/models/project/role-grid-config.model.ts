export interface RoleGridConfig {
  userName: string;
  pageNum: number;
  pageSize: number;
  sortColumn: string;
  sortDir: string;
  columnNames: string;
  globalFilter: string;
  filters: string;
}