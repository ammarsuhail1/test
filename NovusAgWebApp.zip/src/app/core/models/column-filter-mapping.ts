export class ColumnFilterMapping {
}
