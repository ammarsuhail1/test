export class User {
    UserId: string;   
    UserName: string;
    Password: string;
    FirstName: string;
    LastName: string;
    FullName:string;
    TimeZone:number;
    Language: string;
    ListRole:any[];
    token: string;
    Roles: string[]

}