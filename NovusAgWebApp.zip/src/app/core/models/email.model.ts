export interface Email {
  MailSubject: string;
  MailBody: string;
  MailFrom: string;
  MailTo: string | string[];
  IsSMS: number; // 0 or 1
  TrnsctnId: number;
  MailKey?: string;
  [key: string]: any;
}