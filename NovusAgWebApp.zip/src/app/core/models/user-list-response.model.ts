export interface UserListResponse {
  code: string;
  status: 'SUCCESS' | 'FAIL';
  /** totalrecords is optional because it's not in the response if status === 'FAIL' */
  totalrecords?: number;
  /** data is optional because it's not in the response if status === 'FAIL' */
  data?: {
    UserInfo: {
      ManageUsers: Array<UserGridInfo> | UserGridInfo;
    };
  };
  /** message is optional because it's not in the response if status === 'SUCCESS' */
  message?: string;
}

export interface UserGridInfo {
  DateLastModified: string;
  DateRegistered: string;
  EmailAddress: string;
  FirstName: string;
  LastName: string;
  Phone: string;
  Status: string;
  UserId: string;
  UserName: string;
}