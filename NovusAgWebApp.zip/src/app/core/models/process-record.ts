export class processrecord{
    ParentTransactionID:string;
    ProcessName:string;
    StateName:string;
}