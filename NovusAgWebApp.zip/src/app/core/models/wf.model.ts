import { DmoType } from './dmos';

export interface WorkflowModel {
  FromEmail:      string;
  EmailSubject:   string;
  Version:        string;
  Stages:         { [stageGUID: string]: Stage };
  BusinessModels: BusinessModels;
  Roles:          Role;
  DisplayName:    string;
  Name:           string;
}

interface BusinessModels {
}

interface Role {
  [roleGUID: string]: {
    DisplayName: string;
    Name:        string;
  }
}

export interface Stage {
  States:      { [stateGUID: string]: State };
  Conditions:  { [key: string]: Condition };
  DisplayName: string;
  Name:        string;
}

type ConditionArea = 'DataModelGroup' | 'DataModelObject' | 'BusinessModelObject' | 'Trigger'


export interface Condition {
  Area:             ConditionArea;
  Level:            string;
  BusinessModelID:  string;
  IsEnabled?:       boolean;
  IsVisible?:       boolean;
  IsRequired?:      boolean;
  GUID:             string;
  ChildConditions:  {[key: string]: ChildCondition};
  ParentConditions: {[key: string]: ParentCondition};
  Name:             string;
}

export interface ChildCondition {
  Type:     DmoType;
  BmoGuid:  string;
  DmogGuid: string;
  Name:     string;
}


export interface ParentCondition {
  ConditionID:         string;
  ConditionExpression: 'equal' | 'not equal';
  Value:               string;
  LogicalOperator:     'AND' | 'OR';
  Type:                DmoType;
  BmoGuid:             string;
  DmogGuid:            string;
  Name:                string;
}

export interface State {
  SpecID:      string;
  EndState:    string;
  WfosType:    string;
  Roles:       { [roleGUID: string]: { Name: string } };
  Triggers:    { [triggerGUID: string]: Trigger };
  Conditions:  { [key: string]: Condition };
  DisplayName: string;
  Name:        string;
}


export interface Trigger {
  TriggerId:    string;
  Guid:         string;
  Type:         string;
  ActionName:   string;
  ActionRoles:  { [roleGUID: string]: { Name: string } };
  StartStage:   string;
  StartState:   string;
  Notification: Notification;
  Roles:        any;
  CcRoles:      any;
  Conditions:  { [key: string]: TriggerCondition };
  DisplayName:  string;
  Name:         string;
}

interface TriggerCondition {
  EndStage:      string;
  EndState:      string;
  EndStageGUID:  string;
  EndStateGUID:  string;
  Description:   string;
  Notification:  Notification;
  EmailDocument: string;
  EmailSubject:  string;
  Role:          any;
  Filter:        any;
  CCRole:        any;
  Name:          string;
}

interface Notification {
  ConfirmMessage?: string;
  Message:        string;
  Subject:        string;
}