export interface AlternateUser {
  UserId: number;
  UserName: string;
  RoleId: number;
  RoleName: string;
  RoleFriendlyName: string;
  OutOfOfficeUserId: number;
  OutOfOfficeUserName: string;
  OutOfOfficeUserEmailID: string;
}