import { BaseDmo } from "./base-dmo.model";

type DataSource = 'values' | 'json' | 'wfapigetdata' | 'c2miceapi';

export interface MultiSelectDropDownListDmo extends BaseDmo {
  DataSource: DataSource,
  Defaultvalue: string,
  IsMultiSelect: true,
  Options: string,
  Type: 'MultiSelectDropDownList',
}