export interface AppInfo {
  dId: string;
  Id: string;
  Name: string,
  DisplayName: string,
  AppUrl: string;
  ImageUrl: string;
  ShortDescription: string;
  LongDescription: string;
  Tags: string;
  Status: string;
  Type: string;
  AppType: string;
  ModifiedOn: string; 
}

export interface AppList {
  [type: string]: AppInfo[]
}