import { Component, OnInit, AfterViewInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { RouterOutlet } from '@angular/router';
import { LoaderComponent } from '@app/shared';
import { environment } from '@env/environment';
import { NovusService } from './core/services/novus.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html'
})

export class AppComponent implements OnInit, AfterViewInit {
  title = 'listingcms';
  public loaderComponent = LoaderComponent;
  public showShell = true;

  constructor(private titleService: Title, private novus: NovusService) {
    if (localStorage.AccessToken) {
      this.novus.getUsersByRole('NAG_Location_Admin').subscribe(roles => {
        // sessionStorage.setItem('locationAdmins', JSON.stringify(roles))
        localStorage.setItem('locationAdmins', JSON.stringify(roles))
      });
      // this.novus.getUsersByRole('NAG_Division_Admin').subscribe(roles => {
      //   // sessionStorage.setItem('divisionAdmins', JSON.stringify(roles))
      //   localStorage.setItem('divisionAdmins', JSON.stringify(roles))
      // });
    }
  }
  ngOnInit() {
    if (sessionStorage.getItem('DisplayName')) {
      const processtitle = sessionStorage.getItem('DisplayName');
      this.setDocTitle(processtitle);
    }

  }

  ngAfterViewInit() {}

  public onActivate() {
    const path = location.pathname;
    this.showShell = path !== '/llc-view';
  }

  setDocTitle(title: string) {
    this.titleService.setTitle(`${environment.projectTitle} | ${title}`);
 }
}
