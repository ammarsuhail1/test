import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { GridFilter } from '@app/core';
import { ConditionEvent, SortType } from '../column-filter/column-filter.component';

@Component({
  selector: 'app-detail-grid',
  templateUrl: './detail-grid.component.html',
  styleUrls: ['./detail-grid.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DetailGridComponent implements OnInit {
  @Input() dataSource: Record<string, any>[] = [];
  @Input() columns: ColumnData<any>[] = [];

  @Output() filtersUpdated = new EventEmitter<GridFilter[]>();
  @Output() sortedBy = new EventEmitter<string>();
  
  public filtersState: FiltersState = {};

  ngOnInit() {
    this.initFiltersState();
  }


  public onFilterUpdate(event: ConditionEvent | null, column: string) {
    if (event) {
      const filter: GridFilter = {
        DataField: column,
        FilterType: 'Column_Filter',
        LogicalOperator: event.logicalOperator || 'Or',
        GridConditions: [],
      };
      if (event.firstCondition) {
        filter.GridConditions.push(event.firstCondition);
      };
      if (event.secondCondition) {
        filter.GridConditions.push(event.secondCondition);
      }

      if (filter.GridConditions.length > 0) {
        this.filtersState[column].gridFilter = filter;
      } else {
        this.filtersState[column].gridFilter = null;
      }
    } else {
      this.filtersState[column].gridFilter = null;
    }
    console.log(this.filtersState[column])
    this.toggleColumnFilter(column);
    const updated = Object.values(this.filtersState)
      .map(col => col.gridFilter)
      .filter(filter => filter !== null);
    this.filtersUpdated.emit(updated);
  }

  public onSortUpdate(type: SortType, column: string) {
    this.toggleColumnFilter(column);
    const val = type === 'remove' ? '' : `${column} ${type}`;
    this.sortedBy.emit(val);
  }

  public onFilterClick(column: string, colFilter) {
    this.toggleColumnFilter(column);
  }

  private toggleColumnFilter(column: string) {
    this.filtersState[column].show = !this.filtersState[column].show;
    this.columns.forEach(({key}) => {
      if (key !== column) {
        this.filtersState[key].show = false;
      }
    })
  }

  private initFiltersState() {
    this.columns.forEach(({key}) => {
      this.filtersState[key] = {
        show: false,
        gridFilter: null,
      };
    });
  }


}

type FiltersState = {
  [column: string]: FilterState
}

type FilterState = {
  show: boolean,
  gridFilter: GridFilter,
}

type ColumnType = 'numeric' | 'string';
export type ColumnData<T> = {
  key: T,
  type: ColumnType,
  text: string,
};