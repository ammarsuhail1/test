import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { LLCColumn, LLCSection, LLCViewPayload, LLCViewResponse, SelectedCell } from '@app/core/models/project';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ExpandedViewComponent } from '../../containers/expanded-view/expanded-view.component';

@Component({
  selector: 'app-grid',
  templateUrl: './grid.component.html',
  styleUrls: ['./grid.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class GridComponent implements OnInit {
  @Input() data: LLCViewResponse;
  @Input() llcPayload: LLCViewPayload;

  private tableState = {};
  public columns = ['Actuals', 'Budget', 'Prior Year', '% Sales Actual', 'Variance To Budget', 'Variance PY'];
  public selectedCell: SelectedCell;

  constructor(private modal: NgbModal) { }

  ngOnInit(): void {
    this.initTableState();
    console.log(this)
  }

  private initTableState() {
    this.data.forEach(({ReportCategory: {Name}}) => {
      this.tableState[Name] = {};
      this.tableState[Name].expanded = true;
    })
  }

  public categoryExpanded(category: string): boolean {
    return this.tableState[category].expanded;
  }

  public toggleCategory(category: string) {
    this.tableState[category].expanded = !this.tableState[category].expanded;
  }

  public getTableTotalValues(category: string) {
    const dataObj = this.data.find(obj => obj.ReportCategory.Name === category);
    const total = dataObj.ReportCategory.AccountCategory.reduce((acc, {Sections: curr}) => {
      return {
        monthToDate: {
          actuals: acc.monthToDate.actuals + curr.monthToDate.actuals,
          budget: acc.monthToDate.budget + curr.monthToDate.budget,
          priorYear: acc.monthToDate.priorYear + curr.monthToDate.priorYear,
          salesActual: acc.monthToDate.salesActual + curr.monthToDate.salesActual, 
          varianceToBudget: acc.monthToDate.varianceToBudget + curr.monthToDate.varianceToBudget,
          variancePY: acc.monthToDate.variancePY + curr.monthToDate.variancePY,
        },
        yearToDate: {
          actuals: acc.yearToDate.actuals + curr.yearToDate.actuals,
          budget: acc.yearToDate.budget + curr.yearToDate.budget,
          priorYear: acc.yearToDate.priorYear + curr.yearToDate.priorYear,
          salesActual: acc.yearToDate.salesActual + curr.yearToDate.salesActual, 
          varianceToBudget: acc.yearToDate.varianceToBudget + curr.yearToDate.varianceToBudget,
          variancePY: acc.yearToDate.variancePY + curr.yearToDate.variancePY,
        },
      }
    }, 
    {
        monthToDate: {
          actuals: 0,
          budget: 0,
          priorYear: 0,
          salesActual: 0,
          varianceToBudget: 0,
          variancePY: 0,
        },
        yearToDate: {
          actuals: 0,
          budget: 0,
          priorYear: 0,
          salesActual: 0,
          varianceToBudget: 0,
          variancePY: 0,
        },
    });

    return {
      monthToDate: {
        ...total.monthToDate,
        salesActual: total.monthToDate.salesActual.toFixed(2),
      },
      yearToDate: {
        ...total.yearToDate,
        salesActual: total.yearToDate.salesActual.toFixed(2),
      },
    }
  }

  public setSelectedCell(val: number, column: LLCColumn, section: LLCSection, i: number, j: number, isTotal: boolean) {
    this.selectedCell = {
      plreportcategory: this.data[i].ReportCategory.Name,
      accountcategory: !isTotal ? this.data[i].ReportCategory.AccountCategory[j].Name : null,
      lineamount_Sum: val,
      // month: 5,
      month: this.llcPayload.month,
      column,
      type: section,
    }
    return {...this.selectedCell};
  }
  
  public openExandedView() {
    const modal = this.modal.open(ExpandedViewComponent, {windowClass: 'expanded-view-modal', keyboard: false, backdrop: 'static'});
    const component: ExpandedViewComponent = modal.componentInstance;
    component.llcPayload = this.llcPayload;
    component.selectedCell = this.selectedCell;
  }
}

