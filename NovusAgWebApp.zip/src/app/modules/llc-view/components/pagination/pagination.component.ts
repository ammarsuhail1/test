import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PaginationComponent implements OnInit {
  @Input() current: number = 1;
  @Input() step: number = 50;
  @Input() total: number = 0;

  @Output() pageChanged = new EventEmitter<number>();

  public hasPrevPage: boolean;
  public hasNextPage: boolean;
  private last: number;

  ngOnInit() {
    this.resetProps();
  }
  
  public onPageChange(pageNum: number) {
    this.resetProps();
    let num: number;
    if (!this.hasPrevPage && pageNum < this.current) {
      // Underflow to last
      num = this.last;
    } else if (!this.hasNextPage && pageNum > this.current) {
      // Overflow to first
      num = 1;
    } else {
      num = pageNum;
    }
    this.pageChanged.emit(num);
  }
  
  private resetProps() {
    this.last = Math.ceil(this.total / this.step);
    this.hasPrevPage = this.current > 1;
    this.hasNextPage = this.last > this.current;
  }

}
