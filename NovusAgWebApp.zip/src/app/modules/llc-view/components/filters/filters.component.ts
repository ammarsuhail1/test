import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { LLCFiscalYear, LLCViewPayload } from '@app/core/models/project';
import { debounceTime, takeWhile } from 'rxjs/operators';

@Component({
  selector: 'app-filters',
  templateUrl: './filters.component.html',
  styleUrls: ['./filters.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class FiltersComponent implements OnInit, OnDestroy {
  @Input() dates: LLCFiscalYear;
  @Input() userData: any;
  @Output() selectedFilters = new EventEmitter<LLCViewPayload>();

  private componentActive = true;
  
  form: FormGroup;

  months: Array<{id: number; text: string}>;
  years: string[];

  constructor(private fb: FormBuilder) {
    this.form = this.fb.group({
      year: [],
      month: [],
      region: [],
      territory: [],
      location: []
    });
  }

  ngOnInit() {
    this._constructDateDropdowns();
    this._initForm();
    this.form.get('year').valueChanges
      .pipe(takeWhile(_ => this.componentActive))
      .subscribe(year => {
        this._updateMonthDropdown(year);
        this.form.get('month').patchValue(this.months[0].id, {emitEvent: true});
      });
    this.form.valueChanges
      .pipe(
        takeWhile(_ => this.componentActive),
        debounceTime(500),
      )
      .subscribe(value => this._onNewValues(value));
  }

  private _initForm() {
    const initValues = {
      year: this.dates.CurrentYear,
      month: this.months[+this.dates.MonthClosed - 1].id,
      region: this.userData.region,
      territory: this.userData.territory,
      location: this.userData.location
    };
    this.form.patchValue(initValues);
    setTimeout(_ => this._onNewValues(this.form.value));
  }

  private _constructDateDropdowns() {
    const years = this.dates.FiscalYearMonths.map(item => item.FiscalYear);
    years.sort();
    this.years = years;
    if (years.length > 0) {
      this._updateMonthDropdown(years[years.length - 1]);
    }
  }

  private _updateMonthDropdown(year: string) {
    this.months = this.dates.FiscalYearMonths
      .find(item => item.FiscalYear === year).Months
      .map((month, i) => ({id: i + 1, text: month}));
  }

  private _onNewValues(formValue: any) {
    this.selectedFilters.emit({
      currentYear: formValue.year,
      priorYear: +formValue.year - 1,
      month: formValue.month,
      regions: this._handleSelectAll(formValue, 'region', 'item_text'),
      territory: this._handleSelectAll(formValue, 'territory', 'item_text'),
      locations: this._handleSelectAll(formValue, 'location', 'item_id'),
    });
  }

  private _handleSelectAll(formValue: any, name: string, bind: string) {
    const values = formValue[name][0] === 0 || formValue[name].length === 0 
      ? this.userData[name] 
      : formValue[name];
    return values.map(item => item[bind]).toString();
  }

  ngOnDestroy() {
    this.componentActive = false;
  }

}
