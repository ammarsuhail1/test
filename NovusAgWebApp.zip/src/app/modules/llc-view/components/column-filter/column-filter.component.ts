import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Condition, GridCondition } from '@app/core';

@Component({
  selector: 'app-column-filter',
  templateUrl: './column-filter.component.html',
  styleUrls: ['./column-filter.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ColumnFilterComponent implements OnInit {
  @Input() type: 'numeric' | 'string' = 'string';
  @Output() onConditions = new EventEmitter<ConditionEvent | null>();
  @Output() onSort = new EventEmitter<SortType>();
  private initFormValues = {
    condition1: 'CONTAINS',
    condition2: null,
    value1: null,
    value2: null,
    operator: 'And',
  };
  form: FormGroup;
  conditions: Array<FilterCondition> = [];
  removeSortEnabled = false;
  constructor(private fb: FormBuilder) {
    this.form = this.fb.group({
      condition1: ['CONTAINS'],
      value1: [''],
      operator: ['And'],
      condition2: [''],
      value2: [''],
    })
  }

  ngOnInit() {
    this.conditions = this.type === 'numeric' ? numericConditions : stringConditions;
  }

  public onSubmit() {
    let firstCondition: GridCondition;
    let secondCondition: GridCondition;
    let logicalOperator;
    const {condition1, condition2, value1, value2, operator} = this.form.value;
    if (condition1 && value1) {
      firstCondition = {Condition: condition1, ConditionValue: value1};
    }
    if (condition2 && value2) {
      secondCondition = {Condition: condition2, ConditionValue: value2};
      logicalOperator = operator;
    }
    this.onConditions.emit({logicalOperator, firstCondition, secondCondition})
  }
  
  public onClear() {
    this.onConditions.emit(null);
    this.form.reset();
    this.form.patchValue(this.initFormValues, {emitEvent: true});
  }

  public onSortClick(val: SortType) {
    this.onSort.emit(val);
    this.removeSortEnabled = val !== 'remove';
  }

}

export type SortType = 'asc' | 'desc' | 'remove';

type FilterCondition = {
  value: Condition;
  text: string;
}

export type ConditionEvent = {
  firstCondition: GridCondition | null,
  secondCondition: GridCondition | null,
  logicalOperator: 'And' | 'Or' | null;
}

const numericConditions: FilterCondition[]  = [
  { value: 'CONTAINS', text: 'Contains'},
  { value: 'STARTS_WITH', text: 'StartsWith'},
  { value: 'ENDS_WITH', text: 'EndsWith'},
  { value: 'EQUAL', text: '='},
  { value: 'NOT_EQUAL', text: '!='},
  { value: 'LESS_THAN', text: '<'},
  { value: 'GREATER_THAN', text: '>'},
];
const stringConditions: FilterCondition[] = [
  { value: 'CONTAINS', text: 'Contains'},
  { value: 'STARTS_WITH', text: 'StartsWith'},
  { value: 'ENDS_WITH', text: 'EndsWith'},
  { value: 'NULL', text: 'Null'},
  { value: 'NOT_NULL', text: 'NotNull'},
  { value: 'EQUAL', text: '='},
  { value: 'NOT_EQUAL', text: '!='},
];