import { ChangeDetectionStrategy, Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { MatOption } from '@angular/material';
import { BehaviorSubject } from 'rxjs';

@Component({
  selector: 'app-llc-dropdown',
  templateUrl: './llc-dropdown.component.html',
  styleUrls: ['./llc-dropdown.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LlcDropdownComponent implements OnInit {
  @Input() parentForm: FormGroup;
  @Input() controlName: string;
  @Input() data = [];
  @Input() bindText = 'item_text';

  public placeholder$ = new BehaviorSubject<string>('All');
  constructor() { }

  ngOnInit() {
    // Select all by default
    this.control.patchValue([0], {emitEvent: false});
  }

  get control() {
    return this.parentForm.get(this.controlName);
  }

  private updatePlaceholder(all: MatOption) {
    if (all.selected) {
      this.placeholder$.next('All');
      return;
    }
    if (this.control.value.length <= 2) {
      this.placeholder$.next(this.control.value.map(item => item[this.bindText]).toString());
    } else {
      this.placeholder$.next(`${this.control.value.length} selected`);
    }
  }

  public tosslePerOne(all: MatOption){ 
    if (all.selected) {  
     all.deselect();
     this.updatePlaceholder(all);
     return false;
    }
    this.updatePlaceholder(all);
    
  }
  public toggleAllSelection(all: MatOption) {
    if (all.selected) {
      this.control
      .patchValue([0], {emitEvent: false});
    } else {
      this.control.patchValue([], {emitEvent: false});
    }
    this.updatePlaceholder(all);
  }

  public onSelectClick(all: MatOption) {
    this.updatePlaceholder(all);
  }

}
