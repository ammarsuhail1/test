import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LlcDropdownComponent } from './llc-dropdown.component';

describe('LlcDropdownComponent', () => {
  let component: LlcDropdownComponent;
  let fixture: ComponentFixture<LlcDropdownComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LlcDropdownComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LlcDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
