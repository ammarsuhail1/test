import { AfterViewInit, Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[cell]'
})
export class CellDirective implements AfterViewInit {

  constructor(private el: ElementRef<HTMLTableDataCellElement>) { 
    
  }
  
  ngAfterViewInit() { 
    const cell = this.el.nativeElement;
    if (cell.innerText.startsWith('-')) {
        cell.innerText = `(${cell.innerText.slice(1)})`
        // cell.style.color = 'red';
      }
    }
}
