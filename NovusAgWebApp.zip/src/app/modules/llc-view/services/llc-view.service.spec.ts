import { TestBed } from '@angular/core/testing';

import { LlcViewService } from './llc-view.service';

describe('LlcViewService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LlcViewService = TestBed.get(LlcViewService);
    expect(service).toBeTruthy();
  });
});
