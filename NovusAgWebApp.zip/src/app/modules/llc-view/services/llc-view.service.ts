import { Injectable } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { UserService } from '@app/core';
import { IncomeStatementPayload, LLCViewPayload } from '@app/core/models/project';
import { NovusService } from '@app/core/services/novus.service';
import { SearchService } from '@app/core/services/search.service';
import { UtilityService } from '@app/core/services/utility.service';
import { forkJoin, NEVER } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';

@Injectable()
export class LlcViewService {

  constructor(
    private userService: UserService,
    private utility: UtilityService,
    private search: SearchService,
    private novus: NovusService,
    private route: ActivatedRoute,
    ) { }

  public getLLCViewData(payload: LLCViewPayload) {
    return this.novus.getLLCViewData(payload);
  }

  public getIncomeStatementDetails(payload: IncomeStatementPayload) {
    return this.novus.getLLCViewIncomeStatementDetails(payload);
  }

  public getDates() {
    return this.novus.getLLCViewFiscalYear();
  }

  public getFilterInformation() {
    return this.route.queryParams.pipe(
      map(params => params.uName || params.uname),
      switchMap(username => this.userService.getUserProfile(username)),
      switchMap(res => {
        if (!res && !res.data && res.data.Users) {
          return NEVER;
        }
        const user = res.data.Users;
        const regionIds = this._extractDropdownIds(user.Region);
        const territoryIds = this._extractDropdownIds(user.LLC);
        const locationIds = this._extractDropdownIds(user.Location);
        return forkJoin([
          this._getDownstreamRecords('Region', regionIds),
          this._getDownstreamRecords('LLC', territoryIds),
          this._getDownstreamRecords('Location', locationIds),
        ])
      }),
      map(res => {
        return {
          region: res[0],
          territory: res[1],
          location: res[2],
        }
      }),
    )
  }

  public exportToExcel(payload: IncomeStatementPayload) {
    return this.novus.llcViewExportToExcel(payload);
  }

  private _extractDropdownIds(obj: any = {}) {
    return Object.values(obj).map((v: string) => v.split(',')).flat();
  }

  private _constructGridConfigForDownstreamRecords(name: string, ids: Array<string>) {
    let item_id: string = DROPDOWNS[name].id;
    let item_text: string = DROPDOWNS[name].text;
    const config = this.utility.generateGridConfig({
      ProcessName: DROPDOWNS[name].processName,
      ColumnList: `${item_id},${item_text}`,
      SortOrder: 'asc',
      PageSize: -1,
      SortColumn: item_text,
      IsDistinct: true,
      IsColumnListOnly: true,
    });
    const filter = this.utility.generateGridFilter('Column_Filter', DROPDOWNS[name].id);   
    filter.GridConditions = ids.map(id => this.utility.generateGridCondition('EQUAL', id));
    config.GridFilters.push(filter);
    return config;
  }

  private _getDownstreamRecords(name: string, options: Array<string>) {
    const id: string = DROPDOWNS[name].id;
    const text: string = DROPDOWNS[name].text;
    const config = this._constructGridConfigForDownstreamRecords(name, options);
    return this.search.search(config).pipe(
      map(data => data.Data.map(item => ({item_id: item[id], item_text: item[text]}))),
    )
  }
}

const DROPDOWNS = {
  Region: {processName: 'NVS_MD_RegionMstr', dataField: '', upstreamProcess: '', id: 'dmoregionregncode', text: 'dmoregionregnnam',},
  LLC: {processName: 'NVS_MD_TERRITORY', dataField: 'dmoterirorytmsregion', upstreamProcess: 'Subregion', id: 'dmoterirorytmcode', text: 'dmoterirorytmname',},
  Location: {processName: 'NVS_MD_Location', dataField: 'dmolocationpfc', upstreamProcess: 'ProfitCenter', id: 'dmolcnlmcode', text: 'dmolcnlmname',},
};