import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LlcViewRoutingModule } from './llc-view-routing.module';
import { LlcMainComponent } from './containers/llc-main/llc-main.component'
import { CellDirective } from './directives/cell.directive';
import { MaterialModule } from '@app/shared/material.module';
import { FiltersComponent } from './components/filters/filters.component';
import { ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { GridComponent } from './components/grid/grid.component';
import { LlcViewService } from './services/llc-view.service';
import { LlcDropdownComponent } from './components/llc-dropdown/llc-dropdown.component';
import { NgbModalModule, NgbPopoverModule } from '@ng-bootstrap/ng-bootstrap';
import { ExpandedViewComponent } from './containers/expanded-view/expanded-view.component';
import { SummaryComponent } from './components/summary/summary.component';
import { ColumnFilterComponent } from './components/column-filter/column-filter.component';
import { DetailGridComponent } from './components/detail-grid/detail-grid.component';
import { PaginationComponent } from './components/pagination/pagination.component';
import { MatSelectModule } from '@angular/material';


@NgModule({
  declarations: [
    LlcMainComponent, 
    CellDirective, 
    FiltersComponent, 
    GridComponent, 
    LlcDropdownComponent, 
    ExpandedViewComponent, 
    SummaryComponent,
    ColumnFilterComponent,
    DetailGridComponent,
    PaginationComponent,
  ],
  imports: [
    CommonModule,
    LlcViewRoutingModule,
    ReactiveFormsModule,
    NgSelectModule,
    MatSelectModule,
    NgbPopoverModule,
    NgbModalModule,
  ],
  providers: [LlcViewService],
  entryComponents: [ExpandedViewComponent]
})
export class LlcViewModule { }
