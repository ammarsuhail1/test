import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LlcMainComponent } from './containers/llc-main/llc-main.component';


const routes: Routes = [{ path: '', component: LlcMainComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LlcViewRoutingModule { }
