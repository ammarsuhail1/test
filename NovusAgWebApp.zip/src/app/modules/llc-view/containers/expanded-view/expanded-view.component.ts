import { Component, Input, OnInit } from '@angular/core';
import { GridFilter } from '@app/core';
import { IncomeStatement, IncomeStatementPayload, LLCViewPayload, SelectedCell } from '@app/core/models/project';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ColumnData } from '../../components/detail-grid/detail-grid.component';
import { LlcViewService } from '../../services/llc-view.service';
import { saveAs } from 'file-saver';

@Component({
  selector: 'app-expanded-view',
  templateUrl: './expanded-view.component.html',
  styleUrls: ['./expanded-view.component.scss'],
})
export class ExpandedViewComponent implements OnInit {
  @Input() selectedCell: SelectedCell;
  @Input() llcPayload: LLCViewPayload;
  private ISPayload: IncomeStatementPayload = null;

  public fullScreen = false;
  public statements: IncomeStatement[];
  public recordsCount: number;
  public columns: ColumnData<ColumnKey>[] = [
    {key: 'UniqueId', text: 'UniqueId', type: 'numeric'}, 
    {key: 'JEnum', text: 'JEnum', type: 'numeric'}, 
    {key: 'LineItem', text: 'LineItem', type: 'numeric'}, 
    {key: 'DebCred', text: 'DebCred', type: 'string'}, 
    {key: 'AcctId', text: 'AcctId', type: 'string'}, 
    {key: 'Detail', text: 'Detail', type: 'string'}, 
    {key: 'Location', text: 'Location', type: 'string'}, 
    {key: 'LocationID', text: 'LocationID', type: 'string'}, 
    {key: 'Region', text: 'Region', type: 'string'}, 
    {key: 'Territory', text: 'Territory', type: 'string'}, 
    {key: 'LocationName', text: 'LocationName', type: 'string'}, 
    {key: 'LineAmount', text: 'LineAmount', type: 'numeric'}, 
    {key: 'TotalAmount', text: 'TotalAmount', type: 'numeric'}, 
    {key: 'Quantity', text: 'Quantity', type: 'numeric'}, 
    {key: 'Date', text: 'Date', type: 'numeric'}, 
    {key: 'Type', text: 'Type', type: 'string'}, 
    {key: 'Reference', text: 'Reference', type: 'string'}, 
    {key: 'CustomerId', text: 'CustomerId', type: 'string'}, 
    {key: 'CustomerName1', text: 'CustomerName1', type: 'string'}, 
    {key: 'CustomerName2', text: 'CustomerName2', type: 'string'}, 
    {key: 'VendorId', text: 'VendorId', type: 'string'}, 
    {key: 'VendorName', text: 'VendorName', type: 'string'}, 
    {key: 'Source', text: 'Source', type: 'string'}, 
    {key: 'UserName', text: 'UserName', type: 'string'}, 
    {key: 'Description', text: 'Description', type: 'string'}, 
    {key: 'FiscalMonth', text: 'FiscalMonth', type: 'numeric'}, 
    {key: 'FiscalMonthName', text: 'FiscalMonthName', type: 'string'}, 
    {key: 'FiscalDate', text: 'FiscalDate', type: 'numeric'}, 
    {key: 'FiscalYear', text: 'FiscalYear', type: 'numeric'}, 
    {key: 'TranDate', text: 'TranDate', type: 'numeric'}, 
    {key: 'GLAccountID', text: 'GLAccountID', type: 'string'}, 
    {key: 'GLAccountName', text: 'GLAccountName', type: 'string'}, 
    {key: 'AccountCategory', text: 'AccountCategory', type: 'string'}, 
    {key: 'ReportCategory', text: 'ReportCategory', type: 'string'}, 
  ];
  public view: View = 'summary';

  constructor(
    private llcViewService: LlcViewService,
    private activeModal: NgbActiveModal,
    ) { }

  ngOnInit() {
    this.ISPayload = {
      accountCategory: this.selectedCell.accountcategory || '',
      reportCategory: this.selectedCell.plreportcategory,
      // month: '5',
      // year: '2021',
      // parameterType: '',
      // locations: '',
      // territory: '',
      // regions: '',
      month: this.llcPayload.month.toString(),
      year: this.llcPayload.currentYear.toString(),
      parameterType: this.selectedCell.type,
      locations: this.llcPayload.locations,
      territory: this.llcPayload.territory,
      regions: this.llcPayload.regions,
      pageNo: 1, 
      pageSize: 50,
      sortColumn: '',
      gridFilters: [],
    };
  }

  public onViewSelect(view: View) {
    this.view = view;
    if (view === 'details') {
      this.getData();
    }
  }

  public onPageChange(pageNo: number) {
    this.ISPayload = {
      ...this.ISPayload,
      pageNo,
    };
    this.getData();
    }
  
  public onFiltersChange(filters: GridFilter[]) {
    this.ISPayload = {
      ...this.ISPayload,
      gridFilters: filters,
    };  
    this.getData();
  }
  
  public onSortChange(sortColumn: string) {
    this.ISPayload = {
      ...this.ISPayload,
      sortColumn,
      pageNo: 1,
    };  
    this.getData();
  }

  public toggleFullScreen() {
    this.fullScreen = !this.fullScreen;
    const dialog = document.querySelector('.modal-dialog');
    if (this.fullScreen) {
      dialog.classList.add('full-screen');
    } else {
      dialog.classList.remove('full-screen');
    }
  }

  public onExport() {
    const payload = {
      ...this.ISPayload,
      pageSize: -1,
      pageNo: -1,
    };
    this.llcViewService.exportToExcel(payload).subscribe(data => saveAs(data, 'DashboardExcel_PivotDrillDownGrid'));
  }

  public closeView() {
    this.activeModal.close();
  }

  private getData() {
    this.llcViewService.getIncomeStatementDetails(this.ISPayload)
      .subscribe(data => {
        this.statements = data.Data;
        this.recordsCount = +data.RecordsCount
      });
  }

}

type View = 'summary' | 'details';
type ColumnKey = keyof IncomeStatement;