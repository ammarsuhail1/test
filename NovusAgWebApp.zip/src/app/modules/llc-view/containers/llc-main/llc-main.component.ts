import { ChangeDetectionStrategy, Component, OnInit } from '@angular/core';
import { LLCFiscalYear, LLCViewPayload, LLCViewResponse } from '@app/core/models/project';
import { Observable, of } from 'rxjs';
import { LlcViewService } from '../../services/llc-view.service';

@Component({
  selector: 'app-llc-main',
  templateUrl: './llc-main.component.html',
  styleUrls: ['./llc-main.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LlcMainComponent implements OnInit {
  public userData$: Observable<any>; 
  public dates$: Observable<LLCFiscalYear>;
  public data$: Observable<LLCViewResponse>;
  public currentPayload: LLCViewPayload = null;

  constructor(private service: LlcViewService) {}
  
  ngOnInit() {
    this.userData$ = this.service.getFilterInformation();
    this.dates$ = this.service.getDates();
    // this.data$ = of(DATA);
  }

  public onSelectFilters(payload: LLCViewPayload) {
    this.currentPayload = payload;
    this.data$ = this.service.getLLCViewData(payload);
  }


}

// const DATA = [
//   {
//     "ReportCategory": {
//       "Name": "1. Sales",
//       "AccountCategory": [
//         {
//           "Name": " 1. Fertilizer",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 11630923.0,
//               "budget": 13032065.0,
//               "priorYear": 10371180.0,
//               "salesActual": 26.13,
//               "varianceToBudget": -1401142.0,
//               "variancePY": 1259743.0
//             },
//             "yearToDate": {
//               "actuals": 51851225.0,
//               "budget": 59921954.0,
//               "priorYear": 47068749.0,
//               "salesActual": 36.93,
//               "varianceToBudget": -8070729.0,
//               "variancePY": 4782476.22
//             }
//           }
//         },
//         {
//           "Name": " 2. Crop Protection ",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 19750250.0,
//               "budget": 17582263.0,
//               "priorYear": 11631427.0,
//               "salesActual": 44.37,
//               "varianceToBudget": 2167988.0,
//               "variancePY": 8118824.0
//             },
//             "yearToDate": {
//               "actuals": 61136574.0,
//               "budget": 46427632.0,
//               "priorYear": 32414458.0,
//               "salesActual": 43.55,
//               "varianceToBudget": 14708942.0,
//               "variancePY": 28722116.28
//             }
//           }
//         },
//         {
//           "Name": " 3. Seed",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 6431425.0,
//               "budget": 4591845.0,
//               "priorYear": 4139217.0,
//               "salesActual": 14.45,
//               "varianceToBudget": 1839580.0,
//               "variancePY": 2292208.0
//             },
//             "yearToDate": {
//               "actuals": 12742021.0,
//               "budget": 17611367.0,
//               "priorYear": 14225444.0,
//               "salesActual": 9.08,
//               "varianceToBudget": -4869346.0,
//               "variancePY": -1483422.63
//             }
//           }
//         },
//         {
//           "Name": " 4. Nutritional ",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 3792369.0,
//               "budget": 2583934.0,
//               "priorYear": 1953660.0,
//               "salesActual": 8.52,
//               "varianceToBudget": 1208435.0,
//               "variancePY": 1838708.0
//             },
//             "yearToDate": {
//               "actuals": 7473225.0,
//               "budget": 5405892.0,
//               "priorYear": 4077640.0,
//               "salesActual": 5.32,
//               "varianceToBudget": 2067334.0,
//               "variancePY": 3395585.0
//             }
//           }
//         },
//         {
//           "Name": " 5. Application",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 2562566.0,
//               "budget": 1906400.0,
//               "priorYear": 1745549.0,
//               "salesActual": 5.76,
//               "varianceToBudget": 656166.0,
//               "variancePY": 817017.0
//             },
//             "yearToDate": {
//               "actuals": 6548239.0,
//               "budget": 5525213.0,
//               "priorYear": 5013008.0,
//               "salesActual": 4.66,
//               "varianceToBudget": 1023026.0,
//               "variancePY": 1535231.66
//             }
//           }
//         },
//         {
//           "Name": " 6. Miscellaneous",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 393450.0,
//               "budget": 0.0,
//               "priorYear": 17495.0,
//               "salesActual": 0.88,
//               "varianceToBudget": 393450.0,
//               "variancePY": 375955.0
//             },
//             "yearToDate": {
//               "actuals": 1373139.0,
//               "budget": 0.0,
//               "priorYear": 273692.0,
//               "salesActual": 0.98,
//               "varianceToBudget": 1373139.0,
//               "variancePY": 1099446.9
//             }
//           }
//         },
//         {
//           "Name": " 7. Sales Discounts",
//           "Sections": {
//             "monthToDate": {
//               "actuals": -50923.0,
//               "budget": 0.0,
//               "priorYear": 52083.0,
//               "salesActual": -0.11,
//               "varianceToBudget": -50923.0,
//               "variancePY": -103006.0
//             },
//             "yearToDate": {
//               "actuals": -730921.0,
//               "budget": 0.0,
//               "priorYear": -77159.0,
//               "salesActual": -0.52,
//               "varianceToBudget": -730921.0,
//               "variancePY": -653761.47
//             }
//           }
//         }
//       ]
//     }
//   },
//   {
//     "ReportCategory": {
//       "Name": "2. COGs",
//       "AccountCategory": [
//         {
//           "Name": " 8. Fertilizer",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 8024183.0,
//               "budget": 10663898.0,
//               "priorYear": 8706258.0,
//               "salesActual": 68.99,
//               "varianceToBudget": -2639714.0,
//               "variancePY": -682075.0
//             },
//             "yearToDate": {
//               "actuals": 40622002.0,
//               "budget": 47495419.0,
//               "priorYear": 38288581.0,
//               "salesActual": 78.34,
//               "varianceToBudget": -6873416.0,
//               "variancePY": 2333421.18
//             }
//           }
//         },
//         {
//           "Name": " 9. Crop Protection ",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 20506024.0,
//               "budget": 11177294.0,
//               "priorYear": 11905980.0,
//               "salesActual": 103.83,
//               "varianceToBudget": 9328730.0,
//               "variancePY": 8600044.0
//             },
//             "yearToDate": {
//               "actuals": 65077580.0,
//               "budget": 37426440.0,
//               "priorYear": 36558865.0,
//               "salesActual": 106.45,
//               "varianceToBudget": 27651140.0,
//               "variancePY": 28518714.53
//             }
//           }
//         },
//         {
//           "Name": "10. Seed",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 6102052.0,
//               "budget": 3054635.0,
//               "priorYear": 4288877.0,
//               "salesActual": 94.88,
//               "varianceToBudget": 3047417.0,
//               "variancePY": 1813175.0
//             },
//             "yearToDate": {
//               "actuals": 13166007.0,
//               "budget": 15856971.0,
//               "priorYear": 14921524.0,
//               "salesActual": 103.33,
//               "varianceToBudget": -2690965.0,
//               "variancePY": -1755517.1
//             }
//           }
//         },
//         {
//           "Name": "11. Nutritional ",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 2380193.0,
//               "budget": 1624200.0,
//               "priorYear": 1371371.0,
//               "salesActual": 62.76,
//               "varianceToBudget": 755992.0,
//               "variancePY": 1008822.0
//             },
//             "yearToDate": {
//               "actuals": 4953355.0,
//               "budget": 2726552.0,
//               "priorYear": 2538112.0,
//               "salesActual": 66.28,
//               "varianceToBudget": 2226803.0,
//               "variancePY": 2415243.87
//             }
//           }
//         },
//         {
//           "Name": "12. Application ",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 619960.0,
//               "budget": 289619.0,
//               "priorYear": 362000.0,
//               "salesActual": 24.19,
//               "varianceToBudget": 330341.0,
//               "variancePY": 257960.0
//             },
//             "yearToDate": {
//               "actuals": 1388115.0,
//               "budget": 576945.0,
//               "priorYear": 768046.0,
//               "salesActual": 21.2,
//               "varianceToBudget": 811170.0,
//               "variancePY": 620069.01
//             }
//           }
//         },
//         {
//           "Name": "13. Miscellaneous",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 484550.0,
//               "budget": 0.0,
//               "priorYear": 21384.0,
//               "salesActual": 123.15,
//               "varianceToBudget": 484550.0,
//               "variancePY": 463166.0
//             },
//             "yearToDate": {
//               "actuals": 853945.0,
//               "budget": 0.0,
//               "priorYear": 107370.0,
//               "salesActual": 62.19,
//               "varianceToBudget": 853945.0,
//               "variancePY": 746574.66
//             }
//           }
//         }
//       ]
//     }
//   },
//   {
//     "ReportCategory": {
//       "Name": "3. Rebates",
//       "AccountCategory": [
//         {
//           "Name": " 8. Fertilizer",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 0.0,
//               "budget": 0.0,
//               "priorYear": 0.0,
//               "salesActual": 0.0,
//               "varianceToBudget": 0.0,
//               "variancePY": 0.0
//             },
//             "yearToDate": {
//               "actuals": 0.0,
//               "budget": -13340.0,
//               "priorYear": -12650.0,
//               "salesActual": 0.0,
//               "varianceToBudget": 13340.0,
//               "variancePY": 12649.59
//             }
//           }
//         },
//         {
//           "Name": " 9. Crop Protection ",
//           "Sections": {
//             "monthToDate": {
//               "actuals": -4785229.0,
//               "budget": -4266155.0,
//               "priorYear": -3935653.0,
//               "salesActual": -24.23,
//               "varianceToBudget": -519073.0,
//               "variancePY": -849575.0
//             },
//             "yearToDate": {
//               "actuals": -15941135.0,
//               "budget": -14116581.0,
//               "priorYear": -13747630.0,
//               "salesActual": -26.07,
//               "varianceToBudget": -1824553.0,
//               "variancePY": -2193505.15
//             }
//           }
//         },
//         {
//           "Name": "10. Seed",
//           "Sections": {
//             "monthToDate": {
//               "actuals": -1016751.0,
//               "budget": -1518651.0,
//               "priorYear": -581342.0,
//               "salesActual": -15.81,
//               "varianceToBudget": 501900.0,
//               "variancePY": -435409.0
//             },
//             "yearToDate": {
//               "actuals": -1976561.0,
//               "budget": -2944809.0,
//               "priorYear": -3354668.0,
//               "salesActual": -15.51,
//               "varianceToBudget": 968248.0,
//               "variancePY": 1378107.08
//             }
//           }
//         }
//       ]
//     }
//   },
//   {
//     "ReportCategory": {
//       "Name": "4. Gross Profit",
//       "AccountCategory": [
//         {
//           "Name": " 1. Fertilizer",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 3606740.0,
//               "budget": 2170376.0,
//               "priorYear": 1664922.0,
//               "salesActual": 31.01,
//               "varianceToBudget": 1436364.0,
//               "variancePY": 1941818.0
//             },
//             "yearToDate": {
//               "actuals": 11229223.0,
//               "budget": 11737304.0,
//               "priorYear": 8792817.0,
//               "salesActual": 21.66,
//               "varianceToBudget": -508081.0,
//               "variancePY": 2436405.45
//             }
//           }
//         },
//         {
//           "Name": " 2. Crop Protection",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 4029455.0,
//               "budget": 10671124.0,
//               "priorYear": 3661100.0,
//               "salesActual": 20.4,
//               "varianceToBudget": -6641669.0,
//               "variancePY": 368355.0
//             },
//             "yearToDate": {
//               "actuals": 12000129.0,
//               "budget": 23117774.0,
//               "priorYear": 9603222.0,
//               "salesActual": 19.63,
//               "varianceToBudget": -11117645.0,
//               "variancePY": 2396906.9
//             }
//           }
//         },
//         {
//           "Name": " 3. Seed",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 1346124.0,
//               "budget": 3055861.0,
//               "priorYear": 431683.0,
//               "salesActual": 20.93,
//               "varianceToBudget": -1709737.0,
//               "variancePY": 914442.0
//             },
//             "yearToDate": {
//               "actuals": 1552575.0,
//               "budget": 4699205.0,
//               "priorYear": 2658588.0,
//               "salesActual": 12.18,
//               "varianceToBudget": -3146629.0,
//               "variancePY": -1106012.61
//             }
//           }
//         },
//         {
//           "Name": " 4. Nutritional",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 1412176.0,
//               "budget": 959733.0,
//               "priorYear": 582289.0,
//               "salesActual": 37.24,
//               "varianceToBudget": 452443.0,
//               "variancePY": 829887.0
//             },
//             "yearToDate": {
//               "actuals": 2519870.0,
//               "budget": 2679339.0,
//               "priorYear": 1539529.0,
//               "salesActual": 33.72,
//               "varianceToBudget": -159469.0,
//               "variancePY": 980341.13
//             }
//           }
//         },
//         {
//           "Name": " 5. Application",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 1942606.0,
//               "budget": 1616781.0,
//               "priorYear": 1383549.0,
//               "salesActual": 75.81,
//               "varianceToBudget": 325825.0,
//               "variancePY": 559057.0
//             },
//             "yearToDate": {
//               "actuals": 5160125.0,
//               "budget": 4948268.0,
//               "priorYear": 4244962.0,
//               "salesActual": 78.8,
//               "varianceToBudget": 211857.0,
//               "variancePY": 915162.65
//             }
//           }
//         },
//         {
//           "Name": " 6. Miscellaneous",
//           "Sections": {
//             "monthToDate": {
//               "actuals": -91101.0,
//               "budget": 0.0,
//               "priorYear": -3889.0,
//               "salesActual": -23.15,
//               "varianceToBudget": -91101.0,
//               "variancePY": -87211.0
//             },
//             "yearToDate": {
//               "actuals": 519194.0,
//               "budget": 0.0,
//               "priorYear": 166322.0,
//               "salesActual": 37.81,
//               "varianceToBudget": 519194.0,
//               "variancePY": 352872.24
//             }
//           }
//         },
//         {
//           "Name": " 7. Sales Discounts",
//           "Sections": {
//             "monthToDate": {
//               "actuals": -50923.0,
//               "budget": 0.0,
//               "priorYear": 52083.0,
//               "salesActual": 100.0,
//               "varianceToBudget": -50923.0,
//               "variancePY": -103006.0
//             },
//             "yearToDate": {
//               "actuals": -730921.0,
//               "budget": 0.0,
//               "priorYear": -77159.0,
//               "salesActual": 100.0,
//               "varianceToBudget": -730921.0,
//               "variancePY": -653761.47
//             }
//           }
//         }
//       ]
//     }
//   },
//   {
//     "ReportCategory": {
//       "Name": "5. Operating Expenses (Payroll)",
//       "AccountCategory": [
//         {
//           "Name": "14. Salaries",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 1070297.0,
//               "budget": 818725.0,
//               "priorYear": 940161.0,
//               "salesActual": 2.4,
//               "varianceToBudget": 251572.0,
//               "variancePY": 130136.0
//             },
//             "yearToDate": {
//               "actuals": 5560610.0,
//               "budget": 4742318.0,
//               "priorYear": 5428146.0,
//               "salesActual": 3.96,
//               "varianceToBudget": 818293.0,
//               "variancePY": 132464.54
//             }
//           }
//         },
//         {
//           "Name": "15. Hourly Wages",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 540830.0,
//               "budget": 485386.0,
//               "priorYear": 545529.0,
//               "salesActual": 1.22,
//               "varianceToBudget": 55444.0,
//               "variancePY": -4699.0
//             },
//             "yearToDate": {
//               "actuals": 2554908.0,
//               "budget": 2236699.0,
//               "priorYear": 2549750.0,
//               "salesActual": 1.82,
//               "varianceToBudget": 318209.0,
//               "variancePY": 5157.62
//             }
//           }
//         },
//         {
//           "Name": "16. Other (Payroll)",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 159943.0,
//               "budget": 136192.0,
//               "priorYear": 156636.0,
//               "salesActual": 0.36,
//               "varianceToBudget": 23750.0,
//               "variancePY": 3306.0
//             },
//             "yearToDate": {
//               "actuals": 1225896.0,
//               "budget": 829761.0,
//               "priorYear": 946127.0,
//               "salesActual": 0.87,
//               "varianceToBudget": 396134.0,
//               "variancePY": 279768.94
//             }
//           }
//         },
//         {
//           "Name": "17. Overtime",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 252908.0,
//               "budget": 242449.0,
//               "priorYear": 281683.0,
//               "salesActual": 0.57,
//               "varianceToBudget": 10459.0,
//               "variancePY": -28775.0
//             },
//             "yearToDate": {
//               "actuals": 863797.0,
//               "budget": 840803.0,
//               "priorYear": 960638.0,
//               "salesActual": 0.62,
//               "varianceToBudget": 22994.0,
//               "variancePY": -96840.9
//             }
//           }
//         },
//         {
//           "Name": "18. Incentives",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 15000.0,
//               "budget": 0.0,
//               "priorYear": 0.0,
//               "salesActual": 0.03,
//               "varianceToBudget": 15000.0,
//               "variancePY": 15000.0
//             },
//             "yearToDate": {
//               "actuals": 641064.0,
//               "budget": 138144.0,
//               "priorYear": 160304.0,
//               "salesActual": 0.46,
//               "varianceToBudget": 502920.0,
//               "variancePY": 480759.95
//             }
//           }
//         },
//         {
//           "Name": "19. Benefits",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 357214.0,
//               "budget": 247234.0,
//               "priorYear": 283343.0,
//               "salesActual": 0.8,
//               "varianceToBudget": 109980.0,
//               "variancePY": 73871.0
//             },
//             "yearToDate": {
//               "actuals": 1685493.0,
//               "budget": 1441126.0,
//               "priorYear": 1176450.0,
//               "salesActual": 1.2,
//               "varianceToBudget": 244367.0,
//               "variancePY": 509042.81
//             }
//           }
//         }
//       ]
//     }
//   },
//   {
//     "ReportCategory": {
//       "Name": "6. Operating Expenses (General)",
//       "AccountCategory": [
//         {
//           "Name": "20. Professional Services",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 305641.0,
//               "budget": 30408.0,
//               "priorYear": 39391.0,
//               "salesActual": 0.69,
//               "varianceToBudget": 275233.0,
//               "variancePY": 266250.0
//             },
//             "yearToDate": {
//               "actuals": 713789.0,
//               "budget": 738973.0,
//               "priorYear": 741435.0,
//               "salesActual": 0.51,
//               "varianceToBudget": -25184.0,
//               "variancePY": -27646.24
//             }
//           }
//         },
//         {
//           "Name": "21. Fees",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 47417.0,
//               "budget": 30974.0,
//               "priorYear": 28673.0,
//               "salesActual": 0.11,
//               "varianceToBudget": 16442.0,
//               "variancePY": 18744.0
//             },
//             "yearToDate": {
//               "actuals": 126742.0,
//               "budget": 85911.0,
//               "priorYear": 78555.0,
//               "salesActual": 0.09,
//               "varianceToBudget": 40831.0,
//               "variancePY": 48187.33
//             }
//           }
//         },
//         {
//           "Name": "22. Travel & Entertainment",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 68420.0,
//               "budget": 28807.0,
//               "priorYear": 26662.0,
//               "salesActual": 0.15,
//               "varianceToBudget": 39613.0,
//               "variancePY": 41758.0
//             },
//             "yearToDate": {
//               "actuals": 431567.0,
//               "budget": 765255.0,
//               "priorYear": 722111.0,
//               "salesActual": 0.31,
//               "varianceToBudget": -333688.0,
//               "variancePY": -290544.06
//             }
//           }
//         },
//         {
//           "Name": "23. Rolling Stock (R&M, Fuel) ",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 435001.0,
//               "budget": 238323.0,
//               "priorYear": 253466.0,
//               "salesActual": 0.98,
//               "varianceToBudget": 196678.0,
//               "variancePY": 181534.0
//             },
//             "yearToDate": {
//               "actuals": 1966925.0,
//               "budget": 1301127.0,
//               "priorYear": 1376296.0,
//               "salesActual": 1.4,
//               "varianceToBudget": 665799.0,
//               "variancePY": 590629.8
//             }
//           }
//         },
//         {
//           "Name": "24. Plant (R&M, Fuel) ",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 210209.0,
//               "budget": 209848.0,
//               "priorYear": 205487.0,
//               "salesActual": 0.47,
//               "varianceToBudget": 361.0,
//               "variancePY": 4722.0
//             },
//             "yearToDate": {
//               "actuals": 1352923.0,
//               "budget": 1121840.0,
//               "priorYear": 1140498.0,
//               "salesActual": 0.96,
//               "varianceToBudget": 231084.0,
//               "variancePY": 212424.98
//             }
//           }
//         },
//         {
//           "Name": "25. Rent",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 331741.0,
//               "budget": 205794.0,
//               "priorYear": 403657.0,
//               "salesActual": 0.75,
//               "varianceToBudget": 125947.0,
//               "variancePY": -71916.0
//             },
//             "yearToDate": {
//               "actuals": 915572.0,
//               "budget": 906962.0,
//               "priorYear": 1494709.0,
//               "salesActual": 0.65,
//               "varianceToBudget": 8609.0,
//               "variancePY": -579136.81
//             }
//           }
//         },
//         {
//           "Name": "26. Lease Expense",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 863873.0,
//               "budget": 40987.0,
//               "priorYear": 384962.0,
//               "salesActual": 1.94,
//               "varianceToBudget": 822886.0,
//               "variancePY": 478911.0
//             },
//             "yearToDate": {
//               "actuals": 3765085.0,
//               "budget": 81801.0,
//               "priorYear": 1302591.0,
//               "salesActual": 2.68,
//               "varianceToBudget": 3683284.0,
//               "variancePY": 2462494.11
//             }
//           }
//         },
//         {
//           "Name": "27. Office",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 24236.0,
//               "budget": 39576.0,
//               "priorYear": 40101.0,
//               "salesActual": 0.05,
//               "varianceToBudget": -15340.0,
//               "variancePY": -15866.0
//             },
//             "yearToDate": {
//               "actuals": 243240.0,
//               "budget": 265164.0,
//               "priorYear": 269130.0,
//               "salesActual": 0.17,
//               "varianceToBudget": -21924.0,
//               "variancePY": -25890.32
//             }
//           }
//         },
//         {
//           "Name": "28. Utilities ",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 44007.0,
//               "budget": 35135.0,
//               "priorYear": 36817.0,
//               "salesActual": 0.1,
//               "varianceToBudget": 8873.0,
//               "variancePY": 7190.0
//             },
//             "yearToDate": {
//               "actuals": 196488.0,
//               "budget": 198330.0,
//               "priorYear": 207690.0,
//               "salesActual": 0.14,
//               "varianceToBudget": -1842.0,
//               "variancePY": -11201.97
//             }
//           }
//         },
//         {
//           "Name": "29. Computer",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 64339.0,
//               "budget": 48348.0,
//               "priorYear": 51953.0,
//               "salesActual": 0.14,
//               "varianceToBudget": 15991.0,
//               "variancePY": 12387.0
//             },
//             "yearToDate": {
//               "actuals": 404235.0,
//               "budget": 266149.0,
//               "priorYear": 287586.0,
//               "salesActual": 0.29,
//               "varianceToBudget": 138085.0,
//               "variancePY": 116649.08
//             }
//           }
//         },
//         {
//           "Name": "30. Communications",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 33816.0,
//               "budget": 25540.0,
//               "priorYear": 25689.0,
//               "salesActual": 0.08,
//               "varianceToBudget": 8276.0,
//               "variancePY": 8127.0
//             },
//             "yearToDate": {
//               "actuals": 160635.0,
//               "budget": 150271.0,
//               "priorYear": 153576.0,
//               "salesActual": 0.11,
//               "varianceToBudget": 10365.0,
//               "variancePY": 7059.27
//             }
//           }
//         },
//         {
//           "Name": "31. Safety & Operations",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 26786.0,
//               "budget": 11733.0,
//               "priorYear": 12237.0,
//               "salesActual": 0.06,
//               "varianceToBudget": 15054.0,
//               "variancePY": 14549.0
//             },
//             "yearToDate": {
//               "actuals": 113733.0,
//               "budget": 118525.0,
//               "priorYear": 122300.0,
//               "salesActual": 0.08,
//               "varianceToBudget": -4792.0,
//               "variancePY": -8567.17
//             }
//           }
//         },
//         {
//           "Name": "32. Insurance",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 263727.0,
//               "budget": -237588.0,
//               "priorYear": 255049.0,
//               "salesActual": 0.59,
//               "varianceToBudget": 501315.0,
//               "variancePY": 8678.0
//             },
//             "yearToDate": {
//               "actuals": 1173471.0,
//               "budget": -1142833.0,
//               "priorYear": 1206941.0,
//               "salesActual": 0.84,
//               "varianceToBudget": 2316304.0,
//               "variancePY": -33470.23
//             }
//           }
//         },
//         {
//           "Name": "33. Taxes & Licenses",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 50712.0,
//               "budget": 53763.0,
//               "priorYear": 42060.0,
//               "salesActual": 0.11,
//               "varianceToBudget": -3051.0,
//               "variancePY": 8652.0
//             },
//             "yearToDate": {
//               "actuals": 352817.0,
//               "budget": 349442.0,
//               "priorYear": 261587.0,
//               "salesActual": 0.25,
//               "varianceToBudget": 3375.0,
//               "variancePY": 91230.19
//             }
//           }
//         },
//         {
//           "Name": "34. Advertising",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 7683.0,
//               "budget": 17628.0,
//               "priorYear": 18407.0,
//               "salesActual": 0.02,
//               "varianceToBudget": -9945.0,
//               "variancePY": -10724.0
//             },
//             "yearToDate": {
//               "actuals": 94981.0,
//               "budget": 195732.0,
//               "priorYear": 187779.0,
//               "salesActual": 0.07,
//               "varianceToBudget": -100751.0,
//               "variancePY": -92798.2
//             }
//           }
//         },
//         {
//           "Name": "35. Loss & Damage Claims",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 0.0,
//               "budget": 0.0,
//               "priorYear": -50000.0,
//               "salesActual": 0.0,
//               "varianceToBudget": 0.0,
//               "variancePY": 50000.0
//             },
//             "yearToDate": {
//               "actuals": 37649.0,
//               "budget": 0.0,
//               "priorYear": 13948.0,
//               "salesActual": 0.03,
//               "varianceToBudget": 37649.0,
//               "variancePY": 23700.61
//             }
//           }
//         },
//         {
//           "Name": "36. Other - Operating Expense",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 2183795.0,
//               "budget": 775208.0,
//               "priorYear": 525119.0,
//               "salesActual": 4.91,
//               "varianceToBudget": 1408587.0,
//               "variancePY": 1658676.0
//             },
//             "yearToDate": {
//               "actuals": -3466691.0,
//               "budget": 2268144.0,
//               "priorYear": -3216396.0,
//               "salesActual": -2.47,
//               "varianceToBudget": -5734835.0,
//               "variancePY": -250295.1
//             }
//           }
//         }
//       ]
//     }
//   },
//   {
//     "ReportCategory": {
//       "Name": "Fertlizer Cost Per Ton",
//       "AccountCategory": [
//         {
//           "Name": "Fertlizer Cost Per Ton",
//           "Sections": {
//             "monthToDate": {
//               "actuals": 196.0,
//               "budget": 0.0,
//               "priorYear": 247.0,
//               "salesActual": 0.0,
//               "varianceToBudget": 8024183.0,
//               "variancePY": -51.0
//             },
//             "yearToDate": {
//               "actuals": 199.0,
//               "budget": 0.0,
//               "priorYear": 327.0,
//               "salesActual": 0.0,
//               "varianceToBudget": 40622002.0,
//               "variancePY": -128.0
//             }
//           }
//         }
//       ]
//     }
//   },
//   {
//     "ReportCategory": {
//       "Name": "LLC Net Commission",
//       "AccountCategory": [
//         {
//           "Name": "LLC Net Commission",
//           "Sections": {
//             "monthToDate": {
//               "actuals": -1850461.0,
//               "budget": 2159813.0,
//               "priorYear": 2559337.0,
//               "salesActual": -4.16,
//               "varianceToBudget": -4010274.0,
//               "variancePY": -4409798.0
//             },
//             "yearToDate": {
//               "actuals": -5578187.0,
//               "budget": -1323643.0,
//               "priorYear": 3933840.0,
//               "salesActual": -3.97,
//               "varianceToBudget": -4254544.0,
//               "variancePY": -9512027.09
//             }
//           }
//         }
//       ]
//     }
//   }
// ]
