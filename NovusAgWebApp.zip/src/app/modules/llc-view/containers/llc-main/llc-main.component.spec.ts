import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LlcMainComponent } from './llc-main.component';

describe('LlcViewComponent', () => {
  let component: LlcMainComponent;
  let fixture: ComponentFixture<LlcMainComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LlcMainComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LlcMainComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
