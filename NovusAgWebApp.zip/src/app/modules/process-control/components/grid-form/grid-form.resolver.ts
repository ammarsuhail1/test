import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Observable } from 'rxjs';

import { NovusService } from '@app/core/services/novus.service';
import { ApplicationService } from '@app/core';

import { UserLocation } from '@app/core/models/project';
import { map } from 'rxjs/operators';

@Injectable()
export class GridFormResolver implements Resolve<UserLocation> {

  constructor(private novus: NovusService) {}

  resolve(route: ActivatedRouteSnapshot): Observable<any> {
    const processName = route.paramMap.get('process_name');
    if (!sessionStorage.getItem(processName + 'config')) {
      sessionStorage.setItem('processName', processName);
      sessionStorage.setItem('DisplayName', processName.split('_').join(' '));
      sessionStorage.setItem(processName + 'config', JSON.stringify(this.novus.tempGRIDCONFIGforLOCATIONACCESS()));
    }
    return this.novus.getUserLocation([route.paramMap.get('id')]).pipe(map(res => res[0]));
  }
}
