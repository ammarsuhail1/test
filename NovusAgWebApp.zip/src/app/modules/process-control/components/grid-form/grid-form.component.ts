import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { FormControl, Validators, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

import { Observable } from 'rxjs';
import { map, tap } from 'rxjs/operators';

import { NovusService } from '@app/core/services/novus.service';
import { MatOption } from '@angular/material';

@Component({
  selector: 'app-grid-form',
  templateUrl: './grid-form.component.html',
  styleUrls: ['./grid-form.component.scss']
})
export class GridFormComponent implements OnInit {
  @Input() data: any;
  @Input() id: string;
  processName: string;
  form: FormGroup;
  columns: any;
  appName = sessionStorage.getItem('DisplayName');
  locations$: Observable<string[]>;
  locations: string[] = [];
  @ViewChild('allSelected', {static: false}) private allSelected: MatOption;
  constructor(private route: ActivatedRoute, private novus: NovusService) { }

  ngOnInit() {
    this.route.data.subscribe(data => {
      this.processName = this.route.snapshot.paramMap.get('process_name');
      const { Columns } = JSON.parse(sessionStorage.getItem(this.processName + 'config'));
      this.columns = Columns;
      this.form = this.toFormGroup(data.gridFormData || this.data)
    });
    this.locations$ = this.novus.getLocations().pipe(
      map(locations => locations.map(location => location.LocationID)),
      map(locations => locations.sort()),
      tap(locations => this.locations = locations),
    );
  }

  private toFormGroup(data: any) {
    const group = {};
    Object.entries(data).forEach(entry => {
      if (entry[0] === 'LOCATIONID') {
        group[entry[0]] = new FormControl((entry[1] as string).split(','));
      } else {
        group[entry[0]] = new FormControl(entry[1], [Validators.required])
      }
    });
    return new FormGroup(group);
  }

  public onSubmit() {
    if (!this.form.valid) {
      return;
    }
    this.form.controls.LOCATIONID
    .patchValue(this.form.controls.LOCATIONID.value.filter(location => location !== 0));

    const { USERID, LOCATIONID } = this.form.value;
    this.novus.saveUserLocations(USERID, LOCATIONID.toString()).subscribe();
  }

  public tosslePerOne(all){ 
    if (this.allSelected.selected) {  
     this.allSelected.deselect();
     return false;
    }
    if(this.form.controls.LOCATIONID.value.length === this.locations.length)
     this.allSelected.select();
 
  }
  public toggleAllSelection() {
    if (this.allSelected.selected) {
      this.form.controls.LOCATIONID
        .patchValue([0, ...this.locations]);
    } else {
      this.form.controls.LOCATIONID.patchValue([]);
    }
  }

  public onSelectClick() {
    if (this.form.controls.LOCATIONID.value.length === this.locations.length) {
      this.allSelected.select();
    }
  }

}
