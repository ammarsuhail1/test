import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociatedContractsComponent } from './associated-contracts.component';

describe('AssociatedContractsComponent', () => {
  let component: AssociatedContractsComponent;
  let fixture: ComponentFixture<AssociatedContractsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssociatedContractsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociatedContractsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
