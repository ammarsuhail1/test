import { DatePipe } from '@angular/common';
import { Component, ElementRef, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { AuthenticationService, ColumnFilterService, DmoControlService, GridFilter, IHeaderMap, User, UserService } from '@app/core';
import { NovusService } from '@app/core/services/novus.service';
import { SearchService } from '@app/core/services/search.service';
import { UtilityService } from '@app/core/services/utility.service';
import { environment } from '@env/environment';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { takeWhile } from 'rxjs/operators';
import { DetailViewService } from '../../services/detail-view.service';
import {UserDetail} from '@app/core/models/user-detail';

@Component({
  selector: 'app-associated-contracts',
  templateUrl: './associated-contracts.component.html',
  styleUrls: ['./associated-contracts.component.scss']
})
export class AssociatedContractsComponent implements OnInit, OnDestroy {

  @Input() transactionId: string;
  @Input() topCornerDetails: Array<{DisplayName: string, Value: string}>[];
  @ViewChild('detailViewModal', { static: false }) detailViewModal: ElementRef;
  @Output() refreshParent = new EventEmitter<boolean>();
  private currentUser: User = this.auth.currentUserValue;
  private dateFormat = environment.Setting.dateFormat;
  headers: Array<{DisplayName: string, Value: string}>[];
  componentActive = true;
  filters: any = {};
  dataSource: any;
  itemsCount: number;
  itemsPerPage: number;
  selectedContractTransactionId: string;
  releaseFilter = this.utility.generateGridFilter('State_Filter', 'Assign Location', 'CONTAINS', 'Assign Location');
  pageNum = -1;
  constructor(
    private novus: NovusService,
    private utility: UtilityService,
    private columnFilter: ColumnFilterService,
    private datePipe: DatePipe,
    private modalService: NgbModal,
    private dv: DetailViewService,
    private user: UserDetail,
    private search: SearchService,
    private dmoControlService: DmoControlService,
    private auth: AuthenticationService,
  ) { }
  bodyData = this.utility.generateGridConfig({
    ProcessName: '',
    ColumnList: '',
    SortOrder: '-1',
    PageSize: 50,
  });

  HeaderMap: IHeaderMap = {
    config: {
      header: {
        columns: [
          {
            objectKey: 'nagscmavpopdponum',
            displayName: 'PO Number',
          },
          {
            objectKey: 'nagscmavctodvcon',
            displayName: 'Vendor Contract Number',
          },
          {
            objectKey: 'nagscmfvctdtvname',
            displayName: 'Vendor Name',
          },
          {
            objectKey: 'nagscmfvctdtpid',
            displayName: 'Product Id',
          },
          {
            objectKey: 'nagscmfvctdtpn',
            displayName: 'Product Name',
          },
          {
            objectKey: 'nagscmfvctdtsstart',
            displayName: 'Shipping Start Date',
            dataType: 'Date',
            format: environment.Setting.dateFormat,
            timeZone: new Date().getTimezoneOffset(),
            width: '10%'
          },
          {
            objectKey: 'nagscmfvctdtsend',
            displayName: 'Shipping End Date',
            dataType: 'Date',
            format: environment.Setting.dateFormat,
            timeZone: new Date().getTimezoneOffset(),
            width: '10%'
          },
          {
            objectKey: 'nagscmfvctdtsloc',
            displayName: 'Shipping Terminal',
          },
          {
            objectKey: 'nagscmavctodex',
            displayName: 'Quantity Exposed',
          },
          {
            objectKey: 'nagscmfvctdtquan',
            displayName: 'Quantity',
          },
          {
            objectKey: 'nagscmfvter',
            displayName: 'Region',
          },
          {
            objectKey: 'nagscmfvctdtprice',
            displayName: 'Contract Price',
          },

        ],
        action: {
          Edit: true,
          Delete: false,
          Checkbox: false,
          Placement: 'IsExternalShow',
          DropDown: false
        },
        columnFilter: []
      },
      paging: true
    }
  };
  async ngOnInit() {
    this.dv.triggerClicked$
    .pipe(takeWhile(_ => this.componentActive))
    .subscribe(_ => this.bindData());
    if (!this.user.hasRole('nagsystemadmin') && this.user.hasRole('nagdivisionadmin')) {
      const locationBasedFilter = await this.search.locationBasedFilter('Supply_Chain_Manager').toPromise();
      this.bodyData.GridFilters.push(locationBasedFilter as GridFilter);
    }
    this.bindData();
  }
  
  private bindData() {
    console.log(this.topCornerDetails)
    this.headers = [this.topCornerDetails[0].filter(header => header.DisplayName !== 'State' && header.DisplayName !== 'Stage')];
    this.novus.getFPRAssociatedContracts(this.transactionId, this.bodyData).subscribe(response => {
      this.dataSource = response.Data;
      this.itemsCount = +response.RecordsCount;
      this.itemsPerPage = + response.End;
    },
    _error => {
      this.dataSource = [];
      this.itemsCount = 0;
    });
  }

  public isDate(value: string) {
    const regex = /([0-9]){1,2}\/([0-9]{2})\/([0-9]){4}/;
    return value.match(regex);
  }

  public convertDateTime(value: string) {
    return this.dmoControlService.getUserDateTime(value, this.dateFormat, this.currentUser.TimeZone);
  }

  private showDetailPage(row: any) {
    this.selectedContractTransactionId = row.TRNSCTNID;
    this.headers[0].push({DisplayName: 'Contract Price', Value: row.nagscmfvctdtprice});
    this.modalService.open(this.detailViewModal, { backdrop: 'static', scrollable: true, windowClass : 'detail-view-modal' });  
  }

  public close(modal: NgbActiveModal, data?: any) {
    this.selectedContractTransactionId = null;
    this.headers[0].pop();
    if (data) {
      this.refreshParent.emit(true);
    }
    modal.close()
  }

  pageChange(event) {
    this.bodyData.PageNumber = event.currentPage - 1;
    this.bodyData.PageSize = event.pageSize;
    this.bindData();
  }

  actionClick(event) {
    if (event.action == "asc" || event.action == "desc") {
      if (event.action == "asc") {        
        event.action = "asc";
      } else {
        event.action = "desc";
      }
    }
    switch (event.action) {
      case 'Edit':
        this.showDetailPage(this.dataSource[event.rowIndex])
        break;
      case 'Filter_Header':
        this.bindColumnFilterDdl(event);
        break;
      case 'Filter_Click':
        if (!this.validate(event)) {
          break;
        }
        this.bodyData.PageNumber = 0;
        let filter: any = {};
        filter = {
          GridConditions: [
          ],
          DataField: event.colData.objectKey,
          LogicalOperator: event.filterData.logicalOpt.Value === 'Select...' ? '' : event.filterData.logicalOpt.Value,
          FilterType: 'Column_Filter'
        };
        if (event.filterData.filterValue1 && event.filterData.filterValue1 !== '') {
          if (event.colData.dataType === 'Date') {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: this.datePipe.transform(event.filterData.filterValue1, 'yyyy-MM-dd')
            });
          } else {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: event.filterData.filterValue1
            });
          }
        }
        if (event.filterData.filterValue2 && event.filterData.filterValue2 !== '') {
          if (event.colData.dataType === 'Date') {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: this.datePipe.transform(event.filterData.filterValue2, 'yyyy-MM-dd')
            });
          } else {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: event.filterData.filterValue2
            });
          }
        }
        if (filter && Object.keys(filter).length !== 0) {
          this.filters['Column_Filter~$~' + event.colData.objectKey] = filter;
        }
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
      case 'asc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'asc';
        this.bindData();
        break;
      case 'desc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'desc';
        this.bindData();
        break;
      case 'Remove Sort':
        this.bodyData.SortColumn = '-1';
        this.bodyData.SortOrder = '-1';
        this.bindData();
        break;
      case 'FilterClear_Click':
        delete this.filters['Column_Filter~$~' + event.colData.objectKey];
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
    }
  }


  private generateFilter() {
    // this.bodyData.GridFilters = [];
    this.bodyData.PageNumber = 0;
    Object.keys(this.filters).forEach(key => {
      this.bodyData.GridFilters.push(this.filters[key]);
    });
    this.bindData();
  }
  validate(event): boolean {
    if (event.filterData.ConditionOpt1 && (event.filterData.ConditionOpt1.Value === '' ||
      event.filterData.ConditionOpt1.Value === 'Select...')) {
      return false;
    } else if (event.filterData.filterValue1 && event.filterData.filterValue1.Value === '') {
      return false;
    } else {
      return true;
    }
  }
  bindColumnFilterDdl(item) {
    let type = '';
    if (item.colData.dataType === 'Date') {
      type = 'DateEditBox';
    }
    const FilterData = this.columnFilter.GetFilterByDataType(type); // Calling Function to get ColumnFilter Condition data
    if (FilterData.length === 0) { // Check if Array is empty then call API for options data
    } else {
      this.HeaderMap.config.header.columnFilter['colData_' + item.colIndex] = FilterData;
    }
  }
  removeFilter() {
    this.filters = [];
    const defaultBodyData = this.utility.generateGridConfig({
      ProcessName: '',
      ColumnList: '',
      SortOrder: '-1',
      PageSize: 50,
    });
    defaultBodyData.GridFilters = this.bodyData.GridFilters.filter(filter => filter.FilterType as any === 'Customize_Filter');
    this.bodyData = defaultBodyData;
    this.pageNum = 0;
    this.generateFilter();
  }

  ngOnDestroy() {
    this.componentActive = false;
  }

}
