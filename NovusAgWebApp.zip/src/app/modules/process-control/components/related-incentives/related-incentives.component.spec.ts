import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RelatedIncentives } from './related-incentives.component';

describe('CrossProductInformationComponent', () => {
  let component: RelatedIncentives;
  let fixture: ComponentFixture<RelatedIncentives>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RelatedIncentives ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RelatedIncentives);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
