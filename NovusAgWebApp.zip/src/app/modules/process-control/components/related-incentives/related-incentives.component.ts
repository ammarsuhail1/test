import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { ColumnFilterService, IHeaderMap, MessageService } from '@app/core';
import { AutoCompleteSearchBoxDmo } from '@app/core/models/dmos';
import { RecordData } from '@app/core/models/record-data.model';
import { NovusService } from '@app/core/services/novus.service';
import { UtilityService } from '@app/core/services/utility.service';
import { environment } from '@env/environment';
import { takeWhile } from 'rxjs/operators';
import { DetailViewService } from '../../services/detail-view.service';
import {SearchService} from '@app/core/services/search.service';

@Component({
  selector: 'app-related-incentives',
  templateUrl: './related-incentives.component.html',
  styleUrls: ['./related-incentives.component.scss']
})
export class RelatedIncentives implements OnInit, OnDestroy {

  @Input() transactionId: string;
  @Input() currentStage: string;
  @Input() currentState: string;
  @Input() dmos: any[];
  @Input() appData: RecordData;
  @Input() locationFilter = null;
  @Output() refreshParent = new EventEmitter<boolean>();

  mappedDmos = {};
  componentActive = true;
  filters: any = {};
  dataSource: any;
  itemsCount: number;
  itemsPerPage: number;
  pageNum = -1;
  constructor(
    private novus: NovusService,
    private utility: UtilityService,
    private columnFilter: ColumnFilterService,
    private datePipe: DatePipe,
    private msg: MessageService,
    private dv: DetailViewService,
  ) { }
  bodyData = this.utility.generateGridConfig({
    TransactionId: this.transactionId,
    ProcessName: '',
    ColumnList: '',
    SortColumn: 'RelIncentiveID',
    SortOrder: 'desc',
    PageSize: 20,
  });

  HeaderMap: IHeaderMap = {
    config: {
      header: {
        columns: [
          {
            objectKey: 'IncentiveID',
            parentKey: 'nagincaviid',
            displayName: 'Incentive ID',
          },
          {
            objectKey: 'IncentiveName',
            parentKey: 'nagincfvidname',
            displayName: 'Incentive Name',
          },
          {
            objectKey: 'OfferedBy',
            parentKey: 'nagincaviddeob',
            displayName: 'Offered By',
          },
          {
            objectKey: 'EffectiveFrom',
            parentKey: 'nagincaviddeef',
            displayName: 'Effective From',
            dataType: 'Date',
            format: environment.Setting.dateFormat,
            timeZone: new Date().getTimezoneOffset(),
            width: '10%'
          },
          {
            objectKey: 'EffectiveTo',
            parentKey: 'nagincaviddeet',
            displayName: 'Effective To',
            dataType: 'Date',
            format: environment.Setting.dateFormat,
            timeZone: new Date().getTimezoneOffset(),
            width: '10%'
          },
          {
            objectKey: 'DiscountDol',
            parentKey: 'nagincaviddeda',
            displayName: 'Discount $',
            dataType: 'Currency'
          },
          {
            objectKey: 'DiscountPer',
            parentKey: 'nagincavidded',
            displayName: 'Discount %',
            dataType: 'Percent'
          },
          {
            objectKey: 'ThresholdMet',
            parentKey: 'nagincfvtmet',
            displayName: 'Threshold Met',
          },
          {
            objectKey: 'State',
            parentKey: 'WFOSDISPNAME',
            displayName: 'State',
          },
        ],
        action: {
          Edit: false,
          Delete: true,
          Checkbox: false,
          Placement: 'IsExternalShow',
          DropDown: false
        },
        columnFilter: []
      },
      paging: true
    }
  };
  async ngOnInit() {
    this.prepareDmosForForm();    
    this.dv.triggerClicked$
    .pipe(takeWhile(_ => this.componentActive))
    .subscribe(_ => this.bindData());
    this.bindData();
  }

  private bindData() {
    this.novus.getRelatedIncentives(this.transactionId, this.bodyData).subscribe(response => {
      this.dataSource = response.Data;
      this.itemsCount = +response.RecordsCount;
      this.itemsPerPage = + response.End;
    },
    _error => {
      this.dataSource = [];
      this.itemsCount = 0;
    });
  }

  private prepareDmosForForm() {
    this.HeaderMap.config.header.columns.forEach(col => {
      const dmo = this.dmos.find(dmo => dmo.DMOGuid === col.parentKey);
      if (dmo)
        this.mappedDmos[col.parentKey] = this._modifyDmo(dmo);
    });
    const stateDmo = {
      ...this.mappedDmos['nagincaviddeda'],
      DMOGuid: 'WFOSDISPNAME',
      Name: 'WFOSDISPNAME',
    };
    this.mappedDmos['WFOSDISPNAME'] = stateDmo;
    
  }

  private _modifyDmo(dmo: any) {
    dmo = {...dmo};
    if (dmo.DMOGuid === 'nagincaviid' || dmo.DMOGuid === 'nagincfvidname') {
      const mappings = [
        {Name: 'NAG_INC_AV_ID_De_OB', GUID: 'nagincaviddeob'},
        {Name: 'NAG_INC_AV_ID_De_EF', GUID: 'nagincaviddeef'},
        {Name: 'NAG_INC_AV_ID_De_ET', GUID: 'nagincaviddeet'},
        {Name: 'NAG_INC_AV_ID_De_DA', GUID: 'nagincaviddeda'},
        {Name: 'NAG_INC_AV_ID_De_D', GUID: 'nagincavidded'},
        {Name: 'NAG_INC_FV_TMet', GUID: 'nagincfvtmet'},
        {Name: 'WFOSDISPNAME', GUID: 'WFOSDISPNAME'},
      ];
      dmo.DMOGuid === 'nagincaviid' 
        ? mappings.push({Name: 'NAG_INC_FV_ID_Name', GUID: 'nagincfvidname'})
        : mappings.push({Name: 'NAG_INC_AV_IID', GUID: 'nagincaviid'});
      const config = this.utility.generateGridConfig({
        ProcessName: 'NAG_Incentives',
        ColumnList: this.HeaderMap.config.header.columns.map(col => col.parentKey).toString(),
        SortColumn: dmo.DMOGuid,
        IsColumnListOnly: false,
      });
      const parentIncentiveId = this.appData.DataInformation.nagincaviid.DMOVAL;
      const filter = this.utility.generateGridFilter('Column_Filter', 'nagincaviid', 'DOES_NOT_CONTAIN', parentIncentiveId);
      config.GridFilters.push(filter);
      // const emptyFilter = this.utility.generateGridFilter('Column_Filter', 'nagincfvidname', 'DOES_NOT_CONTAIN', '');
      // config.GridFilters.push(emptyFilter);
      if (this.locationFilter) {
        config.GridFilters.push(this.locationFilter);
      }
      const asb: AutoCompleteSearchBoxDmo = {
        ...dmo,
        DataSource: 'WFAPI/listview/getprocessdata',
        DependencyDmos: `[{"Name":""}]`,
        DependentDmos: `[{"Name":""}]`,
        EmitOnStart: false,
        Key: dmo.DMOGuid,
        Value: dmo.DMOGuid,
        DisplayValue: dmo.DMOGuid,
        Mappings: JSON.stringify(mappings),
        Model: JSON.stringify(config),
        ModelBodyProcessId: 'NAG_Incentives',
        Type: 'AutoCompleteSearchBox',
        IsReadOnly: false,
      };
      dmo = asb;
    } else {
      dmo.IsReadOnly = true;
    }
    if (dmo.DMOGuid === 'nagincfvtmet') {
      dmo.Type = 'TextBox'
      dmo.IsTooltip = false;
    }
    return dmo;
  }


  pageChange(event) {
    this.bodyData.PageNumber = event.currentPage - 1;
    this.bodyData.PageSize = event.pageSize;
    this.bindData();
  }

  actionClick(event) {
    if (event.action == "asc" || event.action == "desc") {
      if (event.action == "asc") {        
        event.action = "asc";
      } else {
        event.action = "desc";
      }
    }
    switch (event.action) {
      case 'Save':
        if (event.form.NAG_INC_AV_IID === this.appData.DataInformation.nagincaviid.DMOVAL) {
          this.msg.showMessage('Warning', {body: 'Cannot add the current Incentive!'});
        } else {
          this.novus.createRelatedIncentive(this.transactionId, event.form, Object.values(this.mappedDmos)).subscribe(
            result => {
              if (result == 1) {
                this.msg.showMessage('Warning', {body: 'Incentive already exists!'});
              } else if (result == 2) {
                this.msg.showMessage('Warning', {body: 'Incentive does not exist!'});
              } else {
                this.bindData();
              }          
            }, 
            err => this.msg.showMessage('Fail', {body: 'Related Incentive was not created!'})
          );
        }
        break;
      case 'Delete':
        const record = this.dataSource[event.rowIndex];
        this.novus.deleteRelatedIncentive(this.transactionId, record).subscribe(
          _ => this.bindData(),
          err => this.msg.showMessage('Warning', {body: 'Something went wrong. Related Incentive was not deleted.'})
        )
        break;
      case 'Filter_Header':
        this.bindColumnFilterDdl(event);
        break;
      case 'Filter_Click':
        if (!this.validate(event)) {
          break;
        }
        this.bodyData.PageNumber = 0;
        let filter: any = {};
        filter = {
          GridConditions: [
          ],
          DataField: event.colData.objectKey,
          LogicalOperator: event.filterData.logicalOpt.Value === 'Select...' ? '' : event.filterData.logicalOpt.Value,
          FilterType: 'Column_Filter'
        };
        if (event.filterData.filterValue1 && event.filterData.filterValue1 !== '') {
          if (event.colData.dataType === 'Date') {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: this.datePipe.transform(event.filterData.filterValue1, 'yyyy-MM-dd')
            });
          } else {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: event.filterData.filterValue1
            });
          }
        }
        if (event.filterData.filterValue2 && event.filterData.filterValue2 !== '') {
          if (event.colData.dataType === 'Date') {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: this.datePipe.transform(event.filterData.filterValue2, 'yyyy-MM-dd')
            });
          } else {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: event.filterData.filterValue2
            });
          }
        }
        if (filter && Object.keys(filter).length !== 0) {
          this.filters['Column_Filter~$~' + event.colData.objectKey] = filter;
        }
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
      case 'asc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'asc';
        this.bindData();
        break;
      case 'desc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'desc';
        this.bindData();
        break;
      case 'Remove Sort':
        this.bodyData.SortColumn = '-1';
        this.bodyData.SortOrder = '-1';
        this.bindData();
        break;
      case 'FilterClear_Click':
        delete this.filters['Column_Filter~$~' + event.colData.objectKey];
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
    }
  }


  private generateFilter() {
    this.bodyData.GridFilters = [];
    this.bodyData.PageNumber = 0;
    Object.keys(this.filters).forEach(key => {
      this.bodyData.GridFilters.push(this.filters[key]);
    });
    this.bindData();
  }
  validate(event): boolean {
    if (event.filterData.ConditionOpt1 && (event.filterData.ConditionOpt1.Value === '' ||
      event.filterData.ConditionOpt1.Value === 'Select...')) {
      return false;
    } else if (event.filterData.filterValue1 && event.filterData.filterValue1.Value === '') {
      return false;
    } else {
      return true;
    }
  }
  bindColumnFilterDdl(item) {
    let type = '';
    if (item.colData.dataType === 'Date') {
      type = 'DateEditBox';
    }
    const FilterData = this.columnFilter.GetFilterByDataType(type); // Calling Function to get ColumnFilter Condition data
    if (FilterData.length === 0) { // Check if Array is empty then call API for options data
    } else {
      this.HeaderMap.config.header.columnFilter['colData_' + item.colIndex] = FilterData;
    }
  }
  removeFilter() {
    this.filters = [];
    const defaultBodyData = this.utility.generateGridConfig({
      ProcessName: '',
      ColumnList: '',
      SortOrder: '-1',
      PageSize: 50,
    });
    defaultBodyData.GridFilters = this.bodyData.GridFilters.filter(filter => filter.FilterType as any === 'Customize_Filter');
    this.bodyData = defaultBodyData;
    this.pageNum = 0;
    this.generateFilter();
  }

  ngOnDestroy() {
    this.componentActive = false;

  }
}
