import { formatDate } from '@angular/common';
import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { UserService } from '@app/core';
import { IHeaderMap } from '@app/core/models/plasmaGridInterface';
import { ColumnFilterService } from '@app/core/services/column-filter.service';
import { SearchService } from '@app/core/services/search.service';
import { environment } from '@env/environment';
import { NgbModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import {UserDetail} from '@app/core/models/user-detail';
import { Console } from 'console';
import { GridViewExportComponent } from '@app/shared';
import { NovusService } from '@app/core/services/novus.service';
import { DetailViewService } from '../../services/detail-view.service';

@Component({
  selector: 'app-pricing-grid',
  templateUrl: './pricing-grid.component.html',
  styleUrls: ['./pricing-grid.component.scss']
})
export class PricingGridComponent implements OnInit {

  @Input() transactionId: string;
  @Input() parentForm: FormGroup;
  filters: any = {};
  dataSource: any;
  itemsCount: number;
  pageNum = -1;
  ProcessName: string;
  isExport:boolean = true;
  // Client app specific
  public totalsFooter: any;
  headersData: any[];

  HeaderMap: IHeaderMap = {
    config: {
      header: {
        columns: [],
        action: {
          Edit: false,
          Delete: false,
          Checkbox: false,
          Placement: 'IsExternalShow',
          DropDown: false
        },
        columnFilter: []
      },
      paging: true,
      autoTableLayout: true,
      disableFilters: true,
    }
  };

  constructor(
    private search: SearchService,
    private columnFilter: ColumnFilterService,
    private user: UserDetail,
    private modalService: NgbModal,
    private dv: DetailViewService,
    private novus: NovusService
  ) {
    this.dateFormat = environment.Setting.dateFormat;
    const isLlc = user.hasRole('3bfd3nagllcowner');
    const isLocation = user.hasRole('3bfd3naglocationmanager');
    const isRegional = user.hasRole('3bfd3nagregionalmanager');
    this._addColumn('MONTHS', 'Season');
    if (!isLlc && !isLocation && !isRegional) {
      this._addColumn('MFRAnchorPrice', 'Mfr. Anchor Price', 'TextWithPrefix', '$');
      this._addColumn('DistributorAnchorPrice', 'Distributor Anchor Price', 'TextWithPrefix', '$');
      this._addColumn('DistributorPrice', 'Distributor Price', 'TextWithPrefix', '$');
    }
    if (!isLlc && !isLocation) {
      this._addColumn('NovusCostFloor', 'Novus Cost Floor', 'TextWithPrefix', '$');
    }
    if (!isLocation) {
      this._addColumn('LLCCostFloor', 'LLC Cost Floor', 'TextWithPrefix', '$');
    }
    this._addColumn('MinimumRetailPrice', 'Minimum Retail Price', 'TextWithPrefix', '$');
    this._addColumn('SuggestedRetailPrice', 'Suggested Retail Price', 'TextWithPrefix', '$');
  }

  filterValue1: string = "";
  filterValue2: string = "";
  ConditionOpt1: string = "";
  ConditionOpt2: string = "";
  logicalOpt: string = "OR";
  TimeZone: string;
  dateFormat = '';
  FromDateobj: NgbDateStruct;
  ToDateobj: NgbDateStruct;
  pageIndex = 1;

  bodyData = {
    TransactionId: this.transactionId,
    PageSize: 20,
    PageNumber: 1,
    SortColumn: '-1',
    SortOrder: 'desc',
    TimeZone: new Date().getTimezoneOffset(),
    GridFilters: []
  };

  ngOnInit() {
    this.bodyData.TransactionId = this.transactionId;

    if (sessionStorage.getItem('faq_grid_filter')) {
      this.bodyData = JSON.parse(sessionStorage.getItem('faq_grid_filter'));
      if (this.bodyData.GridFilters != undefined) {
        if (this.bodyData.GridFilters.length > 0) {
          if (this.bodyData.GridFilters[0].FilterType == 'Global_Search') {
            if (this.bodyData.GridFilters[0].GridConditions.length > 0) {
              (<HTMLInputElement>document.getElementById("globalSearch")).value = this.bodyData.GridFilters[0].GridConditions[0].ConditionValue.toString();
            }
          }
        }
      }
      this.bindIncentive(this.bodyData);
    }
    else {
      this.bindIncentive(this.bodyData);
    }

    this.dv.currentHeadersData$.subscribe(data => this.headersData = data);
  }

  private _addColumn(objectKey: string, displayName: string, dataType?: string, prefix?: string) {
    const column = {objectKey, displayName, dataType, prefix};
    this.HeaderMap.config.header.columns.push(column);
  }

  private bindIncentive(bodyData) {
    this.search.GetProductPricingGrid(bodyData, this.transactionId)
    .subscribe((x: any) => {      
      this.dataSource = x.Data;
      this.itemsCount = x.RecordsCount;
      this.ProcessName = "";
      if (x.PricingData && x.PricingData[0]) {
        this.parentForm.get('NAG_PR_AV_TD').patchValue(parseFloat(x.PricingData[0].TotalDiscount).toFixed(2), {emitEvent: true});
        this.parentForm.get('NAG_PR_AV_PD_PRDT_Cost').patchValue(parseFloat(x.PricingData[0].CurrentNovusCostFloor).toFixed(2), {emitEvent: true});
        this.parentForm.get('NAG_PR_AV_Pr_CLOLO').patchValue(parseFloat(x.PricingData[0].CurrentLLCCostFloor).toFixed(2), {emitEvent: true});
        this.parentForm.get('NAG_PR_AV_Pr_CMGRP').patchValue(parseFloat(x.PricingData[0].CurrentMinRetailPrice).toFixed(2), {emitEvent: true});
        this.parentForm.get('NAG_PR_AV_Pr_CMini').patchValue(parseFloat(x.PricingData[0].CurrentSuggRetailPrice).toFixed(2), {emitEvent: true});
      }
      //this.totalsFooter = (x as any).summary; 
    },
      err => {
        console.log(err);
      });
  }

  actionClick(event) {
    switch (event.action) {
      case 'Filter_Header':
        this.bindColumnFilterDdl(event);
        break;
      case 'Edit':
        break;
      case 'Filter_Click':
        if (!this.validate(event)) {
          break;
        }
        this.bodyData.PageNumber = 1;
        let filter: any = {};
        filter = {
          GridConditions: [
          ],
          DataField: event.colData.objectKey,
          LogicalOperator: event.filterData.logicalOpt.Value === 'Select...' ? '' : event.filterData.logicalOpt.Value,
          FilterType: 'Column_Filter'
        };
        if (event.filterData.filterValue1 && event.filterData.filterValue1 !== '') {
          filter.GridConditions.push({
            Condition: event.filterData.ConditionOpt1.Value,
            ConditionValue: event.filterData.filterValue1
          });
        }
        if (event.filterData.filterValue2 && event.filterData.filterValue2 !== '') {
          filter.GridConditions.push({
            Condition: event.filterData.ConditionOpt2.Value,
            ConditionValue: event.filterData.filterValue2
          });
        }
        if (filter && Object.keys(filter).length !== 0) {
          this.filters['Column_Filter~$~' + event.colData.objectKey] = filter;
        }
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
      //case 'asc':
        //this.bodyData.SortColumn = event.colData.objectKey;
        //this.bodyData.SortOrder = 'asc';
        //sessionStorage.setItem('faq_grid_filter', JSON.stringify(this.bodyData));
        //this.bindIncentive(this.bodyData);
        
        //break;
      //case 'desc':
        //this.bodyData.SortColumn = event.colData.objectKey;
        //this.bodyData.SortOrder = 'desc';
        //sessionStorage.setItem('faq_grid_filter', JSON.stringify(this.bodyData));
        
        //this.bindIncentive(this.bodyData);
        //break;
      //case 'Remove Sort':
        //this.bodyData.SortColumn = '-1';
        //this.bodyData.SortOrder = 'desc';
        //sessionStorage.setItem('faq_grid_filter', JSON.stringify(this.bodyData));
        //this.bindIncentive(this.bodyData);
        break;
      case 'Delete':
        // this.openConfirmation(this.dataSource[event.rowIndex].UserName);
        break;
      case 'FilterClear_Click':
        delete this.filters['Column_Filter~$~' + event.colData.objectKey];
        sessionStorage.removeItem('faq_grid_filter');
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;  
      case "Export Excel":
        this.openNewExportPopup('excel');
        break;
      case "Export PDF":
        this.openNewExportPopup('pdf');
        break;    
    }
    
  }

  private GenerateDMOList(): any[] {
    let result: any[] = [];

    const pageHeaders = this.headersData;
    const firstRow = pageHeaders[0];

    firstRow.forEach(item => {
      const key = item.DisplayName.replace(' ', '');
      const dmo = {
        BusinessModelObject: {
          Name: 'Page Header',
          GUID: 'headers'
        },
        DataModelObjectGroup: {
          Name: "Details",
          GUID: "pageheaderdetails",
        },              
        Name: key,
        GUID: `header.${item.DisplayName}`,
        DisplayName: item.DisplayName,
        Type: 'TextBox',
        DataType: null
      };
      result.push(dmo);
    });


    this.HeaderMap.config.header.columns.forEach(item => {
      const dmo = {
        BusinessModelObject: {
          Name: 'Pricing Grid',
          GUID: 'pricinggrid'
        },
        DataModelObjectGroup: {
          Name: "Details",
          GUID: "pricinggriddetails",
        },              
        Name: item.objectKey,
        GUID: `grid.${item.objectKey}`,
        DisplayName: item.displayName,
        Type: "TextBox",
        DataType: item.dataType,
        IsChecked: false
      };
      result.push(dmo);
    });   
    
    return result;
  }

  openNewExportPopup(ExportType: string) {
    const data = this.GenerateDMOList();
    const modalRef = this.modalService.open(GridViewExportComponent, { backdrop: 'static' });
    const modalInstance: GridViewExportComponent = modalRef.componentInstance;
    modalInstance.ExportType = ExportType.toUpperCase();
    modalInstance.ExportPopup = modalRef;
    modalInstance.ExportUserData.SortColumn = this.bodyData.SortColumn;
    modalInstance.ExportUserData.SortOrder = this.bodyData.SortOrder;
    modalInstance.ExportUserData.GridFilters = this.bodyData.GridFilters;
    modalInstance.ExportUserData.TransactionID = this.transactionId;
    modalInstance.ExportUserData.ProcessName = "PricingGrid";
    modalInstance.ExternalCall = {
      FromURL: true,
      GUID: 'GUID',
      displayValue: 'DisplayName',
      DownloadFileURL: this.novus.getPricingGridEndPoint(ExportType)
    };
    modalInstance.setDmoList(data);
  }

  private generateFilter() {
    sessionStorage.removeItem('faq_grid_filter');
    this.bodyData.GridFilters = [];
    this.bodyData.PageNumber = 1;
    this.bodyData.SortColumn = '-1';
    Object.keys(this.filters).forEach(key => {
      this.bodyData.GridFilters.push(this.filters[key]);
    });
    sessionStorage.setItem('faq_grid_filter', JSON.stringify(this.bodyData));
    this.bindIncentive(this.bodyData);
  }
  validate(event): boolean {

    if (event.filterData.ConditionOpt1 && (event.filterData.ConditionOpt1.Value === '' ||
      event.filterData.ConditionOpt1.Value === 'Select...')) {
      return false;
    } else if (event.filterData.filterValue1 && event.filterData.filterValue1.Value === '') {
      return false;
    } else {
      return true;
    }
  }
  bindColumnFilterDdl(item) {
    let type = '';
    if (item.colData.dataType === 'Date' || item.colData.dataType === 'Currency') {
      type = 'DateEditBox';
    }
    const FilterData = this.columnFilter.GetFilterByDataType(type);
    if (FilterData.length === 0) {
    } else {
      const key = Object.keys(item.colData)[0];
      this.HeaderMap.config.header.columnFilter['colData_' + item.colIndex] = FilterData;
      this.ConditionOpt1 = item.ConditionOpt1;
      this.ConditionOpt2 = item.ConditionOpt2;
    }
  }
  removeFilter() {
    this.filters = [];
    this.pageNum = 1;
    this.generateFilter();
  }

  pageChange(event) {
    this.bodyData.PageNumber = event.currentPage;
    this.bodyData.PageSize = event.pageSize;
    this.bindIncentive(this.bodyData);
  }

  convertToLocalDataAndTime(value, format, zone) {
    if (value == null || value === '') {
      return null;
    }
    try {
      const d = new Date(value);
      let timeZone;
      if (!zone) {
        timeZone = this.TimeZone;
      } else {
        timeZone = zone;
      }
      const localOffset = timeZone * -60000;
      const localTime = d.getTime();
      d.setTime(localTime);
      return formatDate(d, format, 'en-US');
    } catch (error) {
      return '';
    }
  }

  ChangeFilterDateFormat(dateValue) {
    var d = new Date(dateValue);
    var localOffset = d.getTimezoneOffset() * 60000;
    return new Date(d.getTime() + localOffset);
  }
}

