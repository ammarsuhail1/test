import { Component, OnInit, Input, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { formatDate } from '@angular/common';
import { SearchService } from '@app/core/services/search.service';
import { ColumnFilterService } from '@app/core/services/column-filter.service';
import { IHeaderMap } from '@app/core/models/plasmaGridInterface';
import { environment } from '@env/environment';
import { GenericGirdService } from '@app/core/services/generic-gird.service';
import { NgbModal, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { GridViewExportComponent } from '@app/shared';
import { TableRowState } from '@app/core/models/table-row-state.model';
import { NovusService } from '@app/core/services/novus.service';
import { RecordData } from '@app/core/models/record-data.model';
import { ListviewService, MAX_SELECT_ALL_CAP } from '@app/core';
import { GenericGridService } from '@app/shared/components/generic-grid/generic-grid.service';
import { takeWhile } from 'rxjs/operators';
import { Observable } from 'rxjs';


@Component({
  selector: 'app-incentive',
  templateUrl: './incentive.component.html',
  styleUrls: ['./incentive.component.scss'],
  providers: [GenericGridService]
})
export class IncentiveComponent implements OnInit, OnDestroy {

  @Input() transactionId: string;
  @Input() PprocessName: string;
  @Input() parentData: RecordData;
  filters: any = {};
  dataSource: any;
  itemsCount: number;
  pageNum = 1;
  ProcessName:string;
  isExport:boolean = true;
  IsBulkUpdateAllow = false;
  IsSyncing: boolean = false;
  IsBulkTriggerAllow = false;
  private componentActive = true;
  public targetColumns: string[] = [];

  // Client app specific
  public totalsFooter: any;

  public rowState: TableRowState = {
    success: {property: 'BidStatus', values: ['Bid Won', 'Highest Bid']},
    fail: {property: '', values: []},
  };

  constructor(
    public grid: GenericGridService,
    private search: SearchService,
    private novus: NovusService,
    private columnFilter: ColumnFilterService,
    private router: Router,
    private modalService: NgbModal,
    private listviewService: ListviewService
  ) { 
    this.dateFormat = environment.Setting.dateFormat;
  }

  filterValue1: string = "";
  filterValue2: string = "";
  ConditionOpt1: string = "";
  ConditionOpt2: string = "";
  logicalOpt: string = "OR";
  TimeZone: string;
  dateFormat = '';
  FromDateobj: NgbDateStruct;
  ToDateobj: NgbDateStruct;

  bodyData = {
    TransactionId: this.transactionId,
    PageSize: 10,
    PageNumber: 1,
    SortColumn: '-1',
    SortOrder: 'desc',
    TimeZone: new Date().getTimezoneOffset(),
    GridFilters: []
  };

  HeaderMap: IHeaderMap;

  ngOnInit() {
    this.grid.selectedAll$
      .pipe(takeWhile(_ => this.componentActive))
      .subscribe(selectedAll => selectedAll ? this.getAllRecords() : this.grid.updateSelectedRecords([]));
    this.listviewService.userActionPermission({ ProcessName: 'NAG_Incentives' }).subscribe(
      data => {
        this.IsBulkUpdateAllow = data.IsBulkUpdateAllow;
      });

    this.bodyData.TransactionId = this.transactionId;
    if (sessionStorage.getItem('faq_grid_filter')) {
      this.bodyData = JSON.parse(sessionStorage.getItem('faq_grid_filter'));
      if (this.bodyData.GridFilters != undefined) {
        if (this.bodyData.GridFilters.length > 0) {
          if (this.bodyData.GridFilters[0].FilterType == 'Global_Search') {
            if (this.bodyData.GridFilters[0].GridConditions.length > 0) {
              (<HTMLInputElement>document.getElementById("globalSearch")).value = this.bodyData.GridFilters[0].GridConditions[0].ConditionValue.toString();
            }
          }
        }
      }
      this.bindIncentive(this.bodyData);
    }
    else {
      this.bindIncentive(this.bodyData);
    }
    
    if (this.PprocessName === 'NAG_Programs') {
      if (this.parentData && this.parentData.DataInformation.prgprodsync) {
        if (this.parentData.DataInformation.prgprodsync.DMOVAL === '1') this.IsSyncing = true;
      }
    }
}

  private getAllRecords() {
    if (this.itemsCount > MAX_SELECT_ALL_CAP) {
      return;
    }
    const payload: any = {
      ...this.bodyData,
      PageNumber: 1,
      PageSize: this.itemsCount,
    };
    let call$: Observable<any>;
    if (this.PprocessName === 'NAG_Programs') {
      call$ = this.search.GetProgramIncentiveSubGridData(payload, this.transactionId);
    } else {
      call$ = this.search.GetProductIncentiveSubGridData(payload, this.transactionId)
    }

    call$.subscribe(res => this.grid.updateSelectedRecords(res.Data.map(rec => ({...rec, selected: this.grid.selectedAllValue}))));
  }

  private bindIncentive(bodyData) {
    if (['NAG_Programs', 'NAG_Onboarded_Products'].some(app => app === this.PprocessName)) {
      this.search.locationBasedFilterForProductApps('NAG_Incentives').subscribe(async (filter: any) => {

        if (bodyData.GridFilters && bodyData.GridFilters.filter(x => x.DataField === 'nagincavpilid').length === 0) {
          bodyData.GridFilters.push(filter);
        }

        const {IsBulkTriggerAllow} = await this.listviewService.userActionPermission({ProcessName: 'NAG_Incentives'}).toPromise();
        this.IsBulkTriggerAllow = IsBulkTriggerAllow;

        let columnFilter = [];

        if (this.HeaderMap) {
          if (this.HeaderMap.config.header.columnFilter)
            columnFilter = this.HeaderMap.config.header.columnFilter;
        }

        if (this.PprocessName === 'NAG_Programs') {          
          this.HeaderMap = {  
            config: {
              header: {
                columns: [
                  {
                    objectKey: 'nagincaviid',
                    displayName: 'Incentive ID',
                    width: '10%'
                  },
                  {
                    objectKey: 'nagincfvidname',
                    displayName: 'Incentive Name',
                    width: '10%'
                  },
                  {
                    objectKey: 'nagincavpipid',
                    displayName: 'Product ID',
                    width: '10%'
                  },
                  {
                    objectKey: 'nagincavpipn',
                    displayName: 'Product',
                    width: '10%'
                  },
                  {
                    objectKey: 'nagincapiman',
                    displayName: 'Manufacturer',
                    width: '10%'
                  },
                  {
                    objectKey: 'nagincaviddeob',
                    displayName: 'Offered By',
                    width: '10%'
                  },
                  {
                    objectKey: 'nagincaviddept',
                    displayName: 'Incentive Type',
                    //dataType: 'Checkbox',
                    width: '10%'
                  },
                  {
                    objectKey: 'nagincavpidis',
                    displayName: 'Distributor',
                    width: '10%'
                  }, 
                  {
                    objectKey: 'nagincavpidid',
                    displayName: 'Department ID',
                    width: '10%'
                  },
                  {
                    objectKey: 'nagincavidded',
                    displayName: 'Discount(%)',
                    width: '10%',
                  }, 
                  {
                    objectKey: 'nagincaviddeda',
                    displayName: 'Discount ($)',
                    width: '10%',
                    dataType: 'Currency'
                  },
                  {
                    objectKey: 'dispname',
                    displayName: 'State',
                    width: '10%'
                  }

                ],
                action: {
                  Edit: false,
                  Delete: false,
                  Checkbox: true,
                  Placement: 'IsExternalShow',
                  DropDown: false
                },
                columnFilter: columnFilter
              },
              paging: true,
              resizable: true,
            }
          };

          this.targetColumns = ['nagincaviid'];
          this.isExport = true;
          this.search.GetProgramIncentiveSubGridData(bodyData, this.transactionId).subscribe((x: any) => {
            this.dataSource = x.Data.map(item => {
              const record = this.grid.selectedRecordsValue.find(rec => rec.TRNSCTNID === item.TRNSCTNID);
              return {...item, nagincavidded: `${item.nagincavidded}%`, selected: !!record};
            });
            this.itemsCount = x.RecordsCount;
            this.ProcessName = "NAG_Incentives_Program";
          },
            err => {
              console.log(err);
            });
        }
        else {
          this.isExport = true;
          this.HeaderMap = {
            config: {
              header: {
                columns: [
                  {
                    objectKey: 'nagincaviid',
                    displayName: 'Incentive ID',
                    width: '10%'
                  },
                  {
                    objectKey: 'nagincfvidname',
                    displayName: 'Incentive Name',
                    width: '20%'
                  },
                  {
                    objectKey: 'nagincavpipid',
                    displayName: 'Product',
                    width: '10%'
                  },
                  {
                    objectKey: 'nagincaviddeob',
                    displayName: 'Offered By',
                    width: '15%'
                  },
                  {
                    objectKey: 'nagincaviddept',
                    displayName: 'Incentive Type',
                    // dataType: 'Checkbox',
                    width: '15%'
                  }, 
                  {
                    objectKey: 'nagincavidded',
                    displayName: 'Discount(%)',
                    width: '10%',
                    // dataType: 'Percent'
                  }, 
                  {
                    objectKey: 'nagincaviddeda',
                    displayName: 'Discount ($)',
                    width: '10%',
                    dataType: 'Currency'
                  },
                  {
                    objectKey: 'dispname',
                    displayName: 'State',
                    width: '10%'
                  }

                ],
                action: {
                  Edit: false,
                  Delete: false,
                  Checkbox: true,
                  Placement: 'IsExternalShow',
                  DropDown: false
                },
                columnFilter: columnFilter
              },
              paging: true,
              resizable: true,
            }
          };
          this.targetColumns = ['nagincaviid'];

          this.search.GetProductIncentiveSubGridData(bodyData, this.transactionId).subscribe((x: any) => {
            this.dataSource = x.Data.map(item => {
              const record = this.grid.selectedRecordsValue.find(rec => rec.TRNSCTNID === item.TRNSCTNID);
              return {...item, nagincavidded: `${item.nagincavidded}%`, selected: !!record};
            });
            this.itemsCount = x.RecordsCount;
            this.ProcessName = "NAG_Incentives_Products";
            this.totalsFooter = (x as any).summary;
          },
            err => {
              console.log(err);
            });
        }
      })
    }
  }

  actionClick(event) {
    switch (event.action) {
      case 'Filter_Header':
        this.bindColumnFilterDdl(event);
        break;
      case 'Edit':
        
        const EmailAddress = this.dataSource[event.rowIndex].EmailAddress;
        this.router.navigate(['/e-saleyard/edit-buyer', EmailAddress]);
        break;
      case 'Filter_Click':
        if (!this.validate(event)) {
          break;
        }
        this.bodyData.PageNumber = 1;
        let filter: any = {};
        filter = {
          GridConditions: [
          ],
          DataField: event.colData.objectKey,
          LogicalOperator: event.filterData.logicalOpt.Value === 'Select...' ? '' : event.filterData.logicalOpt.Value,
          FilterType: 'Column_Filter'
        };

        if (event.colData.dataType === 'Checkbox') {
          const choices: string[] = event.filterData.filterValue1.split(',');

          filter.LogicalOperator = 'OR';
          choices.forEach(x => {
            filter.GridConditions.push({
              Condition: 'EQUAL',
              ConditionValue: x
            });
          });
        } else {
          if (event.filterData.filterValue1 && event.filterData.filterValue1 !== '') {       
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: event.filterData.filterValue1
            });          
          }
          if (event.filterData.filterValue2 && event.filterData.filterValue2 !== '') {         
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: event.filterData.filterValue2
            });          
          }
        }
        if (event.filterData.ConditionOpt1.Value === 'NULL') {
          filter.GridConditions.push({
            Condition: 'EMPTY',
            ConditionValue: 'EMPTY'
          });
        }
        if (event.filterData.ConditionOpt1.Value === 'NOT_NULL') {
          filter.GridConditions.push({
            Condition: 'NOT_EMPTY',
            ConditionValue: 'NOT_EMPTY'
          });
          filter.LogicalOperator = 'AND';
        }
        if (filter && Object.keys(filter).length !== 0) {
          this.filters['Column_Filter~$~' + event.colData.objectKey] = filter;
        }
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
      case 'asc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'asc';
        sessionStorage.setItem('faq_grid_filter', JSON.stringify(this.bodyData));
        this.bindIncentive(this.bodyData);
        
        break;
      case 'desc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'desc';
        sessionStorage.setItem('faq_grid_filter', JSON.stringify(this.bodyData));
        
        this.bindIncentive(this.bodyData);
        break;
      case 'Remove Sort':
        this.bodyData.SortColumn = '-1';
        this.bodyData.SortOrder = 'desc';
        sessionStorage.setItem('faq_grid_filter', JSON.stringify(this.bodyData));
        this.bindIncentive(this.bodyData);
        break;
      case 'Delete':
        // this.openConfirmation(this.dataSource[event.rowIndex].UserName);
        break;
      case 'FilterClear_Click':
        delete this.filters['Column_Filter~$~' + event.colData.objectKey];
        sessionStorage.removeItem('faq_grid_filter');
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
        case 'Export Excel':
          this.openNewExportPopup('excel');
          break;
        case 'Export PDF':
          this.openNewExportPopup('pdf');
          break;
        case 'RefreshGrid':
          this.refreshGrid();
          break;
    }
    
  }

  private generateFilter() {
    this.grid.updateSelectedRecords([]);
    sessionStorage.removeItem('faq_grid_filter');
    this.bodyData.GridFilters = [];
    this.bodyData.PageNumber = 1;
    this.bodyData.SortColumn = '-1';
    Object.keys(this.filters).forEach(key => {
      this.bodyData.GridFilters.push(this.filters[key]);
    });
    sessionStorage.setItem('faq_grid_filter', JSON.stringify(this.bodyData));
    this.bindIncentive(this.bodyData);
  }

  validate(event): boolean {

    if (event.filterData.ConditionOpt1 && (event.filterData.ConditionOpt1.Value === '' ||
      event.filterData.ConditionOpt1.Value === 'Select...')) {
      return false;
    } else if (event.filterData.filterValue1 && event.filterData.filterValue1.Value === '') {
      return false;
    } else {
      return true;
    }
  }
  bindColumnFilterDdl(item) {
    let type = '';
    if (item.colData.dataType === 'Date' || item.colData.dataType === 'Currency') {
      type = 'DateEditBox';
    } else if (item.colData.dataType === 'Checkbox') {
      type = 'CheckBoxList';
    }
    const FilterData = this.columnFilter.GetFilterByDataType(type); 
    if (FilterData.length === 0) {    
    } else {
      const key = Object.keys(item.colData)[0];
      this.HeaderMap.config.header.columnFilter['colData_' + item.colIndex] = FilterData;
      this.ConditionOpt1 = item.ConditionOpt1;
      this.ConditionOpt2 = item.ConditionOpt2;
    }

  }
  removeFilter() {
    this.filters = [];
    this.pageNum = 1;
    this.generateFilter();
  }

  pageChange(event) {
    this.bodyData.PageNumber = event.currentPage;
    this.bodyData.PageSize = event.pageSize;
    this.bindIncentive(this.bodyData);
  }

  openNewExportPopup(ExportType: string) {
    if (this.PprocessName === 'NAG_Programs') {
      this.novus.getProgramInentiveColumns('NAG_Incentives').subscribe(Result => {
        const modalRef = this.modalService.open(GridViewExportComponent, { backdrop: 'static' });
        const modalInstance: GridViewExportComponent = modalRef.componentInstance;
        modalInstance.ExportType = ExportType.toUpperCase();
        modalInstance.ExportPopup = modalRef;
        modalInstance.ExportUserData.SortColumn = this.bodyData.SortColumn;
        modalInstance.ExportUserData.SortOrder = this.bodyData.SortOrder;
        modalInstance.ExternalCall = {
          FromURL: true,
          GUID: 'GUID',
          displayValue: 'DisplayName',
          DownloadFileURL: this.novus.getProgIncentivEndPoint(ExportType)
        };
        modalInstance.ExportUserData.GridFilters = this.bodyData.GridFilters;
        modalInstance.ExportUserData.ProcessName = 'NAG_Incentives';
        modalInstance.ExportUserData.TransactionID = this.transactionId;
        modalInstance.setDmoList(Result);
      },
        err => {
          console.log(err);
        });
    }
    else {
      this.novus.getInentiveColumns('NAG_Incentives').subscribe(Result => {
        const modalRef = this.modalService.open(GridViewExportComponent, { backdrop: 'static' });
        const modalInstance: GridViewExportComponent = modalRef.componentInstance;
        modalInstance.ExportType = ExportType.toUpperCase();
        modalInstance.ExportPopup = modalRef;
        modalInstance.ExportUserData.SortColumn = this.bodyData.SortColumn;
        modalInstance.ExportUserData.SortOrder = this.bodyData.SortOrder;
        modalInstance.ExternalCall = {
          FromURL: true,
          GUID: 'GUID',
          displayValue: 'DisplayName',
          DownloadFileURL: this.novus.getIncentivEndPoint(ExportType)
        };
        modalInstance.ExportUserData.GridFilters = this.bodyData.GridFilters;
        modalInstance.ExportUserData.ProcessName = 'NAG_Incentives';
        modalInstance.ExportUserData.TransactionID = this.transactionId;
        modalInstance.setDmoList(Result);
      },
        err => {
          console.log(err);
        });
    }
   
  }

  convertToLocalDataAndTime(value, format, zone) {
    if (value == null || value === '') {
      return null;
    }
    try {
      const d = new Date(value);
      let timeZone;
      if (!zone) {
        timeZone = this.TimeZone;
      } else {
        timeZone = zone;
      }
      const localOffset = timeZone * -60000;
      const localTime = d.getTime();
      d.setTime(localTime);
      return formatDate(d, format, 'en-US');
    } catch (error) {      
      return '';
    }
  }

 ChangeFilterDateFormat(dateValue){
    var d = new Date(dateValue);
    var localOffset = d.getTimezoneOffset() * 60000;
    return new Date(d.getTime() + localOffset);    
  }

  refreshGrid() {
    this.bodyData = {
      TransactionId: this.transactionId,
      PageSize: 10,
      PageNumber: 1,
      SortColumn: '-1',
      SortOrder: 'desc',
      TimeZone: new Date().getTimezoneOffset(),
      GridFilters: this.bodyData.GridFilters,
    };    
    this.bindIncentive(this.bodyData);
  }

  ngOnDestroy() {
    this.componentActive = false;
  }
}
