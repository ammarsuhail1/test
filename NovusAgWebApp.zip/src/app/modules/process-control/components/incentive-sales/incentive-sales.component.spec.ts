import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IncentiveSalesComponent } from './incentive-sales.component';

describe('IncentiveSalesComponent', () => {
  let component: IncentiveSalesComponent;
  let fixture: ComponentFixture<IncentiveSalesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IncentiveSalesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IncentiveSalesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
