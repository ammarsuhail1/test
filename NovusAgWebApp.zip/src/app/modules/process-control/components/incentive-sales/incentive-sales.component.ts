import { DatePipe } from '@angular/common';
import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ColumnFilterService, IHeaderMap, GridResponse } from '@app/core';
import { NovusService } from '@app/core/services/novus.service';
import { UtilityService } from '@app/core/services/utility.service';
import { environment } from '@env/environment';
import { takeWhile } from 'rxjs/operators';
import { DetailViewService } from '../../services/detail-view.service';

@Component({
  selector: 'app-incentive-sales',
  templateUrl: './incentive-sales.component.html',
  styleUrls: ['./incentive-sales.component.scss']
})
export class IncentiveSalesComponent implements OnInit, OnDestroy {
  @Input() transactionId: string;
  @Input() salesData: GridResponse<any>;
  componentActive = true;
  filters: any = {};
  dataSource: any;
  itemsCount: number;
  itemsPerPage: number;
  pageNum = -1;
  constructor(
    private dv: DetailViewService,
    private utility: UtilityService,
    private columnFilter: ColumnFilterService,
    private datePipe: DatePipe,
    private novus: NovusService,
  ) { }
  bodyData = this.utility.generateGridConfig({
    ProcessName: '',
    ColumnList: '',
    SortOrder: '-1',
    PageSize: 10,
    PageNumber: 1,
  });

  HeaderMap: IHeaderMap = {
    config: {
      header: {
        columns: [
          {
            objectKey: 'productid',
            displayName: 'Product Code',
          },
          {
            objectKey: 'productname',
            displayName: 'Product Name',
          },
          {
            objectKey: 'locationid',
            displayName: 'Location ID',
          },
          {
            objectKey: 'locationname',
            displayName: 'Location Name',
          },
          {
            objectKey: 'department',
            displayName: 'Department ID',
          },
          {
            objectKey: 'quantity',
            displayName: 'Quantity',
          },
          {
            objectKey: 'billunit',
            displayName: 'Units',
          },
          {
            objectKey: 'sales',
            displayName: 'Sales',
          },
          {
            objectKey: 'invdate',
            displayName: 'Sale/Invoice Date',
            dataType: 'Date',
            format: environment.Setting.dateFormat,
            timeZone: new Date().getTimezoneOffset(),
          },

        ],
        action: {
          Edit: false,
          Delete: false,
          Checkbox: false,
          Placement: 'IsExternalShow',
          DropDown: false
        },
        columnFilter: []
      },
      paging: true,
      autoTableLayout: true,
    }
  };
  async ngOnInit() {
    if (this.salesData && this.salesData.Data.length > 0) {
      this.dataSource = this.salesData.Data;
      this.itemsCount = +this.salesData.RecordsCount;
      this.itemsPerPage = +this.salesData.End - +this.salesData.Begin + 1;
    } else {
      this.dataSource = [];
      this.itemsCount = 0;
    }
    //this.dv.tabRefreshed$
      //.pipe(takeWhile(_ => this.componentActive))
      //.subscribe(_ => this.bindData());
    //this.bindData();
  }
  
  private bindData() {
    // this.novus.getIncentiveSales(this.transactionId, this.bodyData).subscribe(response => {
    //   this.dataSource = response.Data;
    //   this.itemsCount = +response.RecordsCount;
    //   this.itemsPerPage = +response.End - +response.Begin + 1;
    // },
    // _error => {
    //   this.dataSource = [];
    //   this.itemsCount = 0;
    // });
  }


  pageChange(event) {
    this.bodyData.PageNumber = event.currentPage;
    this.bodyData.PageSize = event.pageSize;
    this.bindData();
  }

  actionClick(event) {
    if (event.action == "asc" || event.action == "desc") {
      if (event.action == "asc") {        
        event.action = "asc";
      } else {
        event.action = "desc";
      }
    }
    switch (event.action) {
      case 'Filter_Header':
        this.bindColumnFilterDdl(event);
        break;
      case 'Filter_Click':
        if (!this.validate(event)) {
          break;
        }
        this.bodyData.PageNumber = 1;
        let filter: any = {};
        filter = {
          GridConditions: [
          ],
          DataField: event.colData.objectKey,
          LogicalOperator: event.filterData.logicalOpt.Value === 'Select...' ? '' : event.filterData.logicalOpt.Value,
          FilterType: 'Column_Filter'
        };
        if (event.filterData.filterValue1 && event.filterData.filterValue1 !== '') {
          if (event.colData.dataType === 'Date') {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: this.datePipe.transform(event.filterData.filterValue1, 'yyyy-MM-dd')
            });
          } else {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: event.filterData.filterValue1
            });
          }
        }
        if (event.filterData.filterValue2 && event.filterData.filterValue2 !== '') {
          if (event.colData.dataType === 'Date') {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: this.datePipe.transform(event.filterData.filterValue2, 'yyyy-MM-dd')
            });
          } else {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: event.filterData.filterValue2
            });
          }
        }
        if (filter && Object.keys(filter).length !== 0) {
          this.filters['Column_Filter~$~' + event.colData.objectKey] = filter;
        }
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
      case 'asc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'asc';
        this.bindData();
        break;
      case 'desc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'desc';
        this.bindData();
        break;
      case 'Remove Sort':
        this.bodyData.SortColumn = '-1';
        this.bodyData.SortOrder = '-1';
        this.bindData();
        break;
      case 'FilterClear_Click':
        delete this.filters['Column_Filter~$~' + event.colData.objectKey];
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
    }
  }


  private generateFilter() {
    // this.bodyData.GridFilters = [];
    this.bodyData.PageNumber = 1;
    Object.keys(this.filters).forEach(key => {
      this.bodyData.GridFilters.push(this.filters[key]);
    });
    this.bindData();
  }
  validate(event): boolean {
    if (event.filterData.ConditionOpt1 && (event.filterData.ConditionOpt1.Value === '' ||
      event.filterData.ConditionOpt1.Value === 'Select...')) {
      return false;
    } else if (event.filterData.filterValue1 && event.filterData.filterValue1.Value === '') {
      return false;
    } else {
      return true;
    }
  }
  bindColumnFilterDdl(item) {
    let type = '';
    if (item.colData.dataType === 'Date') {
      type = 'DateEditBox';
    }
    const FilterData = this.columnFilter.GetFilterByDataType(type); // Calling Function to get ColumnFilter Condition data
    if (FilterData.length === 0) { // Check if Array is empty then call API for options data
    } else {
      this.HeaderMap.config.header.columnFilter['colData_' + item.colIndex] = FilterData;
    }
  }
  removeFilter() {
    this.filters = [];
    const defaultBodyData = this.utility.generateGridConfig({
      ProcessName: '',
      ColumnList: '',
      SortOrder: '-1',
      PageSize: 10,
      PageNumber: 1,
    });
    defaultBodyData.GridFilters = this.bodyData.GridFilters.filter(filter => filter.FilterType as any === 'Customize_Filter');
    this.bodyData = defaultBodyData;
    this.pageNum = 0;
    this.generateFilter();
  }

  ngOnDestroy() {
    this.componentActive = false;
  }

}
