import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssociatedProductInstancesComponent } from './associated-product-instances.component';

describe('AssociatedProductInstancesComponent', () => {
  let component: AssociatedProductInstancesComponent;
  let fixture: ComponentFixture<AssociatedProductInstancesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssociatedProductInstancesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssociatedProductInstancesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
