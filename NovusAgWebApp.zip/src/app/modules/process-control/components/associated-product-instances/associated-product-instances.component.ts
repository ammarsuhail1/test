import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { ColumnFilterService, IHeaderMap, ListviewService, MAX_SELECT_ALL_CAP } from '@app/core';
import { SearchService } from '@app/core/services/search.service';
import { UtilityService } from '@app/core/services/utility.service';
import { GenericGridService } from '@app/shared/components/generic-grid/generic-grid.service';
import { takeWhile } from 'rxjs/operators';
import { DetailViewService } from '../../services/detail-view.service';

@Component({
  selector: 'app-associated-product-instances',
  templateUrl: './associated-product-instances.component.html',
  styleUrls: ['./associated-product-instances.component.scss'],
  providers: [GenericGridService],
})
export class AssociatedProductInstancesComponent implements OnInit, OnDestroy {
  @Input() transactionId: string;
  @Output() refreshParent = new EventEmitter<boolean>();

  public IsBulkTriggerAllow = false;
  componentActive = true;
  filters: any = {};
  dataSource: any;
  itemsCount: number;
  itemsPerPage: number;
  pageNum = -1;
  constructor(
    public grid: GenericGridService,
    private utility: UtilityService,
    private columnFilter: ColumnFilterService,
    private datePipe: DatePipe,
    private dv: DetailViewService,
    private search: SearchService,
    private listView: ListviewService,
  ) { }
  bodyData = this.utility.generateGridConfig({
    TransactionId: this.transactionId,
    ProcessName: '',
    ColumnList: '',
    SortOrder: '-1',
    PageSize: 10,
  });

  HeaderMap: IHeaderMap = {
    config: {
      header: {
        columns: [
          {
            objectKey: 'nagprfvpdpname',
            displayName: 'Product ID',
          },
          {
            objectKey: 'nagprfvpdprname',
            displayName: 'Product Name',
            width: '25%'
          },
          {
            objectKey: 'nagpravdeptid',
            displayName: 'Department ID',
          },
          {
            objectKey: 'nagpravlocname',
            displayName: 'Location Name',
          },
          {
            objectKey: 'nagznfvzsdtz',
            displayName: 'Zone Name',
          },
          {
            objectKey: 'nagdifvdsdtd',
            displayName: 'Distributor Name',
          },
          {
            objectKey: 'nagpravpiid',
            displayName: 'Product Instance ID',
            dataType: 'Link',
            width: '15%'
          },
          {
            objectKey: 'WFOSDISPNAME',
            displayName: 'State',
          },
        ],
        action: {
          Edit: false,
          Delete: false,
          Checkbox: true,
          Placement: 'IsExternalShow',
          DropDown: false
        },
        columnFilter: []
      },
      paging: true,
      autoTableLayout: true,
      resizable: true,
    }
  };
  async ngOnInit() {
    this.grid.selectedAll$
      .pipe(takeWhile(_ => this.componentActive))
      .subscribe(selectedAll => selectedAll ? this.getAllRecords() : this.grid.updateSelectedRecords([]));
    this.listView.userActionPermission({ProcessName: 'NAG_Onboarded_Products'})
      .subscribe(({IsBulkTriggerAllow}) => this.IsBulkTriggerAllow = IsBulkTriggerAllow);
    this.dv.triggerClicked$
    .pipe(takeWhile(_ => this.componentActive))
    .subscribe(_ => this.bindData());
    this.bindData();
  }

  private getAllRecords() {
    if (this.itemsCount > MAX_SELECT_ALL_CAP) {
      return;
    }
    const payload: any = {
      ...this.bodyData,
      PageNumber: 1,
      PageSize: this.itemsCount,
    };
    this.search.getAssociatedProductInstances(payload, this.transactionId)
      .subscribe(res => this.grid.updateSelectedRecords(res.Data.map(rec => ({...rec, selected: this.grid.selectedAllValue}))));
  }

  private bindData() {
    this.search.getAssociatedProductInstances(this.bodyData, this.transactionId).subscribe(response => {
      this.dataSource = response.Data.map(item => {
        const record = this.grid.selectedRecordsValue.find(rec => rec.TRNSCTNID === item.TRNSCTNID);
        return {...item, selected: !!record};
      });
      this.itemsCount = +response.RecordsCount;
      this.itemsPerPage = + response.End;
    },
    _error => {
      this.dataSource = [];
      this.itemsCount = 0;
    });
  }



  pageChange(event) {
    this.bodyData.PageNumber = event.currentPage - 1;
    this.bodyData.PageSize = event.pageSize;
    this.bindData();
  }

  actionClick(event) {
    if (event.action == "asc" || event.action == "desc") {
      if (event.action == "asc") {        
        event.action = "asc";
      } else {
        event.action = "desc";
      }
    }
    switch (event.action) {
      case 'Link':
        const transactionId = this.dataSource[event.rowIndex].TRNSCTNID;
        this.openProductInstance(transactionId);
        break;
      case 'Filter_Header':
        this.bindColumnFilterDdl(event);
        break;
      case 'Filter_Click':
        if (!this.validate(event)) {
          break;
        }
        this.bodyData.PageNumber = 0;
        let filter: any = {};
        filter = {
          GridConditions: [
          ],
          DataField: event.colData.objectKey,
          LogicalOperator: event.filterData.logicalOpt.Value === 'Select...' ? '' : event.filterData.logicalOpt.Value,
          FilterType: 'Column_Filter'
        };
        if (event.filterData.filterValue1 && event.filterData.filterValue1 !== '') {
          if (event.colData.dataType === 'Date') {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: this.datePipe.transform(event.filterData.filterValue1, 'yyyy-MM-dd')
            });
          } else {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: event.filterData.filterValue1
            });
          }
        }
        if (event.filterData.filterValue2 && event.filterData.filterValue2 !== '') {
          if (event.colData.dataType === 'Date') {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: this.datePipe.transform(event.filterData.filterValue2, 'yyyy-MM-dd')
            });
          } else {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: event.filterData.filterValue2
            });
          }
        }
        if (filter && Object.keys(filter).length !== 0) {
          this.filters['Column_Filter~$~' + event.colData.objectKey] = filter;
        }
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
      case 'asc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'asc';
        this.bindData();
        break;
      case 'desc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'desc';
        this.bindData();
        break;
      case 'Remove Sort':
        this.bodyData.SortColumn = '-1';
        this.bodyData.SortOrder = '-1';
        this.bindData();
        break;
      case 'FilterClear_Click':
        delete this.filters['Column_Filter~$~' + event.colData.objectKey];
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
    }
  }

  private openProductInstance(transactionId: string) {
    const link = `/process_control/NAG_Onboarded_Products/detail_view/${encodeURIComponent(transactionId)}`;
    window.open(link, '_blank');
  }
  private generateFilter() {
    this.grid.updateSelectedRecords([]);
    this.bodyData.GridFilters = [];
    this.bodyData.PageNumber = 0;
    Object.keys(this.filters).forEach(key => {
      this.bodyData.GridFilters.push(this.filters[key]);
    });
    this.bindData();
  }
  validate(event): boolean {
    if (event.filterData.ConditionOpt1 && (event.filterData.ConditionOpt1.Value === '' ||
      event.filterData.ConditionOpt1.Value === 'Select...')) {
      return false;
    } else if (event.filterData.filterValue1 && event.filterData.filterValue1.Value === '') {
      return false;
    } else {
      return true;
    }
  }
  bindColumnFilterDdl(item) {
    let type = '';
    if (item.colData.dataType === 'Date') {
      type = 'DateEditBox';
    }
    const FilterData = this.columnFilter.GetFilterByDataType(type); // Calling Function to get ColumnFilter Condition data
    if (FilterData.length === 0) { // Check if Array is empty then call API for options data
    } else {
      this.HeaderMap.config.header.columnFilter['colData_' + item.colIndex] = FilterData;
    }
  }
  removeFilter() {
    this.filters = [];
    const defaultBodyData = this.utility.generateGridConfig({
      ProcessName: '',
      ColumnList: '',
      SortOrder: '-1',
      PageSize: 50,
    });
    defaultBodyData.GridFilters = this.bodyData.GridFilters.filter(filter => filter.FilterType as any === 'Customize_Filter');
    this.bodyData = defaultBodyData;
    this.pageNum = 0;
    this.generateFilter();
  }

  ngOnDestroy() {
    this.componentActive = false;

  }

}
