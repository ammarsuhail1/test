import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-drilldown',
  templateUrl: './drilldown.component.html',
  styleUrls: ['./drilldown.component.scss']
})
export class DrillDownComponent {
  ProcessName: string;
  queryParams: any;
  constructor(private route: ActivatedRoute) {
    this.queryParams = this.route.snapshot.queryParams; 
    this.ProcessName = this.route.snapshot.params.id;
  }
}
