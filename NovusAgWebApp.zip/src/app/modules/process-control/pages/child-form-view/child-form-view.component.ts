import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { environment } from '@env/environment';
import { FormViewService, DmoControlService, ApplicationService, AuthenticationService, BMConditionService, MessageService } from '@app/core';
import { DetailViewService } from '../../services/detail-view.service';
import { tap } from 'rxjs/operators';
import { CustomFormActionsService } from '../../services/custom-form-actions.service';
import { UserDetail } from '@app/core/models/user-detail';

@Component({
  selector: 'child-form-view',
  templateUrl: './child-form-view.component.html',
  styleUrls: ['./child-form-view.component.scss']
})
export class ChildFormViewComponent implements OnInit {
  BMId: number;
  BMJSON: any = {};
  WFJSON: any = {};
  form: FormGroup;
  dmos = [];
  bmogCondJson = [];
  triggerCondJson = [];
  processName: string;
  processUrlName: string;
  transactionId: string;
  applicationData: any = {};

  parentTransactionId: string;
  parentProcessName: string;
  parentData: any;

  topCornerDetails = [];
  triggers: any = [];
  currentStageGuid: string;
  currentStateGuid: string;
  formSubmitted = false;
  formTriggered = false;
  currentUser: any = {};
  isSubprocess: any = false;
  wfosType: string;
  wfosName: string;
  SubProcessNames: string;
  ParentDmoName: string;
  ParentDmoValue: string;
  CanvasType: string = 'AdminView';
  uniqueConstraint:any;  

  constructor(
    private cfa: CustomFormActionsService,
    private detail: DetailViewService,
    private toastr: ToastrService,
    private router: Router,
    private route: ActivatedRoute,
    private formViewService: FormViewService,
    private applicationService: ApplicationService,
    private dmoControlService: DmoControlService,
    private cdr: ChangeDetectorRef,
    private authenticationService: AuthenticationService,
    public location: Location, 
    private bmCondition: BMConditionService, 
    private msg: MessageService,
    private userDetail: UserDetail) { }

  ngOnInit() {
    this.currentUser = this.userDetail;
    this.route.paramMap.subscribe(params => {
      this.transactionId = params.get('childId');
      this.parentTransactionId = params.get('id');
      this.parentProcessName = params.get('process_name');
      this.processName = params.get('childProcess');
      this.processUrlName = params.get('childProcess');
      this.applicationService.getApplicationData(null, null, this.CanvasType, this.transactionId).subscribe(async (appData) => {
        this.applicationData = appData;
        /* For child view instances pull parent data */
        if (this.parentTransactionId) {
          await this.detail.getDetails(this.parentTransactionId)
            .pipe(tap(response => this.parentData = response.DataInformation))
            .toPromise();
        }

        this.applicationService.getTopCornerDetail(null, null, this.CanvasType, this.transactionId).subscribe(topDetails => {
            this.topCornerDetails = topDetails;

            this.currentStageGuid = this.applicationData.ApplicationInfo[0].StagGuid;
            this.currentStateGuid = this.applicationData.ApplicationInfo[0].StateGuid;
            this.getBMWFJson();
        })
      })

     

    });
  }

  private getBMWFJson() {
    this.formViewService.getBmWfJson(this.processName, this.CanvasType, this.transactionId).subscribe(response => {
      if (response.BM !== undefined && response.WF !== undefined && response.BM !== null && response.WF !== null)  {
        this.BMId = response.BM.BMId;
        this.uniqueConstraint = response.BM.UniqueConstraint;
        this.BMJSON = response.BM.BusinessModelObjectGroup.AdminView;
        this.BMJSON.List.push('notes');
        this.BMJSON.List.push('notification');
        this.BMJSON.List.push('activitylog');
        this.BMJSON.List.push('history');
        this.BMJSON.BusinessModelObjects.notes = { Type: 'Log', DisplayName: 'Notes' };
        this.BMJSON.BusinessModelObjects.activitylog = { Type: 'Log', DisplayName: 'Activity Log' };
        this.BMJSON.BusinessModelObjects.history = { Type: 'Log', DisplayName: 'Change Log' };
        this.BMJSON.BusinessModelObjects.notification = { Type: 'Log', DisplayName: 'Notification' };
        this.WFJSON = response.WF;
        this.getForm();
      } else {
        this.msg.showMessage('Warning', {body: environment.Setting.xmlgeneratemsg});
      }
    });
  }

  getForm() {
    this.BMJSON.List.forEach(bmoGuid => {
      if (this.BMJSON.BusinessModelObjects[bmoGuid].Type === 'SubProcess') {
        this.SubProcessNames = this.SubProcessNames === undefined ? this.BMJSON.BusinessModelObjects[bmoGuid].ProcessName : this.SubProcessNames + "," + this.BMJSON.BusinessModelObjects[bmoGuid].ProcessName;
      }
      if (this.BMJSON.BusinessModelObjects[bmoGuid].Type === 'ChildProcess') {
        this.ParentDmoName = this.BMJSON.BusinessModelObjects[bmoGuid].ParentProcessDmoName;
      }
      this.bmogCondJson[bmoGuid] = {
        IsVisible: true, IsEnable: true, IsRequired: null, Name: this.BMJSON.BusinessModelObjects[bmoGuid].Name
        , isHideFromStageState: false
      };
      if (this.BMJSON.BusinessModelObjects[bmoGuid].List != undefined) {

        this.BMJSON.BusinessModelObjects[bmoGuid].List.forEach(dmogGuid => {
          this.bmogCondJson[bmoGuid][dmogGuid] = {
            IsVisible: true, IsEnable: true, IsRequired: null,
            Name: this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].Name,
            isHideFromStageState: false
          };
          this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].List.forEach(rowID => {
            this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].Rows[rowID].Columns.forEach(objCOLUMN => {
              objCOLUMN.List.forEach(dmoGUID => {
                const dmoData = { ...objCOLUMN.DataModelObjects[dmoGUID] };
                dmoData.DMOGuid = dmoGUID;
                dmoData.BmoGuid = bmoGuid;
                dmoData.DmogGuid = dmogGuid;
                this.dmos.push(dmoData);
                this.bmogCondJson[bmoGuid][dmogGuid][dmoGUID] = {
                  IsVisible: true, IsEnable: true,
                  IsRequired: objCOLUMN.DataModelObjects[dmoGUID].IsRequired, Name: objCOLUMN.DataModelObjects[dmoGUID].Name,
                  dmoOption: objCOLUMN.DataModelObjects[dmoGUID].Options,
                  isHideFromStageState: false
                };
              });
            });
          });
        });
      }
    });
    this.getTriggers();
    this.dmoControlService.CurrentStage = this.WFJSON.Stages[this.currentStageGuid];
    this.dmoControlService.CurrentState = this.WFJSON.Stages[this.currentStageGuid].States[this.currentStateGuid];
    this.wfosType = this.WFJSON.Stages[this.currentStageGuid].States[this.currentStateGuid].WfosType;
    this.wfosName = this.WFJSON.Stages[this.currentStageGuid].States[this.currentStateGuid].Name;
    this.form = this.dmoControlService.toAdminViewFormGroup(this.dmos, this.applicationData);
    this.bmCondition.LoadWFConditiononPageLoad(this.WFJSON, this.currentStageGuid, this.currentStateGuid, this.BMId, this.form, this.bmogCondJson, this.BMJSON);
    this.bmCondition.LoadBMConditiononPageLoad(this.BMJSON, this.form, this.bmogCondJson, this.triggerCondJson);
    this.ParentDmoValue = this.form.controls[this.ParentDmoName] === undefined ? undefined : this.form.controls[this.ParentDmoName].value;
    this.cdr.detectChanges();
    if (this.processName === 'Release_Manager') {
      this.cfa.populateLocationPrice(this.form, this.parentData).toPromise();
    }
  }

  getTriggers() {
    this.triggers = [];
    if (this.detail.createSaveTrigger(this.applicationData, this.WFJSON)) {
      const save = {
        Name: 'Save Data',
        DisplayName: 'Save',
        ActionName: 'Submit',
        Type: 'Action',
        TriggerId: 0
      };
      this.triggers.push(save);
      this.triggerCondJson[save.TriggerId] = {isVisible: true, isEnable: true }; 

    }
    Object.keys(this.WFJSON.Stages[this.currentStageGuid].States[this.currentStateGuid].Triggers).forEach(triggerId => {
      this.triggers.push(this.WFJSON.Stages[this.currentStageGuid].States[this.currentStateGuid].Triggers[triggerId]);
      const trigger = this.WFJSON.Stages[this.currentStageGuid].States[this.currentStateGuid].Triggers[triggerId];
      this.triggerCondJson[triggerId] = {
        IsVisible: true, IsEnable: true, Guid: trigger.Guid
      };
    });
  }

  triggerSubmit(trigger: any) {
    if (trigger.ActionName === 'Submit') {
      this.formSubmitted = true;
      this.formTriggered = false;
      this.applicationService.checkValidations();
      if (!this.form.valid) {
        return;
      }
    } else {
      this.formSubmitted = false;
      this.formTriggered = true;

      let isFormInValid = false;
      Object.keys(this.form.controls).forEach(controlKey => {
        if (this.form.controls[controlKey].valid === false) {
          Object.keys(this.form.controls[controlKey].errors).forEach(errorKey => {
            if (errorKey !== 'required') {
              isFormInValid = true;
            }
          });
        }
      });
      if (isFormInValid) {
        return;
      }
    }
    this.submitForm(trigger);
  }

  private submitForm(trigger: any) {
    let formValue = { ...this.form.value };
    formValue = this.dmoControlService.getDirtyValues(this.form);
    formValue = this.dmoControlService.sanitizeFormValue(this.dmos, formValue);

    const submitData: any = {
      Identifier: {
        Name: null,
        Value: null,
        TrnsctnID: this.transactionId
      },
      ProcessName: this.processName,
      TriggerName: trigger.Name,
      UserName: this.currentUser.UserName,
      UniqueConstraints: this.uniqueConstraint,
      Data: [formValue]
    };

    let isvalidateUniqueCons: any = true;
    this.applicationService.ValidateUniqueDmoValue(submitData).subscribe(
      (resultData: any) => {
        isvalidateUniqueCons = resultData;        
      }
    );

    if (isvalidateUniqueCons) {
      this.applicationService.updateApplication(submitData).subscribe(res => {
        this.toastr.success('Data saved successfully');
        for (let cntrl in this.form.controls) {
          if (this.form.get(cntrl).dirty === true) {
            this.form.get(cntrl).markAsPristine();
          }
          this.form.get(cntrl).updateValueAndValidity();
        } 
        this.applicationService.getApplicationData(null, null, this.CanvasType, this.transactionId).subscribe(data => {
          this.applicationData = data;
          this.currentStageGuid = this.applicationData.ApplicationInfo[0].StagGuid;
          this.currentStateGuid = this.applicationData.ApplicationInfo[0].StateGuid;
          this.getBMWFJson();
        });
      });
    }
    else {
      this.toastr.warning('Please verify the Unique Constraints DMO(s)');
    }        
  }

  // isTriggerVisible(trigger: any) {
  //   if (trigger.DisplayName === 'Save')
  //     return true;
  //   let isShowHideTrigger = false;
  //   isShowHideTrigger = Object.keys(trigger.ActionRoles).every(actionRole => this.currentUser.Roles.includes(actionRole));
  //   if (isShowHideTrigger) {
  //     isShowHideTrigger = this.triggerCondJson[trigger.Guid].IsVisible;
  //   }
  //   return isShowHideTrigger;
  // }

  isTriggerVisible(trigger: any) {
    if (trigger.Name === 'Save Data')
      return true;
      
    let isShowHideTrigger = false;
    Object.keys(trigger.ActionRoles).forEach(roleguid => {
      if (isShowHideTrigger == false)
        isShowHideTrigger = this.currentUser.ListRole.indexOf(roleguid) > -1 ? true : false;
    });
    if (isShowHideTrigger)
      isShowHideTrigger = this.triggerCondJson[trigger.Guid].IsVisible;
    return isShowHideTrigger;
  }

  isTriggerEnable(trigger: any) {
    if (trigger.Name === 'Save Data')
      return true;
    return this.triggerCondJson[trigger.Guid].IsEnable;
  }

  getDMOFileData(dmoGUID: string) {
    if (this.applicationData.FileInformation[dmoGUID] === undefined) {
      return [];
    } else {
      return this.applicationData.FileInformation[dmoGUID];
    }
  }

  checkSubProcessRecord(trigger: any) {
    let result: any = '';
    if (this.wfosType === 'SubProcess') {
      if (this.SubProcessNames !== undefined) {
        if (this.SubProcessNames.indexOf(',') > -1) {

        } else {
          const processrecord = {
            ParentTransactionID: this.transactionId,
            ProcessName: this.SubProcessNames,
            StateName: this.wfosName
          };
          this.applicationService.checkSubProcessRecordCount(processrecord).subscribe(
            (resultData: any) => {
              result = resultData;
              if (result === 0) {
                this.triggerSubmit(trigger);
              } else {
                this.toastr.error('All Sub Process records are not on end state.');
              }
            }
          );
        }
      }
    } else {
      this.triggerSubmit(trigger);
    }
  }

  go_back() {
    this.router.navigate(['process_control', this.processUrlName]);
  }
}
