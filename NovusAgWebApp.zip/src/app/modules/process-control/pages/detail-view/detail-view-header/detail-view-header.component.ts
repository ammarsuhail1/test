import { ChangeDetectionStrategy, Component, Input } from '@angular/core';
import { DmoControlService } from '@app/core';
import { environment } from '@env/environment';

@Component({
  selector: 'app-detail-view-header',
  templateUrl: './detail-view-header.component.html',
  styleUrls: ['./detail-view-header.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class DetailViewHeaderComponent {
  @Input() headers: Array<{DisplayName: string, Value: string}>[] = [];
  private dateFormat = environment.Setting.dateFormat;
  
  constructor(private dmoControlService: DmoControlService) {}

  public isDate(value: string) {
    const regex = /([0-9]){1,2}\/([0-9]{2})\/([0-9]){4}/;
    return value.match(regex);
  }

  public convertDateTime(value: string) {
    return this.dmoControlService.getUserDateTime(value, this.dateFormat);
  }

}
