import { Component, OnInit, ChangeDetectorRef, Input, ElementRef, ViewChildren, QueryList, OnDestroy, Output, EventEmitter } from '@angular/core';
import { AbstractControl, FormGroup } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Title } from '@angular/platform-browser';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';

import { SpinnerVisibilityService } from 'ng-http-loader';
import { FormViewService, DmoControlService, ApplicationService, AuthenticationService, BMConditionService, MessageService, UserService, GridResponse, ListviewService } from '@app/core';
import { DocumentViewService } from '@app/core/services/document-view.service';
import { CustomFormActionsService } from '../../services/custom-form-actions.service';
import { DetailViewService } from '../../services/detail-view.service';
import { NovusService } from '@app/core/services/novus.service';

import { TabComponent } from '@app/shared';

import { environment } from '@env/environment';
import { takeWhile, tap } from 'rxjs/operators';
import { DeliveryTicketResponse } from '@app/core/models/project';
import { GridViewService } from '@app/shared/components/grid-view/grid-view.service';
import { Observable } from 'rxjs';
import {UserDetail} from '@app/core/models/user-detail';
import {SearchService} from '@app/core/services/search.service';

@Component({
  selector: 'app-detail-view',
  templateUrl: './detail-view.component.html',
  styleUrls: ['./detail-view.component.scss'],
})
export class DetailViewComponent implements OnInit, OnDestroy {

  @Input() transactionId: string;
  @Input() processUrlName: string;
  @Output() navigatedBack = new EventEmitter<boolean>();

  @ViewChildren(TabComponent) tabs !: QueryList<TabComponent>;
  headers$: Observable<Array<{DisplayName: string, Value: string}>[]>;
  associatedContractsHeaders: Array<{DisplayName: string, Value: string}>[];
  salesData: GridResponse<any>; // relevant only to NAG_Incentives

  dateFormat: string = environment.Setting.dateFormat;
  vendorPICList: any;

  BMId: number;
  BMJSON: any = {};
  WFJSON: any = {};
  form: FormGroup;
  dmos = [];
  bmogCondJson = [];
  triggerCondJson = [];
  processName: string;
  applicationData: any = {};

  parentTransactionId: string;
  parentProcessName: string;
  parentData: any;

  triggers: any = [];
  currentStageGuid: string;
  currentStateGuid: string;
  formSubmitted = false;
  formTriggered = false; 
  dateSubmitted = false; 
  currentUser: any = {};
  isSubprocess: any = false;
  wfosType: string;
  wfosName: string;
  SubProcessNames: string;
  ParentDmoName: string;
  ParentDmoValue: string;
  ChildDmoGuid = {};
  CanvasType = 'AdminView';
  uniqueConstraint: any;
  filledYN = false; // NOVUS SPECIFIC
  fprRefreshed = false;
  componentActive = true;
  public IsChangeLogAllow = false;
  public IsNotesAllow = false;
  public IsActivityLogAllow = false;
  public IsNotificationAllow = false;
  isCrop = true;
  UseAsMedia = true;
  locationFilter$: Observable<any>;

  get isFullView() {
    return this.router.url.includes('detail_view')
  }

  constructor(
    private search: SearchService,
    private gridView: GridViewService,
    private modal: NgbModal,
    private user: UserDetail,
    private novus: NovusService,
    private dv: DetailViewService,
    private cfa: CustomFormActionsService,
    private spinner: SpinnerVisibilityService,
    private el: ElementRef,
    private toastr: ToastrService,
    private router: Router,
    private route: ActivatedRoute,
    private formViewService: FormViewService,
    private applicationService: ApplicationService,
    private dmoControlService: DmoControlService,
    private cdr: ChangeDetectorRef,
    private authenticationService: AuthenticationService,
    public location: Location,
    private bmCondition: BMConditionService,
    private msg: MessageService,
    private documentServie: DocumentViewService,
    private titleService: Title,
    private listView: ListviewService,
    ) { }

  isEContractRecords() {
    return this.processUrlName === 'LMKCRMEContractsRecords';
  }

  ngOnInit() {
    this.currentUser = this.authenticationService.currentUserValue;
    this.route.paramMap.subscribe(async params => {
      if (this.transactionId == null) {
        this.transactionId = params.get('childId') || params.get('id');
        this.transactionId = decodeURIComponent(this.transactionId);
        if (params.get('childId')) {
          this.isSubprocess = true;
          this.parentTransactionId = decodeURIComponent(params.get('id'));
        }
      }
      

      if (this.processUrlName == null) {
        this.processUrlName = params.get('childProcess') || params.get('process_name');
        if (params.get('childProcess')) {
          this.parentProcessName = params.get('process_name');
        }
      }

      this.processName = params.get('childProcess') || sessionStorage.getItem('AppName');
      if (this.processName === '' || this.processName === undefined || this.processName === null) {
        this.opendetailLink();
      }
      if (this.processName === 'LMKOpportunities') {
        this.documentServie.isAttachmentGridView = true;
        this.CanvasType = 'View4';
      } else {
        this.CanvasType = 'AdminView';
      }
      const permissions = await this.listView.userActionPermission({ProcessName: this.processName}).toPromise();
      this.IsNotesAllow = permissions.IsNotesAllow;
      this.IsNotificationAllow = permissions.IsNotificationAllow;
      this.IsChangeLogAllow = permissions.IsChangeLogAllow;
      this.IsActivityLogAllow = permissions.IsActivityLogAllow;
      this.dv.updateViewInfo({
        processName: this.processName,
        transactionId: this.transactionId,
        parentTransactionId: this.parentTransactionId,
      });
      if (this.processName === 'NAG_Incentives') {
          await this.initIncentiveSales();
          this.locationFilter$ = this.search.locationBasedFilterForProductApps(this.processName);
      }
      this.applicationService.getApplicationData(null, null, this.CanvasType, this.transactionId).subscribe( async (appData) => {
        this.applicationData = appData;
        this.dv.updateViewData(appData);
        
        if (!this.parentTransactionId && this.processName === 'Release_Manager')
          this.parentTransactionId = appData.ApplicationInfo[0].PTransID;
        /* For child view instances pull parent data */
        if (this.parentTransactionId) {
          await this.dv.getDetails(this.parentTransactionId)
            .pipe(tap(response => this.parentData = response.DataInformation))
            .toPromise();
        }
              
        this.currentStageGuid = this.applicationData.ApplicationInfo[0].StagGuid;
        this.currentStateGuid = this.applicationData.ApplicationInfo[0].StateGuid;
        this.getBMWFJson();
    
      });
    });
  }

  private getBMWFJson() {
    this.headers$ = this.dv.getHeaders(this.transactionId, this.CanvasType).pipe(tap(headers => {
      this.associatedContractsHeaders = headers;
      this.dv.headersData(headers);
    }));
    this.formViewService.getBmWfJson(this.processName, this.CanvasType, this.transactionId).subscribe(response => {
      if (response.BM !== undefined && response.WF !== undefined && response.BM !== null && response.WF !== null) {
        this.spinner.hide();
        this.BMId = response.BM.BMId;
        this.uniqueConstraint = response.BM.UniqueConstraint;
        if (this.processName === 'LMKOpportunities') {
          this.BMJSON = response.BM.BusinessModelObjectGroup.View4;
        } else {
          this.BMJSON = response.BM.BusinessModelObjectGroup.AdminView;
        }
        
        if (this.processName === 'Fertilizer_Purchase_Request_Manager' && !this.currentUser.ListRole.some(role => role === 'nagdivisionadmin')) {
          this.BMJSON.List = this.BMJSON.List.filter(bmog => bmog !== 'nagfpravac');
        }
        if (this.IsNotesAllow) {
          this.BMJSON.List.push('notes');
          this.BMJSON.BusinessModelObjects.notes = { Type: 'Log', DisplayName: 'Notes' };
        }
        if (this.IsNotificationAllow) {
          this.BMJSON.List.push('notification');
          this.BMJSON.BusinessModelObjects.notification = { Type: 'Log', DisplayName: 'Notification' };
        }
        if (this.IsActivityLogAllow) {
          this.BMJSON.List.push('activitylog');
          this.BMJSON.BusinessModelObjects.activitylog = { Type: 'Log', DisplayName: 'Activity Log' };
        }
        if (this.IsChangeLogAllow) {
          this.BMJSON.List.push('history');
          this.BMJSON.BusinessModelObjects.history = { Type: 'Log', DisplayName: 'Change Log' };
        }
        this.WFJSON = response.WF;
        this.getForm();
      } else {
        this.msg.showMessage('Warning', {body: environment.Setting.xmlgeneratemsg});
      }
    });
  }

  public isDate(value: string) {
    const regex = /([0-9]){1,2}\/([0-9]{2})\/([0-9]){4}/;
    return value.match(regex);
  }

  public convertDateTime(value: string) {
    return this.dmoControlService.getUserDateTime(value, this.dateFormat, this.currentUser.TimeZone);
  }

  getForm() {
    this.dmos = [];

    // Reset these two switches to avoid preemptive invalid feedback
    // on form fields from wf conditions applied after state change 
    this.formSubmitted = false;
    this.formTriggered = false;
    this.dateSubmitted = false;
    
    this.BMJSON.List.forEach(bmoGuid => {
      if (this.BMJSON.BusinessModelObjects[bmoGuid].Type === 'SubProcess') {
        this.SubProcessNames = this.BMJSON.BusinessModelObjects[bmoGuid].ProcessName;
        /* What was the point of concatenating the process name strings 
          if checkSubProcessRecord call always fails to complete ?
          I leave the previous code commented below for reference 
        */

        // this.SubProcessNames = this.SubProcessNames === undefined ? this.BMJSON.BusinessModelObjects[bmoGuid].ProcessName : this.SubProcessNames + "," + this.BMJSON.BusinessModelObjects[bmoGuid].ProcessName;
      }
      if (this.BMJSON.BusinessModelObjects[bmoGuid].Type === 'ChildProcess') {
        this.ParentDmoName = this.BMJSON.BusinessModelObjects[bmoGuid].ParentProcessDmoName;
        let childProcessName = this.BMJSON.BusinessModelObjects[bmoGuid].ProcessName;
        if (childProcessName != undefined)
          this.ChildDmoGuid[childProcessName] = { ChildProcessDmoGuid: this.BMJSON.BusinessModelObjects[bmoGuid].ChildProcessDmoGuid };
      }
      this.bmogCondJson[bmoGuid] = {
        IsVisible: true,
        IsEnable: true,
        IsRequired: null,
        Name: this.BMJSON.BusinessModelObjects[bmoGuid].Name,
        isHideFromStageState: false
      };
      if (this.BMJSON.BusinessModelObjects[bmoGuid].List !== undefined) {

        this.BMJSON.BusinessModelObjects[bmoGuid].List.forEach(dmogGuid => {
          this.bmogCondJson[bmoGuid][dmogGuid] = {
            IsVisible: true,
            IsEnable: true,
            IsRequired: null,
            Name: this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].Name,
            isHideFromStageState: false
          };
          if (this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].Type !== 'Grid') {
            this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].List.forEach(rowID => {
              this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].Rows[rowID].Columns.forEach(objCOLUMN => {
                objCOLUMN.List.forEach(dmoGUID => {
                  const dmoData = { ...objCOLUMN.DataModelObjects[dmoGUID] };
                  dmoData.DMOGuid = dmoGUID;
                  dmoData.BmoGuid = bmoGuid;
                  dmoData.DmogGuid = dmogGuid;
                  this.dmos.push(dmoData);
                  this.bmogCondJson[bmoGuid][dmogGuid][dmoGUID] = {
                    IsVisible: true,
                    IsEnable: true,
                    IsRequired: objCOLUMN.DataModelObjects[dmoGUID].IsRequired,
                    Name: objCOLUMN.DataModelObjects[dmoGUID].Name,
                    dmoOption: objCOLUMN.DataModelObjects[dmoGUID].Options,
                    isHideFromStageState: false
                  };
                });
              });
            });
          }
        });
      }
    });
    this.getTriggers();
    this.dmoControlService.CurrentStage = this.WFJSON.Stages[this.currentStageGuid];
    this.dmoControlService.CurrentState = this.WFJSON.Stages[this.currentStageGuid].States[this.currentStateGuid];
    this.wfosType = this.WFJSON.Stages[this.currentStageGuid].States[this.currentStateGuid].WfosType;
    this.wfosName = this.WFJSON.Stages[this.currentStageGuid].States[this.currentStateGuid].Name;
    this.form = this.dmoControlService.toAdminViewFormGroup(this.dmos, this.applicationData);
    this.bmCondition.LoadBMConditiononPageLoad(this.BMJSON, this.form, this.bmogCondJson, this.triggerCondJson);
    this.bmCondition.LoadWFConditiononPageLoad(this.WFJSON, this.currentStageGuid, this.currentStateGuid, this.BMId, this.form, this.bmogCondJson, this.BMJSON);
    this.ParentDmoValue = this.form.controls[this.ParentDmoName] === undefined ? undefined : this.form.controls[this.ParentDmoName].value;
    const activeTab = this.tabs.find(tab => tab.active);
    if (activeTab) {
      this.onTabSelected(activeTab.title);
    }
    if (this.componentActive) {
      this.cdr.detectChanges();
    }

    if (this.processName === 'Release_Manager') {
      this.cfa.fromContractsToRM(this.form, this.parentData);
      this.cfa.reactToProductChangeInRMDetails(this.form).toPromise();  
      this.cfa.populateAddOnDetailsInRM(this.form, this.parentData); 
      this.cfa.addCustomerRequiredValidators(this.form, this.triggerCondJson).toPromise();
      // this.cfa.validateQuantityPulledBasedOnQuantityInRM(this.form).toPromise();
      this.cfa.roundAvailableCreditInRM(this.form).toPromise();
      if (this.currentStateGuid === 'nagwflmopenloc')
        this.cfa.populateLocationPrice(this.form, this.parentData).toPromise();
      else if (this.currentStateGuid === 'nagwflmpulledti') {
        this.cfa.handleTriggersVisibilityInRM(this.form,this.triggerCondJson).toPromise();
      }
    }

    else if (this.processName === 'Customer_Product_Manager') {
      this.cfa.populatePricingManagerFields(this.form, this.applicationData).toPromise();
    }

    else if (this.processName === 'Supply_Chain_Manager') {
      this.cfa.populateOtherContractDetails(this.transactionId, this.form)
        // .pipe(tap(quantitesChanged => {
        //   if (quantitesChanged)
        //     this.submitForm({Name: 'Save Data'});
        // }))
        .toPromise();
      // this.cfa.populateShippingStartAndEndDatesAndContractNumber(this.form).toPromise();
      this.cfa.calculateOtherPODetails(this.form).toPromise();
      if ((this.currentStateGuid === 'nagwfscmclosedclosed' || this.currentStateGuid === 'nagwfscmopenpulled') && !this.filledYN) {
        this.novus.updateContractsStateToPOClosed(this.transactionId).subscribe(update => {
          this.filledYN = update;
          if (this.filledYN) 
            // Emulate page reload with Save trigger if FilledYN is true
            this.submitForm({Name: 'Save Data'}, false, true)
              .then(_ => this.novus.deactivatePricingManagerEntriesState(this.transactionId).toPromise());
        })
      }
    }

    else if (this.processName === 'Vendor_Master') {
      this.cfa.populateAvailableCreditInVendorMaster(this.form, this.transactionId).toPromise();
    }

    else if (this.processName === 'Fertilizer_Purchase_Request_Manager') {
      this.cfa.reactToFPRNumberChange(this.transactionId, this.form)
        .pipe(takeWhile(_ => this.componentActive))
        .subscribe(data => {
          if (this.fprRefreshed) {
            this.router.navigate(['process_control', this.processName]).then(_ => {
              if (!this.isFullView) {
                this.navigatedBack.emit(true);
              }
            });
          }
      });
    }
    else if (this.processName === 'NAG_Onboarded_Products') {
    //  this.cfa.populatePricingGridDetails(this.transactionId, this.form).subscribe(changed => {
    //    if (changed) {
    //      this.submitForm({Name: 'Save Data'});
    //    }
    //  })
    }
  }

  
  getTriggers() {    
    this.triggers = [];
    if (this.dv.createSaveTrigger(this.applicationData, this.WFJSON, this.processName)) {
      const save = {
        Name: 'Save Data',
        DisplayName: 'Save',
        ActionName: 'Submit',
        Type: 'Action',
        TriggerId: 0
      };
      if (this.processName === 'Fertilizer_Purchase_Request_Manager') {
        save.DisplayName = 'Save and Exit';
      }
      this.triggers.push(save);
      this.triggerCondJson[save.TriggerId] = {isVisible: true, isEnable: true }; 

    }
    const triggers = this.WFJSON.Stages[this.currentStageGuid].States[this.currentStateGuid].Triggers;
    Object.keys(triggers).forEach(triggerId => {
      this.triggers.push(triggers[triggerId]);
      this.triggerCondJson[triggerId] = {
        IsVisible: true, IsEnable: true, Guid: triggerId
      };
    });
  }

  async triggerSubmit(trigger: any) {
    if (trigger.Name === 'Save Data') {      
      if(this.form.controls["NAG_PGM_FV_PGD_DT_Eto"] != null && this.form.controls["NAG_PGM_FV_PGD_DT_Eto"].errors){
        this.dateSubmitted = true;        
        setTimeout(() => {
            const activateTab = this.tabs.filter(tab => tab.active)[0];
            const allInvalidElements = activateTab.el.nativeElement.querySelectorAll('.accordion-item--isInvalidForm');
            if (allInvalidElements.length) {
              allInvalidElements[0].scrollIntoView({behavior: 'smooth'});
            } else {
              const tabsElement = this.el.nativeElement.querySelector('app-tabs');
              tabsElement.scrollIntoView({behavior: 'smooth'});
            }
          });
          return;
      }
      else{
        this.submitForm(trigger);
        return;
      }
    }
    
    if (trigger.ActionName === 'Submit') {
      this.formSubmitted = true;
      this.formTriggered = false; 
      this.dateSubmitted = false;     
      this.applicationService.checkValidations();
      if (!this.form.valid) {
        setTimeout(() => {
          const activateTab = this.tabs.filter(tab => tab.active)[0];
          const allInvalidElements = activateTab.el.nativeElement.querySelectorAll('.accordion-item--isInvalidForm');
          if (allInvalidElements.length) {
            allInvalidElements[0].scrollIntoView({behavior: 'smooth'});
          } else {
            const tabsElement = this.el.nativeElement.querySelector('app-tabs');
            tabsElement.scrollIntoView({behavior: 'smooth'});
          }
        });
        return;
      }
      if (this.processName === 'Release_Manager' && trigger.Name === 'NAG_LM_OPEN_Cust_CA') {
        if (await this.cfa.creditStatusFailedOnReadyToShip(this.form).toPromise()) {
          return;
        }
        if (this.cfa.creditLimitExceeds75OnCustomerAssigned(this.form)) {
          this.msg.showMessage('Warning', {
            body: "This release number will push this customer's used credit beyond 75% of the total credit limit.\
            Would you like to continue?",
            caller: this,
            callback: () => this.submitForm(trigger, true),
            isConfirmation: true,
            isDelete: true,
            btnText: 'Assign',
            checkboxText: 'Yes, assign to customer'
          })
          return;
        }

        if (this.cfa.creditLimitExceededOnCustomerAssigned(this.form)) {
          this.msg.showMessage('Warning', {
            body: "Due to this customer's credit limit, they cannot be assigned a release number at this price.\
            Please reach out to the credit team for further information",
          })
          return;
        }
      }
    } else {
      this.formSubmitted = false;
      this.formTriggered = true;  
      this.dateSubmitted = false;      
      let isFormInValid = false;
      Object.keys(this.form.controls).forEach(controlKey => {
        if (this.form.controls[controlKey].valid === false) {
          if (this.form.controls[controlKey].errors != null) {
            Object.keys(this.form.controls[controlKey].errors).forEach(errorKey => {
              if (errorKey !== 'required') {
                isFormInValid = true;
              }
            });
          }
        }
      });
      if (isFormInValid) {
        return;
      }
    }
    
    this.submitForm(trigger);

  }

  private async submitForm(trigger: any, withWarning = false, hideToast = false) {
    if (this.processName === 'Fertilizer_Purchase_Request_Manager') {
      if (this.cfa.pickupEndDataExceeds60DaysFromPickupStartDate(this.form)) {
        this.msg.showMessage('Warning', {
          body: 'End date of request cannot be more than 60 days from Start date',
        });
        return;
      }
    }
    else if (this.processName === 'NVS_MD_PRODUCT') {
      if (trigger.Name === 'TRGR_PRDCTClose_Expr') {
        const deactivated = await this.novus.deactivateProductMaster(this.transactionId).toPromise();
        if (!deactivated) {
          this.msg.showMessage('Warning', {
            body: 'Please deactivate associated product instances before deactivating the product master record'
          });
          return;
        }
      }
    }
    else if (this.processName === 'NAG_Incentives') {
      if (trigger.Name === 'NAG_WF_INC_OPEN_GoLive') {
        const thresholdMet = await this.novus.changeIncentivesStateToAccruing(this.transactionId).toPromise();
        if (!thresholdMet) {
          this.msg.showMessage('Warning', {
            body: 'The state of current incentive will be updated once the threshold is met for all related incentives',
          });
          return;
        }
      }
    }
    else if (this.processName === 'Release_Manager') {
      
      this.form.patchValue({              
        //NAG_LM_FV_LD_DT_Load_Num: ((this.form.get('NAG_LM_FV_LD_DT_Load_Num').value).replace('+',"")).trim()
        NAG_LM_FV_LD_DT_Load_Num: this.replaceAll(this.form.get('NAG_LM_FV_LD_DT_Load_Num').value,"+","").trim()
      });

      const isValid = await this.cfa.validateReleaseNumberAndQuantityInRM(this.form, this.transactionId, 'update');
      if (!isValid) return;
      
      if (trigger.Name === 'NAG_WF_LM_Open_AIT') {
        const response = await this.novus.postDeliveryTicketToAgvance(this.form).toPromise();
        if (response.Status === 'OK')
          this.cfa.populateDeliveryTicketNumberInRM(this.form, response.Message);
        else if (response.Status === 'Error')
          this.msg.showMessage('Warning', {header: 'Alert' ,body: response.Message});
      } 
      else if (trigger.Name === 'NAG_WF_LM_TI_TI') {
        const responses: Array<DeliveryTicketResponse> = [];
        let response = await this.novus.createPurchaseReceiptForAssginedLocation(this.form).toPromise();
        responses.push(response);
        if (response && response.Status === 'OK')
          this.cfa.populateTicketNumberInRM(this.form, response.Message);
        else if (response && response.Status === 'Error')
          this.msg.showMessage('Warning', {header: 'Alert', body: response.Message});
        
        response = await this.novus.createNegativePurchaseReceiptForDivisionLocation(this.form, this.parentData).toPromise();
        responses.push(response);
        if (response && response.Status === 'Error')
          this.msg.showMessage('Warning', {header: 'Alert', body: response.Message});
        
        response = await this.novus.createPositivePurchaseReceiptForDivisionLocation(this.form, this.parentData).toPromise();
        responses.push(response);
        if (response && response.Status === 'Error')
          this.msg.showMessage('Warning', {header: 'Alert', body: response.Message});

        this.cfa.populateTransferInventoryFlagInRM(this.form, responses);
        
      }
    }

    if (this.processName === 'NAG_Incentives' || this.processName === 'NAG_Programs') {
      let discountType: any;
      let discountDollar: AbstractControl;
      let rateApplication: AbstractControl;
      let discountAcre: AbstractControl;
      let unitApplication: AbstractControl;
      let discountPercentage: AbstractControl;
      let billUnits: AbstractControl;

      if (this.processName === 'NAG_Incentives') {
        discountType = this.form.get('NAG_INC_AV_DISTYPE').value;
        discountDollar = this.form.get('NAG_INC_AV_ID_De_DA');
        rateApplication = this.form.get('NAG_INC_AV_Packs');
        discountAcre = this.form.get('NAG_INC_AV_DPA');
        unitApplication = this.form.get('NAG_INC_FV_UofApp');
        discountPercentage = this.form.get('NAG_INC_AV_ID_De_D');
        billUnits = this.form.get('NAG_INC_FV_BillUnits');
      } else if (this.processName === 'NAG_Programs') {
        discountType = this.form.get('NAG_PGM_AV_IR_DType').value;
        discountDollar = this.form.get('NAG_PGM_AV_In_DA');
        rateApplication = this.form.get('NAG_PGM_AV_IR_RoA');
        discountAcre = this.form.get('NAG_PGM_AV_IR_DPA');
        unitApplication = this.form.get('NAG_PGM_AV_IR_UoA');
        discountPercentage = this.form.get('NAG_PGM_AV_In_In_DP');
        billUnits = this.form.get('NAG_PGm_AV_IR_BUnits');
      }
 
      if (discountDollar.dirty && discountDollar.value === '') discountDollar.setValue(0);
      if (discountPercentage.dirty && discountPercentage.value === '') discountPercentage.setValue(0);
      if (rateApplication.dirty && rateApplication.value === '') rateApplication.setValue(0);
      
      if (discountPercentage.value != 0 && discountType !== 'Percentage') {
        discountPercentage.reset(0); 
        discountPercentage.markAsDirty();
      }

      if (discountDollar.value != 0 && discountType === 'Percentage') {
        discountDollar.reset(0);
        discountDollar.markAsDirty();
      }

      if (rateApplication.value != 0 && discountType !== 'Dollars Per Acre') {
        rateApplication.reset(0);
        rateApplication.markAsDirty();
      }

      if (discountAcre.value != 0 && discountType !== 'Dollars Per Acre') {
        discountAcre.reset(0);
        discountAcre.markAsDirty();
      }

      if (unitApplication.value !== 'Select...' && discountType !== 'Dollars Per Acre') {
        unitApplication.reset('');
        unitApplication.markAsDirty();
      }

      if (billUnits.value !== 'Select...' && discountType !== 'Dollars Per Acre') {
        billUnits.reset('');
        billUnits.markAsDirty();
      }
    }

    let formValue = { ...this.form.value };       
    formValue = this.dmoControlService.getDirtyValues(this.form);
    formValue = this.dmoControlService.sanitizeFormValue(this.dmos, formValue);
    if (!this.dmoControlService.xssValidated(formValue)) {
      this.msg.showMessage('Warning', {body: 'Please remove these characters from the form < > ; alert('});
      return;
    }

    if (this.processName === 'NAG_Distributor_Cost_Assignment') {
      /*
      const exists = await this.novus.distributorExists(formValue).toPromise();
      if (exists) {
        this.msg.showMessage('Fail', {body: 'A record with these values exists already.'});
        return;
      }
      */
    }

    const submitData: any = {
      Identifier: {
        Name: null,
        Value: null,
        TrnsctnID: this.transactionId
      },
      ProcessName: this.processName,
      TriggerName: trigger.Name,
      UserName: this.currentUser.UserName,
      UniqueConstraints: this.uniqueConstraint,
      Data: [formValue],
      StateType: this.applicationData.ApplicationInfo[0].StateType,
    };

    let isvalidateUniqueCons: any = true;
    this.applicationService.ValidateUniqueDmoValue(submitData).subscribe(
      (resultData: any) => {
        isvalidateUniqueCons = resultData;
      }
    );
    if (isvalidateUniqueCons) {
      if (this.processName === 'Release_Manager') {
        if (trigger.Name !== 'NAG_WF_LM_Open_AL_R' && trigger.Name !== 'NAG_WF_LM_Open_AL') {
          await this.novus.updateFPRQuantityMetrics(this.transactionId, this.form).toPromise();
        }
      }
     
      this.applicationService.updateApplication(submitData).subscribe(async res => {
        this.fprRefreshed = this.processName === 'Fertilizer_Purchase_Request_Manager' && trigger.Name === 'Save Data';
        if (!res.result.applicationId.includes(this.transactionId)) {
          this.msg.showMessage('Warning', {body: res.result.applicationId});
        }
        if (!hideToast) {
          this.toastr.success('Data saved successfully');  
        }

        if (this.processName === 'NAG_Margin' && 
            (trigger.Name === 'NAG_WF_MGN_Define_Ac' || trigger.Name === 'NAG_WF_MGN_ACTIVE_deact')) {
              
          const from = this.form.get('NAG_MAR_FV_MDT_DT_EF').value;
          const to = this.form.get('NAG_MAR_FV_MDT_DT_ET').value;
          const effectiveFrom = new Date(from.year, from.month - 1, from.day);
          const effectiveTo = new Date(to.year, to.month - 1, to.day);
          const now = new Date();
          const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  
          if (trigger.Name === 'NAG_WF_MGN_Define_Ac') {
            if (effectiveFrom.getTime() <= today.getTime() && effectiveTo.getTime() >= today.getTime()) {
              this.novus.updateProductMargins(this.transactionId).toPromise();
            }
          }
  
          if (trigger.Name === 'NAG_WF_MGN_ACTIVE_deact') {
            if (effectiveFrom.getTime() <= today.getTime() && effectiveTo.getTime() >= today.getTime()) {
              this.novus.updateProductMargins(this.transactionId).toPromise();  
            }
          }
        }  

        for (let cntrl in this.form.controls) {
          if (this.form.get(cntrl).dirty === true) {
            this.form.get(cntrl).markAsPristine();
          }
          this.form.get(cntrl).updateValueAndValidity();
        } 

        if (this.processName === 'NAG_Incentives') {
          await this.initIncentiveSales();
          await this.novus.updateIncentiveDiscountPerAcre(this.transactionId).toPromise();
        }
        
        if (this.processName === 'Release_Manager') 
        {          
          if (trigger.Name === 'NAG_WF_LM_Open_AL_R' || trigger.Name === 'NAG_WF_LM_Open_AL')
          {            
            this.novus.revertReleaseToPrevState(this.transactionId).subscribe(success => {
              this._getApplicationData(this.CanvasType, this.transactionId, trigger, withWarning, submitData);
            });
          }
          else{
            this._getApplicationData(this.CanvasType, this.transactionId, trigger, withWarning, submitData);
          } 
        }
        else{
          this._getApplicationData(this.CanvasType, this.transactionId, trigger, withWarning, submitData);
        }
      });
    } else {
      this.spinner.hide();
      this.toastr.warning('Please verify the Unique Constraints DMO(s)');
    }
  }

  _getApplicationData(CanvasType: string, transactionId: string, trigger: any, withWarning:boolean, submitData) {
     this.applicationService.getApplicationData(null, null, this.CanvasType, this.transactionId).subscribe(data => {
      this.dv.updateViewData(data);
      this.novus.updateDownstreamRecords(this.processName, this.form).toPromise();
      this.novus.updateUserDownstreamRecords(this.processName, this.form, this.applicationData.DataInformation).toPromise();
      this.applicationData = data;
      this.currentStageGuid = this.applicationData.ApplicationInfo[0].StagGuid;
      this.currentStateGuid = this.applicationData.ApplicationInfo[0].StateGuid;
      this.dv.onTriggerClick(trigger);
      if (this.processName === 'Supply_Chain_Manager') {
        if (trigger.Name === 'NAG_SCM_CLOSED_Closed_Cp' || trigger.Name === 'NAG_SCM_OPEN_Pending_PO') {
          const vendorId = this.form.get('NAG_SCM_FV_CT_DT_VID').value;
          const prepay = +this.form.get('NAG_SCM_AV_PO_Amt').value || 0;
          this.novus
            .updateVendorAvailableCreditLimit(vendorId, prepay, trigger.Name, this.transactionId)
            .toPromise();

          if (trigger.Name === 'NAG_SCM_CLOSED_Closed_Cp' || trigger.Name === 'NAG_SCM_OPEN_Pulled_Cc') {
            this.novus.deactivatePricingManagerEntriesState(this.transactionId).toPromise();
          }
        }
        this.cfa.updateChildReleasesOfContract(submitData).toPromise();
      }

      else if (this.processName === 'NAG_Incentives') {
        this.novus.updateRelatedIncentiveData(transactionId).subscribe();
      }

      else if (this.processName === 'NVS_MD_PRODUCT') {
        if (trigger.Name === 'TRGR_PRDCTInProc_Submt' || (trigger.Name === 'STT_PRDCTClose_Active_Sav' && this.currentStateGuid === 'sttprdctcloseactive')) {
          this.novus.createProductInstance([this.transactionId]).subscribe();
        }
      }

      else if (this.processName === 'Release_Manager') {
        const contractPrice = +this.parentData.nagscmfvctdtprice.RLTYPDMOVAL || 0;
        const replCost = +this.parentData.nagscmavrepl.RLTYPDMOVAL || 0;
        this.cfa.updateOtherContractDetails(this.parentTransactionId, contractPrice, replCost).subscribe();

        this.novus.changeParentState(this.parentTransactionId).toPromise()
          .catch(console.log);

        if (withWarning)
          this.cfa.sendNotificationToCreditTeam(this.form).toPromise();

        if (trigger.Name === 'NAG_LM_OPEN_Cust_CA' || trigger.Name === 'NAG_LM_OPEN_Open_Del') {
          this.novus.updateCustomerCredit(this.transactionId, trigger.Name).toPromise();
          if (trigger.Name === 'NAG_LM_OPEN_Cust_CA' && !this.user.hasRole('nagsystemadmin') && this.user.hasRole('naglocationadmin')) {
            if (!this.isFullView) {
              this.gridView.refreshProcess();
              this.location.replaceState(`/process_control/${this.processUrlName}`);
              this.modal.dismissAll();
            } else {
              if (this.isSubprocess) {
                this.router.navigate(['/process_control', 'Supply_Chain_Manager', 'detail_view', this.parentTransactionId], { queryParams: { tab: 'Release Grid' } })
              } else {
                this.router.navigate(['/process_control', this.processName]);
              }

            }
            return;
          }
        }
        // else if (trigger.Name === 'NAG_WF_LM_Open_AL_R' || trigger.Name === 'NAG_WF_LM_Open_AL')
        //   this.novus.revertReleaseToPrevState(this.transactionId).subscribe(success => {
        //     if (success)
        //       this.submitForm({ Name: 'Save Data' }, false, true);
        //   });
        else if (trigger.Name === 'NAG_WF_LM_TI_Close') {
          if (this.isSubprocess) {
            this.router.navigate(['/process_control', 'Supply_Chain_Manager', 'detail_view', this.parentTransactionId], { queryParams: { tab: 'Release Grid' } });
          } else {
            this.router.navigate(['/process_control', this.processName]);
            this.modal.dismissAll();
          }
        }
      }

      this.getBMWFJson();
    });
  }

  replaceAll(str, find, replace) 
  {
    var escapedFind=find.replace(/([.*+?^=!:${}()|\[\]\/\\])/g, "\\$1");
    return str.replace(new RegExp(escapedFind, 'g'), replace);
   }

  public onTabSelected(tabName: string) {
    // NOVUS SPECIFIC
    if (this.processName === 'Supply_Chain_Manager') {
      // Show All Releases Pulled trigger only when Release Grid tab is selected
      const allReleasesPulled = this.triggers.find(trigger => trigger.Name === 'NAG_SCM_OPEN_Open_Pulled');
      if (allReleasesPulled) 
        this.triggerCondJson[allReleasesPulled.Guid].IsVisible = tabName === 'Release Grid'; 
    }
    else if (this.processName === 'NVS_MD_PRODUCT') {
      this.triggers.forEach(trigger => {
        this.triggerCondJson[trigger.Guid].IsVisible = tabName !== 'Associated Product Instances';
      });
    }
  }

  public onRefresh() {
    this.fprRefreshed = this.processName === 'Fertilizer_Purchase_Request_Manager';
    this.ngOnInit();
  }

  isTriggerVisible(trigger: any) {
    if (trigger.Name === 'Save Data')
      return true;
    let isShowHideTrigger = false;
    Object.keys(trigger.ActionRoles).forEach(roleguid => {
      if (isShowHideTrigger == false)
        isShowHideTrigger = this.currentUser.ListRole.indexOf(roleguid) > -1 ? true : false;
    });
    if (isShowHideTrigger) {
      isShowHideTrigger = this.triggerCondJson[trigger.Guid].IsVisible;
    }
    return isShowHideTrigger;
  }
  
  isTriggerEnable(trigger: any) {
    if (trigger.Name === 'Save Data')
      return true;
    return this.triggerCondJson[trigger.Guid].IsEnable;
  }

  getDMOFileData(dmoGUID: string) {
    if (this.applicationData.FileInformation[dmoGUID] === undefined) {
      return [];
    } else {
      return this.applicationData.FileInformation[dmoGUID];
    }
  }

  private async initIncentiveSales() {
    // this.salesData = await this.novus.getIncentiveSales(this.transactionId, {
    //   ProcessName: this.processName,
    //   ColumnList: '',
    //   SortOrder: '-1',
    //   PageSize: 10,
    //   PageNumber: 1,
    // }).toPromise();
  }

  checkSubProcessRecord(trigger: any) {
    let result: any = '';
    if (this.wfosType === 'SubProcess') {
      if (this.SubProcessNames !== undefined) {
        if (this.SubProcessNames.indexOf(',') > -1) {

        } else {
          const processrecord = {
            ParentTransactionID: decodeURIComponent(this.transactionId),
            ProcessName:  this.processName === 'Supply_Chain_Manager' ? this.processName : this.SubProcessNames,
            StateName: this.wfosName
          };
          this.applicationService.checkSubProcessRecordCount(processrecord).subscribe(
            (resultData: any) => {
              result = resultData;
              if (result === 0) {
                this.triggerSubmit(trigger);
              } else {
                this.toastr.error('All Sub Process records are not on end state.');
              }
            }
          );
        }
      }
    } else {
      this.triggerSubmit(trigger);
    }

  }

  go_back() {
    if (this.processName === 'LMKCRMCommissionAdjustment') {
      this.router.navigate(['crm/commissionadjustment', this.processUrlName]);
    } else {
      this.router.navigate(['process_control', this.processUrlName]);
    }
  }

  opendetailLink(){
    let url = (this.router.url).split('/');
    if(this.processName===null || this.processName==='' || this.processName === undefined){
        if(url[2] === 'LMKESaleyardListings'){
          this.processName = 'LMKOpportunities';
          sessionStorage.AppName = 'LMKOpportunities';
        }else{
          this.processName = url[2];
          sessionStorage.AppName = url[2];
        }
        if(this.processName!==''){
          this.applicationService.getDisplayNameByProcessName(this.processName).subscribe(res=>{
            if(res!=null){
              sessionStorage.setItem('DisplayName', res[0].DisplayName);
              let DisplayName = sessionStorage.getItem('DisplayName');
              this.titleService.setTitle(`${environment.projectTitle} | ${DisplayName}`);
            }
          })
        }
    }
  }

  ngOnDestroy() {
    if (this.processName === 'NAG_Programs') {
      sessionStorage.removeItem('faq_grid_filter');
      sessionStorage.removeItem('storage_GridSearchConfig');  
    }
    this.componentActive = false;
    this.cfa.cleanUpSubscriptions();
    this.dv.resetViewState();
  }
}
