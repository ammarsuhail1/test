import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Location } from '@angular/common';
import { GridViewService } from '@app/shared/components/grid-view/grid-view.service';

@Component({
  selector: 'app-process-control',
  templateUrl: './process-control.component.html',
  styleUrls: ['./process-control.component.scss']
})
export class ProcessControlComponent implements OnInit {

  @ViewChild('detailViewModal', { static: false }) detailViewModal: ElementRef;

  ProcessName = sessionStorage.getItem('AppName');
  HideDeleteIcon = false;
  transactionId: string;
  processUrlName: string;
  detailPageLink: string;
  constructor(
    private modalService: NgbModal,
    private location: Location,
    private gridViewService: GridViewService,
  ) { }

  ngOnInit() {
  }

  showDetailPage(event) {
    this.transactionId = event.id;
    this.processUrlName = event.processUrlName;
    this.location.replaceState(`/process_control/${this.processUrlName}/detail_view/${encodeURIComponent(this.transactionId)}`);
    this.detailPageLink = `/process_control/${this.processUrlName}/detail_view/${this.transactionId}`;
    this.modalService.open(this.detailViewModal, { backdrop: 'static', scrollable: true, windowClass : 'detail-view-modal' });  
  }

  close(modal) {
    
    this.gridViewService.refreshProcess({ignoreSubProcess: true});
    this.location.replaceState(`/process_control/${this.processUrlName}`);
    this.modalService.dismissAll();
  }

}
