import { Injectable } from "@angular/core";
import { ApplicationService, FormViewService, BusinessModel, DataModelObjectGroup, AuthenticationService, UserService } from '@app/core';
import { map, tap, switchMap, filter, debounceTime, take, withLatestFrom, startWith, distinctUntilChanged } from 'rxjs/operators';
import { forkJoin, of, Observable, BehaviorSubject, Subject, combineLatest, from } from 'rxjs';
import { RecordData } from '@app/core/models/record-data.model';
import { Trigger, WorkflowModel } from '@app/core/models/wf.model';
import { UserDetail } from '@app/core/models/user-detail';
import { ActivatedRoute } from "@angular/router";
import {formatCurrency} from '@angular/common';
import {SearchService} from '@app/core/services/search.service';
import {UtilityService} from '@app/core/services/utility.service';

// 80% of detail-view component code should be moved to a service

@Injectable()
export class DetailViewService {
  private _appName: string;
  private _currentStateGuid: string;
  private _currentStageGuid: string;

  private _triggerClicked = new Subject<Trigger>();
  // TBD
  private _currentView = new BehaviorSubject<any>(null);

  private _currentViewRouteDetails = new BehaviorSubject<ViewRouteDetails>(null);

  private _currentViewData = new BehaviorSubject<RecordData>(null);

  private _tabRefresh = new Subject<boolean>();
  private _currentHeadersData = new Subject<any[]>();

  get currentHeadersData$() {
    return this._currentHeadersData.asObservable();
  }

  get triggerClicked$() {
    return this._triggerClicked.asObservable();
  }

  get currentViewInfo$() {
    return this._currentViewRouteDetails.asObservable();
  }

  get currentViewData$() {
    return this._currentViewData.asObservable();
  }

  get tabRefreshed$() {
    return this._tabRefresh.asObservable()
  }

  constructor(
    private auth: AuthenticationService,
    private app: ApplicationService,
    private formView: FormViewService,
    private route: ActivatedRoute,
    private user: UserDetail,
    private search: SearchService,
    private utility: UtilityService,
  ) {}


  private _constructPage(data: ConstructPageObject) {
    data.canvasType = data.canvasType || 'AdminView';
    data.identifierName = data.identifierName || null;
    data.identifierValue = data.identifierValue || null;
    data.parentTransactionId = data.parentTransactionId || null;
    const { processName, 
            transactionId,
            parentTransactionId,
            identifierName,
            identifierValue,
            canvasType, } = data;
    
    return forkJoin([
      this._getDetails(transactionId, canvasType, identifierName, identifierValue),
      this.formView.getBmWfJson(processName, canvasType, transactionId),
      this.app.getTopCornerDetail(identifierName, identifierValue, canvasType, transactionId),
      parentTransactionId ? this._getDetails(parentTransactionId) : of(null),
    ]).pipe(
      switchMap(data => {
        if (data[3] === null) {
          const parentTransactionId = data[0].ApplicationInfo[0].PTransID;
          if (parentTransactionId)
            return forkJoin([
              of(data.slice(0, 3)),
              this._getDetails(parentTransactionId),
            ]);
        }
        return of(data);
      }),
      map(data => this._mapServerResponse(data)),
    );
  }

  private _mapServerResponse(data: any[]) {
    const flattened = data.flat();
    return {
      bm: flattened[1].BM as BusinessModel,
      wf: flattened[1].WF as WorkflowModel,
      recordData: flattened[0] as RecordData,
      parentRecordData: flattened[3] as RecordData,
      cornerDetail: flattened[2] as Array<{DisplayName: string; Value: string}>
    }
  }

  private _getDetails(transactionId: string, view: string = 'AdminView', identifierName = null, identifierValue = null): Observable<RecordData> {
    return this.app.getApplicationData(identifierName, identifierValue, view, transactionId);
  }

  public getDetails(transactionId: string, view: string = 'AdminView', identifierName = null, identifierValue = null): Observable<RecordData> {
    return this.app.getApplicationData(identifierName, identifierValue, view, transactionId);
  }

  public getHeaders(transactionId: string, view: string = 'AdminView', identifierName = null, identifierValue = null): Observable<DetailViewHeaders[]> {
    return combineLatest([
      this.app.getTopCornerDetail(identifierName, identifierValue, view, transactionId).pipe(startWith([])),
      this.currentViewData$
    ]).pipe(
      distinctUntilChanged((a, b) => a.toString() === b.toString()),
      switchMap(([headers, data]) => from(this._mapCustomHeadersToOriginalCall(headers, data, transactionId))),
      
    )
  }

  private async _mapCustomHeadersToOriginalCall(headers: DetailViewHeaders, appData: RecordData, transactionId: string) {
    const info = appData.ApplicationInfo[0];
    const processName = info.APPName;
    const data = appData.DataInformation;
    headers = [
      {DisplayName: 'Stage', Value: info.StageFriendlyName},
      {DisplayName: 'State', Value: info.StateFriendlyName}
    ];
    if (processName === 'Supply_Chain_Manager') {
      headers = [
        { DisplayName: 'Vendor', Value: data.nagscmfvctdtvname.RLTYPDMOVAL },
        { DisplayName: 'Quantity', Value: data.nagscmfvctdtquan.RLTYPDMOVAL },
        { DisplayName: 'Product', Value: data.nagscmfvctdtpn.RLTYPDMOVAL },
        { DisplayName: 'PO Number', Value: data.nagscmavpopdponum.RLTYPDMOVAL },
        ...headers,
        { DisplayName: 'Contract Price', Value: data.nagscmfvctdtprice.RLTYPDMOVAL },
      ];
    } else if (processName === 'NAG_Incentives') {
      headers = [
        { DisplayName: 'Incentive Name', Value: data.nagincfvidname.RLTYPDMOVAL },
        { DisplayName: 'Program Name', Value: data.nagincaviddep.RLTYPDMOVAL },
        { DisplayName: 'Product', Value: data.nagincavpipn.RLTYPDMOVAL },
        { DisplayName: 'Offered By', Value: data.nagincaviddeob.RLTYPDMOVAL },
        ...headers,
      ];
    } else if (processName === 'NAG_Margin') {
      headers = [
        { DisplayName: 'Margin', Value: data.nagmarfvmdtdtm.RLTYPDMOVAL },
        { DisplayName: 'Margin Type', Value: data.nagmarfvmdtdtmt.RLTYPDMOVAL },
        ...headers,
      ];
    } else if (processName === 'NAG_Bundles') {
      headers = [
        { DisplayName: 'Bundle Name', Value: data.nagbnfvpckpdn.RLTYPDMOVAL },
        ...headers,
      ];
    } else if (processName === 'NAG_Programs') {
      headers = [
        { DisplayName: 'Program Name', Value: data.nagpgmfvpgddtprgname.RLTYPDMOVAL },
        { DisplayName: 'Season', Value: data.nagpgmfvseason.RLTYPDMOVAL },
        { DisplayName: 'Offered By', Value: data.nagpgmfvpgddtoff.RLTYPDMOVAL },
        ...headers,
      ];
    } else if (processName === 'NAG_Onboarded_Products') {
      const isLlc = this.user.hasRole('3bfd3nagllcowner');
      const isLocation = this.user.hasRole('3bfd3naglocationmanager');
      const isRegional = this.user.hasRole('3bfd3nagregionalmanager');

      const [zones, dists] = await this._constructZoneAndDistributorHeaders(data.nagprfvpdgeo.RLTYPDMOVAL, data.nagprfvpddis.RLTYPDMOVAL);
      
      const firstRow = [
        { DisplayName: 'Product ID', Value: data.nagprfvpdpname.RLTYPDMOVAL },
        { DisplayName: 'Product Name', Value: data.nagprfvpdprname.RLTYPDMOVAL },
        { DisplayName: 'Units', Value: data.nagprfvpdun.RLTYPDMOVAL }, // Pack Size changed to units
        { DisplayName: 'Zone', Value: zones }, 
        { DisplayName: 'Inventory Department ID', Value: data.nagprfvinvdeptid.RLTYPDMOVAL },
        { DisplayName: 'Manufacturer', Value: data.nagprfvpdman.RLTYPDMOVAL }, 
        { DisplayName: 'Distributor', Value: dists }, 
        ...headers,
        { DisplayName: 'Product Instance ID', Value: data.nagpravpiid.RLTYPDMOVAL }, 
      ];

      const secondRow = [];
      const pricingData = await this._constructDistributorPriceHeader(transactionId);

      if (!isLlc && !isRegional && !isLocation) {
        // const {distPrice, distAnchorPrice} = await this._constructDistributorPriceHeader(transactionId);
        secondRow.push(
          { DisplayName: 'Mfr Anchor Price', Value: this._formatCurrency(data.nagprfvpdmdllp.RLTYPDMOVAL)},
          pricingData.DistributorAnchorPrice,
          pricingData.DistributorPrice,
        );
      }

      if (!isLlc && !isLocation) {
        secondRow.push(pricingData.NovusCostFloor);
      }

      if (!isLocation) {
        secondRow.push(pricingData.LLCCostFloor);
      }
      secondRow.push(
        pricingData.MinimumRetailPrice,
        pricingData.SuggestedRetailPrice,
      );      

      return [firstRow, secondRow]

    } else if (processName === 'Fertilizer_Purchase_Request_Manager') {
      headers = [

        { DisplayName: 'FPR Number', Value: data.nagfprfvfpdtfid.RLTYPDMOVAL },
        { DisplayName: 'Location Name', Value: data.nagfprfvfpdtnewloc.RLTYPDMOVAL },
        { DisplayName: 'Total Tons', Value: data.nagfprfvfpdttons.RLTYPDMOVAL },
        { DisplayName: 'Pick-up Start Date', Value: data.nagfprfvfpdtsdate.RLTYPDMOVAL },
        { DisplayName: 'Shipping End Date', Value: data.nagfprfvfpdtfulfilby.RLTYPDMOVAL },
        { DisplayName: 'Shipping Terminal', Value: data.nagfprterminal.RLTYPDMOVAL },
        ...headers,
        { DisplayName: 'Region', Value: data.nagfprfvfpdtregion.RLTYPDMOVAL },
      ];
      const isFertilizer = this.user.hasRole('nagfertilizermanager') || this.user.hasRole('nagdivisionadmin');
      if (isFertilizer) {
        headers.push({ DisplayName: 'Remaining Tons', Value: data.nagfpravfpdtquanrem.RLTYPDMOVAL });
      }
    }

    return [headers];
  }

  private async _constructZoneAndDistributorHeaders(zoneIds: string, distIds: string) {
    const res: string[] = [];
    if (zoneIds) {
      const zoneConfig = this.utility.generateGridConfig({
        ProcessName: 'NAG_Zone',
        ColumnList: 'nagznfvzsdtz',
        IsColumnListOnly: true,
        SortColumn: 'nagznfvzsdtz',
      });
      const zoneFilter = this.utility.generateGridFilter('Column_Filter', 'nagznfvzid');
      zoneFilter.GridConditions = zoneIds.split(',').map(id => this.utility.generateGridCondition('EQUAL', id));
      zoneConfig.GridFilters = [zoneFilter];
      const zones = await this.search.search<any>(zoneConfig).pipe(map(data => data.Data.map(item => item.nagznfvzsdtz))).toPromise();
      res.push(zones.join(', '));
    } else {
      res.push('');
    }
    if (distIds) {
      const distConfig = this.utility.generateGridConfig({
        ProcessName: 'NAG_Distributor',
        ColumnList: 'nagdifvdsdtd',
        IsColumnListOnly: true,
        SortColumn: 'nagdifvdsdtd',
      });
      const distFilter = this.utility.generateGridFilter('Column_Filter', 'nagdifvdistid');
      distFilter.GridConditions = distIds.split(',').map(id => this.utility.generateGridCondition('EQUAL', id));
      distConfig.GridFilters = [distFilter];
      const dists = await this.search.search<any>(distConfig).pipe(map(data => data.Data.map(item => item.nagdifvdsdtd))).toPromise();
      res.push(dists.join(', '));
    } else {
      res.push('');
    }
    return res;
  }

  private async _constructDistributorPriceHeader(transactionId: string) {
    const distPrice = { DisplayName: 'Distributor Price', Value: '' };
    const distAnchorPrice = { DisplayName: 'Distributor Anchor Price', Value: '' };
    const novCostFloor = { DisplayName: 'Novus Cost Floor', Value: '' };
    const llcCostFloor = { DisplayName: 'LLC Cost Floor', Value: '' };
    const minRetailPrice = { DisplayName: 'Minimum Retail Price', Value: '' };
    const sugRetailPrice = { DisplayName: 'Suggested Retail Price', Value: '' };
    const config = {
      TransactionId: transactionId,
      GridFilters: [],
      PageNumber: 1,
      PageSize: 20,
      SortColumn: '-1',
      SortOrder: 'desc',
      TimeZone: new Date().getTimezoneOffset(),
    } as any;
    const data: any = await this.search.GetProductPricingGrid(config, transactionId).toPromise();
    distPrice.Value = this._formatCurrency(data.PricingData[0].CurrentDistributorPrice);
    distAnchorPrice.Value = this._formatCurrency(data.PricingData[0].CurrentDistributorAnchorPrice);
    novCostFloor.Value = this._formatCurrency(data.PricingData[0].CurrentNovusCostFloor);
    llcCostFloor.Value = this._formatCurrency(data.PricingData[0].CurrentLLCCostFloor);
    minRetailPrice.Value = this._formatCurrency(data.PricingData[0].CurrentMinRetailPrice);
    sugRetailPrice.Value = this._formatCurrency(data.PricingData[0].CurrentSuggRetailPrice);
    /*
    const months = [
      'Jan', 
      'Feb', 
      'Mar', 
      'Apr', 
      'May', 
      'Jun', 
      'Jul', 
      'Aug', 
      'Sep', 
      'Oct', 
      'Nov', 
      'Dec', 
    ];
    const currentMonth = months[new Date().getMonth()];
    const records = data.Data as any[];
    const record = records.find(rec => rec.MONTHS.startsWith(currentMonth));
    if (record) {
      distPrice.Value = this._formatCurrency(record.DistributorPrice);
      distAnchorPrice.Value = this._formatCurrency(record.DistributorAnchorPrice);
    }
    */
    return {
      DistributorPrice: distPrice, 
      DistributorAnchorPrice: distAnchorPrice,
      NovusCostFloor: novCostFloor,
      LLCCostFloor: llcCostFloor,
      MinimumRetailPrice: minRetailPrice,
      SuggestedRetailPrice: sugRetailPrice
    };
  }

  private _formatCurrency(val: string) {
      return formatCurrency(+val || 0, 'en-US', '$')
  }

  public getRecordDmoObjects(transactionId: string, processName?: string) {
    processName = processName || sessionStorage.getItem('processName');
    return this.formView.getBmWfJson(processName, 'AdminView', transactionId).pipe(
      map(response => response.BM as BusinessModel),
      map(bm => bm.BusinessModelObjectGroup.AdminView.BusinessModelObjects),
      map(bmos => Object.values(bmos)),
      map(bmos => {
        const dmogs: DataModelObjectGroup[] = [];
        bmos.forEach(bmoObject => {
          Object.values(bmoObject.DataModelObjectGroups).forEach(dmog => {
            dmogs.push(dmog)
          });
        });
        return dmogs;
      }),
      map(dmogs => {
        const dmos = {};
        dmogs.forEach(dmogObject => {
          dmogObject.List.forEach(dmogGUID => {
            dmogObject.Rows[dmogGUID].Columns.forEach(col => {
              col.List.forEach(dmoGUID => {
                dmos[dmoGUID] = col.DataModelObjects[dmoGUID];
                dmos[dmoGUID].DMOGuid = dmoGUID;
              });
            });
          });
        });
        return dmos;
      }),
    )
  }

  public createSaveTrigger(appData: any, workflow: any, processName?: string) {
    processName = processName || sessionStorage.getItem('processName');
    /* Do not create save trigger for the following master apps */
    const excluded = [
      'NVS_MD_ENTITY', 
      'NVS_MD_REGION', 
      'NVS_MD_SUBREGION', 
      'NVS_MD_TERRITORY', 
      'NVS_MD_PROFITCENTER', 
      'NVS_MD_STORAGE',
      'NVS_MD_Location',
      'NVS_MD_PRODUCT',
      'NVS_MD_RegionMstr',
      'NVS_MD_VENDOR',
    ];
    if (excluded.some(appName => appName === processName))
      return false;
    let create = false;
    this._appName = appData.ApplicationInfo[0].APPName;
    this._currentStageGuid = appData.ApplicationInfo[0].StagGuid;
    this._currentStateGuid = appData.ApplicationInfo[0].StateGuid;
    const rolesObj = workflow.Stages[this._currentStageGuid].States[this._currentStateGuid].Roles;
    const roles = Object.keys(rolesObj);
    const userRoles: string[] = this.auth.currentUserValue.ListRole;

    if (this._appName === 'Vendor_Master' && userRoles.find(role => role === 'vendormasteradmin'))
      return true;

    if (!roles)
      return create;

    for (let i = 0; i < roles.length; i++)
      if (userRoles.find(role => role === roles[i])) {
        create = true;
        break;
      }
    return create;
  } 

  public onTriggerClick(trigger: Trigger) {
    this._triggerClicked.next(trigger);
  }

  public updateViewInfo(info: ViewRouteDetails) {
    this._currentViewRouteDetails.next(info);
  }

  public updateViewData(data: RecordData) {
    this._currentViewData.next(data);
  }

  public refreshTab() {
    this._tabRefresh.next(true);
  }

  public resetViewState() {
    this.updateViewInfo(null);
    this.updateViewData(null);
  }
  
  public headersData(data: any[]) {
    this._currentHeadersData.next(data);
  }
}

type DetailViewHeaders = Array<{DisplayName: string, Value: string}>;

interface ViewRouteDetails {
  processName: string;
  transactionId: string;
  parentTransactionId?: string;
}

interface ConstructPageObject {
  processName: string;
  transactionId: string;
  parentTransactionId?: string;
  canvasType?: string;
  identifierName?: string;
  identifierValue?: string;
}

interface IDetailView extends ViewRouteDetails{
  bm: BusinessModel;
  wf: WorkflowModel;
  recordData: RecordData;
  parentRecordData?: RecordData;
  cornerDetails?: Array<{ DisplayName: string; Value: string }>;
}
