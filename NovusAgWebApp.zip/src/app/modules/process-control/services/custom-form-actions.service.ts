import { Injectable } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';

import { Observable, combineLatest, of, BehaviorSubject, forkJoin, NEVER, EMPTY } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, map, switchMap, takeWhile, startWith, tap, withLatestFrom, switchMapTo, skipWhile, pairwise, catchError, delay, take, scan } from 'rxjs/operators';

import { NovusService } from '@app/core/services/novus.service';
import { SearchService } from '@app/core/services/search.service';
import { ApplicationService, UpdateJSON, DmoControlService, MessageService } from '@app/core';

import { PurchaseOrderAgvance, PurchaseOrderMaster, DeliveryTicketResponse, PricingManagerInfo } from '@app/core/models/project';
import { EmailService } from '@app/core/services/email.service';
import { UtilityService } from '@app/core/services/utility.service';
import { environment } from '@env/environment';
import { genericValidator } from '@app/core/validators/generic-validator';
import { UserDetail } from '@app/core/models/user-detail';
import { DetailViewService } from './detail-view.service';
import { RecordData } from '@app/core/models/record-data.model';
import {BaseDmo} from '@app/core/models/dmos';


const CALCULATION_DEBOUNCE = 300;
const SEARCH_INPUT_DEBOUNCE = 1000;
const DROPDOWN_DEBOUNCE = 0;

/* Provided in Process Control Module */
@Injectable()
export class CustomFormActionsService {

  private cfaActive: boolean = true;

  private _user = this.userDetail;

  private _productDeps = new BehaviorSubject<Array<CustomDropdown>>([]);
  private _bookingIds = new BehaviorSubject<Array<CustomDropdown>>([]);
  private _syncInProgress = new BehaviorSubject<boolean>(false);

  private _bulkUpdateVisiblity = new BehaviorSubject<{[guid: string]: boolean}>(null);
  
  get bulkUpdateVisiblity$() {
    return this._bulkUpdateVisiblity.asObservable()
    
  }

  get syncInProgress$() {
    return this._syncInProgress.asObservable();
  }

  get departments$() {
    return this._productDeps.asObservable();
  }

  get bookingIds$() {
    return this._bookingIds.asObservable();
  }
  
  constructor(
    private msg: MessageService,
    private utility: UtilityService,
    private novus: NovusService,
    private search: SearchService, 
    private email: EmailService,
    private dcs: DmoControlService,
    private app: ApplicationService,
    private dv: DetailViewService,
    private userDetail: UserDetail
  ) {}


  public cleanUpSubscriptions() {
    this.cfaActive = false;
  }

  public disableCustomerDetailsInRM(form: FormGroup) {
    const dmos = [
      'NAG_LM_AV_LC_Cdet_Cust', // Customer Name
      'NAG_LM_AV_LC_Cdet_CID', // Customer ID
      'NAG_LM_AV_LC_Cdet_St', // Street
      'NAG_LM_AV_LC_Cdet_City', // City
      'NAG_LM_AV_LC_Cdet_State', // State
      'NAG_LM_AV_LC_Cdet_Zip', // Zip Code
      'NAG_LM_AV_LC_Cdet_TC', // Total Credit
      'NAG_LM_AV_LC_Cdet_AC', // Available Credit
      'NAG_LM_AV_LC_Cdet_Sales', // SalesPerson
      'NAG_LM_AV_LC_Cdet_Contact', // Customer Phone Number
      'NAG_LM_AV_LC_Cdet_BookID', // Booking ID
      'NAG_LM_AV_CD_PriceF', // Customer Price
      'NAG_LM_AV_CD_Pre', // Prepaid?
    ];
    dmos.forEach(dmoName => form.get(dmoName).disable());
  }

  public calculateTotalTonsInFertilizerRequests(form: FormGroup) {
    const loads = form.get('NAG_FPR_FV_FP_DT_Nload');
    const  size = form.get('NAG_FPR_FV_FP_DT_LoadSize');

    const quantityFulfilled = form.get('NAG_FPR_AV_FP_DT_QuanFulf');
    const quantityRemaining = form.get('NAG_FPR_AV_FP_DT_QuanRem');

    const loadsRemaining = form.get('NAG_FPR_FV_LoadsRem');
    const loadsFulfilled = form.get('NAg_FPR_FV_LoadsFul');    
    const total = form.get('NAG_FPR_FV_FP_DT_Tons');
    return combineLatest(
      loads.valueChanges.pipe(startWith(loads.value)),
      size.valueChanges.pipe(startWith(size.value)),
    ).pipe(
      debounceTime(CALCULATION_DEBOUNCE),
      map(values => values.map(value => +value || 0)),
      tap(([_, size]) => {
        const lrValue = size ? (+quantityRemaining.value / size).toFixed(2) : 0;
        const lfValue = size ? (+quantityFulfilled.value / size).toFixed(2) : 0;
        this.search._populateFormField(loadsRemaining, lrValue);
        this.search._populateFormField(loadsFulfilled, lfValue);
      }),
      map(([loads, size]) => (loads * size).toFixed(2)),
      tap(value => this.search._populateFormField(total, value)),
    );

  }

  public fromContractsToRM(form: FormGroup, data: any, isFormView?: boolean) {
    // Parent Data
    const vendorName = data.nagscmfvctdtvname.RLTYPDMOVAL;
    const productName = data.nagscmfvctdtpn.RLTYPDMOVAL;
    const productId = data.nagscmfvctdtpid.RLTYPDMOVAL;
    const contractNumber = data.nagscmavctodvcon.RLTYPDMOVAL;
    const poNumber = data.nagscmavpopdponum.RLTYPDMOVAL;
    const shippingTerminal = data.nagscmfvctdtsloc.RLTYPDMOVAL;
    const shippingTerminalId = data.nagscmfvctdtslocid.RLTYPDMOVAL;
    const productDepartment = data.nagscmfvctdtpdept.RLTYPDMOVAL;
    const unit = data.nagscmfvctdtunit.RLTYPDMOVAL;
    const deliveryType = data.nagscmavpopddtype.RLTYPDMOVAL;

    // Release data
    const venName = form.get('NAG_LM_AV_RD_Ven');
    const prodName = form.get('NAG_LM_AV_LD_DT_P');
    const prodId = form.get('NAG_LM_AV_RD');
    const contract = form.get('NAG_LM_AV_LD_CD_CN');
    const number = form.get('NAG_LM_AV_LD_CD_PO');
    const shipTerminal = form.get('NAG_LM_FV_LD_Sloc');
    const shipTerminalId = form.get('NAG_LM_FV_LD_SLocID');
    const outboundDepartmentId = form.get('NAG_LM_AV_CD_Out');
    const releaseUnit = form.get('NAG_LM_FV_LD_DT_Units');
    const ticketType = form.get('NAG_LM_FV_TT');
    const dateReleaseAssigned = form.get('NAG_LM_FV_LD_DT_G_Date');
    if (venName)
      this.search._populateFormField(venName, vendorName);
    if (prodName)
      this.search._populateFormField(prodName, productName, true);
    if (prodId)
      this.search._populateFormField(prodId, productId, true);
    if (contract)
      this.search._populateFormField(contract, contractNumber);
    if (number)
      this.search._populateFormField(number, poNumber);
    if (shipTerminal && isFormView)
      this.search._populateFormField(shipTerminal, shippingTerminal);
    if (shipTerminalId && isFormView)
      this.search._populateFormField(shipTerminalId, shippingTerminalId);
    if (outboundDepartmentId)
      this.search._populateFormField(outboundDepartmentId, productDepartment, true);
    if (releaseUnit && isFormView)
      this.search._populateFormField(releaseUnit, unit);
    if (ticketType && isFormView)
      this.search._populateFormField(ticketType, deliveryType == 'Delivery' ? 'Delivered' : deliveryType);
    if (dateReleaseAssigned && isFormView) {
      const currentDate = new Date().toISOString();
      this.search._populateFormField(dateReleaseAssigned, currentDate, false, 'StaticDateBox');
    }
  }

  public populateCustomControlsOnBulkUpdate(form: FormGroup) {
    // Release data
    const dateReleaseAssigned = form.get('NAG_LM_FV_LD_DT_G_Date');    
    if (dateReleaseAssigned) {
      const currentDate = new Date().toISOString();
      this.search._populateFormField(dateReleaseAssigned, currentDate, false, 'StaticDateBox');
    }
  }

  public handleResponseOnReleaseCreate(response: any, submitData: UpdateJSON) {
    if (response.result && response.result.length > 0) {
      const found = response.result.find(res => res.Status === 'Error');
      if (found) {
        const dmos = submitData.Data[0];
        const start = dmos.NAG_LM_FV_LD_RN_S;
        const count = +dmos.NAG_LM_FV_LD_RN_Ct || 0;
        const increment = +dmos.NAG_LM_FV_LD_RN_I || 0;
        const bulkCreateRun = start && count && increment;
        if (!bulkCreateRun || response.result.length === 1) {
          this.msg.showMessage('Fail', {body: found.Result});
          return;
        }
        const createdReleases = response.result.filter(r => r.Status === 'Success').length;
        const message = `${createdReleases} release${createdReleases === 1 ? '' : 's'} created successfully.<br>
        Error encountered at release "${found.ReleaseNumber}".<br>
        Reason: ${found.Result}.
        `
        this.msg.showMessage(createdReleases > 0 ? 'Warning' : 'Fail', {body: message})
      } else {
        const message = response.result.length === 1
          ? 'The release was created successfully.'
          : 'All releases created successfully.'
        this.msg.showMessage('Success', {body: message});
      }
    }
  }

  /** Payload to update a release record's following dmos:
   * - PO Number,
   * - Contract Number,
   * - Vendor Name,
   * - Vendor ID,
   * - Region Department Id
    */
  public payloadToUpdateRelease(transactionId: string, data: any) {
    const dmoData = {
      NAG_LM_AV_LD_CD_CN: data.nagscmavctodvcon.RLTYPDMOVAL,
      NAG_LM_AV_LD_CD_PO: data.nagscmavpopdponum.RLTYPDMOVAL,
      NAG_LM_AV_RD_Ven: data.nagscmfvctdtvname.RLTYPDMOVAL,
      NAG_LM_AV_CD_Out: data.nagscmfvctdtpdept.RLTYPDMOVAL,
      NAG_LM_AV_RD_VenorID: data.nagscmfvctdtvid.RLTYPDMOVAL,
      NAG_AV_RD_CD_SSD: data.nagscmavpopdstart.RLTYPDMOVAL,
      NAG_AV_RD_CD_ESD: data.nagscmavpopdend.RLTYPDMOVAL,
    };
    const payload: UpdateJSON = this.utility.generateUpdateJson(transactionId, dmoData, 'Release_Manager');
    return payload;
  }

  public updateChildReleasesOfContract(payload: UpdateJSON) {
    const pullStartDate = payload.Data[0].NAG_SCM_AV_PO_PD_Start;
    const pullEndDate = payload.Data[0].NAG_SCM_AV_PO_PD_End;
    let call$ = of(null);
    // If they exist in this object, then they changed
    if (pullStartDate || pullEndDate) {
      const transactionId = payload.Identifier.TrnsctnID;
      call$ = this.novus.updateReleasesDatesByContract(transactionId);
    }
    return call$;
  }

  /** 
   * - Fetches the latest release quantities
   * - Calculates +/- Position
   * - Adds them to the payload  
   */
  public updateOtherContractDetails(transactionId: string, contractPrice: number, replCost: number) {
    return this.novus.getReleaseQuantities(transactionId).pipe(
      switchMap(response => {
        const plusMinusPosition = (replCost - contractPrice) * response.QtyExposed;
        return this.novus.updateOtherContractsDetails(transactionId, {
          QtyShipped: response.QtyShipped,
          QtyCommitted:response.QtyCommitted,
          QtyExposed: response.QtyExposed,
          Position: plusMinusPosition,
          ReplCost: replCost,
        })
      }),
    );
  }

  public updateOtherContractDetailsOnBulkUpdate(releaseTransactionId: string) {
    return this.dv.getDetails(releaseTransactionId).pipe(
      map(data => data.ApplicationInfo[0].PTransID),
      switchMap(contractTransactionId => this.dv.getDetails(contractTransactionId).pipe(
        switchMap(response => {
          const data = response.DataInformation;
          const contractPrice = +data.nagscmfvctdtprice.RLTYPDMOVAL || 0;
          const replCost = +data.nagscmavrepl.RLTYPDMOVAL || 0;
          return this.updateOtherContractDetails(contractTransactionId, contractPrice, replCost)
        }),
      )),
    )
  }

  public reactToDiscountTypeChangeInIncentivesBulkUpdateForm(form: FormGroup, dmos: any[]) {
    const controlNames = ['NAG_INC_AV_ID_De_D', 'NAG_INC_AV_ID_De_DA', 'NAG_INC_AV_DPA', 'NAG_INC_AV_Packs', 'NAG_INC_FV_BillUnits', 'NAG_INC_FV_UofApp'];
    const discountType = form.get('NAG_INC_AV_DISTYPE');
    const percentage = form.get('NAG_INC_AV_ID_De_D');
    const dollar = form.get('NAG_INC_AV_ID_De_DA');
    //const perAcre = form.get('NAG_INC_AV_DPA');
    //const rateOfApp = form.get('NAG_INC_AV_Packs');
    //const billUnits = form.get('NAG_INC_FV_BillUnits');
    //const unitsOfApp = form.get('NAG_INC_FV_UofApp');
    const controlGuids = ['nagincavidded', 'nagincaviddeda', 'nagincavdpa', 'nagincavpacks', 'nagincfvbillunits', 'nagincfvuofapp'];
    const perGUID = 'nagincavidded';
    const dollarGUID = 'nagincaviddeda';
    const visibility = {};
    controlGuids.forEach(guid => visibility[guid] = false);

    return discountType.valueChanges.pipe(
      startWith(discountType.value),
      tap(value => {
        if (value === 'Percentage') {
          for (const guid in visibility) {
            visibility[guid] = false;
          }
          visibility[perGUID] = true;
          controlNames.forEach(name => {
            form.get(name).disable();
          })
          percentage.enable();
        } else if (value === 'Dollars') {
          for (const guid in visibility) {
            visibility[guid] = false;
          }
          visibility[dollarGUID] = true;
          controlNames.forEach(name => {
            form.get(name).disable();
          })
          dollar.enable();
        } else {
          for (const guid in visibility) {
              visibility[guid] = true;
          }
          visibility[perGUID] = false;
          controlNames.forEach(name => form.get(name).enable());
          percentage.disable();
        }

        this.updateBulkUpdateVisibility(visibility);
      })
    )
  }

  public updateBulkUpdateVisibility(obj: {[key: string]: boolean}) {
    const state = this._bulkUpdateVisiblity.getValue();
    this._bulkUpdateVisiblity.next({...state, ...obj});
  }

  public syncPurchaseOrderDetails(form: FormGroup) {
    const control = form.get('NAG_SCM_AV_PO_PD_PONum');
    const autoGeneratedPONumber = form.get('NAG_SCM_FV_CT_DT_RquestID');
    if (control.value.trim().length === 0)
      return EMPTY;

    if (autoGeneratedPONumber.value !== control.value) {
      this.msg.showMessage('Warning', {
          body: `Your PO's Don't Match. Click Cancel to return to screen. Click OK to confirm as entered, then Re-Sync to use PO entered.`,
          caller: this,
          callback: () => this._fetchPOData(control.value, form).toPromise(),
          isConfirmation: true,
          btnText: 'Ok',
          cancelBtn: false,
        });
        return EMPTY;
    }
    return this._fetchPOData(control.value, form);
    
  }

  private _fetchPOData(poNumber: string, form: FormGroup) {
    this._syncInProgress.next(true);
    // Try to get data from the master table
    return this.search.getPurchaseOrderDetails(poNumber).pipe(
      map(this._mapMasterPOToAgvancePO),
      catchError(_ => this.novus.getPODetails(poNumber)),
      switchMap(item => {
        if (item) {
          this.populatePurchaseDetails(item, form);
          return of(item);
        }
        // If nothing found, try to get data from AgVance api
        else
          return this.novus.getPODetails(poNumber).pipe(
            tap(item => this.populatePurchaseDetails(item, form)),
          );
      }),
    );
  }

  private _mapMasterPOToAgvancePO(item: PurchaseOrderMaster): PurchaseOrderAgvance {
    return {
      PONumber: item.nagpomavdtdtponum,
      VendorID: item.nagpomavdtdtvid,
      VendorName: item.nagpomavdtdtven,
      TypeofContract: item.nagpomavdtdttype,
      PullStartDate: item.nagpomavdtdtpstart,
      PullEndDate: item.nagpomavdtdtpend,
      ProductName: item.nagpomavdtdtprod,
      ProductID: item.nagpomavdtdtpid,
      Quantity: item.nagpomavdtdtquant,
      Unit: item.nagpomavdtdtunit,
      Cost: item.nagpomavdtdtcost,
      FreightRate: item.nagpomavdtdtfrate,
      DeliveryType: item.nagpomavdtdtdtype,
      DateRequested: item.nagpomavdtdtdreq,
      PickupDelivLocation: item.nagpomavdtdtpdloc,
      FilledYN: item.nagpomavdtdtfilledyn,
      DepartmentID: item.nagpomavdtdtpdeptid,
      DepartmentName: item.nagpomavdtdtpdeptnam,
      LocationID: item.nagpomavdtdtlocid,
      LocationName: item.nagpomavdtdtlocname,
      Contractnumber: item.nagpomavdtdtvconn,
    };
  }

  public resetShipToDepartmentIdOnLocationIdChange(form: FormGroup) {
   
    const locationId = form.get('NAG_LM_AV_LC_Ldet_LID');
    const shipToDepartmentId = form.get('NAG_LM_AV_LC_Dept');
    
    const stream$ = combineLatest(
      (locationId ? locationId.valueChanges : EMPTY).pipe(
        startWith(locationId ? locationId.value : ''),
      ),
      (shipToDepartmentId ? shipToDepartmentId.valueChanges : EMPTY).pipe(
        startWith(shipToDepartmentId ? shipToDepartmentId.value : ''),
      ),
    );
    return stream$.pipe(
      distinctUntilChanged((a,b) => a.toString() === b.toString()),
        // Get a tuple of previous and current emissions
      pairwise(),
      tap(([prev, cur]) => {
        // If Location id changed, reset ship to department id
        if (prev[0] !== cur[0]) {
          this.search._populateFormField(shipToDepartmentId, '', true);
        };
      }),
    )
  }

  public populatePricingManagerFields(form: FormGroup, data?: RecordData) {
    let initValue = data ? data.DataInformation.nagcpafvvcn.DMOVAL : '';

    const contractNumber = form.get('NAG_CPA_FV_VCn');
    const productName = form.get('NAG_CPA_AV_CP_DT_Product');
    const productId = form.get('NAG_CPA_AV_CP_DT_Prod_ID');
    const vendor = form.get('NAG_CPA_AV_CP_DT_Vendor');
    const vendorId = form.get('NAG_CPA_AV_CP_DT_VendorID');
    const region = form.get('NAG_PM_FV_TER');
    const poPrice = form.get('NAG_CPA_AV_CP_DT_POP');
    return contractNumber.valueChanges.pipe(
      startWith(contractNumber.value),
      filter(value => value !== 'Select...' && value !== initValue),
      customPipeforDropdownField,
      tap(_ => initValue = null),
      switchMap(number => this.novus.getPricingManagerInfoByContractNumber(number)),
      map(res => {
        if (res.statuscode === 200) {
          return res.result as PricingManagerInfo[];
        }
        this.msg.showMessage('Warning', { body: res.result as string });
        return [];
      }),
      filter(response => !!response[0]),
      map(response => response[0]),
      tap(data => {
        this.search._populateFormField(productName, data.ProductName);
        this.search._populateFormField(productId, data.ProductID);
        this.search._populateFormField(vendor, data.VendorName);
        this.search._populateFormField(vendorId, data.VendorID);
        this.search._populateFormField(region, data.Region);
        this.search._populateFormField(poPrice, data.ContractPrice);
      }),
    );
  }

  /** On Assigned Location Id (`NAG_LM_AV_LC_Ldet_LID`) 
   * or Ship to Department Id (`NAG_LM_AV_LC_Dept`) change,
   * queries Pricing Manager for Additional Fee 
   * to populate Location Price (`NAG_LM_AV_LC_LDet_Price`)
   * in Release Manager
  */
  public populateLocationPrice(form: FormGroup, data?: any) {
    // Payload information
    const releaseNumber = form.get('NAG_LM_FV_LD_DT_Load_Num');
    const vendorId = data ? data.nagscmfvctdtvid.RLTYPDMOVAL : form.get('NAG_LM_AV_RD_VenorID').value || '';
    const locationId = form.get('NAG_LM_AV_LC_Ldet_LID');
    const shipToDepartmentId = form.get('NAG_LM_AV_LC_Dept');
    const shippingTerminalId = form.get('NAG_LM_FV_LD_SLocID');
    const productId = form.get('NAG_LM_AV_RD');
    const customerId = form.get('NAG_LM_AV_LC_Cdet_CID');
    const region = form.get('NAG_LM_AV_Reg');
    const contractNumber = form.get('NAG_LM_AV_LD_CD_CN');    
    
    const locationPrice = form.get('NAG_LM_AV_LC_LDet_Price');

    const fprNumber = form.get('NAG_LM_FV_FPR');
    

    const stream$ = combineLatest(
      locationId.valueChanges.pipe(
        // Emit the initial value of location id explicitly
        // This is done, so the distinctUntilChanged having gotten the initial value,
        // has the opportunity to compare the incoming values
        startWith(locationId.value),
        debounceTime(SEARCH_INPUT_DEBOUNCE),
        distinctUntilChanged(),
      ),
      shipToDepartmentId.valueChanges.pipe(
        startWith(shipToDepartmentId.value),
      ),
      region.valueChanges.pipe(startWith(region.value)),
    )
    return stream$.pipe(
      map(values => values.map(value => value === 'Select...' ? null : value)),
      distinctUntilChanged((a,b) => a.toString() === b.toString()),
      switchMap(([locId, depId, regionId]) => {
      
        return this.novus.getLocationPriceByParams({
          ReleaseNumber: releaseNumber ? releaseNumber.value || '' : '',
          AssignedLocationID: locId || '',
          ShipToDepartmentID: depId || '',
          CustomerID: customerId ? customerId.value || '' : '',
          ProductID: productId.value || '',
          Region: regionId || '',
          ShippingTerminalID: shippingTerminalId.value || '',
          VendorContractNumber: contractNumber.value || '',
          VendorID: vendorId || '',
        });
      }),
      tap(async({AdditionalFee }) => {
        const details = await this.dv.currentViewInfo$.pipe(take(1)).toPromise();
        const isFpr = details && details.processName === 'Fertilizer_Purchase_Request_Manager';
        if (locationId.touched || shipToDepartmentId.touched || region.touched || fprNumber.touched || isFpr) {
            this.search._populateFormField(locationPrice, AdditionalFee, true)
        }
      }),
    );
  }

  public forceFetchFPRSearchBoxLists(form: FormGroup) {
    const terminal = form.get('NAG_FPR_Terminal');
    const locationName = form.get('NAG_FPR_FV_FP_DT_NewLoc');
    const locationId = form.get('NAG_FPR_FV_FP_DT_Lnum');
    const departmentName = form.get('NAG_FPR_FV_DName');
    const departmentId = form.get('NAG_FPR_FV_FP_DT_Pdept');
    const productName = form.get('NAG_FPR_FV_FP_DT_Pname');

    //setTimeout(() => {
      //terminal.patchValue('');
      //locationName.patchValue('');
      //locationId.patchValue('');
      //departmentName.patchValue('');
      //departmentId.patchValue('');
      //productName.patchValue('');
    //}, 100);
  }

  public forceFetchContractsSearchBoxLists(form: FormGroup) {
    const terminal = form.get('NAG_SCM_FV_CT_DT_Sloc');
    const terminalId = form.get('NAG_SCM_FV_CT_DT_SlocID');
    setTimeout(() => {
      terminal.patchValue('');
      terminalId.patchValue('');
    }, 100);
  }

  public populateCustomerCreditInRM(form: FormGroup) {
    const id = form.get('NAG_LM_AV_LC_Cdet_CID');
    const totalCredit = form.get('NAG_LM_AV_LC_Cdet_TC');
    const availableCredit = form.get('NAG_LM_AV_LC_Cdet_AC');

    return id.valueChanges.pipe(
      customPipeforDropdownField,
      switchMap(value => this.novus.getCustomerCredit(value)),
      tap(data => {
        if (data) {
          this.search._populateFormField(totalCredit, data.CreditLimit);
          /* Emit event here is set to true to make the `roundAvailableCreditInRM` function work */
          this.search._populateFormField(availableCredit, data.AvailableCredit, true);
        }
      }),
    );
  }

  public populateAssociateToProgram(form: FormGroup) {
    const control = form.get('NAG_PGM_FV_PGD_DT_PrgName');
    return  this.dv.currentViewInfo$.pipe(
      takeWhile(_ => !!control),
      filter(info => !!info),
      map((info: any) => info.processName),
      filter(processName => processName === 'NAG_Programs'),
      switchMapTo(this.dv.currentViewData$),
      filter(data => !!data),
      map(({DataInformation: data}) => ({
        ddOptionKey: data.nagpgmfvid.DMOVAL,
        ddOptionValue: data.nagpgmfvpgddtprgname.DMOVAL
      })),
      tap(value =>this.search._populateFormField(control, value, true)),
    );
  }

  public populateTransferInventoryFlagInRM(form: FormGroup, responses: Array<DeliveryTicketResponse>) {
    if (responses.every(response => response.Status === 'OK' || response.Message.includes('A Purchase Receipt already exists'))) {
      this.search._populateFormField(form.get('NAG_SCM_AV_Flag'), '1', true);
    }
  }

  public populateDeliveryTicketNumberInRM(form: FormGroup, value: string) {
    const ticketNumber = form.get('NAG_LM_AV_PD_DELIVTKTNUM');
    const ticketFlag = form.get('NAG_LM_AV_DELFLAG');
    this.search._populateFormField(ticketNumber, value, true);
    this.search._populateFormField(ticketFlag, 1, true);
  }

  public populateTicketNumberInRM(form: FormGroup, value: string) {
    const control = form.get(' NAG_LM_AV_AO_TicketNum');
    this.search._populateFormField(control, value);
  }

  /** On page loads and on every consecutive trigger click 
   * updates Available Credit (`NAG_VDM_AV_DT_DT_Acredit`) if it's diferent from the previous value
   * and performs manual save
  */
  public populateAvailableCreditInVendorMaster(form: FormGroup, transactionId: string) {
    const vendorId = form.get('NAG_VDM_AV_DT_DT_VID');
    const availableCredit = form.get('NAG_VDM_AV_DT_DT_Acredit');
    const initAvailableCreditValue = availableCredit.value;
    return this.novus.getVendorAvailableCreditLimit(vendorId.value).pipe(
      tap(value => this.search._populateFormField(availableCredit, value)),
      switchMap(value => {
        if (initAvailableCreditValue != value) {
          const data = {NAG_VDM_AV_DT_DT_Acredit: value};
          const payload = this.utility.generateUpdateJson(transactionId, data, 'Vendor_Master');
          return this.app.updateApplication(payload);
        }
        return NEVER;
      }),
    );
  }

  /** On Assigned Location Id change get all location admins with that location id */
  public reactToAssignedLocationIdChangeInRM(form: FormGroup, locationAdmins: any[]) {
    const control = form.get('NAG_LM_AV_LC_Ldet_LID');
    return control.valueChanges.pipe(
      startWith(control.value),
      switchMap(value => {
        if (!value) return of(locationAdmins);
        return of(value).pipe(
        debounceTime(SEARCH_INPUT_DEBOUNCE),
        distinctUntilChanged(),
        map(value => (value as string).trim()),
        switchMap(value => this.novus.getUsersByLocationId(value)),
        map(users => {
          const intersectedUsers = [];
          users.forEach(user => {
            locationAdmins.forEach(admin => {
              // Select only intersecting users from two arrays
              if (user.USERID === admin.ValueField) {
                intersectedUsers.push(admin);
              }
            });
          });
          return intersectedUsers;
        }),
        );
      }),
    );
  }

  /** On Receiving Type change update the validators of Customer and Customer Id */
  public handleCustomerDetailsValidationInBulkUpdate(form: FormGroup, dmos: any[]) {
    const receivingType = form.get('NAG_LM_AV_LC_LDet_Op');
    const customer = form.get('NAG_LM_AV_LC_Cdet_Cust');
    const customerId = form.get('NAG_LM_AV_LC_Cdet_CID');
    const customerDmo = dmos.findIndex(dmo => dmo.Name === 'NAG_LM_AV_LC_Cdet_Cust');
    const customerIdDmo = dmos.findIndex(dmo => dmo.Name === 'NAG_LM_AV_LC_Cdet_CID');
    const observable$ = receivingType ? receivingType.valueChanges : of(null);
    return observable$.pipe(
      filter(value => value),
      tap(type => {
  
        if (type === 'Customer') {
          dmos[customerDmo].IsRequired = true;
          dmos[customerIdDmo].IsRequired = true;
          customer.setValidators(Validators.required);
          customerId.setValidators(Validators.required);
        } else {
          dmos[customerDmo].IsRequired = false;
          dmos[customerIdDmo].IsRequired = false;
          customer.clearValidators();
          customerId.clearValidators();
        }
        customer.updateValueAndValidity();
        customerId.updateValueAndValidity();
      }),
    );
  }

  /** On Receiving type change, when the value equals 'Customer'
   * make Customer and Customer Id fields mandatory before any trigger is fired
  */
  public addCustomerRequiredValidators(form: FormGroup, triggerConditions: any) {
    const receivingType = form.get('NAG_LM_AV_LC_LDet_Op');
    const customer = form.get('NAG_LM_AV_LC_Cdet_Cust');
    const customerId = form.get('NAG_LM_AV_LC_Cdet_CID');
    return receivingType.valueChanges.pipe(
      startWith(receivingType.value),
      skipWhile(_ => !triggerConditions['nagwflmopenait']),
      tap(type => {
        if (type === 'Customer') {
          if (!customer.value) {
            customer.setValidators(Validators.required);
          }
          if (!customerId.value) {
            customerId.setValidators(Validators.required);
          }    
        }
      }),
    )
  }

  public validateLocationPriceInRM(form: FormGroup) {
    const locationPrice = form.get('NAG_LM_AV_LC_LDet_Price');
    locationPrice.setValidators(Validators.required);
    return locationPrice.valueChanges.pipe(
      startWith(locationPrice.value),
      map(value => +value || 0),
      tap(value => {
        genericValidator(locationPrice, value !== 0, 'Location Price cannot be 0');
      })
    )
  }

  public validateQuantityOnBulkUpdate(form: FormGroup) {
    const quantity = form.get('NAG_LM_FV_LD_DT_Quantity');
    quantity.setValidators(Validators.required);
    return quantity.valueChanges.pipe(
      startWith(quantity.value),
      filter(value => value),
      map(value => +value || 0),
      tap(value => {
        genericValidator(quantity, value > 0, 'Quantity cannot be <= 0');
      })
    )
  }

  public reactToContractNumberChangeInPM(form: FormGroup) {
    const contractNumber = form.get('NAG_CPA_FV_VCn');
    return contractNumber.valueChanges.pipe(
      startWith(contractNumber.value),
      filter(value => value),
      switchMap(value => this.search.getReleaseNumbersByContractNumber(value)),
    );
  }

  public handleTriggersVisibilityInRM(form: FormGroup, triggerConditions: any) {
    const receivingType = form.get('NAG_LM_AV_LC_LDet_Op');
    const deliveryTicketFlag = form.get('NAG_LM_AV_DELFLAG');
    const transferInventoryFlag = form.get('NAG_SCM_AV_Flag');
    return combineLatest(
      receivingType.valueChanges.pipe(startWith(receivingType.value)),
      deliveryTicketFlag.valueChanges.pipe(startWith(deliveryTicketFlag.value)),
      transferInventoryFlag.valueChanges.pipe(startWith(transferInventoryFlag.value)),
    ).pipe(
      tap(([type, delivery, transfer]) => {
        if (type === 'Customer') {
          if (!delivery && !transfer) 
            this._swtichTriggerVisibility(triggerConditions, true, false, false);
          else if (!delivery && transfer)
            this._swtichTriggerVisibility(triggerConditions, true, false, true);
          else if (delivery && !transfer) 
           this._swtichTriggerVisibility(triggerConditions, false, true, false);
          else if (delivery && transfer) 
            this._swtichTriggerVisibility(triggerConditions, false, false ,true);
        } else {
          if (!transfer) 
            this._swtichTriggerVisibility(triggerConditions, false, true ,false);
          if (transfer)
            this._swtichTriggerVisibility(triggerConditions, false, false ,true);
        }
      }),
    );
  }

  private _swtichTriggerVisibility(triggerConditions: any, delivery: boolean, transfer: boolean, close: boolean) {
    triggerConditions['nagwflmopenait'].IsVisible = delivery;
    triggerConditions['nagwflmtiti'].IsVisible = transfer;
    triggerConditions['nagwflmticlose'].IsVisible = close;
  }

  /** When Inbound Department Id changes, a record's details with that department id
   * populate location form fields in Assgined Location Details section
   */
  public reactToInboundDepartmentIdChangeInRM(form: FormGroup) {
    const control = form.get('NAG_LM_AV_LC_Dept');
    return control.valueChanges.pipe(
      startWith(control.value),
      map(value => !value || value === 'Select...' ? null : value),
      customPipeforDropdownField,
      switchMap(value => this.search.getInventoryDepartmentDetailsByDepartmentId(value)),
      tap(item => {
        if (item) {
          const address = item.dpfvdeptdetadd;
          const [city, state] = (item.dpfvdeptdetcs as string).split(', ');
          const zip = item.dpfvdeptdetzip;
          this.search._populateFormField(form.get('NAG_LM_AV_LC_Ldet_Street'), address);
          this.search._populateFormField(form.get('NAG_LM_AV_LC_Ldet_City'), city);
          this.search._populateFormField(form.get('NAG_LM_AV_LC_Ldet_State'), state);
          this.search._populateFormField(form.get('NAG_LM_AV_LC_Ldet_Zip'), zip);
        }
      }),
    );
  }

  /** On change fetches selected Location Manager's phone number 
   * 
   * and populates the Location Phone Number form field
   */
  public reactToLocationManagerChangeInRM(form: FormGroup) {
    const control = form.get('NAG_LM_AV_LC_Ldet_LM');
    const locationPhone = form.get('NAG_LM_AV_LC_Ldet_Ph');
    return control.valueChanges.pipe(
      startWith(control.value),
      tap(value => {
        if (!value)
          this.search._populateFormField(locationPhone, '');
      }),
      filter(value => value),
      // Extract username from "FirstName LastName(UserName)" formatted string
      map(value => value.match(/\((.*)\)/).pop()),
      // Get that user's profile
      switchMap(value => this.novus.getUserProfile(value)),
      // Extract the user's mobile phone number
      map(user => user.MobileCountryCode + user.MobileNo),
      // Populate Location Phone Number form field
      tap(phone => {
        if (locationPhone)
          this.search._populateFormField(locationPhone, phone);
      }),
    );
  }

  /** On Location Id change fetch Department Ids
   * from Address Master and fill in the dropdown with those values
   */
  public reactToLocationIdChangeInPMForm(form: FormGroup) {
    const control = form.get('NAG_CPA_AV_CP_DT_LocID');
    return control.valueChanges.pipe(
      customPipeforDropdownField,
      switchMap(value => this.search.getDepartmentIdByLocationId(value)),
      map(ids => ids.map(id => ({ code: id, value: id }) )),
      tap(ids => this._productDeps.next(ids)),
    );
  }

  public reactToProductChangeInRMDetails(form: FormGroup) {
    const control = form.get('NAG_LM_AV_LD_DT_P');
    return control.valueChanges.pipe(
      customPipeforDropdownField,
      switchMap(value => this.search.getBookingIdsOnProductChange(value)),
      map(list => list.map(id => ({code: id, value: id}))),
      tap(list => this._bookingIds.next(list)),
    )
  }

  /**
   * On FPR Number (`NAG_FPR_FV_FP_DT_FID`) change
   * fetch values for the following dmos:
   * - Quantity Fulfilled (`NAG_FPR_AV_FP_DT_QuanFulf`)
   * - Quantity Remaining (`NAG_FPR_AV_FP_DT_QuanRem`)
   */
  public reactToFPRNumberChange(transactionId: string, form: FormGroup) {
    const control = form.get('NAG_FPR_FV_FP_DT_FID');
    const quantityFulfilled = form.get('NAG_FPR_AV_FP_DT_QuanFulf');
    const quantityRemaining = form.get('NAG_FPR_AV_FP_DT_QuanRem');

    const remainingLoads = form.get('NAG_FPR_FV_LoadsRem');
    const fulfilledLoads = form.get('NAg_FPR_FV_LoadsFul');    

    return control.valueChanges.pipe(
      skipWhile(_ => !quantityFulfilled || !quantityRemaining),
      startWith(control.value),
      customPipeforDropdownField,
      switchMap(value => this.novus.getFPRQuantityData(value)),
      tap(res => {
        if (res) {
          if ((quantityFulfilled.value !== res.QuantityFulfilled) || (quantityRemaining.value !== res.QuantityRemaining)
               || (remainingLoads.value !== res.RemainingLoads) || (fulfilledLoads.value !== res.FulfilledLoads)) {
            
                this.search._populateFormField(quantityFulfilled, res.QuantityFulfilled);
                this.search._populateFormField(quantityRemaining, res.QuantityRemaining);            
                this.search._populateFormField(remainingLoads, res.RemainingLoads);
                this.search._populateFormField(fulfilledLoads, res.FulfilledLoads);

                if (transactionId) {
                  const formValue = this.dcs.sanitizeFormValue(this.dcs.dmos, form.value);
                  this._saveFPREntryOnQuantityChange(transactionId, formValue).toPromise();
                }
          }
        }
      }),

    )
  }

  public updateQuantityFieldsOfFPROnBulkUpdate(fprNumber: string) {
    const transactionId$ = this.search.getFPRRecordsByFPRNumber(fprNumber).pipe(
      map(res => res.Data[0].TRNSCTNID)
    );
    const payload$ = this.novus.getFPRQuantityData(fprNumber).pipe(
      map(res => {
        return {
          NAG_FPR_AV_FP_DT_QuanFulf: res.QuantityFulfilled,
          NAG_FPR_AV_FP_DT_QuanRem: res.QuantityRemaining,
        }
      }),
    );
    return forkJoin([transactionId$, payload$]).pipe(
      switchMap(([transactionId, payload]) => this._saveFPREntryOnQuantityChange(transactionId, payload)),
    )
  }

  public populateFPRDataOnBulkUpdate(transactionId: string, form: FormGroup) {
    const fprNumber = form.get('NAG_LM_FV_FPR');
    const location = form.get('NAG_LM_AV_LC_Ldet_Loc');
    const locationId = form.get('NAG_LM_AV_LC_Ldet_LID');
    const departmentId = form.get('NAG_LM_AV_LC_Dept');
    return this.novus.getFPRDataForBulkUpdate(transactionId).pipe(
      filter(res => res && !!res[0]),
      map(res => res[0]),
      tap(data => {
        this.search._populateFormField(fprNumber, data.FPRNumber, true);
        this.search._populateFormField(location, data.LocationName);
        this.search._populateFormField(locationId, data.LocationID, true);
      }),
      delay(SEARCH_INPUT_DEBOUNCE),
      tap(data => this.search._populateFormField(departmentId, data.DepartmentID, true)),
    )
  }

  private _saveFPREntryOnQuantityChange(transactionId: string, data: {[key: string]: any}) {
    const payload = this.utility.generateUpdateJson(transactionId, data, 'Fertilizer_Purchase_Request_Manager');
    return this.app.updateApplication(payload);
  }

  public reactToProductChangeInFPRForm(form: FormGroup) {
    const control = form.get('NAG_FPR_FV_FP_DT_Pname');
    const productId = form.get('NAG_FPR_FV_FP_DT_PID');
    return productId.valueChanges.pipe(
      takeWhile(_ => this.cfaActive),
      filter(value => value && value.trim().length > 0),
      distinctUntilChanged(),
      customPipeforDropdownField,
      withLatestFrom(control.valueChanges),
      switchMap(([_, name]) => this.search.getBookingIdsOnProductChange(name)),
      map(list => list.map(id => ({code: id, value: id}))),
      tap(list => this._bookingIds.next(list)),
    )
  }

  public reactToProductIdChangeInContractsForm(form: FormGroup) {
    const locationId = form.get('NAG_SCM_FV_LocID');
    const productId = form.get('NAG_SCM_FV_CT_DT_PID');
    return combineLatest(
      productId.valueChanges.pipe(
        startWith(productId.value),
        customPipeforDropdownField,
      ),
      locationId.valueChanges.pipe(
        startWith(locationId.value),
        debounceTime(SEARCH_INPUT_DEBOUNCE)
      ),
      ).pipe(
        switchMap(([prodId, locId]) => this.search.getDepartmentIdsFromDepartments(prodId, locId)),
        map(ids => ids.map(id => ({code: id, value: id}))),
        tap(deps => this._productDeps.next(deps)),
      );
  }

  public calculatePrepayAmount(form: FormGroup) {
    const prepayAmount = form.get('NAG_SCM_AV_PO_Amt');
    const prepayInPercentage = form.get('NAG_SCM_AV_Pper');
    const prepaid = form.get('NAG_SCM_AV_PO_PP');
    const contractPrice = form.get('NAG_SCM_FV_CT_DT_Price');
    const quantity = form.get('NAG_SCM_FV_CT_DT_Quan');

    const stream$ = combineLatest([
      prepaid.valueChanges.pipe(startWith(prepaid.value)), 
      prepayInPercentage.valueChanges.pipe(startWith(prepayInPercentage.value)), 
      contractPrice.valueChanges.pipe(startWith(contractPrice.value)),
      quantity.valueChanges.pipe(startWith(quantity.value)),
    ]);
    return stream$.pipe(
      debounceTime(CALCULATION_DEBOUNCE),
      filter(([value, ..._]) => value && value !== 'No'),
      map(([_, ...rest]) => rest.map(val => +val || 0)),
      map(([percentage, price, quantity]) => (percentage / 100) * (price * quantity)),
      tap(val => this.search._populateFormField(prepayAmount, val, true)),
    );
  }

  public reactToProductIdChangeInFPR(form: FormGroup) {
    const locationId = form.get('NAG_FPR_FV_FP_DT_Lnum');
    const productId = form.get('NAG_FPR_FV_FP_DT_PID');

    return combineLatest(
      productId.valueChanges.pipe(
        startWith(productId.value),
        customPipeforDropdownField,
      ),
      locationId.valueChanges.pipe(
        startWith(locationId.value),
        customPipeforDropdownField,
      ),
    ).pipe(
      skipWhile(([prodId, _]) => !prodId),
      switchMap(([prodId, locId]) => this.search.getDepartmentIdsFromDepartments(prodId, locId)),
      map(ids => ids.map(id => ({code: id, value: id}))),
      tap(deps => this._productDeps.next(deps)),
    );
  }

  public populateAddOnDetailsInRM(form: FormGroup, parentData: any) {
    const lineItem = form.get('NAG_LM_AV_AO_L');
    const calculateAs = form.get('NAG_LM_AV_AO_CA');
    const applyTo = form.get('NAG_LM_AV_AO_AT');
    this.search._populateFormField(lineItem, 1);
    this.search._populateFormField(calculateAs, 'F');
    this.search._populateFormField(applyTo, 'A');

    this._calculateRateInAddOnDetails(form, parentData).toPromise();
    this._reactToChargeAreaChangeInRM(form).toPromise();
    this._populateTicketNumbersInRM(form).toPromise();
  }

  public async validateReleaseNumberAndQuantityInRM(form: FormGroup, transactionId: string, action: 'create' | 'update') {
    const release = form.get('NAG_LM_FV_LD_DT_Load_Num').value || '';
    const quantity = form.get('NAG_LM_FV_LD_DT_Quantity').value || '';
        
    const { Message } = await this.novus.validateRelease(transactionId, release.trim(), quantity, action).toPromise();
    if (Message && Message !== 'Success') {
      this.msg.showMessage('Warning', {body: Message});
      return false;
    }
    return true;
  }
  
  /** Calculates Rate (NAG_LM_AV_AO_R) using formula:
   * 
   * `(locationPrice - contractPrice) * quantity`
  */
  private _calculateRateInAddOnDetails(form: FormGroup, parentData: any) {
    const rate = form.get('NAG_LM_AV_AO_R');
    const quantityPulled = form.get('NAG_LM_AV_LD_PD_AP');
    const locationPrice = form.get('NAG_LM_AV_LC_LDet_Price');
    const contractPrice = +parentData.nagscmfvctdtprice.RLTYPDMOVAL || 0;
    return combineLatest(
      quantityPulled.valueChanges.pipe(startWith(quantityPulled.value)),
      locationPrice.valueChanges.pipe(startWith(locationPrice.value)),
    ).pipe(
      debounceTime(CALCULATION_DEBOUNCE),
      map(values => values.map(val => parseFloat(val) || 0)),
      tap(([q, p]) => this.search._populateFormField(rate, (contractPrice - p) * q)),
    );
  }

  /** When Charge Area changes, populate Charge Id and GL Account form fields */
  private _reactToChargeAreaChangeInRM(form: FormGroup) {
    const control = form.get('NAG_FV_LM_RD_ChargeArea');
    return control.valueChanges.pipe(
      startWith(control.value),
      skipWhile(value => !value || !CHARGE_AREA[value]),
      tap(value => {
        const fields = Object.entries(CHARGE_AREA[value]);
        fields.forEach(field => {
          this.search._populateFormField(form.get(field[0]), field[1], true)
        });
      }),
    );
  }

  /** When Release Number is filed in, populates 
   *  - Assigned Location Purchase Receipt Number (NAG_LM_AV_AO_TicketNum)
   *  - Division Location Purchase Receipt Number (NAG_LM_AV_AO_DivLocTicNum)
   * 
   */
  private _populateTicketNumbersInRM(form: FormGroup) {
    const releaseNumber = form.get('NAG_LM_FV_LD_DT_Load_Num');
    return releaseNumber.valueChanges.pipe(
      startWith(releaseNumber.value),
      tap(number => {
        if (number) {
          this.search._populateFormField(form.get('NAG_LM_AV_AO_TicketNum'), `${number}-T`, true);
          this.search._populateFormField(form.get('NAG_LM_AV_AO_DivLocTicNum'), `${number}-F`, true);
        }
      }),
    );
  }

  public populateInboundDepartmentIds(form: FormGroup) {
    const shipToDepartmentId = form.get('NAG_LM_AV_LC_Dept');
    const locationId = form.get('NAG_LM_AV_LC_Ldet_LID');
    const productId = form.get('NAG_LM_AV_RD');
    const isDetailView = location.href.includes('detail_view');
    return combineLatest(
      isDetailView && productId
      ? productId.valueChanges.pipe(
          startWith(productId.value),
        )
      : of(null),

      locationId.valueChanges.pipe(
        startWith(locationId.value),
        customPipeforDropdownField,
      ),
    ).pipe(
      switchMap(([prodId, locId]) => this.search.getDepartmentIdsFromDepartments(prodId, locId)),
      map(ids => ids.map(id => ({code: id, value: id}))),
      tap(ids => {
        if (ids.length === 1) {
          this.search._populateFormField(shipToDepartmentId, ids[0].code, true);
        }
      })
    );
  }


  public pickupStartDateExceeds30Days(form: FormGroup) {
    const { year, month, day } = form.get('NAG_FPR_FV_FP_DT_Sdate').value;
    const start = Date.UTC(year, month, day);
    const current = new Date();
    const currentUTC = Date.UTC(current.getFullYear(), current.getMonth() + 1, current.getDate());
    const dayInMilliSeconds = 86_400_000;
    return (start - currentUTC) / dayInMilliSeconds >= 30;
  }

  public creditStatusFailedOnReadyToShip(form: FormGroup) {
    const receivingType = form.get('NAG_LM_AV_LC_LDet_Op');
    if (receivingType.value === 'Customer') {
      const customerId = form.get('NAG_LM_AV_LC_Cdet_CID');
      const statuses = [
        'Bankruptcy', 'Cash Only', 'FIC - Attorney', 'FIC - Tek Collect', 'Hold', 
        'In Collect-Attorney', 'In Collections', 'Permanent COD', 'Temporary COD', 'Application Needed'
      ];
      return this.search.getCustomerCreditStatusByCustomerId(customerId.value).pipe(
        map(res => {
          if (res.Data.length === 0) {
            return false;
          }
          const creditStatus = res.Data[0].nagccmavdtdtstatus;
          const failed = statuses.some(status => status === creditStatus);
          if (failed) {
            this.msg.showMessage('Warning', {
              body: 'Contact Credit Department – Credit Status does not allow sale to this Customer',
            });
          }
          return failed;
        }),
      )
    }
    return of(false);
  }

  public pickupEndDataExceeds60DaysFromPickupStartDate(form: FormGroup) {
    // Pickup Start Date
    const { year: syear, month: smonth, day: sday } = form.get('NAG_FPR_FV_FP_DT_Sdate').value;
    // Pickup End Date
    const { year: eyear, month: emonth, day: eday } = form.get('NAG_FPR_FV_FP_DT_FulfilBy').value;
    const start = Date.UTC(syear, smonth, sday);
    const end = Date.UTC(eyear, emonth, eday);
    const dayInMilliSeconds = 86_400_000;
    return (end - start) / dayInMilliSeconds > 60;
  }

  public creditLimitExceeds75OnRecordCreate(form: FormGroup) {
    const avCredit = +form.get('NAG_SCM_FV_CT_DT_AC').value || 0;
    const totalCredit = +form.get('NAG_SCM_FV_CT_DT_TC').value || 0;
    const contractPrice = +form.get('NAG_SCM_FV_CT_DT_Price').value || 0;
    const quantity = +form.get('NAG_SCM_FV_CT_DT_Quan').value || 0;

    return  ((totalCredit - avCredit) + (contractPrice * quantity)) > (0.75 * totalCredit);
  }

  public creditLimitExceeds75OnCustomerAssigned(form: FormGroup) {
    const receivingType = form.get('NAG_LM_AV_LC_LDet_Op');
    if (receivingType.value === 'Customer') {
      const avCredit = +form.get('NAG_LM_AV_LC_Cdet_AC').value || 0;
      const totalCredit = +form.get('NAG_LM_AV_LC_Cdet_TC').value || 0;
      const price = +form.get('NAG_LM_AV_CD_PriceF').value || 0;
      const quantity = +form.get('NAG_LM_FV_LD_DT_Quantity').value || 0;
  
      return  ((totalCredit - avCredit) + (price * quantity)) > (0.75 * totalCredit) &&
              ((totalCredit - avCredit) + (price * quantity)) <= totalCredit;
    }
    return false;
  }

  public creditLimitExceededOnCustomerAssigned(form: FormGroup) {
    const receivingType = form.get('NAG_LM_AV_LC_LDet_Op');
    if (receivingType.value === 'Customer') {
      const avCredit = +form.get('NAG_LM_AV_LC_Cdet_AC').value || 0;
      const totalCredit = +form.get('NAG_LM_AV_LC_Cdet_TC').value || 0;
      const price = +form.get('NAG_LM_AV_CD_PriceF').value || 0;
      const quantity = +form.get('NAG_LM_FV_LD_DT_Quantity').value || 0;
  
      return ((totalCredit - avCredit) + (price * quantity)) > totalCredit;
    }
    return false;
  }

  public handleRequestorInFertilizerRequests(form: FormGroup) {
    const {UserName} = this.userDetail;
    const requestor = form.get('NAG_FPR_FV_FP_DT_Request');
    requestor.patchValue(UserName);
    requestor.markAsDirty();
  }

  public calculateFreightInReleaseManager(form: FormGroup) {
    const quantityPulled = form.get('NAG_LM_AV_LD_PD_AP');
    const freightRate = form.get('NAG_LM_AV_RD_PD_Fr');
    const freight = form.get('NAG_LM_AV_RD_PD_TF');

    return combineLatest(
      quantityPulled.valueChanges.pipe(startWith(quantityPulled.value)),
      freightRate.valueChanges.pipe(startWith(freightRate.value))
    ).pipe(
      debounceTime(CALCULATION_DEBOUNCE),
      tap(([quantity, rate]) => {
        quantity = +quantity || 0;
        rate = +rate || 0;
        freight.patchValue((quantity * rate).toFixed(2));
        freight.markAsDirty();
      })
    )
  }

  public populateOtherContractDetails(transactionId: string, form: FormGroup) {
    const shipped = form.get('NAG_SCM_AV_CT_OD_Sh');
    const committed = form.get('NAG_SCM_AV_CT_OD_Co');
    const exposed = form.get('NAG_SCM_AV_CT_OD_Ex');
    const replCost = form.get('NAG_SCM_AV_Repl');
    const position = form.get('NAG_SCM_AV_Pos');
    const contractPrice = form.get('NAG_SCM_FV_CT_DT_Price');
    const changedSubject = new BehaviorSubject(false);
    if (replCost && !replCost.value)
      this.search._populateFormField(replCost, contractPrice.value || '', true);

    return this.novus.getReleaseQuantities(transactionId).pipe(
      tap(response => {
        changedSubject.next(false);
        const changed = 
          (shipped.value != response.QtyShipped) ||
          (committed.value != response.QtyCommitted) ||
          (exposed.value != response.QtyExposed);
        changedSubject.next(changed);
      }),
      tap(response => {
        this.search._populateFormField(shipped, response.QtyShipped);
        this.search._populateFormField(committed, response.QtyCommitted);
        this.search._populateFormField(exposed, response.QtyExposed);
      }),
      switchMapTo(replCost.valueChanges.pipe(startWith(replCost.value))),
      debounceTime(CALCULATION_DEBOUNCE),
      tap(value => {
        const positionValue = ((+value || 0) - (+contractPrice.value || 0)) * +exposed.value;
        this.search._populateFormField(position, positionValue);
      }),
      switchMapTo(changedSubject.asObservable()),
      switchMap(changed => {
        if (changed)
          return this.updateOtherContractDetails(transactionId, +contractPrice.value || 0, +replCost.value || 0);
        return EMPTY;
      })
    );
  }

  public populateRequestorInContractsForm(form: FormGroup) {
    this.search._populateFormField(form.get('NAG_SCM_FV_CT_DT_HID_REQU'), this._user.UserName);
  }

  public calculateOtherPODetails(form: FormGroup) {
    const quantity = form.get('NAG_SCM_AV_PO_PD_Qt');
    const contractPrice = form.get('NAG_SCM_AV_PO_PD_Cost');

    const total = form.get('NAG_SCM_AV_PO_TCP');
    const prepay = form.get('NAG_SCM_AV_PO_Amt');
    const due = form.get('NAG_SCM_AV_PO_OD_Due');
    return combineLatest(
      quantity.valueChanges.pipe(startWith(quantity.value)),
      contractPrice.valueChanges.pipe(startWith(contractPrice.value)),
      total.valueChanges.pipe(startWith(total.value)),
      prepay.valueChanges.pipe(startWith(prepay.value)),
    ).pipe(
      debounceTime(CALCULATION_DEBOUNCE),
      distinctUntilChanged((a, b) => a.toString() === b.toString()),
      map(values => values.map(value => +value || 0)),
      tap(([q, c, t, p]) => {
        this.search._populateFormField(total, (q * c), true);
        this.search._populateFormField(due, (t - p));
      })
    )
  }

  /** When customer credit exceeds 75% 
   * admins and the credit team are notified about it
  */
  public sendNotificationToCreditTeam(form: FormGroup) {
    let date = '';
    const pickupDate = form.get('NAG_LM_AV_LD_PD_PD').value;
    if (pickupDate) {
      const { year, month, day } = pickupDate;
      const dateFormat = environment.Setting.dateFormat;
      const timezone = new Date().getTimezoneOffset();
      date = this.dcs.getUserDateTime(`${month}/${day}/${year}`, dateFormat, -timezone);
    }
    const quantity = +form.get('NAG_LM_FV_LD_DT_Quantity').value || 0;
    const customerPrice = +form.get('NAG_LM_AV_CD_PriceF').value || 0;
    const data = {
      releaseNumber: form.get('NAG_LM_FV_LD_DT_Load_Num').value, 
      releaseValue: quantity * customerPrice,
      customerName: form.get('NAG_LM_AV_LC_Cdet_Cust').value, 
      avCreditLimit: form.get('NAG_LM_AV_LC_Cdet_AC').value,
      contractNumber: form.get('NAG_LM_AV_LD_CD_CN').value,
      vendorName: form.get('NAG_LM_AV_RD_Ven').value,
      location: form.get('NAG_LM_AV_LC_Ldet_Loc').value,
      locationManager: form.get('NAG_LM_AV_LC_Ldet_LM').value,
      productDescription: form.get('NAG_LM_AV_LD_DT_P').value,
      quantityOfLoad: `${quantity} ${form.get('NAG_LM_FV_LD_DT_Units').value}`,
      pickupDate: date,
      shippingTerminal: form.get('NAG_LM_FV_LD_Sloc').value,
    };
    return forkJoin(
      this.novus.getUsersByRole('NAG_Credit_Team'),
      this.novus.getUsersByRole('nag_system_admin')
    ).pipe(
      map(roles => roles.flat()),
      skipWhile(users => users.length === 0),
      map(users => Array.from(new Set(users.map(user => user.EmailAddress)))),
      switchMap(emails => this.email.sendEmail('Credit Limit Exceeded', emails, data)),
    );
  }


  /** Reacts to Available Credit (NAG_LM_AV_LC_Cdet_AC) changes
   * and rounds the value to two decimal places.
   * 
   * The rounded value is not sent in payload.
   * The transformation is front end only.
  */
  public roundAvailableCreditInRM(form: FormGroup) {
    const control = form.get('NAG_LM_AV_LC_Cdet_AC');
    return control.valueChanges.pipe(
      startWith(control.value),
      filter((value: string) => value && value.trim().length > 0),
      distinctUntilChanged(),
      /* It's crutial to set emitEvent to false here:
         - avoiding recursive calls (distinctUntilChanged also helps)
         - actual value in the control is not overwritten with the rounded value
      */
      tap(value => control.patchValue(parseFloat(value).toFixed(2), {emitEvent: false}))
    );
  }

  private populatePurchaseDetails(item: PurchaseOrderAgvance, form: FormGroup) {
    this._syncInProgress.next(false);
    if (!item || Object.values(item).every(v => v === null))
      return;
    
      if (!this._contractDetailsMatchPODetails(item, form)) {
        this.msg.showMessage('Warning', {
          body: `Check Vendor, Product and Prepay - They should match.`,
          btnText: 'Proceed Anyways',
          cancelBtn: true,
          isConfirmation: true,
          caller: this,
          callback: () => this._proceedToContractNumbersMatch(item, form),
        });
      } else {
        this._proceedToContractNumbersMatch(item, form);
      }
  }

  private _proceedToContractNumbersMatch(item: PurchaseOrderAgvance, form: FormGroup) {
    if (!this._contractNumbersMatch(item, form)) {
      this.msg.showMessage('Fail', {
        header: 'Error',
        body: `Vendor Contract numbers don't match. Update c2m or re-enter PO in AgVance.`
      });
      return;
    }
    this._populatePODetals(item, form);
    this._populateShippingStartAndEndDatesAndContractNumber(item, form);
    this._populateLocationInfoFromPO(item, form);
  }

  private _contractDetailsMatchPODetails(item: PurchaseOrderAgvance, form: FormGroup) {
    const contractVendorId = form.get('NAG_SCM_FV_CT_DT_VID');
    const contractProductId = form.get('NAG_SCM_FV_CT_DT_PID');
    const contractPOPrepaid = form.get('NAG_SCM_AV_PO_PP');
    
    const vendorIdsMatch = contractVendorId.value === item.VendorID;
    const productIdsMatch = contractProductId.value === item.ProductID;

    if (!item.TypeofContract)
      item.TypeofContract = '';
    const containsPrepay = !!item.TypeofContract.split('|').find(type => type === 'Prepay');
    const prepaidStatusMatch =
      ((contractPOPrepaid.value === 'Yes' || contractPOPrepaid.value === 'Partial') && containsPrepay) ||
      (contractPOPrepaid.value === 'No' && !containsPrepay); 
    return vendorIdsMatch && productIdsMatch && prepaidStatusMatch;
  }

  private _contractNumbersMatch(item: PurchaseOrderAgvance, form: FormGroup) {
    const vendorContractNumber = form.get('NAG_SCM_AV_CT_OD_Vcon').value;
    const poContractNumber = item.Contractnumber;
    if (!vendorContractNumber && poContractNumber)
      this.search._populateFormField(form.get('NAG_SCM_AV_CT_OD_Vcon'), poContractNumber);
    if (vendorContractNumber && poContractNumber)
      return vendorContractNumber === poContractNumber;
    return true;
  }

  private _populateLocationInfoFromPO(item: PurchaseOrderAgvance, form: FormGroup) {
    const departmentId = form.get('NAG_SCM_FV_CT_DT_Pdept');
    const departmentName = form.get('NAG_SCM_FV_DName');
    const locationId = form.get('NAG_SCM_FV_LocID');
    const locationName = form.get('NAG_SCM_FV_Loc');
    const valuesDontMatch = 
      (departmentId.value && departmentId.value !== item.DepartmentID) ||
      (departmentName.value && departmentName.value !== item.DepartmentName) ||
      (locationId.value && locationId.value !== item.LocationID) ||
      (locationName.value && locationName.value !== item.LocationName);

    if (valuesDontMatch)
      this.msg.showMessage('Warning', {
        header: 'Error - Product or Location',
        body: `Please correct Agvance details, or void the contract and start again.`
      });

    if (!departmentId.value)
      this.search._populateFormField(departmentId, item.DepartmentID);
    if (!departmentName.value)
      this.search._populateFormField(departmentName, item.DepartmentName);
    if (!locationId.value)
      this.search._populateFormField(locationId, item.LocationID);
    if (!locationName.value)
      this.search._populateFormField(locationName, item.LocationName);
  }

  private _populateShippingStartAndEndDatesAndContractNumber(item: PurchaseOrderAgvance, form: FormGroup) {
    const shippingStart = form.get('NAG_SCM_FV_CT_DT_Sstart');
    const shippingEnd = form.get('NAG_SCM_FV_CT_DT_SEnd');

    if (!shippingStart.value)
      this.search._populateFormField(shippingStart, item.PullStartDate, false, 'StaticDateBox');
    if (!shippingEnd.value)
      this.search._populateFormField(shippingEnd, item.PullEndDate, false, 'StaticDateBox');
  }

  private _populatePODetals(item: PurchaseOrderAgvance, form: FormGroup) {
    const contractType = form.get('NAG_SCM_AV_PO_PD_Type');
    const vendor = form.get('NAG_Contracts_VName');
    const vendorId = form.get('NAG_SCM_AV_PO_PD_Ven');
    const pullStartDate = form.get('NAG_SCM_AV_PO_PD_Start');
    const pullEndDate = form.get('NAG_SCM_AV_PO_PD_End');
    const productName = form.get('NAG_SCM_AV_PO_PD_Product');
    const productId = form.get('NAG_SCM_AV_PO_PD_PID');
    const quantity = form.get('NAG_SCM_AV_PO_PD_Qt');
    const unit = form.get('NAG_SCM_AV_PO_PD_Unit');
    const freightRate = form.get('NAG_SCM_AV_PO_PD_Frate');
    const deliveryType = form.get('NAG_SCM_AV_PO_PD_Dtype');
    const dateRequested = form.get('NAG_SCM_AV_PO_PD_Dreq');
    const poNumber = form.get('NAG_SCM_AV_PO_PD_PONum');
    const contractPrice = form.get('NAG_SCM_AV_PO_PD_Cost');
    const departmentId = form.get('NAG_SCM_AV_PO_PD_Pdept');
    const departmentName = form.get('NAG_SCM_AV_PName');
    const locationId = form.get('NAG_SCM_AV_PO_LID');
    const locationName = form.get('NAG_SCM_AV_PO_LName');
    const contractNumber = form.get('NAG_SCM_AV_VCONN');
    

    // CR 160: PO Contract Price Autopopulation
    const prepaid = form.get('NAG_SCM_AV_PO_PP').value;
    const contractRequestPrice = form.get('NAG_SCM_FV_CT_DT_Price').value;
    if (prepaid === 'Yes' || prepaid === 'No')
      this.search._populateFormField(contractPrice, item.Cost, true);
    else if (prepaid === 'Partial')
      this.search._populateFormField(contractPrice, contractRequestPrice, true);


    this.search._populateFormField(contractType, item.TypeofContract, false, 'CheckBoxList', 'NAG_SCM_AV_PO_PD_Type');
    this.search._populateFormField(vendor, item.VendorName);
    this.search._populateFormField(vendorId, item.VendorID);
    this.search._populateFormField(pullStartDate, item.PullStartDate || null, true, 'StaticDateBox');
    this.search._populateFormField(pullEndDate, item.PullEndDate || null, true, 'StaticDateBox');
    this.search._populateFormField(productName, item.ProductName);
    this.search._populateFormField(productId, item.ProductID);
    this.search._populateFormField(quantity, item.Quantity, true);
    this.search._populateFormField(unit, item.Unit);
    this.search._populateFormField(freightRate, item.FreightRate);
    this.search._populateFormField(deliveryType, item.DeliveryType);
    this.search._populateFormField(dateRequested, item.DateRequested || null, false, 'StaticDateBox');
    this.search._populateFormField(poNumber, item.PONumber);
    this.search._populateFormField(departmentId,item.DepartmentID);
    this.search._populateFormField(departmentName,item.DepartmentName);
    this.search._populateFormField(locationId,item.LocationID);
    this.search._populateFormField(locationName,item.LocationName);
    this.search._populateFormField(contractNumber,item.Contractnumber);
  }

/*   public populatePricingGridDetails(transactionId: string, form: FormGroup) {
    return this.novus.getProductPricingGrid(transactionId).pipe(
      map(data => {
        const costAfterDiscounts = form.get('NAG_PR_AV_PD_PRDT_Cost');
        const discountedAnchorPrice = form.get('NAG_PR_FV_PD_MD_MLP');
        const totalDiscounts = form.get('NAG_PR_AV_TD');

        const changed = 
          (+costAfterDiscounts.value || 0) !== data.costAfterDiscount ||
          (+discountedAnchorPrice.value || 0) !== data.discountAnchorValue ||
          (+totalDiscounts.value || 0) !== data.TotalDiscounts;
        
        this.search._populateFormField(costAfterDiscounts, data.costAfterDiscount, true);
        this.search._populateFormField(discountedAnchorPrice, data.discountAnchorValue, true);
        this.search._populateFormField(totalDiscounts, data.TotalDiscounts, true);

        return false;
      })
    )

  } */
}

function customPipeforDropdownField(source: Observable<any>) {
  return source.pipe(
    debounceTime(SEARCH_INPUT_DEBOUNCE),
    distinctUntilChanged(),
    filter(value => value && value.trim().length > 0),
    map(value => value.trim()),
  );
}

interface CustomDropdown {
  code: string;
  value: string;
}

/** Autopopulate Charge Id and GL Account form fields depending on the Charge Area selected */
const CHARGE_AREA = {
  'Kansas Dry Transfer': {NAG_LM_AV_AO_Charge: 'KSDRY', NAG_LM_AV_AO_GL: '15103.1060'},
  'Kansas Liquid Transfer': {NAG_LM_AV_AO_Charge: 'KSLIQ', NAG_LM_AV_AO_GL: '15104.1060'},
  'Missouri Dry Transfer': {NAG_LM_AV_AO_Charge: 'MODRY', NAG_LM_AV_AO_GL: '15103.1052'},
  'Missouri Liquid Transfer': {NAG_LM_AV_AO_Charge: 'MOLIQ', NAG_LM_AV_AO_GL: '15104.1052'},
  'Southern IL Dry Transfer': {NAG_LM_AV_AO_Charge: 'SILDRY', NAG_LM_AV_AO_GL: '15103.1900'},
  'Southern IL Liquid Transfer': {NAG_LM_AV_AO_Charge: 'SILLIQ', NAG_LM_AV_AO_GL: '15104.1900'},
  'None': {NAG_LM_AV_AO_Charge: '', NAG_LM_AV_AO_GL: ''},
};
