import { NgModule } from '@angular/core';

// custom date formater
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateFRParserFormatter } from '@app/core';

import { SharedModule } from '@app/shared';
import { ProcessControlRoutingModule } from './process-control-routing.module';

// pages
import { ProcessControlComponent } from './pages/process-control/process-control.component';
import { FormViewComponent } from './pages/form-view/form-view.component';
import { ChildFormViewComponent } from './pages/child-form-view/child-form-view.component';
import { EContractsRecordViewComponent } from './components/e-contracts-record-view/e-contracts-record-view.component';
import { DetailViewComponent } from './pages/detail-view/detail-view.component';
import { BulkLogComponent } from './pages/bulk-log/bulk-log.component';
import { BidsComponent } from './components/bids/bids.component';
import { CustomFormActionsService } from './services/custom-form-actions.service';
import { DetailViewService } from './services/detail-view.service';
import { DrillDownComponent } from './pages/drilldown/drilldown.component';
import { GridFormComponent } from './components/grid-form/grid-form.component';
import { AssociatedContractsComponent } from './components/associated-contracts/associated-contracts.component';
import { DatePipe } from '@angular/common';
import { IncentiveComponent } from './components/incentive/incentive.component';
import { PricingGridComponent } from './components/pricing-grid/pricing-grid.component';
import { RelatedIncentives } from './components/related-incentives/related-incentives.component';
import { DetailViewHeaderComponent } from './pages/detail-view/detail-view-header/detail-view-header.component';
//import { IncentiveProgramRulesComponent } from './components/incentive-program-rules/incentive-program-rules.component';
import { AssociatedProductInstancesComponent } from './components/associated-product-instances/associated-product-instances.component';
import { IncentiveSalesComponent } from './components/incentive-sales/incentive-sales.component';

@NgModule({
  declarations: [
    ProcessControlComponent,
    FormViewComponent,
    ChildFormViewComponent,
    EContractsRecordViewComponent,
    DetailViewComponent,
    BulkLogComponent,
    BidsComponent,
    DrillDownComponent,
    GridFormComponent,
    AssociatedContractsComponent,
    IncentiveComponent,
    PricingGridComponent,
    RelatedIncentives,
    DetailViewHeaderComponent,    
    AssociatedProductInstancesComponent,
    IncentiveSalesComponent,    
  ],
  imports: [
    SharedModule,
    ProcessControlRoutingModule
  ],
  providers: [{
    provide: NgbDateParserFormatter, useClass: NgbDateFRParserFormatter
  },
  DetailViewService,
  CustomFormActionsService,
  DatePipe,
  ]
})
export class ProcessControlModule { }
