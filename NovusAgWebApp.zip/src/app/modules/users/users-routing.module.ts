import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AddUserComponent } from './pages/add-user/add-user.component';
import { EditUserComponent } from './pages/edit-user/edit-user.component';
import { ManageUsersGridComponent } from './pages/manageusers-grid/manageusers-grid.component';
import{UserProfileComponent} from './pages/user-profile/user-profile.component';
import { AuthGuard, ProcessGuard } from '@app/core';
import { RolesComponent } from './pages/roles/roles.component';
import { UserProfileResolver } from './pages/user-profile/user-profile.resolver';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'grid',
    pathMatch: 'full'
  },
  {
    path: '',
    canActivateChild: [AuthGuard],
    children: [
      {
        path: 'grid',
        component: ManageUsersGridComponent,
        canActivate: [ProcessGuard],
      },
      {
        path: 'roles',
        component: RolesComponent,
        canActivate: [ProcessGuard],
      },
      {
        path: 'add-user',
        component: AddUserComponent,
        canActivate: [ProcessGuard],
      },
      {
        path: 'edit-user',
        component: EditUserComponent,
        canActivate: [ProcessGuard],
      },
      {
        path: 'edit-user/:id',
        component: EditUserComponent,
        canActivate: [ProcessGuard],
      },
      {
        path: 'user-profile',
        component: UserProfileComponent
      },
      {
        path: 'user-profile/:uName',
        component: UserProfileComponent,
        resolve: {userProfile: UserProfileResolver},
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
  providers: [UserProfileResolver]
})
export class UsersRoutingModule {}
