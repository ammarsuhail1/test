import { Component, OnInit } from '@angular/core';
import { IHeaderMap } from '@app/core/models/plasmaGridInterface';
import { UserManagementService } from '@app/core/services/user-management.service';
import { ColumnFilterService } from '@app/core/services/column-filter.service';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { MessageComponent } from '@app/shared/components/message/message.component';
import { Router } from '@angular/router';
import { GridViewExportComponent } from '@app/shared/components/grid-view-export/grid-view-export.component';
import { DatePipe } from '@angular/common';
import { FormControl } from '@angular/forms';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { environment } from '@env/environment';
import * as CryptoJS from 'crypto-js';
import { MessageService } from '@app/core';
import { NovusService } from '@app/core/services/novus.service';
import { UserDetail } from '@app/core/models/user-detail';

@Component({
  selector: 'app-users-grid',
  templateUrl: './manageusers-grid.component.html',
  providers: [DatePipe],
  styleUrls: ['./manageusers-grid.component.scss']
})

export class ManageUsersGridComponent implements OnInit {
  encrypted: any;
  transactionId: string;
  filters: any = {};
  dataSource: any;
  ExportData: any;
  itemsCount: number;
  pageNum = -1;
  dammyData: any = {};
  SearchText = new FormControl('');
  constructor(
    private novus: NovusService,
    private msg: MessageService,
    private usermanagement: UserManagementService,
    private columnFilter: ColumnFilterService,
    private modalService: NgbModal,
    private router: Router,
    private datePipe: DatePipe,
    private userDetail: UserDetail) { }
  
  bodyData = {
    PageSize: 10,
    PageNumber: 1,
    SortColumn: 'FirstName',
    SortOrder: 'desc',
    TimeZone: 0,
    GridFilters: [],
    UserId: this.userDetail.UserId.toString(),
    GroupId: this.userDetail.GroupId.toString(),
    AccessToken: this.userDetail.token,
    SearchName: ""
  };

  HeaderMap: IHeaderMap = {
    config: {
      header: {
        columns: [
          {
            objectKey: 'UserName',
            displayName: 'User Name',
            width: '15%'
          },
          {
            objectKey: 'FirstName',
            displayName: 'First Name',
            width: '15%'
          },
          {
            objectKey: 'LastName',
            displayName: 'Last Name',
            width: '15%'
          },
          {
            objectKey: 'EmailAddress',
            displayName: 'Email Address',
            width: '15%'
          },
          {
            objectKey: 'Phone',
            displayName: 'Phone',
            width: '15%'
          },
          {
            objectKey: 'Status',
            displayName: 'Status',
            width: '8%'
          },
          {
            objectKey: 'DateRegistered',
            displayName: 'Created On',
            dataType: 'Date',
            format: 'MM/dd/yyyy',
            timeZone: this.userDetail.TimeZone.toString(),
            width: '10%'
          },
          {
            objectKey: 'DateLastModified',
            displayName: 'Modified On',
            dataType: 'Date',
            format: 'MM/dd/yyyy',
            timeZone: this.userDetail.TimeZone.toString(),
            width: '10%'
          },
        ],
        action: {
          Edit: true,
          Delete: true,
          Checkbox: true,
          Placement: 'IsExternalShow',

          DropDown: false
        },
        columnFilter: []
      },
      paging: true
    }
  };
  ngOnInit() {
    this.bindUser(this.bodyData);
    this.SearchText.valueChanges.pipe(debounceTime(600), distinctUntilChanged()).subscribe(searchText => {
      this.bodyData.SearchName = searchText;
      this.globalSearch(searchText);
    });
  }

  private bindUser(bodyData) {
 
    this.usermanagement.getUserGridList(bodyData).subscribe(Result => {
      if (Result) {
        if (Result.code == "200") {   
          this.dataSource = Result.data.UserInfo.ManageUsers;
          this.itemsCount = Result.totalrecords;
        }
        else if (Result.code == "3035") {
          this.dataSource = [];
          this.itemsCount = 0;
        } else {
          this.msg.showMessage('Fail', {body: Result.message});
        }
      }
    }, error => {
      this.msg.showMessage('Fail', {body: error});
    });
  }

  pageChange(event) {
    this.bodyData.PageNumber = event.currentPage;
    this.bodyData.PageSize = event.pageSize;
    this.bindUser(this.bodyData);
  }

  actionClick(event) {
    if (event.action == "asc" || event.action == "desc") {
      if (event.action == "asc") {
        event.action = "desc";
      } else {
        event.action = "asc";
      }
    }
    switch (event.action) {
      case 'Filter_Header':
        this.bindColumnFilterDdl(event);
        break;
      case 'Edit':
        //
        const UserName = this.dataSource[event.rowIndex].UserName;
        this.encrypted = CryptoJS.AES.encrypt(UserName, environment.Setting.secretCode);
        this.router.navigate(['/users/user-profile', this.encrypted.toString()]);
        break;
      case 'Filter_Click':
        if (!this.validate(event)) {
          break;
        }
        this.bodyData.PageNumber = 1;
        let filter: any = {};
        filter = {
          GridConditions: [
          ],
          DataField: event.colData.objectKey,
          LogicalOperator: event.filterData.logicalOpt.Value === 'Select...' ? '' : event.filterData.logicalOpt.Value,
          FilterType: 'Column_Filter'
        };
        if (event.filterData.filterValue1 && event.filterData.filterValue1 !== '') {
          if (event.colData.dataType === 'Date') {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: this.datePipe.transform(event.filterData.filterValue1, 'yyyy-MM-dd')
            });
          } else {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: event.filterData.filterValue1
            });
          }
        }
        if (event.filterData.filterValue2 && event.filterData.filterValue2 !== '') {
          if (event.colData.dataType === 'Date') {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: this.datePipe.transform(event.filterData.filterValue2, 'yyyy-MM-dd')
            });
          } else {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: event.filterData.filterValue2
            });
          }
        }
        if (filter && Object.keys(filter).length !== 0) {
          this.filters['Column_Filter~$~' + event.colData.objectKey] = filter;
        }
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
      case 'asc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'asc';
        this.bindUser(this.bodyData);
        //
        break;
      case 'desc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'desc';
        // 
        this.bindUser(this.bodyData);
        break;
      case 'Remove Sort':
        this.bodyData.SortColumn = '-1';
        this.bodyData.SortOrder = 'desc';
        this.bindUser(this.bodyData);
        break;
      case 'Delete':
        this.openConfirmation(this.dataSource[event.rowIndex].UserName);
        break;
      case 'FilterClear_Click':
        delete this.filters['Column_Filter~$~' + event.colData.objectKey];
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
    }
    // 
  }

  globalSearch(value) {
    this.pageNum = 1;
    let filter: any = {};
    if (value === '') {
      delete this.filters['Global_Search~$~dmoName'];
    } else {
      filter = {
        GridConditions: [{
          Condition: 'CONTAINS',
          ConditionValue: value
        }
        ],
        DataField: '',
        LogicalOperator: 'Or',
        FilterType: 'Global_Search'
      };
    }
    if (filter && Object.keys(filter).length !== 0) {
      this.filters['Global_Search~$~dmoName'] = filter;
    }
    this.generateFilter();
  }

  private generateFilter() {
    this.bodyData.GridFilters = [];
    this.bodyData.PageNumber = 1;
    Object.keys(this.filters).forEach(key => {
      this.bodyData.GridFilters.push(this.filters[key]);
    });
    // 
    this.bindUser(this.bodyData);
  }
  validate(event): boolean {
    if (event.filterData.ConditionOpt1 && (event.filterData.ConditionOpt1.Value === '' ||
      event.filterData.ConditionOpt1.Value === 'Select...')) {
      return false;
    } else if (event.filterData.filterValue1 && event.filterData.filterValue1.Value === '') {
      return false;
    } else {
      return true;
    }
  }
  bindColumnFilterDdl(item) {
    let type = '';
    if (item.colData.dataType === 'Date') {
      type = 'DateEditBox';
    }
    const FilterData = this.columnFilter.GetFilterByDataType(type); // Calling Function to get ColumnFilter Condition data
    if (FilterData.length === 0) { // Check if Array is empty then call API for options data
      // if (!this.ColumnData[item.datafield]) {
      //   this.showItemLoading = false;
      //   this.listviewService.DMOData(this.ProcessName, item.datafield).subscribe(
      //     data => {
      //       this.ColumnData[item.datafield] = data;
      //       this.showItemLoading = true;
      //     });
      // }
    } else {
      const key = Object.keys(item.colData)[0];
      this.HeaderMap.config.header.columnFilter['colData_' + item.colIndex] = FilterData;
    }
  }
  removeFilter(txtGlobal) {
    this.filters = [];
    txtGlobal.value = '';
    this.pageNum = 1;
    this.generateFilter();
  }

  /* -------------------------Delete Single Record---------------------- */
  openConfirmation(id) {
    this.transactionId = id;
    this.msg.showMessage('Warning', {
      header: 'Delete User Record',
      body: 'Are you sure you want to delete the user record?',
      btnText: 'Confirm Delete',
      checkboxText: 'Yes, delete this user',
      isDelete: true,
      callback: this.deleteConfirmation,
      caller: this,
    })
    // this.showErrorMessage('Are you sure you want to delete?', 'Delete user record', 'Confirm Delete', this.deleteConfirmation, true,
    //   true, false, 'Yes, delete this user.');
  }
  deleteConfirmation(modelRef: NgbModalRef, Caller: ManageUsersGridComponent) {
    if (Caller.transactionId) {
      Caller.usermanagement.deleteUser(Caller.transactionId).subscribe(
        result => {
          if (result.status === 'SUCCESS') {
            Caller.bindUser(Caller.bodyData);
            modelRef.close();
          }
        });
    } else {
      modelRef.close();
    }
  }
  /*------------------- Show Popup -------------------*/
  // showErrorMessage(ErrorMsg: string, HeaderMsg: string, buttonText: string, callback: any, IsConfirmation: boolean, IsDelete: boolean,
  //   IsDefaultView: boolean, confirmationText: string) {
  //   const modalMsgRef = this.modalService.open(MessageComponent, { backdrop: 'static', windowClass: 'Confirm_popup' });
  //   const modalInstance: MessageComponent = modalMsgRef.componentInstance;
  //   modalInstance.Message = ErrorMsg;
  //   modalInstance.ButtonText = buttonText;
  //   modalInstance.MessageHeader = HeaderMsg;
  //   modalInstance.MessagePopup = modalMsgRef;
  //   modalInstance.IsConfirmation = IsConfirmation;
  //   modalInstance.CallBackMethod = callback;
  //   modalInstance.Caller = this;
  //   modalInstance.IsDelete = IsDelete;
  //   modalInstance.IsDefaultView = IsDefaultView;
  //   modalInstance.ConfirmationText = confirmationText;
  // }


  getExportDataList(Result: any) {

    if (Result.code == "200") {
      if (Result.data.UserInfo.ManageUsers.length == undefined) {
        this.ExportData = [Result.data.UserInfo.ManageUsers]
      } else {
        this.ExportData = Result.data.UserInfo.ManageUsers;
      }
    } else if (Result.code == "3035") {
      this.ExportData = [];
    }
  }


  async GetExportData() {
    this.bodyData.PageNumber=1;
    this.bodyData.PageSize=90000;
    
    await this.usermanagement.GetExportData(this.bodyData).then((Result) => {
      
      this.getExportDataList(Result);
    }, error => {
      this.msg.showMessage('Fail', {body: error});
      // this.showErrorMessage(error, 'Error', 'Ok', null, false, false, true, '');
    });
  }

  async openNewExportPopup(ExportType: string) {

    await this.GetExportData();

    this.novus.getUsersGridColumns().subscribe(Result => {
      const modalRef = this.modalService.open(GridViewExportComponent, { backdrop: 'static' });
      const modalInstance: GridViewExportComponent = modalRef.componentInstance;
      modalInstance.ExportType = ExportType.toUpperCase();
      modalInstance.ExportPopup = modalRef;
      modalInstance.ExternalCall = {
        FromURL: true,
        GUID: 'Name',
        displayValue: 'DisplayName',
        DownloadFileURL: `${environment.Setting.ProjectApiUrl}/users/exportTo${ExportType}`
      };
      modalInstance.ExportUserData.ManageUsers = this.ExportData;
      modalInstance.ExportUserData.ProcessName = 'Users';
      modalInstance.setDmoList(Result);
    }, err => {
      this.msg.showMessage('Fail', {body: err.message});
      // this.showErrorMessage(err.message, 'Error', 'Ok', null, false, false, true, '');
    });
  }

  /* -------------------------Change User Status (active/ inactive)---------------------- */
  openStatus() {
    const count = this.dataSource.filter(x => x.selected === true).length;
    if (count === 1) {
      this.msg.showMessage('Warning', {
        header: 'Change User Status',
        body: 'Are you sure you want to change this status?',
        btnText: 'Yes',
        isConfirmation: true,
        callback: this.ChangeStatus,
        caller: this,
      })
      // this.showErrorMessage('Are you sure you want to change this status?', 'Change user status', 'Yes', this.ChangeStatus, true,
      //   false, true, '');
    } else if (count > 1) {
      this.msg.showMessage('Warning', {body: 'Please select only one record'});
      // this.showErrorMessage('Please select only one record', 'Warning !', 'Ok', null, false, false, true, '');
    } else {
      this.msg.showMessage('Warning', {body: 'Please select at least one record'});
      // this.showErrorMessage('Please select at least one record', 'Warning !', 'Ok', null, false, false, true, '');
    }
  }
  ChangeStatus(modelRef: NgbModalRef, Caller: ManageUsersGridComponent) {
    Caller.dataSource.filter(x => x.selected === true).forEach(element => {
      const status = element.Status === 'Active' ? 0 : 1;
      Caller.usermanagement.ChangeUserStatus(element.UserName, status).subscribe(
        result => {
          if (result.status === 'SUCCESS') {
            Caller.bindUser(Caller.bodyData);
          }
        });
    });
    modelRef.close();
  }
}

