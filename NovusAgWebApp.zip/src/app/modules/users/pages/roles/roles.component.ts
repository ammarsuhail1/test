import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormControl } from '@angular/forms';

import { NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';

import { MessageService } from '@app/core';
import { NovusService } from '@app/core/services/novus.service';
import { ColumnFilterService } from '@app/core/services/column-filter.service';

import { UserDetail } from '@app/core/models/user-detail';

import { IHeaderMap } from '@app/core/models/plasmaGridInterface';

@Component({
  selector: 'app-roles',
  templateUrl: './roles.component.html',
  providers: [DatePipe],
  styleUrls: ['./roles.component.scss']
})
export class RolesComponent implements OnInit {

  transactionId: string;
  filters: any = {};
  dataSource: any;
  itemsCount: number;
  pageNum = -1;
  SearchText = new FormControl('');
  constructor(
    private novus: NovusService,
    private msg: MessageService,
    private columnFilter: ColumnFilterService,
    private datePipe: DatePipe,
    private userDetail: UserDetail
  ) { }
  
  bodyData = {
    pageSize: 10,
    pageNum: 0,
    sortColumn: '-1',
    sortDir: '-1',
    columnNames: '',
    globalFilter: '',
    filters: null,
    userName: this.userDetail.UserName,
    TimeZone: 0,
    UserId: this.userDetail.UserId.toString(),
    GroupId: this.userDetail.GroupId.toString(),
    AccessToken: this.userDetail.token,
    SearchName: ""
  };

  HeaderMap: IHeaderMap = {
    config: {
      header: {
        columns: [
          {
            objectKey: 'PolicyName',
            displayName: 'Role Name',
            width: '19%'
          },
          {
            objectKey: 'PolicyFrndName',
            displayName: 'Friendly Name',
            width: '19%'
          },
          {
            objectKey: 'Status',
            displayName: 'Status',
            width: '19%'
          },
          {
            objectKey: 'CreatedDate',
            displayName: 'Created On',
            width: '19%'
          },
          {
            objectKey: 'ModifyDate',
            displayName: 'Modified On',
            width: '18%'
          },
        ],
        action: {
          Edit: false,
          Delete: false,
          Checkbox: true,
          Placement: 'IsExternalShow',
          DropDown: false
        },
        columnFilter: []
      },
      paging: true
    }
  };
  ngOnInit() {
    this.bindData(this.bodyData);
    this.SearchText.valueChanges.pipe(debounceTime(600), distinctUntilChanged()).subscribe(searchText => {
      this.bodyData.SearchName = searchText;
      this.globalSearch(searchText);
    });
  }

  private bindData(bodyData) {
    this.novus.getRoles(bodyData).subscribe(response => {
      this.dataSource = response.Data.RoleInfo.ManageRoles;
      this.itemsCount = +response.RecordsCount;
    },
    _error => {
      this.dataSource = [];
      this.itemsCount = 0;
    });
  }

  pageChange(event) {
    this.bodyData.pageNum = event.currentPage - 1;
    this.bodyData.pageSize = event.pageSize;
    this.bindData(this.bodyData);
  }

  actionClick(event) {
    if (event.action == "asc" || event.action == "desc") {
      if (event.action == "asc") {
        event.action = "desc";
      } else {
        event.action = "asc";
      }
    }
    switch (event.action) {
      case 'Filter_Header':
        this.bindColumnFilterDdl(event);
        break;
      case 'Filter_Click':
        if (!this.validate(event)) {
          break;
        }
        this.bodyData.pageNum = 0;
        let filter: any = {};
        filter = {
          GridConditions: [
          ],
          DataField: event.colData.objectKey,
          LogicalOperator: event.filterData.logicalOpt.Value === 'Select...' ? '' : event.filterData.logicalOpt.Value,
          FilterType: 'Column_Filter'
        };
        if (event.filterData.filterValue1 && event.filterData.filterValue1 !== '') {
          if (event.colData.dataType === 'Date') {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: this.datePipe.transform(event.filterData.filterValue1, 'yyyy-MM-dd')
            });
          } else {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: event.filterData.filterValue1
            });
          }
        }
        if (event.filterData.filterValue2 && event.filterData.filterValue2 !== '') {
          if (event.colData.dataType === 'Date') {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: this.datePipe.transform(event.filterData.filterValue2, 'yyyy-MM-dd')
            });
          } else {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: event.filterData.filterValue2
            });
          }
        }
        if (filter && Object.keys(filter).length !== 0) {
          this.filters['Column_Filter~$~' + event.colData.objectKey] = filter;
        }
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
      case 'asc':
        this.bodyData.sortColumn = event.colData.objectKey;
        this.bodyData.sortDir = 'asc';
        this.bindData(this.bodyData);
        break;
      case 'desc':
        this.bodyData.sortColumn = event.colData.objectKey;
        this.bodyData.sortDir = 'desc';
        this.bindData(this.bodyData);
        break;
      case 'Remove Sort':
        this.bodyData.sortColumn = '-1';
        this.bodyData.sortDir = 'desc';
        this.bindData(this.bodyData);
        break;
      case 'FilterClear_Click':
        delete this.filters['Column_Filter~$~' + event.colData.objectKey];
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
    }
  }

  globalSearch(value) {
    this.pageNum = 0;
    let filter: any = {};
    if (value === '') {
      delete this.filters['Global_Search~$~dmoName'];
    } else {
      filter = {
        GridConditions: [{
          Condition: 'CONTAINS',
          ConditionValue: value
        }
        ],
        DataField: '',
        LogicalOperator: 'Or',
        FilterType: 'Global_Search'
      };
    }
    if (filter && Object.keys(filter).length !== 0) {
      this.filters['Global_Search~$~dmoName'] = filter;
    }
    this.generateFilter();
  }

  private generateFilter() {
    this.bodyData.filters = [];
    this.bodyData.pageNum = 0;
    Object.keys(this.filters).forEach(key => {
      this.bodyData.filters.push(this.filters[key]);
    });
    this.bindData(this.bodyData);
  }
  validate(event): boolean {
    if (event.filterData.ConditionOpt1 && (event.filterData.ConditionOpt1.Value === '' ||
      event.filterData.ConditionOpt1.Value === 'Select...')) {
      return false;
    } else if (event.filterData.filterValue1 && event.filterData.filterValue1.Value === '') {
      return false;
    } else {
      return true;
    }
  }
  bindColumnFilterDdl(item) {
    let type = '';
    if (item.colData.dataType === 'Date') {
      type = 'DateEditBox';
    }
    const FilterData = this.columnFilter.GetFilterByDataType(type); // Calling Function to get ColumnFilter Condition data
    if (FilterData.length === 0) { // Check if Array is empty then call API for options data
    } else {
      this.HeaderMap.config.header.columnFilter['colData_' + item.colIndex] = FilterData;
    }
  }
  removeFilter(txtGlobal) {
    this.filters = [];
    txtGlobal.value = '';
    this.pageNum = 1;
    this.generateFilter();
  }

  /* -------------------------Change Role Status (active/ inactive)---------------------- */
  openStatus() {
    const count = this.dataSource.filter(x => x.selected === true).length;
    if (count === 1) {
      this.msg.showMessage('Warning', {
        header: 'Change Role Status',
        body: 'Are you sure you want to change this status?',
        btnText: 'Yes',
        isConfirmation: true,
        callback: this.ChangeStatus,
        caller: this,
      })
 
    } else if (count > 1) {
      this.msg.showMessage('Warning', {body: 'Please select only one record'});
    } else {
      this.msg.showMessage('Warning', {body: 'Please select at least one record'});
    }
  }
  ChangeStatus(modelRef: NgbModalRef, Caller: RolesComponent) {
    Caller.dataSource.filter(x => x.selected === true).forEach(element => {
      Caller.novus.toggleRoleStatus(element.PolicyID.toString()).subscribe(
        updated => {
          if (updated) {
            Caller.bindData(Caller.bodyData);
          }
        });
    });
    modelRef.close();
  }
}
