import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { SearchService } from '@app/core/services/search.service';
import { UtilityService } from '@app/core/services/utility.service';
import { intersectionBy } from 'lodash';
import { BehaviorSubject, Subject } from 'rxjs';
import { map, tap } from 'rxjs/operators';

@Injectable()
export class UserProfileService {
  private _table = new BehaviorSubject<string>(null);
  constructor(
    private utility: UtilityService,
    private search: SearchService,
  ) { }

  get nextDropdown$() {
    return this._table.asObservable();
  }

  private _constructGridConfigForDownstreamRecords(name: string, conditions: Array<{item_id: string, item_text: string}>) {
    let item_id: string = DOWNSTREAM_INFO[name].id;
    let item_text: string = DOWNSTREAM_INFO[name].text;
    const config = this.utility.generateGridConfig({
      ProcessName: DOWNSTREAM_INFO[name].processName,
      ColumnList: `${item_id},${item_text}`,
      SortOrder: 'asc',
      PageSize: 1000,
      SortColumn: item_text,
      IsDistinct: true,
      IsColumnListOnly: true,
    });
    if (DOWNSTREAM_INFO[name].upstreamProcess) {

      const filter = this.utility.generateGridFilter('Column_Filter', DOWNSTREAM_INFO[name].dataField);
      // console.log(DOWNSTREAM_INFO[name].upstreamProcess, form.get(DOWNSTREAM_INFO[name].upstreamProcess).value)
      if (conditions.length > 0) {
        filter.GridConditions = conditions
          .map(({item_id}) => this.utility.generateGridCondition('EQUAL', item_id));

        config.GridFilters.push(filter);
      }
    }
    return config;
  }

  public getDownstreamRecords(name: string, options: Array<{item_id: string, item_text: string}>) {
    const id: string = DOWNSTREAM_INFO[name].id;
    const text: string = DOWNSTREAM_INFO[name].text;
    const config = this._constructGridConfigForDownstreamRecords(name, options);
    return this.search.search(config).pipe(
      map(data => data.Data.map(item => ({item_id: item[id], item_text: item[text]}))),
      tap(_ => this._table.next(name)),
      // tap(data => {
      //   const control = form.get(name);
      //   const controlValue = intersectionBy(control.value || [], data, 'item_id');
      //   this.search._populateFormField(control, controlValue);
      // }),
      // tap(_ => console.log(form.get(name).value)),
    )
  }

}

const DOWNSTREAM_INFO = {
  Region: {processName: 'NVS_MD_RegionMstr', dataField: '', upstreamProcess: '', id: 'dmoregionregncode', text: 'dmoregionregnnam',},
  Subregion: {processName: 'NVS_MD_SUBREGION', dataField: 'dmosregionregion', upstreamProcess: 'Region', id: 'dmosregionsregioncode', text: 'dmosregionsregiondscr',},
  LLC: {processName: 'NVS_MD_TERRITORY', dataField: 'dmoterirorytmsregion', upstreamProcess: 'Subregion', id: 'dmoterirorytmcode', text: 'dmoterirorytmname',},
  ProfitCenter: {processName: 'NVS_MD_PROFITCENTER', dataField: 'dmopfcpfctrty', upstreamProcess: 'LLC', id: 'dmopfcpfccode', text: 'dmopfcpfcnam',},
  Location: {processName: 'NVS_MD_Location', dataField: 'dmolocationpfc', upstreamProcess: 'ProfitCenter', id: 'dmolcnlmcode', text: 'dmolcnlmname',},
  Storage: {processName: 'NVS_MD_STORAGE', dataField: 'dmostoragesmlcn', upstreamProcess: 'Location', id: 'dmostoragesmcode', text: 'dmostoragesmname',},
};
