import { Component, ElementRef, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthenticationService, MessageService } from '@app/core';
import { UserDetail } from '@app/core/models/user-detail';
import { ImageCompressorService } from '@app/core/services/image-compressor.service';
import { NgbDateFRParserFormatter } from '@app/core/services/ngb-date-fr-parser-formatter';
import { UserService } from '@app/core/services/user.service';
import { MustMatch } from '@app/core/validators/must-match.validator';
import { PasswordStrengthValidator } from '@app/core/validators/password-strength-validator';
import { phoneNumberValidator } from '@app/core/validators/phone.validator';
import { ChangePwdComponent } from '@app/shared/components/change-pwd/change-pwd.component';
import { environment } from '@env/environment';
import { NgbDateParserFormatter, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ImageCroppedEvent, ImageTransform } from 'ngx-image-cropper';
import { ToastrService } from 'ngx-toastr';
import { from, Observable, forkJoin } from 'rxjs';
import { concatMap, distinctUntilChanged, filter, switchMap, take, takeWhile, tap, skip } from 'rxjs/operators';
import { UserProfileService } from './user-profile.service';
@Component({
  selector: 'app-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [{ provide: NgbDateParserFormatter, useClass: NgbDateFRParserFormatter }],
})
export class UserProfileComponent implements OnInit, OnDestroy {
  @ViewChild('trvRoleDropdwon', { static: false }) trvRoleDropdwon: ElementRef;
  @ViewChild('Alternateusertext', { static: false }) Alternateusertext: ElementRef;

  form: FormGroup;
  componentActive = true;
  isDisabled = false;
  profileData: any;

  IsFileUpload: boolean = false;
  ImgName: string = "";
  TempArray = [];
  getManagerByGroupId = [];
  data = {}
  RoleID = [];
  UID: any = "";
  croppedImage: any = '';
  transform: ImageTransform = {scale: 1};
  file: File = null;
  errorMsg: string[5];
  imageChangedEvent: any = '';
 
  files = [];
  afterCroped: any;
  loadData: any;
  loadEmailPreferences: any;
  loadRole_List: any;
  UpdateJson: any;
  updateEmailPref: any;
  IsSubmit: boolean = false;
  addEditData = {
    file: []
  };

  addNewUser = false;

  RoleDropdownList = [];
  
  dropdownSettings = {
    singleSelection: false,
    idField: 'item_id',
    textField: 'item_text',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    itemsShowLimit: 3,
    allowSearchFilter: true
  };
  dropdownsData = {
    Region: [],
    Subregion: [],  
    LLC: [],
    ProfitCenter: [],
    Location: [],
    Storage: [],
  };

  requiredField: boolean = false;
  MinDate: any = { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() };
  MaxDate: any = { year: new Date().getFullYear(), month: new Date().getMonth() + 1, day: new Date().getDate() };
  currentDate: any = (new Date().getMonth() + 1) + "/" + (new Date().getDate()) + "/" + (new Date().getFullYear());
  ProfileLocation: string = environment.Setting.C2M_Console_URL + "/UserResource/Uploaduserprofileimage/";
  constructor(
    private userProfile: UserProfileService,
    private auth: AuthenticationService,
    private compressor: ImageCompressorService,
    private msg: MessageService,
    private router: Router, 
    private ngbDateFRParserFormatter: NgbDateFRParserFormatter, 
    private userService: UserService, 
    private route: ActivatedRoute, 
    private modalService: NgbModal, 
    private fb: FormBuilder, 
    private toastr: ToastrService,
    private userDetail: UserDetail,
    ) {
      if (this.route.snapshot.params.uName) {
        this.profileData = route.snapshot.data.userProfile.data.Users;
        this.UID = this.route.snapshot.params.uName;
        if (this.UID != "myprofile=user") {
          this.UID = this.profileData.Username;
        }
      else{
        this.isDisabled = true;
      }
    }
    this.bindEmptyData();

    this.form = this.fb.group({
      Access_Permission: ['', []],
      User_Name: ['', [Validators.pattern('^[a-zA-Z0-9|_]*$'), Validators.required]],
      Password: ['', [PasswordStrengthValidator, Validators.required]],
      Confirm_Password: ['', [Validators.required]],
      Email: ['', [Validators.email, Validators.required]],
      UserId: ['', [Validators.pattern('^[a-zA-Z0-9|_]*$')]],
      First_Name: ['', [Validators.pattern('^[a-zA-Z0-9|_]*$')]],
      Mobile: this.fb.group({
        Mobile_1: ['', [Validators.pattern('^[0-9]*$')]],
        Mobile_2: ['', [phoneNumberValidator]]
      }),
      Phone: this.fb.group({
        Phone_1: [''],
        Phone_2: [''],
      }),
      Role: ['', []],
      Middle_Initial: ['', [Validators.pattern('^[a-zA-Z0-9|_]*$')]],
      Last_Name: ['', [Validators.pattern('^[a-zA-Z0-9|_]*$'), Validators.maxLength(50)]],

      Out_of_Office: [''],
      Role_List: this.fb.array([]),
      Email_Prefer: this.fb.array([]),
      OutFrom: [null, []],
      OutUntil: [null, []],
      Pic_Name: [''],
      Region:[[],[Validators.required]],
      Subregion:[[],[Validators.required]],
      LLC:[[],[Validators.required]],
      ProfitCenter:[[],[Validators.required]],
      Location:[[],[Validators.required]],
      Storage:[[],[Validators.required]],
      RegionDownstream: [false],
      SubregionDownstream: [false],
      LLCDownstream: [false],
      ProfitCenterDownstream: [false],
      LocationDownstream: [false],
    }, {
      validator: this.UID == '' ? MustMatch('Password', 'Confirm_Password') : ""
    });
    if (this.isDisabled) {
      this.form.get('Access_Permission').disable();
    }
    this.PushEmailPreferencesList();
    this.PushRole_List();
    this.patchValueMethod();
  }
 

  async EditData() {
    const Result = this.route.snapshot.data.userProfile;
    if (Result) {    
      if (Result.code == "200") {
        const data = Result.data.Users;
        this.loadData = {
          UserId: data.USERID,
          User_Name: data.Username,
          Last_Name: Object.values(data.LastName)[0],
          Email: data.EmailAddress,
          First_Name: Object.values(data.firstName)[0],
          Middle_Initial: Object.values(data.mName)[0],
          Mobile: { Mobile_1: data.MobileCountryCode, Mobile_2: data.MobileNo },
          Phone: { Phone_1: data.PhoneCountryCode, Phone_2: data.phone },
          Pic_Name: Object.values(data.photo)[0],
          Access_Permission: data.IsDirectAccess == "False" ? "Novus_SSO" : "Direct_Access",
          Password: "",
          Confirm_Password: "",
          Role: [],
          Out_of_Office: data.InOutStatus == "True" ? "op2" : "op1",
          OutFrom: this.ngbDateFRParserFormatter.parse(data.OutFrom == "" ? this.currentDate : data.OutFrom),
          OutUntil: this.ngbDateFRParserFormatter.parse(data.OutTill == "" ? this.currentDate : data.OutTill),

          defaultDownstream: data.DefaultDownstream,  
          
        };
        var roleDa = [];
        if (Result.data.Users.AlternateUsers.AltUser.length == undefined) {
          roleDa = [Result.data.Users.AlternateUsers.AltUser];
        } else {
          roleDa = Result.data.Users.AlternateUsers.AltUser;
        }
        if (roleDa.length > 0) {
          this.TempArray = [];
          roleDa.forEach(({ RoleId, RoleName }) => {
            this.TempArray.push({ "item_id": RoleId, "item_text": Object.values(RoleName)[0] })
          });
          this.loadData.Role = this.TempArray;
        }
        
        await this.initializeDownstreamDropdowns('Region');

        var EmailP = [];
        if (Result.data.Users.EmailPreferences.EmailPreference.length == undefined) {
          EmailP = [Result.data.Users.EmailPreferences.EmailPreference];
        } else {
          EmailP = Result.data.Users.EmailPreferences.EmailPreference;
        }
        if (EmailP.length > 0) {
          this.TempArray = [];
          EmailP.forEach(({ ProcessTypeId, ProcessName, RoleId, RoleName, ProcessEmail, OBEEmail }) => {
            this.TempArray.push({ "ProcessTypeId": ProcessTypeId, "RoleId": RoleId, "Process_Name": Object.values(ProcessName)[0], "Role_Name": Object.values(RoleName)[0], "Process_Email": Object.values(ProcessEmail)[0] == "checked" ? true : false, "OBE_Email": OBEEmail == "checked" ? true : false })
          });
          this.loadEmailPreferences.EmailPreferences = this.TempArray;
          this.UpdateEmailPreferences();
        }

        var altUs = [];
        if (Result.data.Users.AlternateUsers.AltUser.length == undefined) {
          altUs = [Result.data.Users.AlternateUsers.AltUser];
        } else {
          altUs = Result.data.Users.AlternateUsers.AltUser;
        }

        if (altUs.length > 0) {
          this.TempArray = [];
          altUs.forEach(({ RoleId, RoleName, AlternatUserId, AlternatUserName, email }) => {
            this.TempArray.push({ "email": email, "AlternatUserId": AlternatUserId, "MyRole": Object.values(RoleName)[0], "User_Name": AlternatUserName, "Role_Id": RoleId, "Edit": false })
          });
          this.loadRole_List.Role_List = this.TempArray;
          this.UpdateRole_List();
        }
        const divisionElement: HTMLElement = document.getElementById('Storage') as HTMLElement;
        if (divisionElement) {
          divisionElement.click();
        }
        this.patchValueMethod();
       
      } else {
        this.msg.showMessage('Fail', {body: Result.message});
      }
    } else {
      this.msg.showMessage('Fail', {body: 'Something went wrong'});
    }
  }


  patchValueMethod() {
    this.form.patchValue({
      Access_Permission: this.loadData.Access_Permission,
      User_Name: this.loadData.User_Name,
      Password: this.loadData.Password,
      Confirm_Password: this.loadData.Confirm_Password,
      Email: this.loadData.Email,
      UserId: this.loadData.UserId,
      First_Name: this.loadData.First_Name,
      Middle_Initial: this.loadData.Middle_Initial,
      Last_Name: this.loadData.Last_Name,
         
      Role: this.loadData.Role,
      Mobile: {
        Mobile_1: this.loadData.Mobile.Mobile_1,
        Mobile_2: this.loadData.Mobile.Mobile_2,
      },
      Phone: {
        Phone_1: this.loadData.Phone.Phone_1,
        Phone_2: this.loadData.Phone.Phone_2
      },
      Out_of_Office: this.loadData.Out_of_Office,
      OutFrom: this.loadData.OutFrom,
      OutUntil: this.loadData.OutUntil,
      Pic_Name: this.loadData.Pic_Name,
    });
   
  }

  bindEmptyData() {
    this.loadData =
    {
      "UserId": "0",
      "Access_Permission": "Novus_SSO",
      "User_Name": "",
      "Password": "",
      "Confirm_Password": "",
      "Email": "",
      "First_Name": "",
      "Mobile": { "Mobile_1": "", "Mobile_2": "" },
      "Middle_Initial": "",
      "Phone": { "Phone_1": "", "Phone_2": "" },
      "Role": [],
      "Last_Name": "",   
      "Out_of_Office": "",
      "OutFrom": "",
      "OutUntil": "",
      "Pic_Name": "",

    };

    this.loadEmailPreferences =
    {
      "EmailPreferences": [

      ]
    };

    this.loadRole_List = {
      "Role_List": [
      ]
    }
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }


  ResetForm() {
    this.IsSubmit = false;
    if (this.UID == "") {
      this.form.reset();
      // this.bindEmptyData();
    }
    if (this.UID != "myprofile=user") {
      this.trvRoleDropdwon.nativeElement.children[1].children[0].classList = "multiselect-dropdown";
    }
    if (this.UID != "") {
      this.UpdateEmailPreferences();
    }
    this.afterCroped = undefined;
    this.patchValueMethod();
  }

  // convenience getter for easy access to form fields
  get f() { return this.form.controls; }


  getUploadFile(Result: any) {
    if (Result != "") {
      if (Result.code == "200") {
        this.ImgName = Result.message;
        this.IsFileUpload = true;
      } else {
        this.msg.showMessage('Fail', {body: Result.message});
      }
    }
  }
  async UploadFile() {
    this.ImgName = "";
    const formData = new FormData();
    formData.append('uploadFile', this.afterCroped.file, this.imageChangedEvent.target.files[0].name);
    formData.append('oldImg', this.form.get('Pic_Name').value);
    formData.append('accesstoken', this.userDetail.token);
    await this.userService.UploadFile('/v1/fileUploader/UploadUserProfileImage', formData).then(Result => {
      this.transform.scale = 1;
      return this.getUploadFile(Result);
    }, error => {
      this.msg.showMessage('Fail', {body: error});
    });
  }
 
  async submit() {
    this.IsSubmit = true;
    var AlternateUser = "";
    if (this.UID != '' && this.f.Out_of_Office.value == 'op2') {
      this.form.get('Role_List').value.forEach(({ AlternatUserId, User_Name, Role_Id, email, MyRole }) => {
        if (Role_Id != undefined && (AlternatUserId != '0' && AlternatUserId != '' && User_Name != '')) {
          AlternateUser += (Role_Id + ',' + AlternatUserId + ',' + (User_Name).trim() + ',' + email + ',' + MyRole + ';');
        }
      });
      if (AlternateUser == "") {
        this.msg.showMessage('Fail', {body: 'Please enter valid alternative user for at least one role'});
        // this.showErrorMessage("Please enter valid alternative user for at least one role.", 'Oops!', 'Ok', null, false);
        return;
      }
    }
    if (this.f.Out_of_Office.value == 'op2' && this.UID != '') {
      var fromdate = this.form.get('OutFrom').value;
      var todate = this.form.get('OutUntil').value;
      if (this.form.get('OutUntil').value != "" && this.form.get('OutFrom').value != "") {

        if (((fromdate.day >= this.MaxDate.day && fromdate.month >= this.MaxDate.month) || (fromdate.year >= this.MaxDate.year))) {
          if (!((todate.day >= fromdate.day && todate.month >= fromdate.month) || (todate.year >= fromdate.year))) {
            this.form.get('OutUntil').setValidators(f => <any>{ notValid: true });
            this.form.patchValue({ OutUntil: this.form.get('OutUntil').value })
            this.form.updateValueAndValidity();
          } else {
            this.form.get('OutUntil').clearValidators();
            this.form.get('OutUntil').updateValueAndValidity();
            this.form.get('OutFrom').clearValidators();
            this.form.get('OutFrom').updateValueAndValidity();
          }
        } else {
          this.form.get('OutFrom').setValidators(f => <any>{ notValid: true });
          this.form.patchValue({ OutFrom: this.form.get('OutFrom').value })
          this.form.updateValueAndValidity();
        }
      }
    }

    if (this.UID != "myprofile=user") {
      if (this.form.get('Role').value.length == 0) {
        this.trvRoleDropdwon.nativeElement.children[1].children[0].classList = "is-invalid multiselect-dropdown";
      } else {
        this.trvRoleDropdwon.nativeElement.children[1].children[0].classList = "multiselect-dropdown";
      }
    }

    if (this.f.Out_of_Office.value == 'op1' || this.UID == '') {
      this.form.get('OutUntil').clearValidators();
      this.form.get('OutUntil').updateValueAndValidity();
      this.form.get('OutFrom').clearValidators();
      this.form.get('OutFrom').updateValueAndValidity();
    }

    if (this.UID != '') {
      this.form.get('Password').clearValidators();
      this.form.get('Password').updateValueAndValidity();
      this.form.get('Confirm_Password').clearValidators();
      this.form.get('Confirm_Password').updateValueAndValidity();
    }

    if (this.form.valid) {
      if (this.afterCroped !== undefined) {
        await this.UploadFile();
      } else {
        this.ImgName = this.form.get('Pic_Name').value;
      }

      this.RoleID = [];
      this.form.get('Role').value.forEach(({ item_id }) => {
        this.RoleID.push(item_id);
      });

      var Email_Pref = "";
      this.form.get('Email_Prefer').value.forEach(({ ProcessTypeId, RoleId, Process_Email, OBE_Email }) => {
        if (RoleId != undefined && (Process_Email == true || OBE_Email == true)) {
          Email_Pref += (ProcessTypeId + ',' + RoleId + ',' + Process_Email + ',' + OBE_Email) + ';'
        }
      });
 

      this.UpdateJson =
      {
        UserId: this.loadData.UserId,
        PolicyBundleId: environment.Setting.PolicyBundleId1,
        GroupId: environment.Setting.GroupId1,
        FirstName: (this.form.get('First_Name').value).trim(),
        MiddleName: (this.form.get('Middle_Initial').value).trim(),
        LastName: (this.form.get('Last_Name').value).trim(),
        UserName: (this.form.get('User_Name').value).trim(),
        EmailAddress: (this.form.get('Email').value).trim(),
        Password: (this.form.get('Password').value).trim(),
        IsDirectAccess: (this.form.get('Access_Permission').value).trim() == "Novus_SSO" ? false : true,
        RoleIDs: this.RoleID.join(','),
        MobileCountryCode: (this.form.get('Mobile.Mobile_1').value).trim(),
        MobileNumber: (this.form.get('Mobile.Mobile_2').value).trim(),
        PhoneCountryCode: (this.form.get('Phone.Phone_1').value).trim(),
        PhoneNumber: (this.form.get('Phone.Phone_2').value).trim(),
        Photo: this.ImgName,
        EmailPref: Email_Pref,
        InOutStatus: (this.form.get('Out_of_Office').value).trim() == "op2" ? true : false,
        OutFrom: this.form.get('OutFrom').value != "" ? this.getDateFormat(this.form.get('OutFrom').value) : null,
        OutTill: this.form.get('OutUntil').value != "" ? this.getDateFormat(this.form.get('OutUntil').value) : null,
        AlternateUser: AlternateUser,
        CreatedBy: this.userDetail.UserId,
        ModifiedBy: this.userDetail.UserId,
        defaultDownstream: this._selectedDownstream(),
      };
      HIERARCHY.forEach(table => {
        this.UpdateJson[table] = this.form.get(table).value.map(({item_id}) => item_id).join(',');
      })
      if (this.UID == "") {
        let call$: Observable<any>;
        if (this.addNewUser) {
          call$ = this.userService.AddUpdateUser(this.UpdateJson);
        } else {
          call$ = this.userService.updateUserProfile(this.UpdateJson);
        }
        call$.subscribe((Result) => {
          if (Result) {
            if (Result.status == "SUCCESS") {
              this.IsSubmit = false;
              // this.bindEmptyData();
             
              this.trvRoleDropdwon.nativeElement.children[1].children[0].classList = "multiselect-dropdown";
              this.afterCroped = undefined;
              this.patchValueMethod();
              this.router.navigate(['/users/grid']);
              this.toastr.success('Save successfully.');
            }
            else if (Result.code == "8022") {
              this.msg.showMessage('Fail', {body: Result.message});
            } else {
              this.msg.showMessage('Fail', {body: Result.message});
            }
          }
        }, error => {
          this.msg.showMessage('Fail', {body: error.message});
        });
      }
      else {
        this.userService.updateUserProfile(this.UpdateJson).subscribe((Result) => {
          if (Result) {
            if (Result.status == "SUCCESS") {
              this.IsSubmit = false;
              
              this.toastr.success('Update successfully.');
            }
            else if (Result.code == "8022") {
              this.msg.showMessage('Fail', {body: Result.message});
            } else {
              this.msg.showMessage('Fail', {body: Result.message});
            }
          }
        }, error => {
          this.msg.showMessage('Fail', {body: error.message});
        });
      }
    }
  }

  getStartDate(dateobj) {
    if (dateobj != undefined) {
      this.form.patchValue({
        OutFrom: this.ngbDateFRParserFormatter.parse(this.getDateFormat(dateobj))
      });
    }
  }

  getendDate(dateobj) {
    if (dateobj != undefined) {
      this.form.patchValue({
        OutUntil: this.ngbDateFRParserFormatter.parse(this.getDateFormat(dateobj))
      });
    }
  }

  getDateFormat(dateobj): any {
    const sDay = dateobj.day;
    const sMonth = dateobj.month;
    const sYear = dateobj.year;
    return sMonth + '/' + sDay + '/' + sYear;

  }

  radio(value) {
    this.form.patchValue({ OutFrom: this.form.controls["OutFrom"].value })
    this.form.patchValue({ OutUntil: this.form.controls["OutUntil"].value })
    this.form.updateValueAndValidity();
  }

  async ngOnInit(): Promise<void> {
    this.userService.getUserRoles().subscribe(list => this.RoleDropdownList = list);
    if (this.UID != "") {
      this.EditData();
    } else {
      this.addNewUser = true;
      await this.initializeDownstreamDropdowns('Region');
    }

    this.form.get('Out_of_Office').valueChanges.pipe(takeWhile(_ => this.componentActive)).subscribe((value) => this.radio(value));

    if (this.UID != 'myprofile=user') {
      this.form.get('Role').valueChanges.pipe(takeWhile(_ => this.componentActive)).subscribe((value) => {
        if (value.length == 0 && this.IsSubmit) {
          this.trvRoleDropdwon.nativeElement.children[1].children[0].classList = "is-invalid multiselect-dropdown";
        } else {
          this.trvRoleDropdwon.nativeElement.children[1].children[0].classList = "multiselect-dropdown";
        }
      });
    }

    
  }

  /* Load Email Preferences on change of role*/
  UpdateEmailPreferences() {
    this.form.removeControl('Email_Prefer');
    this.form.addControl('Email_Prefer', this.fb.array([]));
    this.PushEmailPreferencesList();

  }

  UpdateRole_List() {

    this.form.removeControl('Role_List');
    this.form.addControl('Role_List', this.fb.array([]));
    this.PushRole_List();
  }

  public openchangepassword() {        
    if(this.loadData.Email){
      localStorage.setItem('emailforchangepwd',this.loadData.Email);
      this.modalService.open(ChangePwdComponent, { size: 'lg', backdrop: 'static', windowClass: 'Confirm_popup' });
    } 
  }


  /* Push Email preferences into form array*/
  PushEmailPreferencesList() {
    this.loadEmailPreferences.EmailPreferences.forEach(element => {
      const _Row = this.form.controls.Email_Prefer as FormArray;
      _Row.push(this.fb.group({
        Process_Name: element.Process_Name,
        Role_Name: element.Role_Name,
        Process_Email: element.Process_Email,
        OBE_Email: element.OBE_Email,
        ProcessTypeId: element.ProcessTypeId,
        RoleId: element.RoleId,
      }));
    });
  }

  /* Push Role List into form array*/
  PushRole_List() {
    if (this.loadRole_List.Role_List.length > 0) {
      this.loadRole_List.Role_List.forEach(element => {
        const _Row = this.form.controls.Role_List as FormArray;
        _Row.push(this.fb.group({
          MyRole: element.MyRole,
          User_Name: element.User_Name,
          Role_Id: element.Role_Id,
          Edit: element.Edit,
          email: element.email,
          AlternatUserId: element.AlternatUserId,
        }));
      });
    }
  }

  GetUserByGroupID(searchText) {
    if (searchText != "") {
      this.data = {
        "GroupId": this.userDetail.GroupId.toString(),
        "AccessToken": this.userDetail.token, //localStorage.getItem('AccessToken'),
        "Sptype": "1",
        "SearchName": searchText
      }
      this.userService.getDataByBody('v1/GetUserByGroupID', this.data).subscribe((Result) => {
        if (Result) {
          if (Result.code == "200") {
            if (Result.data.DataInfo.ManageUsers.length == undefined) {
              this.getManagerByGroupId = [Result.data.DataInfo.ManageUsers];
            } else {
              this.getManagerByGroupId = Result.data.DataInfo.ManageUsers;
            }
          }
          else if (Result.code == "3035") {
            this.getManagerByGroupId = [];
          } else {
            this.msg.showMessage('Fail', {body: Result.message});
          }
        }
      }, error => {
        this.msg.showMessage('Fail', {body: error});
      });
    }
  }

  EditRole(Role_Id, FormType) {
    if (FormType == "Edit") {
      this.UpdateRowByRoleId(Role_Id, true, "")
    }
    else {
      this.data = {
        "GroupId": this.userDetail.GroupId.toString(),
        "AccessToken": this.userDetail.token,
        "Sptype": "2",
        "SearchName": this.Alternateusertext.nativeElement.value
      }
      this.userService.getDataByBody('v1/GetUserByGroupID', this.data).subscribe((Result) => {
        if (Result) {
          if (Result.code == "200") {
            if (Result.data.DataInfo.ManageUsers.UserID != "") {
              let myList = this.form.controls.Role_List.value;
              myList.find(item => item.Role_Id == Role_Id).email = Result.data.DataInfo.ManageUsers.UserEmail;
              myList.find(item => item.Role_Id == Role_Id).AlternatUserId = Result.data.DataInfo.ManageUsers.UserID;
              this.form.patchValue({
                Role_List: myList
              });
              this.UpdateRowByRoleId(Role_Id, false, "");
            } else {
              this.msg.showMessage('Fail', {body: 'User doesn\'t exist'});
            }
          }
          else if (Result.code == "3035") {
            this.msg.showMessage('Fail', {body: `User doesn't exist`});
          } else {
            this.msg.showMessage('Fail', {body: Result.message});
          }
        }
      }, error => {
        this.msg.showMessage('Fail', {body: error});
      });
    }
  }

  CancelRow(Role_Id) {
    this.UpdateRowByRoleId(Role_Id, false, "Cancel")
  }

  UpdateRowByRoleId(Role_Id, Status, Type) {
    let PreList = this.loadRole_List.Role_List;
    PreList = PreList.find(x => x.Role_Id == Role_Id)

    let myList = this.form.controls.Role_List.value;
    myList.find(item => item.Role_Id == Role_Id).Edit = Status;

    if (Type == "Cancel") {
      myList.find(item => item.Role_Id == Role_Id).User_Name = PreList.User_Name;
    } else {
      PreList.User_Name = myList.find(item => item.Role_Id == Role_Id).User_Name;
    }
    this.form.patchValue({
      Role_List: myList
    });
  }

  getEmailPref(RoleIDs: string) {
    this.data = {
      "UserId": this.loadData.UserId,
      "AccessToken": this.userDetail.token,
      "RoleIDs": RoleIDs,
    }
    this.userService.getDataByBody('v1/GetEmailPreferences', this.data).subscribe((Result) => {
      if (Result) {
        if (Result.code == "200") {
          if (Result.data.root.UserEmailPref.EmailPreference.length == undefined) {
            this.loadEmailPreferences = [Result.data.root.UserEmailPref.EmailPreference];
          } else {
            this.loadEmailPreferences = Result.data.root.UserEmailPref.EmailPreference;
          }
          this.TempArray = [];
          this.loadEmailPreferences.forEach(({ ProcessTypeId, ProcessName, RoleId, RoleName, IsProcessChecked, IsOBEChecked }) => {
            if (this.UID == '') {
              this.TempArray.push({ "ProcessTypeId": ProcessTypeId, "RoleId": RoleId, "Process_Name": Object.values(ProcessName)[0], "Role_Name": Object.values(RoleName)[0], "Process_Email": true, "OBE_Email": true })
            } else {
              this.TempArray.push({ "ProcessTypeId": ProcessTypeId, "RoleId": RoleId, "Process_Name": Object.values(ProcessName)[0], "Role_Name": Object.values(RoleName)[0], "Process_Email": IsProcessChecked == "True" ? true : false, "OBE_Email": IsOBEChecked == "True" ? true : false })
            }
          })
          this.loadEmailPreferences =
          {
            "EmailPreferences": this.TempArray
          };
          this.UpdateEmailPreferences();
        }
        else if (Result.code == "300") {
          this.loadEmailPreferences =
          {
            "EmailPreferences": []
          };
          this.UpdateEmailPreferences();
          this.msg.showMessage('Fail', {body: Result.message});
        } else {
          this.msg.showMessage('Fail', {body: Result.message});
        }
      }
    }, error => {
      this.msg.showMessage('Fail', {body: error});
    });
  }


  GetAlternateUserOutOfficeList(RoleIDs: string) {
    this.data = {
      "UserId": this.userDetail.UserId,
      "AccessToken": this.userDetail.token,
      "RoleIDs": RoleIDs,
    }
    this.userService.getDataByBody('v1/GetAlternateUserOutOfficeList', this.data).subscribe((Result) => {
      if (Result) {
        if (Result.code == "200") {
          if (Result.data.root.AlternateUsers.AltUser.length == undefined) {
            this.loadRole_List = [Result.data.root.AlternateUsers.AltUser];
          } else {
            this.loadRole_List = Result.data.root.AlternateUsers.AltUser;
          }
          this.TempArray = [];
          this.loadRole_List.forEach(({ RoleId, RoleName, AlternatUserId, AlternatUserName, email }) => {
            this.TempArray.push({ "email": Object.values(email)[0], "AlternatUserId": AlternatUserId, "MyRole": Object.values(RoleName)[0], "User_Name": Object.values(AlternatUserName)[0], "Role_Id": RoleId, "Edit": false })
          })
          this.loadRole_List = {
            "Role_List": this.TempArray
          }
          this.UpdateRole_List();
        }
        else if (Result.code == "300") {
          this.loadRole_List = {
            "Role_List": []
          }
          this.UpdateRole_List();
          this.msg.showMessage('Fail', {body: Result.message});
        } else {
          this.msg.showMessage('Fail', {body: Result.message});
        }
      }
    }, error => {
      this.msg.showMessage('Fail', {body: error});
    });
  }


   async onItemDeSelect(type: string, item: any) {
    if (type == "Role") {
      this.loadEmailPreferences =
      {
        "EmailPreferences": this.loadEmailPreferences.EmailPreferences.filter(x => x.RoleId != item.item_id)
      };
      this.UpdateEmailPreferences();
      this.loadRole_List = {
        "Role_List": this.loadRole_List.Role_List.filter(x => x.Role_Id != item.item_id)
      }
      this.UpdateRole_List()
    }
  }

  getSelectedValues(SelectedValue, DataSource) {
    if (SelectedValue != null && SelectedValue != undefined && SelectedValue != "") {
      if (DataSource != null && DataSource != undefined && DataSource != "") {
        var newSelectedValues = [];
        SelectedValue.forEach(({ item_id, item_text }) => {
          if (DataSource.filter(x => x.item_id == item_id).length > 0) {
            newSelectedValues.push({ "item_id": item_id, "item_text": item_text });
          }
        });
        return newSelectedValues;
      }
    }
  }

  private async initDownstreamPopulate(table: string) {
    const index = HIERARCHY.findIndex(t => t === table);
    const tableData = await forkJoin(HIERARCHY.slice(index).map(t => this.userProfile.getDownstreamRecords(t, []))).toPromise();
    HIERARCHY.slice(index).forEach((t, i) => {
      this.dropdownsData[t] = tableData[i];
      const value = this._initDownstreamConditions(t);
      this.form.get(t).patchValue(value, {emitEvent: false});
    });
  }

  private async handleValueChange(table: string, values: any[]) {
    const selectedDownstream = this._selectedDownstream();
    const index = HIERARCHY.findIndex(t => t == table);
    const nextTable = HIERARCHY[index + 1];
    if (nextTable) {
      if (values.length === 0) {
        this.dropdownsData[nextTable] = [];
        this.form.get(nextTable).patchValue([], {emitEvent: true});
      } else {
        this.dropdownsData[nextTable] = await this.userProfile.getDownstreamRecords(nextTable, values).toPromise();
        if (selectedDownstream) {
          const value = this._selectAllDownStreamRecords(nextTable);
          this.form.get(nextTable).patchValue(value, {emitEvent: true});
        }
      }
    }
  }

  private async initializeDownstreamDropdowns(upstream: string) {
    if (this.loadData.defaultDownstream) {
      this.form.get(this.loadData.defaultDownstream).patchValue(true);
      this._disableDownstreamCheckboxes(this.loadData.defaultDownstream);
    }
    this.dropdownsData[upstream] = await this.userProfile.getDownstreamRecords(upstream, []).toPromise();
    if (!this.addNewUser) {
      await this.initDownstreamPopulate(upstream);
    }
    const value = this._initDownstreamConditions(upstream);
    this.form.get(upstream).patchValue(value, {emitEvent: false});
     HIERARCHY.forEach(table => {
       this.form.get(table).valueChanges
      .pipe(
        takeWhile(_ => this.componentActive),
        distinctUntilChanged((a,b) => a.toString() === b.toString())
      )
      .subscribe(async value => {
        await this.handleValueChange(table, value)
       })
     })
  }

  async onItemSelect(type: string, item: any) {
    if (type == "Role") {
      this.RoleID = [];
      this.form.get('Role').value.forEach(({ item_id }) => {
        this.RoleID.push(item_id);
      });
      this.getEmailPref(this.RoleID.join(','));
      this.loadRole_List.Role_List.push({ "email": "", "AlternatUserId": "0", "MyRole": item.item_text, "User_Name": "", "Role_Id": item.item_id, "Edit": false })
      this.UpdateRole_List()
    }
  }

  onDeSelectAll(type: string, items: any) {
    if (type == "Role") {
      this.loadEmailPreferences =
      {
        "EmailPreferences": []
      };
      this.UpdateEmailPreferences();
      this.loadRole_List = {
        "Role_List": []
      }
      this.UpdateRole_List()
    }
  }

  async onSelectAll(type: string, items: any) {
    if (type == "Role") {
      this.RoleID = [];
      this.RoleDropdownList.forEach(({ item_id }) => {
        this.RoleID.push(item_id);
      });
      this.getEmailPref(this.RoleID.join(','));
      this.GetAlternateUserOutOfficeList(this.RoleID.join(','));
    }  
  }

  fileChangeEvent(event: any, id): void {
    const file = event.target.files.item(0);
    if (file != null) {
      const ext = file.name.split('.').pop();
      if (ext === 'jpg' || ext === 'png') {
        this.errorMsg = '';
        this.imageChangedEvent = event;
        this.modalService.open(id, { ariaLabelledBy: 'modal-basic-title' });
      } else {
        this.msg.showMessage('Warning', {body: 'Not a valid file'});
      }
    }
  }
  imageCropped(event: ImageCroppedEvent) {
    this.croppedImage = event;
  }

  Cropped() {
    if (164 >= this.croppedImage.height && 146 >= this.croppedImage.width) {
      this.compressor
        .compress(this.croppedImage, this.imageChangedEvent.target.files.item(0).name)
        .pipe(tap(file => {
          this.afterCroped = {...this.croppedImage, file};
          this.modalService.dismissAll();
        }))
        .toPromise();
    } else
        this.msg.showMessage('Warning', {body: 'Image size is not correct'});
  }
  
  onZoomIn() {
    const scale = this.transform.scale + 0.1;
    this.transform = {...this.transform, scale};
  }

  onZoomOut() {
    const scale = this.transform.scale - 0.1;
    this.transform = {...this.transform, scale};
  }


  public reactToDownStreamChange(downStreamName: string) {
    this._getAllDownStreamRecords(downStreamName)
    .subscribe(
      table => {
        const value = this._selectAllDownStreamRecords(table);
        this.form.get(table).patchValue(value, {emitEvent: true});
      },
      err => console.log(err),
    );
  }

  private _getAllDownStreamRecords(downStreamName: string) {
    return this.form.get(downStreamName).valueChanges.pipe(
      take(1),
      switchMap(checked => {
        if (checked) {
          this._disableDownstreamCheckboxes(downStreamName);
          return from(HIERARCHY.slice(DOWNSTREAM_INDEX[downStreamName], HIERARCHY.length));
        }
        Object.entries(DOWNSTREAM_INDEX).forEach(([name, index]) => {
          if (DOWNSTREAM_INDEX[downStreamName] < index) {
            this.form.get(name).enable()
          }
        });
        return from([]);
      }),
      filter(_ => {
        const index = DOWNSTREAM_INDEX[downStreamName] - 1;
        return this.form.get(HIERARCHY[index]).valid
      }),
      concatMap(async table => {
        const index = HIERARCHY.findIndex(t => t === table);
        const upstream = HIERARCHY[index - 1];
        if (upstream) {
          const conditions = this.form.get(upstream).value;
          this.dropdownsData[table] = await this.userProfile.getDownstreamRecords(table, conditions).toPromise();
        }
        return table;
      }),
    );
  }

  private _initDownstreamConditions(name: string) {
    if (this.profileData) {
      const ids = this.profileData[name]['#cdata-section'].split(',');
      return this.dropdownsData[name].filter(({item_id}) => ids.some(id => id === item_id))
    }
    return [];
  }


  private _selectAllDownStreamRecords(table: string) {
    return this.getSelectedValues(this.dropdownsData[table], this.dropdownsData[table])
  }

  private _disableDownstreamCheckboxes(downStreamName: string) {
    Object.entries(DOWNSTREAM_INDEX).forEach(([name, index]) => {
      if (DOWNSTREAM_INDEX[downStreamName] < index) {
        this.form.get(name).disable()
        this.form.get(name).patchValue(false, {emitEvent: true});
      }
    });
  }

  private _selectedDownstream() {
    for (const name in DOWNSTREAM_INDEX) {
      if (this.form.get(name).value === true) {
        return name;
      }
    }
    return '';
  }

  ngOnDestroy() {
    this.componentActive = false;
  }

}

const HIERARCHY = ['Region', 'Subregion', 'LLC', 'ProfitCenter', 'Location', 'Storage'];

const DOWNSTREAM_INDEX = {
  RegionDownstream: 1,
  SubregionDownstream: 2,
  LLCDownstream: 3,
  ProfitCenterDownstream: 4,
  LocationDownstream: 5,
};
