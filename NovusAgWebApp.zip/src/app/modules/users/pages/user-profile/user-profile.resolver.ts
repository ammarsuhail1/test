import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthenticationService, UserService } from '@app/core';
import { environment } from '@env/environment';
import * as CryptoJS from 'crypto-js';

import { Observable } from 'rxjs';
import { retry } from 'rxjs/operators';

@Injectable()
export class UserProfileResolver implements Resolve<any> {
  constructor(private user: UserService, private auth: AuthenticationService) {}
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot
  ): Observable<any>{
    let userName = route.params.uName;
    if (userName !== 'myprofile=user') {
      const decrypted = CryptoJS.AES.decrypt(userName, environment.Setting.secretCode);
      userName = decrypted.toString(CryptoJS.enc.Utf8);
    }
    if (userName === 'myprofile=user') {
      userName = this.auth.currentUserValue.UserName;
    }
    return this.user.getUserProfile(userName).pipe(retry(1))
    // return true;
  }
}
