import { Component, OnInit } from '@angular/core';
import { environment } from '@env/environment';
import { Title } from '@angular/platform-browser';

import { ApplicationService, ApiESaleyardService } from '@app/core';
import { Subscription } from 'rxjs';
import { UserDetail } from '@app/core/models/user-detail';


@Component({
  selector: 'app-app-list',
  templateUrl: './app-list.component.html',
  styleUrls: ['./app-list.component.scss']
})
export class AppListComponent implements OnInit {
  loadTitle;
  AppList: any;
  ParentAllList: any;
  ImageEndpoint = environment.Setting.C2M_Console_URL;

  //Novus Dashboard
  private unsubscribe: Subscription[] = [];
  currentUser: any;
  userDetail:UserDetail;

  constructor(
    private applicationService: ApplicationService,
    private titleService: Title,
    private apiESaleyardService: ApiESaleyardService) {

    setTimeout(() => {
      if (!this.ParentAllList) {
        this.LoadGrid();
      }
    }, 2000);
  }
  ngOnInit() {
    this.userDetail = new UserDetail();
    localStorage.removeItem('NotificationCount');
    sessionStorage.setItem('DisplayName', 'Dashboard');
    this.loadTitle = sessionStorage.getItem('DisplayName');
    this.setDocTitle(this.loadTitle);
  }

  OpenApp(objApp): void {        
    if (objApp.Name === 'Income_statement' || objApp.Name === 'Balance_sheet' || objApp.Name === 'Sales_Report' || objApp.Name === 'Financial_Detail_Report' || objApp.Name === 'Fertilizer_Exposure'
       || objApp.Name === 'Income_statementV2' || objApp.Name === 'BalanceSheet_V2') {
      this.redirectDashboard(objApp);
      return;
    }
    if (objApp.Name === 'Announcement') {
      window.open('/announcement', '_blank');
    } else if (objApp.Name === 'QuickMind') {
      window.open('/quickmindlist', '_blank');
   
    } else if (objApp.Name === 'Manage Users') {
      window.open('/users/grid', '_blank');
    
    } else if (objApp.Name === 'Manage Role') {
      window.open('/users/roles', '_blank');
    } else {
        window.open(`/process_control/${objApp.Name}`, '_blank');
    }
  }

  LoadGrid() {
    sessionStorage.removeItem('AppName');
    sessionStorage.removeItem('DisplayName');
    this.applicationService.getProcess().subscribe(data => {
      this.AppList = data;
      const result = [];
      for (const key in this.AppList) {
        if (this.AppList.hasOwnProperty(key)) {
          result.push({
            id: key,
            name: key
          });
        }
      }
      this.ParentAllList = result;
    });
  }

  getChildList(id: string): any {
    return this.AppList[id];
  }

  setDocTitle(title: string) {
    this.titleService.setTitle(`${environment.projectTitle} | ${title}`);
  }

  // redirectDashboard(objApp) {
  //   let redirectURI;
  //   const { DashboardDomainUrl, IncomeStatementDashboardId, BalanceSheetDashboardId, VisibilityKey, ApiKey } = environment.Setting.dashboard;
  //   if (objApp.Name === 'Income_statement') {
  //     redirectURI = `${DashboardDomainUrl}/dashboard_view.aspx?dashboardid=${IncomeStatementDashboardId}&visibility=${VisibilityKey}&apikey=${ApiKey}&cacheKey=1801781595&cacheKey=1841174032&cacheKey=1244235709&cacheKey=82046574`;
  //   } else if (objApp.Name === 'Balance_sheet') {
  //     redirectURI = `${DashboardDomainUrl}/dashboard_view.aspx?dashboardid=${BalanceSheetDashboardId}&visibility=${VisibilityKey}&apikey=${ApiKey}&cacheKey=1801781595&cacheKey=1841174032&cacheKey=1244235709&cacheKey=82046574&cacheKey=1001805353`;
  //   }
  //   window.open(redirectURI, '_blank');
  // }

  redirectDashboard(objApp: any) {
    this.currentUser = this.userDetail;
    const userRoles = this.currentUser.ListRole;    
    //let reportType= ;
    

    const getSearchQuerySubr = this.apiESaleyardService.postGetFile(`user/dashboardReportsFilter?reportType=${objApp.Name}`, null, 'json')
      .subscribe(searchQuerydata => {        
        const form = document.createElement('form');
        form.method = 'post';
        form.action = environment.Setting.dashboard.GatewayUrl;
        form.target = '_blank';

        const c2mAttuidElement = document.createElement('input');
        c2mAttuidElement.name = 'C2Mattuid';
        c2mAttuidElement.value = btoa(this.currentUser.UserName);
        c2mAttuidElement.type = 'hidden';

        const c2mAccessTokenElement = document.createElement('input');
        c2mAccessTokenElement.name = 'C2Maccesstoken';
        c2mAccessTokenElement.value = btoa(this.userDetail.token);
        c2mAccessTokenElement.type = 'hidden';

        const c2mRefreshTokenElement = document.createElement('input');
        c2mRefreshTokenElement.name = 'C2Mrefreshtoken';
        c2mRefreshTokenElement.value = btoa(this.userDetail.RefreshToken);
        c2mRefreshTokenElement.type = 'hidden';

        const returnUrlElement = document.createElement('input');
        returnUrlElement.type = 'hidden';
        returnUrlElement.name = 'ReturnUrl';
        returnUrlElement.value = `${environment.Setting.dashboard.DashboardDomainUrl}/dashboard_view.aspx?pg=dashboard_view.aspx&View=${environment.Setting.dashboard[objApp.Name]}&visibility=${environment.Setting.dashboard.VisibilityKey}`;

        

        if (objApp.Name === 'Income_statement') {
          returnUrlElement.value = `${environment.Setting.dashboard.DashboardDomainUrl}/DashboardLandingPage.aspx?pg=dashboard_view.aspx&View=${environment.Setting.dashboard.IncomeStatementDashboardId}&visibility=${environment.Setting.dashboard.VisibilityKey}`;
        } else if (objApp.Name === 'Balance_sheet') {
          returnUrlElement.value = `${environment.Setting.dashboard.DashboardDomainUrl}/DashboardLandingPage.aspx?pg=dashboard_view.aspx&View=${environment.Setting.dashboard.BalanceSheetDashboardId}&visibility=${environment.Setting.dashboard.VisibilityKey}`;
        }else if (objApp.Name === 'Sales_Report') {
          returnUrlElement.value = `${environment.Setting.dashboard.DashboardDomainUrl}/DashboardLandingPage.aspx?pg=dashboard_view.aspx&View=${environment.Setting.dashboard.SalesReportDashboardId}&visibility=${environment.Setting.dashboard.VisibilityKey}`;
        }else if (objApp.Name === 'Financial_Detail_Report') {
          returnUrlElement.value = `${environment.Setting.dashboard.DashboardDomainUrl}/DashboardLandingPage.aspx?pg=dashboard_view.aspx&View=${environment.Setting.dashboard.IncomeStatementDashboardDetailsId}&visibility=${environment.Setting.dashboard.VisibilityKey}`;
        }else if (objApp.Name === 'Fertilizer_Exposure') {
          returnUrlElement.value = `${environment.Setting.dashboard.DashboardDomainUrl}/DashboardLandingPage.aspx?pg=dashboard_view.aspx&View=${environment.Setting.dashboard.FertilizerExposureDashboardId}&visibility=${environment.Setting.dashboard.VisibilityKey}`;
        } 
        else if (objApp.Name === 'Income_statementV2') {
          returnUrlElement.value = `${environment.Setting.dashboard.DashboardDomainUrl}/DashboardLandingPage.aspx?pg=dashboard_view.aspx&View=${environment.Setting.dashboard.IncomeStatementV2DashboardId}&visibility=${environment.Setting.dashboard.VisibilityKey}`;
        } 
        else if (objApp.Name === 'BalanceSheet_V2') {
          returnUrlElement.value = `${environment.Setting.dashboard.DashboardDomainUrl}/DashboardLandingPage.aspx?pg=dashboard_view.aspx&View=${environment.Setting.dashboard.BalanceSheetV2DashboardId}&visibility=${environment.Setting.dashboard.VisibilityKey}`;
        } 


        const processIdElement = document.createElement('input');
        processIdElement.name = 'ProcessID';
        processIdElement.value = environment.Setting.dashboard.ProcessID;
        processIdElement.type = 'hidden';

        const appTypeElement = document.createElement('input');
        appTypeElement.name = 'AppType';
        appTypeElement.value = environment.Setting.dashboard.AppType;
        appTypeElement.type = 'hidden';

        const appNameElement = document.createElement('input');
        appNameElement.name = 'AppName';
        appNameElement.value = environment.Setting.dashboard.AppName;
        appNameElement.type = 'hidden';

        const searchQueryElement = document.createElement('input');
        searchQueryElement.name = 'searchQuery';
        searchQueryElement.value = searchQuerydata;
        searchQueryElement.type = 'hidden';

        form.appendChild(c2mAttuidElement);
        form.appendChild(c2mAccessTokenElement);
        form.appendChild(c2mRefreshTokenElement);
        form.appendChild(returnUrlElement);
        form.appendChild(processIdElement);
        form.appendChild(appTypeElement);
        form.appendChild(appNameElement);
        form.appendChild(searchQueryElement);

        document.body.appendChild(form);
        form.submit();
      });

    this.unsubscribe.push(getSearchQuerySubr);
  }

  ngOnDestroy() {
    this.unsubscribe.forEach(sb => sb.unsubscribe());
  }



}
