import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-manager-sidenav',
  templateUrl: './content-manager-sidenav.component.html',
  styleUrls: ['./content-manager-sidenav.component.scss']
})
export class ContentManagerSidenavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
