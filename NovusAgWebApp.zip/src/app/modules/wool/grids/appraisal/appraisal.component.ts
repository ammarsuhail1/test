import { Component, OnInit, Inject, LOCALE_ID, ViewChild, Output, EventEmitter } from '@angular/core';
import { formatDate } from '@angular/common';
import { saveAs } from 'file-saver';

import { IHeaderMap, ColumnFilterService, ApiESaleyardService } from '@app/core';
import { WoolSearchService } from '../../wool-search.service';

import { CustomizedGridComponent } from '@app/shared';

@Component({
  selector: 'app-appraisal',
  templateUrl: './appraisal.component.html',
  styleUrls: ['./appraisal.component.scss']
})
export class AppraisalComponent implements OnInit {

  @ViewChild(CustomizedGridComponent, { static: false })
  private gridView: CustomizedGridComponent;

  @Output() openBaleDetailModal = new EventEmitter<any>();

  dataSource: any = [];
  itemsCount: number;
  bodyData = {
    PageSize: 10,
    PageNumber: 1,
    SortColumn: 'AppraisalID',
    SortOrder: 'desc',
    GridFilters: []
  };
  filters: any = {};

  headerMap: IHeaderMap = {
    config: {
      header: {
        columns: [
          {
            objectKey: 'TradingName',
            displayName: 'Customer Name1',
            width: '120px'
          },
          {
            objectKey: 'TradingName2',
            displayName: 'Customer Name2',
            width: '120px'
          },
          {
            objectKey: 'ClientAccountNumber',
            displayName: 'Client Account',
            width: '110px'
          },
          {
            objectKey: 'SaleSeason',
            displayName: 'Sale Season',
            width: '100px'
          },
          {
            objectKey: 'SaleNbrSellingCntr',
            displayName: 'Sale Nbr Selling Cntr',
            width: '140px'
          },
          {
            objectKey: 'SaleNumberId',
            displayName: 'Sale Number Id',
            width: '110px'
          },
          {
            objectKey: 'SaleNbrStorageCntr',
            displayName: 'Sale Nbr Storage Cntr',
            width: '150px'
          },
          {
            objectKey: 'LotNumber',
            displayName: 'Lot Number',
            width: '140px'
          },
          {
            objectKey: 'Brand',
            displayName: 'Brand',
            width: '100px'
          },
          {
            objectKey: 'StandardBaleDesc',
            displayName: 'Standard Bale Desc',
            width: '140px'
          },
          {
            objectKey: 'FolioBales',
            displayName: 'Folio Bales',
            dataType: 'Link',
            width: '100px'
          },
          {
            objectKey: 'FolioGrossWeight',
            displayName: 'Folio Gross Weight',
            width: '140px'
          },
          {
            objectKey: 'FolioTareWeight',
            displayName: 'Folio Tare Weight',
            width: '140px'
          },
          {
            objectKey: 'ActualAppraisal',
            displayName: 'Actual Appraisal',
            width: '120px'
          },
          {
            objectKey: 'GrowerReserve',
            displayName: 'Grower Reserve',
            width: '120px'
          },
          {
            objectKey: 'EstGrossProceed',
            displayName: 'Estimated Gross Proceed',
            width: '170px'
          },
          {
            objectKey: 'Region',
            displayName: 'Region',
            width: '100px'
          },
          {
            objectKey: 'Division',
            displayName: 'Division',
            width: '120px'
          },
          {
            objectKey: 'Branch',
            displayName: 'Branch',
            width: '120px'
          },
          {
            objectKey: 'WAM',
            displayName: 'WAM',
            width: '100px'
          },
          {
            objectKey: 'Agent',
            displayName: 'Agent',
            width: '100px'
          },
        ],
        action: {
        },
        columnFilter: []
      },
      paging: true
    }
  };

  constructor(
    private columnFilter: ColumnFilterService,
    private woolSearchService: WoolSearchService,
    private apiESaleyardService: ApiESaleyardService,
    @Inject(LOCALE_ID) private locale: string
  ) { }

  ngOnInit() {
  }

  transformDate(date) {
    return formatDate(date, 'yyyy-MM-dd', this.locale);
  }

  async generateFilter() {
    this.bodyData.GridFilters = [];
    this.bodyData.PageNumber = 1;
    Object.keys(this.filters).forEach(key => {
      this.bodyData.GridFilters.push(this.filters[key]);
    });
    await this.getDataSource(this.bodyData);
    this.gridView.currentPage = 1;
  }

  async getDataSource(params: any) {
    const response: any = await this.woolSearchService.getAppraisalData(params).toPromise();
    this.dataSource = response.Data;
    this.itemsCount = response.RecordsCount;
  }

  pageChange(event) {
    this.bodyData.PageNumber = event.currentPage;
    this.bodyData.PageSize = event.pageSize;
    this.getDataSource(this.bodyData);
  }

  bindColumnFilterDdl(item) {
    let type = '';
    if (item.colData.dataType === 'Date') {
      type = 'DateEditBox';
    }
    const FilterData = this.columnFilter.GetFilterByDataType(type); // Calling Function to get ColumnFilter Condition data
    if (FilterData.length === 0) { // Check if Array is empty then call API for options data
    } else {
      this.headerMap.config.header.columnFilter['colData_' + item.colIndex] = FilterData;
    }
  }

  actionClick(event: any) {
    switch (event.action) {
      case 'Filter_Header':
        this.bindColumnFilterDdl(event);
        break;
      case 'Filter_Click':
        let filter: any = {};
        filter = {
          GridConditions: [],
          DataField: event.colData.objectKey,
          LogicalOperator: event.filterData.logicalOpt.Value === 'Select...' ? '' : event.filterData.logicalOpt.Value,
          FilterType: 'Column_Filter'
        };
        if (event.filterData.filterValue1 && event.filterData.filterValue1 !== '') {
          if (event.colData.dataType === 'Date') {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: this.transformDate(event.filterData.filterValue1)
            });
          } else {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt1.Value,
              ConditionValue: event.filterData.filterValue1
            });
          }
        }
        if (event.filterData.filterValue2 && event.filterData.filterValue2 !== '') {
          if (event.colData.dataType === 'Date') {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: this.transformDate(event.filterData.filterValue2)
            });
          } else {
            filter.GridConditions.push({
              Condition: event.filterData.ConditionOpt2.Value,
              ConditionValue: event.filterData.filterValue2
            });
          }
        }
        if (filter && Object.keys(filter).length !== 0) {
          this.filters['Column_Filter~$~' + event.colData.objectKey] = filter;
        }
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
      case 'asc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'asc';
        this.getDataSource(this.bodyData);
        break;
      case 'desc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'desc';
        this.getDataSource(this.bodyData);
        break;
      case 'Remove Sort':
        this.bodyData.SortColumn = '-1';
        this.bodyData.SortOrder = 'desc';
        this.getDataSource(this.bodyData);
        break;
      case 'FilterClear_Click':
        delete this.filters['Column_Filter~$~' + event.colData.objectKey];
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
      case 'Link':
        this.openBaleDetailModal.emit({baleId: this.dataSource[event.rowIndex].FolioUniqueId, isUnsoldBale: true});
        break;
    }
  }

  saveExportFile(FileData: any) {
    const curDate = new Date();
    let fileName = '';
    fileName = sessionStorage.AppName
        + '_' + 'Appraisal'
        + '_' + (curDate.getMonth() + 1).toString()
        + '_' + curDate.getDate()
        + '_' + curDate.getFullYear()
        + '_' + curDate.getHours()
        + '_' + curDate.getMinutes()
        + '_' + curDate.getSeconds()
        + '.xlsx';
    saveAs(FileData, fileName);
  }

  getExcelData() {
    const bodyData = {
      PageSize: -1,
      PageNumber: -1,
      SortColumn: 'AppraisalID',
      SortOrder: 'desc',
      GridFilters: []
    };
    Object.keys(this.filters).forEach(key => {
      bodyData.GridFilters.push(this.filters[key]);
    });
    this.apiESaleyardService.postGetFile('awhwool/ExportToExcelAppraisal', bodyData, 'blob')
      .subscribe(
        (resultBlob: Blob) => {
          this.saveExportFile(resultBlob);
        }
      );
  }

}
