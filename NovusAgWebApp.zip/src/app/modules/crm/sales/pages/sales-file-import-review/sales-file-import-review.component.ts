import { Component, OnInit, ViewChild, OnDestroy } from '@angular/core';
import { Location } from '@angular/common';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { UpdateAliasDataModalComponent } from '../../components/update-alias-data-modal/update-alias-data-modal.component';
import { SalesService } from '../../services/sales.service';
import { AuthenticationService, ApplicationService } from '@app/core';
import { IHeaderMap } from '@app/core/models/plasmaGridInterface';
import { Router, ActivatedRoute } from '@angular/router';
import { MessageComponent } from '@app/shared/components/message';
import { UserDetail } from '@app/core/models/user-detail';

@Component({
  selector: 'app-sales-file-import-review',
  templateUrl: './sales-file-import-review.component.html',
  styleUrls: ['./sales-file-import-review.component.scss']
})
export class SalesFileImportReviewComponent implements OnInit, OnDestroy {

  msgList = [];
  currentUser: any;
  dataSource: any;
  EditColumnList: string[];
  submitData: any;
  itemsCount: number;
  TotalDetails: any;
  transactionId: any;
  pageNum: any;
  processName: any;
  errorMsg: any;
  file: any;
  isAllRecords = true;

  constructor(
    private location: Location,
    private modalService: NgbModal,
    private salesService: SalesService,
    private authenticationService: AuthenticationService,
    private appservice: ApplicationService,
    private route: ActivatedRoute,
    private router: Router,
    private userDetail: UserDetail
  ) { }

  bodyData = {
    PageSize: 10,
    PageNumber: 1,
    SortColumn: '-1',
    SortOrder: 'desc'
  };

  ngOnInit() {
    if (!sessionStorage.getItem('currentSaleYardName')) {
      sessionStorage.setItem('currentSaleYardName', this.salesService.currentSaleYardName);
    } else {
      this.salesService.currentSaleYardName = sessionStorage.getItem('currentSaleYardName');
    }
    if (!sessionStorage.getItem('submitDataForCreateSale')) {
      sessionStorage.setItem('submitDataForCreateSale', JSON.stringify(this.salesService.submitDataForCreateSale));
    } else {
      this.salesService.submitDataForCreateSale = JSON.parse(sessionStorage.getItem('submitDataForCreateSale'));
    }
    this.currentUser = this.userDetail;
    this.route.paramMap.subscribe(params => {
      this.transactionId = params.get('id');
    });

    this.bindLotData(this.bodyData, true, false);
    this.EditColumnList = ['BreedAlias', 'ProductAlias', 'VendorAlias', 'BuyerAlias','Quantity','Weight', 
                            'Turnover','Vendor_PIC','Paintmark','Buyer_PIC','InvoiceRef','CarrierSap'];
    }

  HeaderMap: IHeaderMap = {
    config: {
      header: {
        columns: [
          {
            objectKey: 'ID',
            displayName: 'ID',
            width: '4%'
          },
          {
            objectKey: 'Lot_Number',
            displayName: 'Lot No.',
            width: '4%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          }, {
            objectKey: 'BreedAlias',
            displayName: 'Breed Alias',
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          }, {
            objectKey: 'Breed',
            displayName: 'Breed',
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'

          }, {
            objectKey: 'ProductAlias',
            displayName: 'Product Alias',            
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          }, {
            objectKey: 'Product',
            displayName: 'Product',            
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          }, {
            objectKey: 'Weight',
            displayName: 'Weight',
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'

          }, 
          {
            objectKey: 'Quantity',
            displayName: 'Qty',
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          },
          {
            objectKey: 'Turnover',
            displayName: 'Turnover',
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          },
          // {
          //   objectKey: 'Price',
          //   displayName: 'Price',
          //   width: '5%',
          //   dataType: 'TextWithColor',
          //   Color: 'Red',
          //   CompareColumn: 'Status',
          //   Condition: 'equal',
          //   CompareValue: '0'
          // }, 
          {
            objectKey: 'CKG',
            displayName: 'C/KG',            
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          }, {
            objectKey: 'DKG',
            displayName: '$/Head',
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          },           
          {
            objectKey: 'VendorAlias',
            displayName: 'Vendor Alias',            
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          }, {
            objectKey: 'Vendor',
            displayName: 'Vendor',            
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          }, {
            objectKey: 'BuyerAlias',
            displayName: 'Buyer Alias',            
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          }, {
            objectKey: 'Buyer',
            displayName: 'Buyer',            
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          }, {
            objectKey: 'Vendor_PIC',
            displayName: 'Vendor PIC',            
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          }, 
          // {
          //   objectKey: 'HGP',
          //   displayName: 'HGP',            
          //   width: '4%'
          // }, 
          // {
          //   objectKey: 'Paintmark',
          //   displayName: 'Paintmark',            
          //   width: '4%'
          // },
          {
            objectKey: 'AccSaleRef',
            displayName: 'Acct Sale Ref',            
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          }, {
             objectKey: 'Paintmark',
             displayName: 'Paintmark',            
             width: '5%',
             dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
           }, {
             objectKey: 'Buyer_PIC',
             displayName: 'Buyer PIC',            
             width: '5%',
             dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
           }, 
          //  {
          //   objectKey: 'ItemDesc',
          //   displayName: 'Item Description',           
          //   width: '5%',
          //   dataType: 'TextWithColor',
          //   Color: 'Red',
          //   CompareColumn: 'Status',
          //   Condition: 'equal',
          //   CompareValue: '0'
          // },
           {
            objectKey: 'InvoiceRef',
            displayName: 'Invoice Reference',            
            width: '5%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          }, {
            objectKey: 'CarrierSap',
            displayName: 'Carrier Sap#',            
            width: '4%',
            dataType: 'TextWithColor',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          }, 
          // {
          //   objectKey: 'UserId',
          //   displayName: 'UserId',            
          //   width: '4%'
          // }, 
          {
            objectKey: 'Status',
            displayName: 'Status',            
            width: '4%',
            dataType: 'ColorCodeStatus',
            Color: 'Red',
            CompareColumn: 'Status',
            Condition: 'equal',
            CompareValue: '0'
          }
        ],
        action: {
          Edit: true,
          Save: true,
          Cancel: true,
          Delete: false,
          Checkbox: false,
          Placement: 'IsExternalShow',          
          DropDown: false
        },
        columnFilter: []
      },
      paging: true
    }
  };

  private bindLotData(bodyData, isOnValidate, isErrorRecords) {        
    this.salesService.GetImportLotData(this.currentUser.UserName, isOnValidate?'1':'0', isErrorRecords?'1':'0', bodyData).subscribe(x => { 
      x.ContentList.map(x => {
        x.Weight = x.Weight === '0.00' ? '0' : x.Weight;
      });
      this.dataSource = x.ContentList;
      this.itemsCount = x.RecordsCount;
      this.TotalDetails = x.TotalDetails;
      if(isOnValidate)
        this.msgList = x.ListMessages;
    },
      err => {
        console.log(err);
      });
  }

  get_all_records() {
    this.isAllRecords=true;
    this.bindLotData(this.bodyData, false, false);
  
  }

  get_error_records() {
    this.isAllRecords=false;
    this.bindLotData(this.bodyData, false, true);
  }

  open_alias_data_modal() {
    const modalRef = this.modalService.open(UpdateAliasDataModalComponent, { size: 'lg', backdrop: 'static', keyboard: false });
    const modalInstance: UpdateAliasDataModalComponent = modalRef.componentInstance;
    modalRef.result.then(async (result) => {
      if (result) {
      }
      }, (reason) => {
      }
    );
  }

  go_back() {
    // this.showErrorMessage('Are you sure you want to go back?', 'Warrning', 'Yes',
    //   this.redirectionConfirmation, false, true, true, 'would you like to proceed?');
    this.salesService.DeleteLotimport(this.currentUser.UserName, this.salesService.currentSaleYardName).subscribe(x => {
      this.location.back();
    });

  }

  Validate_records() {
    // this.salesService.ValidateImportLotData(this.currentUser.UserName).subscribe(x => {

    //   if (x.ListMessages.length > 0) {
    //     this.msgList = x.ListMessages;
    //   }
    //   this.bindLotData(this.bodyData, false, false);
    // },
    //   err => {
    //     console.log(err);
    //   });
    this.bindLotData(this.bodyData, true, false);
  }

  actionClick(event) {    
    switch (event.action) {      
      case 'Save':
        let IdentifierID = this.dataSource[event.rowIndex].ID;
        let breedAlias = this.dataSource[event.rowIndex].BreedAlias;
        let productAlias = this.dataSource[event.rowIndex].ProductAlias;
        let vendorAlias = this.dataSource[event.rowIndex].VendorAlias;
        let buyerAlias = this.dataSource[event.rowIndex].BuyerAlias;

        let qty = this.dataSource[event.rowIndex].Quantity;
        let width = this.dataSource[event.rowIndex].Weight;        
        let price = this.dataSource[event.rowIndex].Price;
        let turnover = this.dataSource[event.rowIndex].Turnover;
        let vendor_PIC = this.dataSource[event.rowIndex].Vendor_PIC;        
        let paintmark = this.dataSource[event.rowIndex].Paintmark;
        let buyer_PIC = this.dataSource[event.rowIndex].Buyer_PIC;        
        let invoiceRef = this.dataSource[event.rowIndex].InvoiceRef;
        let carrierSap = this.dataSource[event.rowIndex].CarrierSap;        

        this.submitData = {
          ID: IdentifierID,
          BreedAlias: breedAlias,
          ProductAlias: productAlias,
          VendorAlias: vendorAlias,
          BuyerAlias: buyerAlias,
          Quantity: qty,
          Weight: width,          
          Price: price,
          Turnover: turnover,
          Vendor_PIC: vendor_PIC,          
          Paintmark: paintmark,
          Buyer_PIC: buyer_PIC,          
          InvoiceRef: invoiceRef,
          CarrierSap: carrierSap,
          SaleTransactionId: this.transactionId
        };
        
        this.salesService.SaveImportLotData(this.currentUser.UserName, this.submitData).subscribe(res => {
          if(res){
            this.bindLotData(this.bodyData, false, false);
          }
        }, err=>{
          console.log(err);
        });
        
        break;
    }    
  }

  pageChange(event) {

    this.bodyData.PageNumber = event.currentPage;
    this.bodyData.PageSize = event.pageSize;
    this.bindLotData(this.bodyData, false, false);
  }

  createSale() {
    const dataSource = this.salesService.submitDataForCreateSale;
    const submitData = dataSource.submitData;
    this.processName = dataSource.submitData.ProcessName;
    const conjunctionalAgentsData = dataSource.conjunctionalAgentsData;
    this.file = dataSource.file;
    var UserId = this.salesService.submitDataForCreateSale.UserId;
    if (dataSource != undefined && submitData != undefined) {
      this.appservice.insertApplication(submitData).subscribe(async response => {
        this.transactionId = response.result.transactionId;
        if (conjunctionalAgentsData.length) {
          await this.saveConjunctionalAgent(conjunctionalAgentsData);
        }
        //this.upload(this.processName, UserId, submitData.Data[0]["DMOCRM_HeaderInf_Saleyard"].toString());        
        this.salesService.submitDataForCreateSale = null;
        this.salesService.CreateSalesLotTableData(this.currentUser.UserName, this.processName, this.transactionId).subscribe(Result => {
          this.router.navigate(['/crm/sales', this.transactionId]);
        }, error => {
          console.log(error);
        });
      });
      //this.transactionId = "foZgMdhj9kVkpV3@TGE8Ew==";
    }
  }

  async saveConjunctionalAgent(conjunctionlAgents: any) {
    try {
      for (const item of conjunctionlAgents) {
        if (item.agentid !== '' && item.agentid != null &&
          item.dmocrmconjagntrate !== '' && item.dmocrmconjagntrate != null) {
          const body = {
            SaleTransactionID: this.transactionId,
            AgentCode: item.agentid,
            Rate: item.dmocrmconjagntrate
          };
          await this.salesService.saveConjunctionalAgent(body).toPromise();
        }
      }
    } catch (err) {
      console.log(err);
    }
  }

  upload(processName: string, userId: string, saleyardName: string) {
    const file=this.file;
    if (file === null) {
      this.errorMsg = 'Please select file';
      return;
    }
    this.errorMsg = '';
    const formData = new FormData();
    formData.append('uploadFile', file);

    this.salesService.ImportFileData(processName, userId, saleyardName, formData).subscribe(Result => {
      if (Result.status === 'Success') {
        file === null;
      }
    }, error => { console.log(error); });
  }

  /* ---------------------Open Confirmation Popup-------------- */
  // showErrorMessage(ErrorMsg: string, HeaderMsg: string, buttonText: string, callback: any, IsDelete: boolean,
  //   IsDefaultView: boolean, IsConfirmation: boolean, confirmationText: string) {
  //   const modalMsgRef = this.modalService.open(MessageComponent, { backdrop: 'static', windowClass: 'Confirm_popup' });
  //   const modalInstance: MessageComponent = modalMsgRef.componentInstance;
  //   modalInstance.Message = ErrorMsg;
  //   modalInstance.ButtonText = buttonText;
  //   modalInstance.MessageHeader = HeaderMsg;
  //   modalInstance.MessagePopup = modalMsgRef;
  //   modalInstance.IsConfirmation = IsConfirmation;
  //   modalInstance.CallBackMethod = callback;
  //   modalInstance.Caller = this;
  //   modalInstance.IsDelete = IsDelete;
  //   modalInstance.IsDefaultView = IsDefaultView;
  //   modalInstance.ConfirmationText = confirmationText;
  // }
  redirectionConfirmation(modelRef: NgbModalRef, Caller: SalesFileImportReviewComponent) {
    Caller.salesService.DeleteLotimport(Caller.currentUser.UserName, Caller.salesService.currentSaleYardName).subscribe(x => {
      Caller.location.back();
    });
  }
  ngOnDestroy() {
    sessionStorage.removeItem('currentSaleYardName');
    sessionStorage.removeItem('submitDataForCreateSale');
  }
}
