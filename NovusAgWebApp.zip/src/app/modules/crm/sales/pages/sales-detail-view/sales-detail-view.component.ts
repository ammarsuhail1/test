import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Title } from '@angular/platform-browser';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';

import {
  AuthenticationService,
  FormViewService,
  ApplicationService,
  ListviewService,
  MessageService,
  DmoControlService,
  SaleStage
} from '@app/core';

import { SalesFormViewModalComponent } from '../../components/sales-form-view-modal/sales-form-view-modal.component';
import { LotsGridViewComponent } from '../../../lots/pages/lots-grid-view/lots-grid-view.component';
import { SalesDocumentsComponent } from '../../components/sales-documents/sales-documents.component';
import { environment } from '@env/environment';
import { LotSearchService } from '@app/modules/crm/lots/services/lot-search.service';
import { SalesService } from '../../services/sales.service';
import { UserDetail } from '@app/core/models/user-detail';

@Component({
  selector: 'app-sales-detail-view',
  templateUrl: './sales-detail-view.component.html',
  styleUrls: ['./sales-detail-view.component.scss']
})
export class SalesDetailViewComponent implements OnInit {
  @ViewChild(LotsGridViewComponent, { static: false })
  private lotsGridViewComponent: LotsGridViewComponent;

  @ViewChild(SalesDocumentsComponent, { static: false })
  private salesDocumentsComponent: SalesDocumentsComponent;

  dateFormat: string = environment.Setting.dateFormat;
  currentUser: any;
  transactionId: string;
  processName: string;
  stages: any = [];
  currentStage: SaleStage;
  headerInformations: any = {};
  applicationData: any = {};
  BMJSON: any = {};
  alertMessage: string;
  IsLot = false;
  HeaderInformation: any = {};
  stageName: string;

  isFinalised = false;
  isReversalProcess = false;
  isReversalCompleted = false;
  isInvoiceSaleBtnVisible = false;
  isFinaliseBtnVisible = false;
  isDelBtnActivated = false;

  get selectedRecords() {
    return this.lotsGridViewComponent.SelectedRecordIds;
  }

  get lotsData() {
    return this.lotsGridViewComponent.cachedData;
  }

  get lotKeyColumn() {
    return this.lotsGridViewComponent.keyColumn;
  }

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    public location: Location,
    private modalService: NgbModal,
    private formViewService: FormViewService,
    private applicationService: ApplicationService,
    private listviewService: ListviewService,
    private lotsearchService: LotSearchService,
    private authenticationService: AuthenticationService,
    private msg: MessageService,
    private titleService: Title,
    private dmoControlService: DmoControlService,
    private saleservice: SalesService,
    private toastr: ToastrService,
    private userDetail: UserDetail
  ) { }

  ngOnInit() {
    this.currentUser = this.userDetail;
    sessionStorage.setItem('AppName', 'LMKLivestockSales');
    sessionStorage.setItem('DisplayName', 'Livestock Sales');
    this.processName = sessionStorage.getItem('AppName');
    this.route.paramMap.subscribe(params => {
      this.transactionId = params.get('id');

      this.formViewService.getBmWfJson(this.processName, 'AdminView', this.transactionId).subscribe(response => {
        this.BMJSON = response.BM.BusinessModelObjectGroup.AdminView;
        this.applicationService.getApplicationData(null, null, 'AdminView', this.transactionId).subscribe(applicationData => {
          this.applicationData = applicationData;
          // get stages
          this.get_stages();
          // get header informations
          this.get_header_informations();
        }
        );
      }
      );

    });
    if (sessionStorage.getItem('DisplayName')) {
      const processtitle = sessionStorage.getItem('DisplayName');
      this.titleService.setTitle(`${environment.projectTitle} | ${processtitle}`);
    }
  }

  isDate(value: string) {
    const regex = /([0-9]){1,2}\/([0-9]{2})\/([0-9]){4}/;
    return value.match(regex);
  }

  show_delete_msg() {
    // Set modal popup configuration
    // const modalMsgRef = this.modalService.open(MessageComponent, { backdrop: 'static', windowClass: 'Confirm_popup' });
    // const modalInstance: MessageComponent = modalMsgRef.componentInstance;
    // modalInstance.MessagePopup = modalMsgRef;
    // modalInstance.IsConfirmation = true;
    // modalInstance.Caller = this;
    // modalInstance.ConfirmationText = 'Yes, delete this sale.';
    // modalInstance.IsDelete = true;
    // modalInstance.IsConfirmation = true;
    // modalInstance.MessageHeader = 'Delete Sale Record';
    // modalInstance.Message = 'Are you sure you want to delete this sale?';
    // modalInstance.ButtonText = 'Confirm Delete';
    // modalInstance.CallBackMethod = this.deleteSelectedConfirmation;
    this.msg.showMessage('Warning', {
      header: 'Delete Sale Record',
      body: 'Are you sure you want to delete this sale?',
      btnText: 'Confirm Delete',
      checkboxText: 'Yes, delete this sale',
      isDelete: true,
      callback: this.deleteSelectedConfirmation,
      caller: this,
    })
  }

  deleteSelectedConfirmation(modelRef: NgbModalRef, Caller: SalesDetailViewComponent) {
    Caller.listviewService.deleteGridData(Caller.transactionId).subscribe(data => {
      Caller.router.navigate(['/crm/sales']);
    });
  }

  edit_sale_header() {
    const modalRef = this.modalService.open(SalesFormViewModalComponent, { size: 'lg', backdrop: 'static', keyboard: false });
    const modalInstance: SalesFormViewModalComponent = modalRef.componentInstance;
    modalInstance.data = this.applicationData;
    modalInstance.transactionId = this.transactionId;
    modalInstance.stage = this.currentStage;
    modalRef.result.then((result: boolean) => {
      if (result) {
        this.applicationService.getApplicationData(null, null, 'AdminView', this.transactionId).subscribe(applicationData => {
          this.applicationData = applicationData;
          this.get_header_informations();
        });
      }
    }, (reason) => {
    }
    );
  }

  save_record() {
    this.lotsGridViewComponent.triggerSave();
  }

  get_stages() {
    this.listviewService.stageList(this.processName).subscribe(data => {
      this.stages = data;
      if (this.applicationData.DataInformation.dmgcrmheaderinfosalerev &&
        this.applicationData.DataInformation.dmgcrmheaderinfosalerev.DMOVAL != null &&
        this.applicationData.DataInformation.dmgcrmheaderinfosalerev.DMOVAL !== '') {
        if (this.applicationData.ApplicationInfo[0].StageFriendlyName === SaleStage.Inprocess) {
          this.currentStage = SaleStage.ReversalProcess;
        } else if (this.applicationData.ApplicationInfo[0].StageFriendlyName === SaleStage.Finalised) {
          this.currentStage = SaleStage.ReversalCompleted;
        }
      } else {
        this.currentStage = this.applicationData.ApplicationInfo[0].StageFriendlyName;
        this.stages.forEach(stage => {
          if (stage.GUID === this.applicationData.ApplicationInfo[0].StagGuid) {
            stage.active = true;
          }
        });
      }

      this.check_btns_status();
    });

  }

  check_btns_status() {
    this.isFinalised = this.currentStage === SaleStage.Finalised;
    this.isReversalProcess = this.currentStage === SaleStage.ReversalProcess;
    this.isReversalCompleted = this.currentStage === SaleStage.ReversalCompleted;
    this.isInvoiceSaleBtnVisible = this.currentStage === SaleStage.Inprocess;
    this.isFinaliseBtnVisible = this.currentStage === SaleStage.Inprocess || this.currentStage === SaleStage.Invoiced;
    this.isDelBtnActivated = this.currentStage === SaleStage.Inprocess;
  }

  update_stage(stageName: SaleStage) {
    this.stageName = stageName;
    if (this.stageName === SaleStage.ReversalCompleted) {
      this.msg.showMessage('Warning', {
        body: 'Are you sure you want to complete the reversal for this sale?',
        btnText: 'Yes',
        isConfirmation: true,
        isDelete: false,
        callback: this.complete_reversal,
        caller: this,
      });
    } else if (stageName === SaleStage.Invoiced) {
      this.msg.showMessage('Warning', {
        body: 'Are you sure you want to invoice this sale?',
        btnText: 'Yes',
        isConfirmation: true,
        callback: this.confirme_update_stage,
        caller: this,
      });
    } else if (stageName === SaleStage.Finalised) {
      this.msg.showMessage('Warning', {
        body: 'Are you sure you want to finalise this sale?',
        btnText: 'Yes',
        isConfirmation: true,
        callback: this.confirme_update_stage,
        caller: this,
      });
    }
  }
  confirme_update_stage(modelRef: NgbModalRef, Caller: SalesDetailViewComponent) {
    Caller.lotsearchService.getsaleStageData(Caller.transactionId).subscribe(
      async result => {
        if (result.Count > 0) {
          const params: any = {
            Identifier: {
              Name: null,
              Value: null,
              TrnsctnID: Caller.transactionId
            },
            ProcessName: Caller.processName,
            UserName: Caller.currentUser.UserName,
            Data: [{}]
          };
          if (Caller.stageName === SaleStage.Invoiced && result.LotStatus == false) {
            await Caller.saleservice.invoiceReport(Caller.transactionId).toPromise();
            params.TriggerName = 'TRGR_PreProcessing_InvoiceSale';
            Caller.IsLot = true;
          } else if (Caller.stageName === SaleStage.Finalised && result.LotStatus == false) {
            await Caller.saleservice.finalizeReport(Caller.transactionId).toPromise();
            Caller.IsLot = true;
            const loginUser = this.userDetail;
            params.Data = [{ DMOCRMHIFinalizeDate: Caller.saleservice.getCurrentDateTime(loginUser.TimeZone) }]
            if (Caller.currentStage === SaleStage.Inprocess) {
              params.TriggerName = 'TRGR_PreProcessing_FinaliseSale';
            } else if (Caller.currentStage === SaleStage.Invoiced) {
              params.TriggerName = 'TRGR_Invoiced_FinaliseSale';
            }
          }
          if (Caller.IsLot === true) {
            Caller.applicationService.updateApplication(params).subscribe(response => {
              Caller.applicationService.getApplicationData(null, null, 'AdminView', Caller.transactionId).subscribe(applicationData => {
                Caller.applicationData = applicationData;
                Caller.currentStage = Caller.applicationData.ApplicationInfo[0].StageFriendlyName;

                Caller.stages.forEach(stage => {
                  stage.active = false;
                  if (stage.GUID === Caller.applicationData.ApplicationInfo[0].StagGuid) {
                    stage.active = true;
                  }
                });

                Caller.check_btns_status();
              });
            });
            Caller.IsLot = false;
          } else {
            Caller.msg.showMessage('Warning', { body: 'All lot should be completed in this sale' });
          }
        } else {
          Caller.msg.showMessage('Warning', { body: 'This sale should have at least one lot' });
        }
      });
  }

  complete_reversal(modelRef: NgbModalRef, Caller: SalesDetailViewComponent) {
    const loginUser = this.userDetail;

    const submitData: any = {
      Identifier: {
        Name: null,
        Value: null,
        TrnsctnID: Caller.transactionId
      },
      ProcessName: Caller.processName,
      TriggerName: 'TRG_PreProcessing_Revers',
      UserName: Caller.currentUser.UserName,
      Data: [{}]
    };
    submitData.Data = [{ DMOCRMHIFinalizeDate: Caller.saleservice.getCurrentDateTime(loginUser.TimeZone) }]
    Caller.applicationService.updateApplication(submitData).subscribe(res => {
      Caller.saleservice.confirmReversal(Caller.transactionId).subscribe(
        async result => {
          await Caller.saleservice.completeReversal(Caller.transactionId).toPromise();
          Caller.applicationService.getApplicationData(null, null, 'AdminView', Caller.transactionId).subscribe(applicationData => {
            Caller.applicationData = applicationData;
            Caller.currentStage = SaleStage.ReversalCompleted;
            Caller.check_btns_status();
            Caller.lotsGridViewComponent.SelectedRecordIds = [];
            Caller.lotsGridViewComponent.selectedAll = false;
            Caller.lotsGridViewComponent.getGridData();
          });
        });
    });
  }

  get_header_informations() {
    this.BMJSON.List.forEach(bmoGuid => {
      this.BMJSON.BusinessModelObjects[bmoGuid].List.forEach(dmogGuid => {
        if (this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].DisplayName === 'Header Information') {
          this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].List.forEach(rowID => {
            this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].Rows[rowID].Columns.forEach(objCOLUMN => {
              objCOLUMN.List.forEach(dmoGUID => {
                if (this.applicationData.DataInformation[dmoGUID]) {
                  this.headerInformations[objCOLUMN.DataModelObjects[dmoGUID].Name] = {
                    DisplayName: objCOLUMN.DataModelObjects[dmoGUID].DisplayName,
                    DMOVAL: this.applicationData.DataInformation[dmoGUID].DMOVAL.toString().indexOf('~~~') > -1 ?
                      this.applicationData.DataInformation[dmoGUID].DMOVAL.split('~~~')[1] :
                      this.applicationData.DataInformation[dmoGUID].DMOVAL
                  };
                }
              });
            });
          });
        }
      });
    });

    if (this.headerInformations['DMOCRM_HeaderInf_SaleDate'] && this.headerInformations['DMOCRM_HeaderInf_SaleDate'].DMOVAL) {
      this.saleservice.SaleDate = this.headerInformations.DMOCRM_HeaderInf_SaleDate.DMOVAL;
    }
  }

  go_back() {
    if (this.lotsGridViewComponent.IsAddNewRow === true || this.lotsGridViewComponent.tableData.filter(rowItem => rowItem.isEdit).length) {
      this.msg.showMessage('Warning', {
        header: 'Confirmation Message',
        body: 'There is unsaved data prior to directing them to the Livestock Sales data grid',
        btnText: 'Yes',
        isConfirmation: true,
        callback: this.homeRedirectionConfirmation,
        caller: this,
      })
    } else {
      this.router.navigate(['/crm/sales']);
    }

  }

  homeRedirectionConfirmation(modelRef: NgbModalRef, Caller: SalesDetailViewComponent) {
    Caller.router.navigate(['/crm/sales']);
  }

  ReverseSalePopup(ReverseSaleModel) {
    if (this.selectedRecords.length > 0) {
      for (const id of this.selectedRecords) {
        const selectedLot = this.lotsData.filter(item => item[this.lotKeyColumn] === id)[0];
        if (selectedLot.dmolotlotinfostatus === 'skyblue') {
          this.msg.showMessage('Warning', { body: 'The selected lot(s) cannot be reversed' });
          // this.msg.showErrorMessage('The selected lot(s) cannot be reversed', 'Message', 'Ok', null, false, true, false, '');
          return false;
        }
      }
      this.modalService.open(ReverseSaleModel, { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false, size: 'lg' });
    }
  }

  ReverseSale(formvalue: any) {
    this.dmoControlService.GetPlasmaId('DMOCRM_HeaderInf_SaleID').subscribe(res1 => {
      const body = {
        transactionID: this.transactionId,
        saleId: res1.PlasmaID,
        saleReversalType: formvalue.ReverseType
      };
      this.saleservice.createDuplicateSale(body).subscribe(res2 => {
        if (res2.status === 'success') {
          this.saleservice.copyLots(this.transactionId, res2.transactionID, this.selectedRecords.toString()).subscribe(res3 => {
            this.modalService.dismissAll();
            this.lotsGridViewComponent._bodyData.ParentTransactionId = res2.transactionID;
            this.lotsGridViewComponent._bodyData.PageNumber = 0;
            this.lotsGridViewComponent.SelectedRecordIds = [];
            this.lotsGridViewComponent.selectedAll = false;
            this.lotsGridViewComponent.getGridData();
            this.router.navigate(['/crm/sales', res2.transactionID]);
          });
        } else {
          this.toastr.error('There is an error!');
          this.modalService.dismissAll();
        }
      });
    });
  }
  public textSepratorHover(data, separator) {
    if (data) {
      const ar = data.split(separator);
      if (ar.length > 1) {
        return ar;
      }
      return data;
    }
  }
}

