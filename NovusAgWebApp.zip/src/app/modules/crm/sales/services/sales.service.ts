import { Injectable, EventEmitter, Output } from '@angular/core';
import { ApiLmkService } from '@app/core/services/api-lmk.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, forkJoin } from 'rxjs';
import { environment } from '@env/environment';
import { formatDate } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class SalesService {
  endpoint = environment.Setting.ProjectApiUrl;
  currentSaleYardName = '';
  currentSaleYardValue = '';
  submitDataForCreateSale: any;
  SaleDate: string;
  @Output() vendor: EventEmitter<string> = new EventEmitter();
  LotGuids: any[];
  //endpoint = 'http://localhost:49767/api';
  constructor(private http: HttpClient,private lmkservice: ApiLmkService) {
    this.LotGuids = ['dmolotvinfovendorpic', 'dmolotbinfobuyerid', 'dmolotbinfobuyername', 'dmolotbinfobuyerpic', 'dmolotbinfoinvoiceref', 'dmolotlotinfosalenum',
  'dmolotlotinfoqnty', 'dmolotlotinfoprod', 'dmolotlotinfodesc', 'dmolotlotinfopricephd', 'dmolotlotinfopricecpkg', 'dmolotlotinfowtkg'];
  }

  ImportFileData(processName: string, userId: string, saleyardName: string, formData: FormData): Observable<any> {
    let url = 'crmlot/importlotfiles';
    const accessToken = localStorage.getItem('AccessToken');
    const headers = new HttpHeaders({ accessToken: accessToken, processName: processName, userId: userId, saleyardCode: saleyardName });
    return this.http.post<any>(`${this.endpoint}/${url}`, formData, { headers: headers });
  }

  GetImportLotData(userName: string, isOnValidate: string, isErrorRecords: string, modelData:any) {
    
    let url = 'crmlot/getimportlotdata';
    const accessToken = localStorage.getItem('AccessToken');
    const headers = new HttpHeaders({ accessToken: accessToken, userName: userName, isOnValidate: isOnValidate, isErrorRecords: isErrorRecords});
    return this.http.post<any>(`${this.endpoint}/${url}`, modelData, { headers });
  }

  ValidateImportLotData(userName: string): Observable<any> {

    let url = 'crmlot/validatelottableData';
    const accessToken = localStorage.getItem('AccessToken');
    const headers = new HttpHeaders({ accessToken: accessToken, userName: userName });
    return this.http.get(`${this.endpoint}/${url}`, { headers });
  }

  SaveImportLotData(userName: string, data: any) : Observable<any>{
      let url = 'crmlot/updatelottabledata';
      const accessToken = localStorage.getItem('AccessToken');
      const headers = new HttpHeaders({ accessToken: accessToken, userName: userName });
      return this.http.post<any>(`${this.endpoint}/${url}`, data, { headers });
  }

  CreateSalesLotTableData(userName: string, processName: string, parentTrnsctnId: string){
    let url = 'crmlot/createsaleslottabledata';
    const accessToken = localStorage.getItem('AccessToken');
    const headers = new HttpHeaders({ accessToken: accessToken, userName: userName, processName: processName, parentTrnsctnId: parentTrnsctnId });
    return this.http.get(`${this.endpoint}/${url}`, { headers });
  }

  getAlias(body) {
    return this.lmkservice.post('crmlot/getalias', body);
  }
  DeleteLotimport(username: string, saleyardname: string) {
    const url = 'crmlot/deleteimportlotdata';
    const accesstoken = localStorage.getItem('AccessToken');
    const headers = new HttpHeaders({ accessToken: accesstoken, userName: username, saleyardName: saleyardname });
    return this.http.post<any>(`${this.endpoint}/${url}`, null, { headers });
  }
    DownloadTemplateFile(){    
     let url = 'crmsales/downloadtemplatefile';
     let resultType:any = 'Blob';
     const accessToken = localStorage.getItem('AccessToken');
     const Headers = new HttpHeaders({ accessToken: accessToken });    
     return this.http.post<any>(`${this.endpoint}/${url}`, null, { headers: Headers, responseType: resultType });    
  }
  SaveCopyLotData(parentTrnFrom: string, parentTrnTo: string): Observable<any> {
    const url = 'crmsales/copyLots?transactionIdFrom=' + parentTrnFrom + '&transactionIdTo=' + parentTrnTo + '';
    const accesstoken = localStorage.getItem('AccessToken');
    const headers = new HttpHeaders({ accessToken: accesstoken });
    return this.http.post<any>(`${this.endpoint}/${url}`, null, { headers });
  }
  GridVendorTermsData(bodydata: any) {
    return this.lmkservice.post('crmsales/vendorTermsData', bodydata);
  }
  AddVendorTermsData(bodyData: any) {
    const vendorterm = this.lmkservice.post('crmsales/saveVendorTerms', bodyData);
    const buyerterm = this.lmkservice.post('crmsales/saveBuyerTerms', bodyData);
    return forkJoin([vendorterm, buyerterm]);
  }
  bindvendor(id: string) {
    this.vendor.emit(id);
  }
  UpdateVendorTerms(bodyData:any ) {
    return this.lmkservice.post('crmsales/updateVendorTerms', bodyData);
  }
  ResetLot(bodyData) {
    return this.lmkservice.post('crmlot/resetLotBuyerRebate', bodyData);
  }
  saveConjunctionalAgent(bodyData: any) {
    return this.lmkservice.post('crmsales/saveConjunctionalAgent', bodyData);
  }
  getConjunctionalAgent(transactionID: string) {
    return this.lmkservice.get('crmsales/getConjunctionalAgents?transactionID=' + transactionID);
  }
  deleteConjunctionalAgent(id: string) {
    return this.lmkservice.post('crmsales/deleteConjunctionalAgent?Id=' + id + '', null);
  }
  createDuplicateSale(body: any) {
    return this.lmkservice.post('crmsales/duplicateSale', body);
  }
  copyLots(transactionIdFrom: string, transactionIdTo: string, lotsTranId: string) {
    return this.lmkservice.post(`crmsales/copyLots?transactionIdFrom=${transactionIdFrom}&transactionIdTo=${transactionIdTo}&lotsTranId=${lotsTranId}`, null);
  }
  confirmReversal(transactionID: string) {
    return this.lmkservice.post(`crmsales/confirmReversal?transactionID=${transactionID}`);
  }
  isFutureDate(SaleDate: any, DueDate: any): boolean {
    SaleDate = new Date(SaleDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    SaleDate.setHours(0, 0, 0, 0);
    const dData = new Date(DueDate);
    return dData > SaleDate && dData > today;
  }

  invoiceReport(id: string) {
    return this.lmkservice.post(`report/invoiceReport?SaleTransactionID=${id}`);
  }

  finalizeReport(id: string) {
    return this.lmkservice.post(`report/finalizeReport?SaleTransactionID=${id}`);
  }
  completeReversal(id: string) {
    return this.lmkservice.post(`report/reverseReport?SaleTransactionID=${id}`);
  }
    isChangesOnLot(data: any[]) {
    return this.LotGuids.includes(data);
  }
  getCurrentDateTime(zone, value?, format = 'MM/dd/yyyy hh:mm:ss') {
    try {
      let d: any;
      if (value) {
        d = new Date(value); // val is in UTC
      } else {
        d = new Date(); // val is in UTC
      }
      const localOffset = zone * 60000;
      const localTime = d.getTime() - localOffset;
      d.setTime(localTime);
      return formatDate(d, format, 'en-US');
    } catch (error) {

      return '';
    }
  }
}