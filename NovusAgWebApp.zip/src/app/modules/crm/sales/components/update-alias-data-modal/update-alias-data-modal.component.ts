import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbActiveModal, NgbTypeaheadSelectItemEvent, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';

import { IHeaderMap, ApplicationService, AuthenticationService, DmoControlService, ColumnFilterService, MessageService } from '@app/core';
import { SalesFormViewModalComponent } from '../sales-form-view-modal/sales-form-view-modal.component';
import { LotSearchService } from '@app/modules/crm/lots/services/lot-search.service';
import { Observable } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
import { SalesService } from '../../services/sales.service';
import { MessageComponent } from '@app/shared';
import { UserDetail } from '@app/core/models/user-detail';

@Component({
  selector: 'app-update-alias-data-modal',
  templateUrl: './update-alias-data-modal.component.html',
  styleUrls: ['./update-alias-data-modal.component.scss']
})
export class UpdateAliasDataModalComponent implements OnInit {
  formValue: any;
  aliasForm: FormGroup;
  CustomersList: any;
  SAPNo: any;
  saleYardCode: any;
  currentUser: any;
  saleyardSapNo: any;
  transactionId: any;
  dmo = [];
  sname = 'Customer';
  sapno = 'Customer';
  filters: any = {};
  aliasHeaderMap: IHeaderMap = {
    config: {
      header: {
        columns: [
          {
            objectKey: 'Alias',
            displayName: 'Alias',
            width: '25%'
          },
          {
            objectKey: 'SName',
            displayName: this.sname + ' Name',
            width: '25%'
          },
          {
            objectKey: 'SapNo',
            displayName: this.sapno + ' ID',
            width: '23%'
          }
        ],
        action: {
          Delete: true
        },
        columnFilter: []
      },
      paging: false
    }
  };

  aliasDataSource: any = [];
  aliasItemsCount: number;
  aliasPageNum = -1;
  bodyData = {
    PageSize: 10,
    PageNumber: 1,
    SortColumn: '-1',
    SortOrder: 'desc',
    TimeZone: 0,
    saleyardCode: '',
    aliasName: '',
    aliasType: '',
    aliasCategoryName: '',
    GridFilters: []
  };

  constructor(
    public activeModal: NgbActiveModal,
    public lotSearchService: LotSearchService,
    private toastr: ToastrService,
    private authenticationService: AuthenticationService,
    public applicationService: ApplicationService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    public saleservice: SalesService,
    private dmoControlService: DmoControlService,
    private columnFilter: ColumnFilterService,
    private msg: MessageService,
    private userDetail: UserDetail
  ) {
  }

  ngOnInit() {
    this.aliasForm = this.fb.group({
      DMOSYAliases_SYASAliasTyp: ['Customer'],
      lookup_alias_alias: [null],
      lookup_alias_breed: [null],
      lookup_alias_customer: [null],
      lookup_alias_product: [null],
      DMOSYAliases_SYAAliasNo: [null],
      DMOSYAliases_SYAAliasRef: [null],
      DMOSYAliases_SYASaleyard: [null],
      DMOSYAliases_SYAPActFm: [null],
      DMOSYAliases_SYASActTo: [null]
    });


  }

  get f() { return this.aliasForm.controls; }

  capitalize(str1) {
    return str1.charAt(0).toUpperCase() + str1.slice(1);
  }


  actionClick(event) {
    switch (event.action) {
      case 'Filter_Header':
        this.bindColumnFilterDdl(event);
        break;
      case 'Filter_Click':
        if (!this.validate(event)) {
          break;
        }
        this.bodyData.PageNumber = 1;
        let filter: any = {};
        filter = {
          GridConditions: [
          ],
          DataField: event.colData.objectKey,
          LogicalOperator: event.filterData.logicalOpt.Value === 'Select...' ? '' : event.filterData.logicalOpt.Value,
          FilterType: 'Column_Filter'
        };
        if (event.filterData.filterValue1 && event.filterData.filterValue1 !== '') {
          filter.GridConditions.push({
            Condition: event.filterData.ConditionOpt1.Value,
            ConditionValue: event.filterData.filterValue1
          });
        }
        if (event.filterData.filterValue2 && event.filterData.filterValue2 !== '') {
          filter.GridConditions.push({
            Condition: event.filterData.ConditionOpt2.Value,
            ConditionValue: event.filterData.filterValue2
          });
        }
        if (filter && Object.keys(filter).length !== 0) {
          this.filters['Column_Filter~$~' + event.colData.objectKey] = filter;
        }
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
      case 'asc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'asc';
        this.getAliasListBasedOnAliasType();
        
        break;
      case 'desc':
        this.bodyData.SortColumn = event.colData.objectKey;
        this.bodyData.SortOrder = 'desc';
        
        this.getAliasListBasedOnAliasType();
        break;
      case 'Remove Sort':
        this.bodyData.SortColumn = '-1';
        this.bodyData.SortOrder = 'desc';
        this.getAliasListBasedOnAliasType();
        break;
      case 'Delete':
        this.applicationService.deleteGridData(this.aliasDataSource[event.rowIndex].TRNSCTNID).subscribe(x => {
          this.getAliasListBasedOnAliasType();
        });
        break;
      case 'FilterClear_Click':
        delete this.filters['Column_Filter~$~' + event.colData.objectKey];
        this.generateFilter();
        event.ColumnFilterDropdown.close();
        break;
    }
    
  }

  private generateFilter() {
    this.bodyData.GridFilters = [];
    this.bodyData.PageNumber = 1;
    Object.keys(this.filters).forEach(key => {
      this.bodyData.GridFilters.push(this.filters[key]);
    });

    this.getAliasListBasedOnAliasType();
  }
  validate(event): boolean {

    if (event.filterData.ConditionOpt1 && (event.filterData.ConditionOpt1.Value === '' ||
      event.filterData.ConditionOpt1.Value === 'Select...')) {
      return false;
    } else if (event.filterData.filterValue1 && event.filterData.filterValue1.Value === '') {
      return false;
    } else {
      return true;
    }
  }
  CreateNewAlias() {
    var aliasType = this.aliasForm.controls.DMOSYAliases_SYASAliasTyp.value;
    var alias = this.aliasForm.controls.DMOSYAliases_SYAAliasNo.value;
    if (aliasType === 'Customer') {
      aliasType = "Partner";
    }
    const saleYardName = this.saleservice.currentSaleYardName;
    if (saleYardName != undefined) {
     // this.lotSearchService.getSalyardCodeByName(saleYardName).subscribe(res => {
        this.aliasForm.controls['DMOSYAliases_SYASaleyard'].setValue(this.saleservice.currentSaleYardValue);
        this.formValue = { ...this.aliasForm.value };
        this.dmo.push("dmosyaliasessyasaleyard");//saleyard code
        this.dmo.push("dmosyaliasessyaaliasno");//alias name/no
        this.dmo.push("dmosyaliasessyaaliasref");//sap no/bread/product
        this.dmo.push("dmosyaliasessyasaliastyp");//alias type    
        var currentDate = new Date();
        this.formValue.DMOSYAliases_SYAPActFm = currentDate.getMonth() + "/" + currentDate.getDate() + "/" + currentDate.getFullYear();
        this.formValue.DMOSYAliases_SYASActTo = currentDate.getMonth() + "/" + currentDate.getDate() + "/" + "9999";
        this.formValue = this.dmoControlService.sanitizeFormValue(this.dmo, this.formValue);
        if (this.aliasForm.controls.DMOSYAliases_SYASAliasTyp.value == "Customer") {
          this.formValue.DMOSYAliases_SYASAliasTyp = "Partner";
        }
        this.formValue.DMOSYAliases_SYAAliasRef = this.SAPNo;
        this.currentUser = this.userDetail;
        const submitData: any = {
          ProcessName: "LMKConfigSaleyardAliases",
          TriggerName: "TRGR_SaleyardAliasesInProcess_Submit",
          UserName: this.currentUser.UserName,
          UniqueConstraints: '',
          Data: [this.formValue],
          ParentTransactionID: '-1',
          TempTransactionID: '0',
          IsBulkUpload: 'true'
        };
        this.lotSearchService.ValidateAlias(aliasType, this.SAPNo, alias, this.saleservice.currentSaleYardValue).subscribe(
          (resultData: any) => {
            if (resultData[0].rowCount == 0 && resultData[0].rowCount1 == 0) {
              delete submitData.Data[0].lookup_alias_customer;
              delete submitData.Data[0].lookup_alias_alias;
              delete submitData.Data[0].lookup_alias_breed;
              delete submitData.Data[0].lookup_alias_product;
              this.applicationService.insertApplication(submitData).subscribe(data => {
                if (data.status == "Success")
                  this.aliasForm.get("DMOSYAliases_SYAAliasRef").reset();
                this.aliasForm.get("DMOSYAliases_SYAAliasNo").reset();
                this.toastr.success('Data saved successfully');
              });
            }
            else if (resultData[0].rowCount == 1 && resultData[0].rowCount1 == 0) {
              this.msg.showMessage('Warning', {body: 'This alias exists already'});
              // this.showErrorMessage('This alias is already exist.', 'Message', 'Ok', null, false, true, false, '');
            }
            else if (resultData[0].rowCount == 0 && resultData[0].rowCount1 == 1) {
              this.openConfirmation(resultData[0].transactionID);
            }
          }
        );
     // })
    }
  }

  openConfirmation(id) {
    this.transactionId = id;
    this.msg.showMessage('Warning', {
      header: 'Update Alias Record',
      body: 'Are you sure you want to update this alias?',
      btnText: 'Confirm Update',
      checkboxText: 'Yes, update this alias',
      isDelete: true,
      callback: this.updateConfirmation,
      caller: this,
    })
    // this.showErrorMessage('Are you sure you want to update this alias?',
    //   'Update Alias Record', 'Confirm Update', this.updateConfirmation, true, false, true, 'Yes, Update this Alias.');
  }
  /*------------------- Show Popup -------------------*/
  // showErrorMessage(ErrorMsg: string, HeaderMsg: string, buttonText: string, callback: any, IsDelete: boolean, IsDefaultView: boolean,
  //   IsConfirmation: boolean, confirmationText: string) {
  //   const modalMsgRef = this.modalService.open(MessageComponent, { backdrop: 'static', windowClass: 'Confirm_popup' });
  //   const modalInstance: MessageComponent = modalMsgRef.componentInstance;
  //   modalInstance.Message = ErrorMsg;
  //   modalInstance.ButtonText = buttonText;
  //   modalInstance.MessageHeader = HeaderMsg;
  //   modalInstance.MessagePopup = modalMsgRef;
  //   modalInstance.IsConfirmation = IsConfirmation;
  //   modalInstance.CallBackMethod = callback;
  //   modalInstance.Caller = this;
  //   modalInstance.IsDelete = IsDelete;
  //   modalInstance.IsDefaultView = IsDefaultView;
  //   modalInstance.ConfirmationText = confirmationText;
  // }

  updateConfirmation(modelRef: NgbModalRef, Caller: UpdateAliasDataModalComponent) {
    if (Caller.transactionId != "") {
      const submitData: any = {
        Identifier: {
          Name: null,
          Value: null,
          TrnsctnID: Caller.transactionId
        },
        ProcessName: "LMKConfigSaleyardAliases",
        TriggerName: 'Save Data',
        UserName: Caller.currentUser.UserName,
        Data: [Caller.formValue]
      };
      delete submitData.Data[0].lookup_alias_customer;
      delete submitData.Data[0].lookup_alias_alias;
      delete submitData.Data[0].lookup_alias_breed;
      delete submitData.Data[0].lookup_alias_product;

      Caller.applicationService.updateApplication(submitData).subscribe(data => {
        Caller.aliasForm.get('DMOSYAliases_SYAAliasRef').reset();
        Caller.aliasForm.get('DMOSYAliases_SYAAliasNo').reset();
        Caller.toastr.success('Data updated successfully');
      });
    } else {
      modelRef.close();
    }
  }
  customerSearch = (text$: Observable<string>) => {
    return this.lotSearchService.customerSearch(text$);
  }

  selectcustomer(event: NgbTypeaheadSelectItemEvent, field: string) {
    this.lotSearchService.customerData.forEach(customer => {
      if (customer[field] === event.item) {
        this.aliasForm.get('DMOSYAliases_SYAAliasRef').patchValue(customer.dmocustmstrcustname1);
        this.SAPNo = customer.dmocustmstrsapno;
      }
    });
  }
  breadSearch = (text$: Observable<string>) => {
    return this.lotSearchService.breadSearch(text$);
  }

  selectBread(event: NgbTypeaheadSelectItemEvent, field: string) {
    this.lotSearchService.breadData.forEach(breed => {
      if (breed[field] === event.item) {
        this.aliasForm.get('DMOSYAliases_SYAAliasRef').patchValue(breed.dmoprodbrdprodbrddscr);
        this.SAPNo = breed.dmoprodbrdprodbrdcode;
      }
    });
  }

  productSearch = (text$: Observable<string>) => {
    return this.lotSearchService.ProductSearch(text$);
  }

  selectProduct(event: NgbTypeaheadSelectItemEvent, field: string) {
    this.lotSearchService.ProductData.forEach(product => {
      if (product[field] === event.item) {
        this.aliasForm.get('DMOSYAliases_SYAAliasRef').patchValue(product.dmoproductproddscr);
        this.SAPNo = product.dmoproductprodcode;
      }
    });
  }

  getAliasListBasedOnAliasType() {
    const saleYardName = this.saleservice.currentSaleYardName;
    const aliasType = this.aliasForm.controls.DMOSYAliases_SYASAliasTyp.value;
    const aliasName = this.aliasForm.controls.lookup_alias_alias.value;
    let aliasCatgryName: any;
    if (aliasType === 'Customer') {
      aliasCatgryName = this.aliasForm.controls.lookup_alias_customer.value;
    } else if (aliasType === 'Breed') {
      aliasCatgryName = this.aliasForm.controls.lookup_alias_breed.value;
    } else {
      aliasCatgryName = this.aliasForm.controls.lookup_alias_product.value;
    }
    if ((aliasName || aliasCatgryName) && saleYardName) {
      this.bodyData.saleyardCode = this.saleservice.currentSaleYardValue;
      this.bodyData.aliasType = aliasType === 'Customer' ? 'Partner' : aliasType;
      this.bodyData.aliasName = aliasName;
      this.bodyData.aliasCategoryName = aliasCatgryName;

      this.saleservice.getAlias(this.bodyData).subscribe(result => {
        this.aliasDataSource = result.AliasData;
        this.aliasItemsCount = result.AliasData.length;
      });
    } else {
      this.aliasDataSource = [];
    }

  }
  setConfig() {
    this.aliasForm.controls.DMOSYAliases_SYAAliasRef.patchValue("");
    this.aliasForm.controls.DMOSYAliases_SYAAliasNo.patchValue("");
    const name = this.aliasForm.controls.DMOSYAliases_SYASAliasTyp.value;
    this.aliasHeaderMap.config.header.columns[1].displayName = name + ' Name';
    this.aliasHeaderMap.config.header.columns[2].displayName = name + ' Id';
    this.aliasDataSource = [];

  }

  bindColumnFilterDdl(item) {
    let type = '';
    if (item.colData.dataType === 'Date') {
      type = 'DateEditBox';
    }
    const FilterData = this.columnFilter.GetFilterByDataType(type); // Calling Function to get ColumnFilter Condition data
    if (FilterData.length === 0) { // Check if Array is empty then call API for options data
    } else {
      // const key = Object.keys(item.colData)[0];
      this.aliasHeaderMap.config.header.columnFilter['colData_' + item.colIndex] = FilterData;
    }
  }
}
