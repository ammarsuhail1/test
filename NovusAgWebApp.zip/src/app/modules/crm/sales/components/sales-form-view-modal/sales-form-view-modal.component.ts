import { Component, OnInit } from '@angular/core';
import { formatDate, DatePipe } from '@angular/common';
import { Router } from '@angular/router';
import { NgbActiveModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormArray, FormBuilder } from '@angular/forms';
import { Observable, Subject, merge } from 'rxjs';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
import { saveAs } from 'file-saver';

import { LotSearchService } from '../../../lots/services/lot-search.service';
import { SalesService } from '../../services/sales.service';
import { UserDetail } from '@app/core/models/user-detail';

import {
  ApplicationService,
  AuthenticationService,
  FormViewService,
  DmoControlService,
  ListviewService,
  NgbDateFRParserFormatter,
  ApiESaleyardService,
  SaleStage,
  MessageService
} from '@app/core';
import { environment } from '@env/environment';

@Component({
  selector: 'app-sales-form-view-modal',
  templateUrl: './sales-form-view-modal.component.html',
  providers: [DatePipe],
  styleUrls: ['./sales-form-view-modal.component.scss']
})
export class SalesFormViewModalComponent implements OnInit {

  form: FormGroup;
  data: any;
  submitted = false;
  currentUser: any;
  processName: string;
  isEdit = false;
  isCopy = false;
  lotData = [];
  transactionId = null;
  parentTransactionId = null;
  BMJSON: any = {};
  applicationData: any = {};
  optionList: any = {};
  headerInformationdmos = [];
  headerInformationDmog: any;
  createFromFileDmos = [];
  saleIdfocus$ = new Subject<string>();
  saleData = [];
  rateVale = 0;
  flag = false;
  file: File = null;
  IsValidFile = false;
  fileName = '';
  errorMsg = '';
  isFileUpload = false;
  isDateGraeter = false;
  isDoneLoading = false;
  isCalcFeesFieldsChanged = false;
  isConductingBranchChanged = false;
  isBuyerRebateChanged = false;
  stage: SaleStage;
  deleteConjuctionalIndex: number;
  isFinalised = false;
  isReversal = false;

  constructor(
    public activeModal: NgbActiveModal,
    private router: Router,
    private applicationService: ApplicationService,
    private authenticationService: AuthenticationService,
    private dmoControlService: DmoControlService,
    private ngbDateFRParserFormatter: NgbDateFRParserFormatter,
    private formViewService: FormViewService,
    private listviewService: ListviewService,
    private apiESaleyardService: ApiESaleyardService,
    private fb: FormBuilder,
    private lotSearchService: LotSearchService,
    private salesService: SalesService,
    private datePipe: DatePipe,
    private msg: MessageService,
    private userDetail: UserDetail
  ) { }


  ngOnInit() {
    this.isDoneLoading = false;
    this.isFinalised = this.stage === SaleStage.Finalised || this.stage === SaleStage.ReversalCompleted;
    this.isReversal = this.stage === SaleStage.ReversalProcess;
    this.currentUser = this.userDetail;
    this.processName = sessionStorage.getItem('AppName');
    if (this.data) {
      this.isEdit = true;
    }
    this.formViewService.getBmWfJson(this.processName, 'Form').subscribe(async response => {
      this.BMJSON = response.BM.BusinessModelObjectGroup.Form;
      this.BMJSON.List.forEach(bmoGuid => {
        this.BMJSON.BusinessModelObjects[bmoGuid].List.forEach(dmogGuid => {
          if (this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].DisplayName === 'Header Information') {
            this.headerInformationDmog = this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid];
            this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].List.forEach(rowID => {
              this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].Rows[rowID].Columns.forEach(objCOLUMN => {
                objCOLUMN.List.forEach(dmoGUID => {
                  objCOLUMN.DataModelObjects[dmoGUID].DMOGuid = dmoGUID;
                  this.headerInformationdmos.push(objCOLUMN.DataModelObjects[dmoGUID]);
                });
              });
            });
          }
          if (this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].DisplayName === 'Create From File') {
            this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].List.forEach(rowID => {
              this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].Rows[rowID].Columns.forEach(objCOLUMN => {
                objCOLUMN.List.forEach(dmoGUID => {
                  objCOLUMN.DataModelObjects[dmoGUID].DMOGuid = dmoGUID;
                  objCOLUMN.DataModelObjects[dmoGUID].dmoGUID = dmoGUID;
                  this.createFromFileDmos.push(objCOLUMN.DataModelObjects[dmoGUID]);
                });
              });
            });
          }
        });
      });
      const dmos = [...this.headerInformationdmos, ...this.createFromFileDmos];
      this.form = this.dmoControlService.toFormViewGroup(dmos);
      if (this.isEdit) { // edit mode
        this.form = this.dmoControlService.toAdminViewFormGroup(dmos, this.data);
        if (this.data.DataInformation.dmocrmheaderinftrantype) {
          this.OnChangeTransactionType(this.data.DataInformation.dmocrmheaderinftrantype);
        }
        if (this.data.DataInformation.dmocrmheaderinfcndbrnc) {
          this.changeConductingBranch(this.data.DataInformation.dmocrmheaderinfcndbrnc);

        }
      } else if (this.isCopy) { // copy mode
        this.applicationData = await this.applicationService.getApplicationData(null, null, 'AdminView', this.transactionId).toPromise();
        this.form = this.dmoControlService.toAdminViewFormGroup(dmos, this.applicationData);
        if (this.applicationData.DataInformation.dmocrmheaderinftrantype) {
          this.OnChangeTransactionType(this.applicationData.DataInformation.dmocrmheaderinftrantype);
        }
        if (this.applicationData.DataInformation.dmocrmheaderinfcndbrnc) {
          this.changeConductingBranch(this.applicationData.DataInformation.dmocrmheaderinfcndbrnc);
        }
        this.GetPlasmaId();
        this.parentTransactionId = this.transactionId;
      } else { // create mode
        this.GetPlasmaId();
        this.form.controls.DMOCRM_HeaderInf_SaleProc.patchValue(this.currentUser.UserId);
      }
      this.populateDDLOptions();

      this.form.addControl('dmocrmconjagntsetconjag', new FormControl(false));
      this.form.addControl('conjunctionlAgents', new FormArray([]));
      this.form.addControl('enableBranchRebate', new FormControl(false));
      this.form.addControl('rebateRate', new FormControl());
      this.form.get('rebateRate').disable();

      if (this.isEdit && this.data !== undefined) {
        if (this.data.DataInformation.dmocrmintbuybrcrebenab != null && this.data.DataInformation.dmocrmintbuybrcrebenab.DMOVAL === 'true') {
          this.form.get('enableBranchRebate').patchValue(true);
        }
        if (this.data.DataInformation.dmocrmintbuybrcrebrate != null && this.data.DataInformation.dmocrmintbuybrcrebrate.DMOVAL) {
          this.form.get('rebateRate').patchValue(this.data.DataInformation.dmocrmintbuybrcrebrate.DMOVAL);
          this.form.get('rebateRate').enable();
        }
      } else if (this.isCopy && this.applicationData !== undefined) {
        if (this.applicationData.DataInformation.dmocrmintbuybrcrebenab != null && this.applicationData.DataInformation.dmocrmintbuybrcrebenab.DMOVAL === 'true') {
          this.form.get('enableBranchRebate').patchValue(true);
        }
        if (this.applicationData.DataInformation.dmocrmintbuybrcrebrate != null && this.applicationData.DataInformation.dmocrmintbuybrcrebrate.DMOVAL) {
          this.form.get('rebateRate').patchValue(this.applicationData.DataInformation.dmocrmintbuybrcrebrate.DMOVAL);
          this.form.get('rebateRate').enable();
        }
      }
      if (this.isEdit || this.isCopy) {
        this.getConjunctionAgentData();
        this.OnChangeTransactionType(undefined);

      } else if (this.salesService.submitDataForCreateSale) {
        this.form.patchValue(this.salesService.submitDataForCreateSale.submitData.Data[0]);
        this.form.controls['DMOCRM_HeaderInf_SaleDate'].patchValue(this.ngbDateFRParserFormatter.parse(this.salesService.submitDataForCreateSale.submitData.Data[0].DMOCRM_HeaderInf_SaleDate));
        this.changeConductingBranch({ DMOVAL: this.salesService.submitDataForCreateSale.submitData.Data[0].DMOCRM_HeaderInf_CndBrnc });
        this.OnChangeTransactionType({ DMOVAL: this.form.controls['DMOCRM_HeaderInf_TranType'].value });
        if (this.salesService.submitDataForCreateSale.conjunctionalAgentsData.length) {
          this.form.get('dmocrmconjagntsetconjag').setValue(true);
          for (const item of this.salesService.submitDataForCreateSale.conjunctionalAgentsData) {
            this.conjunctionlAgents.push(this.fb.group({
              DATAID: [null],
              // dmocrmconjagntagent: [item.dmocrmconjagntagent],
              // agentid: [item.dmocrmconjagntagent],
              // dmocrmconjagntrate: [item.dmocrmconjagntrate]
              // DATAID: this.isCopy ? [null] : [item.ID],
              dmocrmconjagntagent: [item.AgentName],
              agentid: [item.AgentCode],
              dmocrmconjagntrate: [item.Rate]
            }));
          }
        }
        this.file = this.salesService.submitDataForCreateSale.file;
        this.fileName = this.file.name;
      } else {
        const ddMMyyyy = this.datePipe.transform(new Date(), 'MM/dd/yyyy');
        this.form.controls['DMOCRM_HeaderInf_SaleDate'].patchValue(this.ngbDateFRParserFormatter.parse(ddMMyyyy));
      }
      this.onChanges();
      this.getSaleData();
      this.isDoneLoading = true;
      if (this.isFinalised || this.isReversal) {
        this.form.disable();
      }

      if (this.isReversal) {
        this.form.controls['DMOCRM_HeaderInf_SaleDate'].enable();
        this.form.controls['DMOCRM_HeaderInf_SaleDesc'].enable();
      }
    });
  }

  conjuctionalAgentSearch = (text$: Observable<string>) => {
    return this.lotSearchService.conjuctionalAgentSearch(text$);
  }

  populateDDLOptions() {
    this.BMJSON.List.forEach(bmoGuid => {
      this.BMJSON.BusinessModelObjects[bmoGuid].List.forEach(dmogGuid => {
        if (this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].DisplayName === 'Header Information') {
          this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].List.forEach(rowID => {
            this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].Rows[rowID].Columns.forEach(objCOLUMN => {
              objCOLUMN.List.forEach(dmoGUID => {
                const dmo = objCOLUMN.DataModelObjects[dmoGUID];
                if ((dmo.Type === 'DropDownList' || dmo.Type === 'KeyValueSearchBox') && dmoGUID !== 'dmocrmheaderinfsaleyard' && dmoGUID !== 'dmocrmheaderinfsaletype') {
                  this.optionList[dmo.Name] = [];
                  if (dmo.DataSource === 'values') {
                    dmo.Options.split(',').forEach(item => {
                      if (item !== 'All') {
                        this.optionList[dmo.Name] = [...this.optionList[dmo.Name], { ValueField: item, TextField: item }];
                      }
                    });
                  } else if (dmo.DataSource === 'json') {
                    this.optionList[dmo.Name] = JSON.parse(dmo.Options);
                  } else if (dmo.DataSource === 'c2miceapi') {
                    const callOption = dmo.Options.split('~~~');
                    const apiURL = callOption[0].toString();
                    const responseKey = callOption[callOption.length - 1];
                    this.listviewService.GetDataFromIceAPI(apiURL, 'text').subscribe(result => {
                      const parser = new DOMParser();
                      const xmlDoc = parser.parseFromString(result, 'text/xml');
                      const rowList = xmlDoc.getElementsByTagName('Table1');
                      let nodeIndex = -1;
                      for (const Index in rowList[0].childNodes) {
                        if (rowList[0].childNodes[Index].nodeName === responseKey) {
                          nodeIndex = parseInt(Index, 0);
                        }
                      }
                      if (nodeIndex > -1 && rowList.length > 0) {
                        let rowInex = 0;
                        while (rowInex < rowList.length) {
                          const optionValue = rowList[rowInex].childNodes[nodeIndex].childNodes[0].nodeValue;
                          if (optionValue !== 'All') {
                            this.optionList[dmo.Name] = [...this.optionList[dmo.Name], { ValueField: optionValue, TextField: optionValue }];
                          }
                          rowInex++;
                        }
                      }
                    });
                  } else if (dmo.DataSource === 'wfapigetdata') {
                    const callOption = dmo.Options.split('~~~');
                    const callParam = JSON.parse(callOption[1]);
                    const responseKey = callOption[0].toString().replace(/\s/g, '');
                    const responseParamss = responseKey.split('-');
                    let paramValue = '';
                    this.listviewService.GridData(callParam).subscribe(result => {
                      result.Data.forEach(rowItem => {
                        if (responseParamss.length === 1) {
                          paramValue = rowItem[responseParamss[0]];
                          if (paramValue !== 'All') {
                            this.optionList[dmo.Name] = [...this.optionList[dmo.Name], { ValueField: paramValue, TextField: paramValue }];
                          }
                        } else if (responseParamss.length === 2) {
                          paramValue = `${rowItem[responseParamss[0]]}~${rowItem[responseParamss[1]]}`;
                          this.optionList[dmo.Name] = [...this.optionList[dmo.Name], { ValueField: `${rowItem[responseParamss[0]]}`, TextField: `${rowItem[responseParamss[1]]}` }];
                        }
                      });
                    });
                  } else if (dmo.DataSource.toLowerCase().indexOf('wfapi')>-1) {
                    const responseKey = dmo.Key.toString().replace(/\s/g, '');
                    const responseValue = dmo.Value.toString().replace(/\s/g, '');
                    const callParam = JSON.parse(dmo.Model);
                    this.listviewService.GridData(callParam).subscribe(result => {
                      result.Data.forEach(rowItem => {
                        if (rowItem[responseValue] !== 'All') {
                          this.optionList[dmo.Name] = [...this.optionList[dmo.Name], { ValueField: `${rowItem[responseKey]}`, TextField: `${rowItem[responseValue]}` }];
                        }
                      });
                      });
                  }
                }
              });
            });
          });
        }
      });
    });
  }

  changeConductingBranch(ev) {
    if (ev) {
      let branchName = ev.ValueField || ev.DMOVAL;
      branchName = branchName.indexOf('~~~') > -1 ? branchName.split('~~~')[0] : branchName;
      this.apiESaleyardService.post(`crmsales/getSaleyardName/${branchName}`)
        .pipe(map(data => data.Data))
        .subscribe(data => {
          this.optionList.DMOCRM_HeaderInf_Saleyard = [];
          if (ev.ValueField) {
            this.form.get('DMOCRM_HeaderInf_Saleyard').patchValue('');
          }
          if (Array.isArray(data)) {
            data.forEach(item => {
              if (item.SALEYARDNAME !== 'All') {
                this.optionList.DMOCRM_HeaderInf_Saleyard = [...this.optionList.DMOCRM_HeaderInf_Saleyard, { ValueField: item.SALEYARDCODE, TextField: item.SALEYARDNAME }];
              }
            });
          }
        });
    }
  }

  getConjunctionAgentData() {
    this.salesService.getConjunctionalAgent(this.transactionId).subscribe(response => {
      if (response.length) {
        this.form.get('dmocrmconjagntsetconjag').setValue(true);
        response.forEach(item => {
          this.conjunctionlAgents.push(this.fb.group({
            DATAID: this.isCopy ? [null] : [item.ID],
            dmocrmconjagntagent: [item.AgentName],
            agentid: [item.AgentCode],
            dmocrmconjagntrate: [item.Rate]
          }));
        });

        if (this.isFinalised || this.isReversal) {
          this.conjunctionlAgents.disable();
        }
      }
    });
  }


  onChanges() {
    this.form.get('enableBranchRebate').valueChanges
      .subscribe(checked => {
        this.form.get('rebateRate').patchValue('');
        if (checked) {
          this.form.get('rebateRate').enable();
        } else {
          this.form.get('rebateRate').disable();
        }
      });

    this.form.get('DMOCRM_HeaderInf_TranType').valueChanges
      .subscribe(val => {
        this.isCalcFeesFieldsChanged = true;
      });

    this.form.get('DMOCRM_HeaderInf_SaleType').valueChanges
      .subscribe(val => {
        this.isCalcFeesFieldsChanged = true;
      });

    this.form.get('DMOCRM_HeaderInf_Saleyard').valueChanges
      .subscribe(val => {
        this.isCalcFeesFieldsChanged = true;
      });

    this.form.get('DMOCRM_HeaderInf_CndBrnc').valueChanges
      .subscribe(val => {
        this.isConductingBranchChanged = true;
      });

    this.form.get('rebateRate').valueChanges
      .subscribe(val => {
        this.isBuyerRebateChanged = true;
      });
  }

  OnChangeTransactionType(ev) {
    let val: any;
    if (ev) {
      let trnsTypeName = ev.ValueField || ev.DMOVAL;
      trnsTypeName = trnsTypeName.indexOf('~~~') > -1 ? trnsTypeName.split('~~~')[0] : trnsTypeName;
      this.apiESaleyardService.post(`crmsales/getSaleType/${trnsTypeName}`)
        .pipe(map(data => data.Data))
        .subscribe(data => {
          this.optionList.DMOCRM_HeaderInf_SaleType = [];
          if (ev.ValueField) {
            this.form.get('DMOCRM_HeaderInf_SaleType').patchValue('');
          }
          if (Array.isArray(data)) {
            data.forEach(item => {
              if (item.SALETYPENAME !== 'All') {
                this.optionList.DMOCRM_HeaderInf_SaleType = [...this.optionList.DMOCRM_HeaderInf_SaleType, { ValueField: item.SALECODE, TextField: item.SALETYPENAME }];
              }
            });
          }
        });
    }
    if (ev != undefined) {
      val = ev.ValueField || ev.DMOVAL;
      val = val.indexOf('~~~') > -1 ? val.split('~~~')[0] : val;
    } else {
      val = this.form.get('DMOCRM_HeaderInf_TranType').value;
    }
    const options = 'ZL02,ZL03,ZL04';
    if (val != undefined && val !== null && options.split(',').indexOf(val.trim()) === -1) {
      this.form.get('DMOCRM_HeaderInf_Saleyard').disable();
    } else {
      this.form.get('DMOCRM_HeaderInf_Saleyard').enable();
    }
  }
  GetPlasmaId() {
    this.headerInformationdmos.forEach((dmo: any) => {
      if (dmo.Type === 'ID') {
        this.dmoControlService.GetPlasmaId(dmo.Name).subscribe(value => {
          const chldCtrl = this.form.get(dmo.Name);
          chldCtrl.reset(value.PlasmaID);
          chldCtrl.updateValueAndValidity();
        });
      }
    });
  }


  get conjunctionlAgents() {
    return this.form.get('conjunctionlAgents') as FormArray;
  }

  addConjunctionalAgent() {
    if (this.isFinalised || this.isReversal) {
      return;
    }
    const control = this.form.controls.conjunctionlAgents as FormArray;
    control.push(
      this.fb.group({
        DATAID: [null],
        dmocrmconjagntagent: [null],
        agentid: [null],
        dmocrmconjagntrate: [null]
      })
    );
  }

  deleteConjunctionalAgent(index: number) {
    if (this.isFinalised || this.isReversal) {
      return;
    }
    this.rateVale = 0;
    const control = this.form.controls.conjunctionlAgents as FormArray;
    if (control.controls[index].value.DATAID) {
      this.deleteConjuctionalIndex = index;
      this.msg.showMessage('Warning', {
        header: 'Confirmation Message',
        body: 'Are you sure you want to delete conjuctional agent?',
        btnText: 'Yes',
        isConfirmation: true,
        callback: this.ConfirmationConjuctionDelete,
        caller: this,
      });
    } else {
      control.removeAt(index);
    }
  }
  ConfirmationConjuctionDelete(modelRef: NgbModalRef, Caller: SalesFormViewModalComponent) {
    const control = Caller.form.controls.conjunctionlAgents as FormArray;
    Caller.salesService.deleteConjunctionalAgent(control.controls[Caller.deleteConjuctionalIndex].value.DATAID).subscribe(data => {
      control.removeAt(Caller.deleteConjuctionalIndex);
      Caller.calcBuyerBranchRebate(Caller.transactionId);
    });
  }

  async saveConjunctionalAgent(conjunctionlAgents: any) {
    try {
      for (const item of conjunctionlAgents) {
        if (item.agentid !== '' && item.agentid != null &&
          item.dmocrmconjagntrate !== '' && item.dmocrmconjagntrate != null) {
          const body = {
            SaleTransactionID: this.transactionId,
            AgentCode: item.agentid,
            Rate: item.dmocrmconjagntrate
          };
          await this.salesService.saveConjunctionalAgent(body).toPromise();
        }
      }
    } catch (err) {
      console.log(err);
    }
  }

  getSaleData() {
    const queryBody: any = {
      PageSize: -1,
      PageNumber: -1,
      SortColumn: 'dmocrmheaderinfsaleid',
      SortOrder: 'Asc',
      ProcessName: 'LMKLivestockSales',
      TimeZone: 0,
      ColumnList: 'dmocrmheaderinfsaleid',
      ViewName: 'View 1',
      GridFilters: []
    };
    this.listviewService.GridData(queryBody)
      .pipe(map(data => data.Data))
      .subscribe(response => {
        this.saleData = response;
      });
  }

  saleIdSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
    const inputFocus$ = this.saleIdfocus$;

    return merge(debouncedText$, inputFocus$).pipe(
      map(term => (
        term === ''
          ? this.saleData
            .map(item => item.dmocrmheaderinfsaleid)
            .filter(id => id !== '' && id != null)
          : this.saleData
            .filter(v => v.dmocrmheaderinfsaleid.toLowerCase().indexOf(term.toLowerCase()) > -1)
            .map(item => item.dmocrmheaderinfsaleid)))
    );
  }
  onSubmitRecord() {
    const control = this.form.controls.conjunctionlAgents as FormArray;
    this.rateVale = 0;
    control.controls.forEach(element => { this.rateVale += +element.value.dmocrmconjagntrate; });
    if (this.rateVale > 100) {
      // const modalMsgRef = this.modalService.open(MessageComponent, { backdrop: 'static', windowClass: 'Confirm_popup' });
      // const modalInstance: MessageComponent = modalMsgRef.componentInstance;
      // modalInstance.MessagePopup = modalMsgRef;
      // modalInstance.IsConfirmation = true;
      // modalInstance.Caller = this;
      // modalInstance.MessageHeader = 'Confirmation Message';
      // modalInstance.Message = 'Conjunctional commission exceeds 100%. Do you want to continue.?';
      // modalInstance.ButtonText = 'Yes';
      // modalInstance.IsDefaultView = true;
      // modalInstance.CallBackMethod = this.redirectionConfirmation;
      this.msg.showMessage('Warning', {
        header: 'Confirmation Message',
        body: 'Conjunctional commission exceeds 100%. Do you want to continue?',
        btnText: 'Yes',
        isConfirmation: true,
        callback: this.redirectionConfirmation,
        caller: this,
      })
    } else {
      this.onSubmit();
    }

  }

  handleFileInput(files: FileList) {
    this.file = files.item(0);
    if (this.file) {
      if (this.file.type === 'text/plain' || this.file.type === 'application/vnd.ms-excel' ||
        this.file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') {
        this.IsValidFile = false;
        this.fileName = this.file.name;
      } else {
        this.fileName = '';
        this.errorMsg = 'File not valid';
        this.IsValidFile = true;
      }
    }
  }

  upload(processName: string, userId: string, saleyardName: string) {
    if (this.file === null) {
      this.IsValidFile = true;
      this.errorMsg = 'Please select file';
      return;
    }
    this.IsValidFile = false;
    this.errorMsg = '';
    const formData = new FormData();
    formData.append('uploadFile', this.file);

    this.salesService.ImportFileData(processName, userId, saleyardName, formData).subscribe(Result => {
      if (Result) {
        this.file = null;
        this.fileName = '';
        this.router.navigate(['/crm/sales/processing/file-import-review']);
      }
    }, error => { console.log(error); });
  }

  onSubmit() {
    this.submitted = true;
    const loginUser = this.userDetail;
    if (!this.form.valid) {
      return;
    }
    let formValue: any = {};
    if (this.isEdit) {
      formValue = this.dmoControlService.getDirtyValues(this.form);
    } else {
      formValue = { ...this.form.value };
    }

    if (Object.keys(formValue).includes('DMOCRM_HeaderInf_SaleDate')) {
      if (formValue.DMOCRM_HeaderInf_SaleDate != null &&
        formValue.DMOCRM_HeaderInf_SaleDate !== '' &&
        formValue.DMOCRM_HeaderInf_SaleDate.hasOwnProperty('year') &&
        formValue.DMOCRM_HeaderInf_SaleDate.hasOwnProperty('month') &&
        formValue.DMOCRM_HeaderInf_SaleDate.hasOwnProperty('day')) {
       // formValue.DMOCRM_HeaderInf_SaleDate = this.ngbDateFRParserFormatter.format(formValue.DMOCRM_HeaderInf_SaleDate);
        const dateyyMMdd = ''.concat(formValue.DMOCRM_HeaderInf_SaleDate.year, '-', formValue.DMOCRM_HeaderInf_SaleDate.month, '-', formValue.DMOCRM_HeaderInf_SaleDate.day);
        formValue.DMOCRM_HeaderInf_SaleDate = dateyyMMdd;
        if (environment.Setting.dateTimeFormat24 === true) {
          formValue.DMOCRM_HeaderInf_SaleDate = this.getUserDateTime(formValue.DMOCRM_HeaderInf_SaleDate,
            'MM/dd/yyyy hh:mm:ss', loginUser.TimeZone);
        } else {
          formValue.DMOCRM_HeaderInf_SaleDate = this.getUserDateTime(formValue.DMOCRM_HeaderInf_SaleDate,
            'MM/dd/yyyy hh:mm:ss', loginUser.TimeZone);
        }
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const saledate = new Date(dateyyMMdd);
        saledate.setHours(0, 0, 0, 0);
        if (this.isDateGraeter === false && saledate > today) {
          if (this.isReversal) {
            this.msg.showMessage('Warning', {body: 'You have selected a future date'});
            // this.showErrorMessage('You have selected a future date.', 'Message', 'Ok', null, false, true, false, '');
          } else {
            this.msg.showMessage('Warning', {
              body: 'You have selected a future date. Would you like to proceed?',
              btnText: 'Yes',
              checkboxText: 'Proceed',
              isDelete: false,
              isConfirmation: true,
              callback: this.redirectionConfirmation,
              caller: this,
            })
            // this.showErrorMessage('You have selected a future date. would you like to proceed?', 'Warning', 'Yes',
            //   this.redirectionConfirmation, false, true, true, 'would you like to proceed?');
          }
          return;
        }
      } else {
        if (isNaN(Date.parse(formValue.DMOCRM_HeaderInf_SaleDate))) {
          formValue.DMOCRM_HeaderInf_SaleDate = null;
        }
      }
    }

    let saleyard = formValue["DMOCRM_HeaderInf_Saleyard"];
    let tempFileName = this.fileName;
    if (tempFileName !== '' && saleyard === '') {
      this.isFileUpload = true;
      return;
    }


    let isRebate = false;
    const conjunctionalAgentsData = formValue.conjunctionlAgents;
    if (formValue.enableBranchRebate === true && formValue.rebateRate) {
      formValue.DMOCRM_IntBuyBrcReb_Rate = formValue.rebateRate;
      formValue.DMOCRM_IntBuyBrcReb_Enab = true;
    } else if (formValue.enableBranchRebate === true) {
      formValue.DMOCRM_IntBuyBrcReb_Enab = true;
    } else if (formValue.rebateRate) {
      formValue.DMOCRM_IntBuyBrcReb_Rate = formValue.rebateRate;
    } else if (this.isEdit === true &&
      this.data.DataInformation.dmocrmintbuybrcrebenab.RLTYPDMOVAL === 'true' && formValue.enableBranchRebate === false) {
      formValue.DMOCRM_IntBuyBrcReb_Rate = '';
      formValue.DMOCRM_IntBuyBrcReb_Enab = false;
      isRebate = true;
    } else if (this.isCopy &&
      this.applicationData.DataInformation.dmocrmintbuybrcrebenab.RLTYPDMOVAL === 'true' && formValue.enableBranchRebate === false) {
      formValue.DMOCRM_IntBuyBrcReb_Rate = '';
      formValue.DMOCRM_IntBuyBrcReb_Enab = false;
      isRebate = true;
    }
    delete formValue.enableBranchRebate;
    delete formValue.rebateRate;
    delete formValue.dmocrmconjagntsetconjag;
    delete formValue.conjunctionlAgents;
    if (this.form.controls.dmocrmconjagntsetconjag.value === true && conjunctionalAgentsData !== undefined) {
      if (this.isEdit) {
        const conjData = [];
        Object.keys(conjunctionalAgentsData).forEach(key => {
          const control = this.form.controls.conjunctionlAgents as FormArray;
          conjData.push(control.controls[key].value);
          if (conjData.length) {
            for (let i = 0; i < conjData.length; i++) {
              if (conjData[i].dmocrmconjagntagent === null || conjData[i].dmocrmconjagntrate === null) {
                this.msg.showMessage('Warning', {
                  body: 'The Conjunctional Agent section is missing mandatory fields. Please complete in order to continue',
                });
                // this.showErrorMessage('The Conjunctional Agent section is missing mandatory fields. Please complete in order to continue.', 'Message', 'Ok', null, false, true, false, '');
                return;
              }
            }
          }
        });
      } else {
        if (conjunctionalAgentsData.length) {
          for (let i = 0; i < conjunctionalAgentsData.length; i++) {
            if (conjunctionalAgentsData[i].dmocrmconjagntagent === null || conjunctionalAgentsData[i].dmocrmconjagntrate === null) {
              this.msg.showMessage('Warning', {
                body: 'The Conjunctional Agent section is missing mandatory fields. Please complete in order to continue',
              });
              // this.showErrorMessage('The Conjunctional Agent section is missing mandatory fields. Please complete in order to continue.', 'Message', 'Ok', null, false, true, false, '');
              return;
            }
          }
        }
      }
    }
    if (this.isEdit) {
      const submitData: any = {
        Identifier: {
          Name: null,
          Value: null,
          TrnsctnID: this.transactionId
        },
        ProcessName: this.processName,
        TriggerName: 'Save Data',
        UserName: this.currentUser.UserName,
        Data: [formValue]
      };

      this.applicationService.updateApplication(submitData).subscribe(async data => {
        if (formValue.DMOCRM_IntBuyBrcReb_Rate || formValue.DMOCRM_IntBuyBrcReb_Rate == '') {
          const resetRequest = {
            ParentTransctionId: this.transactionId,
            Rate: formValue.DMOCRM_IntBuyBrcReb_Rate,
            Rebate: formValue.DMOCRM_IntBuyBrcReb_Rate == '' ? 'false' : 'true',
            ProcessName: 'LMKLivestockLots'
          };
          this.salesService.ResetLot(resetRequest).subscribe(x => { });
        }
        const bodyDataVendor = {
          SaleTransactionID: this.transactionId
        };
        this.salesService.AddVendorTermsData(bodyDataVendor).subscribe(x => {
          this.salesService.bindvendor(this.transactionId);
        });
        if (conjunctionalAgentsData) {
          const conjData = [];
          Object.keys(conjunctionalAgentsData).forEach(key => {
            const control = this.form.controls.conjunctionlAgents as FormArray;
            conjData.push(control.controls[key].value);
          });
          await this.saveConjunctionalAgent(conjData);
          this.isBuyerRebateChanged = true;
        }
        // if reversal sale, not doing any lot fees & charges calculation
        if (!this.isReversal) {
          if (this.isCalcFeesFieldsChanged) {
            await this.calcLotFeesChargesById(this.transactionId);
          } else if (this.isBuyerRebateChanged) {
            await this.calcBuyerBranchRebate(this.transactionId);
          } else if (this.isConductingBranchChanged) {
            await this.calcHandlingFee(this.transactionId);
          }
        }
        this.activeModal.close(true);
      });

    } else {
      Object.keys(formValue).forEach(key => {
        if (formValue[key] == null || formValue[key] === '') {
          delete formValue[key];
        }
      });
      const submitData: any = {
        ProcessName: this.processName,
        UserName: this.currentUser.UserName,
        TriggerName: 'TRGR_PreProcessing_Next',
        Data: [formValue]
      };
      if ((formValue.DMOCRM_HeaderInf_TranType === 'ZL02' || formValue.DMOCRM_HeaderInf_TranType === 'ZL03' || formValue.DMOCRM_HeaderInf_TranType === 'ZL04')
        && this.fileName != '' && this.fileName != undefined) {
        const dataSource: any = {
          submitData,
          conjunctionalAgentsData,
          file: this.file,
          UserId: this.currentUser.UserName
        };

       // this.salesService.currentSaleYardName = formValue.DMOCRM_HeaderInf_Saleyard;
        const SelectedSaleYard = this.optionList.DMOCRM_HeaderInf_Saleyard.find(x => x.ValueField === formValue.DMOCRM_HeaderInf_Saleyard);
        if (SelectedSaleYard) {
          this.salesService.currentSaleYardName = SelectedSaleYard.TextField;
        }
        this.salesService.currentSaleYardValue = formValue.DMOCRM_HeaderInf_Saleyard;
        this.salesService.submitDataForCreateSale = dataSource;
        this.upload(this.processName, this.currentUser.UserId, submitData.Data[0]["DMOCRM_HeaderInf_Saleyard"].toString());
        // this.router.navigate(['/crm/sales/processing/file-import-review']);

      } else {
        this.applicationService.insertApplication(submitData).subscribe(async response => {
          this.transactionId = response.result.transactionId;
          if (conjunctionalAgentsData.length && !this.isCopy) {
            await this.saveConjunctionalAgent(conjunctionalAgentsData);
          }
          if (this.isCopy) {
            await this.copyLotRecords();
          }
          this.isFileUpload = false;
          this.router.navigate(['/crm/sales', this.transactionId]);
        });
      }
      this.activeModal.close(true);
    }
  }

  async copyLotRecords() {
    try {
      await this.salesService.SaveCopyLotData(this.parentTransactionId, this.transactionId).toPromise();
    } catch (err) {
      console.log(err);
    }
  }

  redirectionConfirmation(modelRef: NgbModalRef, Caller: SalesFormViewModalComponent) {
    Caller.isDateGraeter = true;
    Caller.onSubmit();
  }

  redirectionCloseConfirmation(modelRef: NgbModalRef, Caller: SalesFormViewModalComponent) {
    Caller.salesService.submitDataForCreateSale = null; Caller.activeModal.dismiss('Close')
  }

  /* ---------------------Open Confirmation Popup-------------- */
  // showErrorMessage(ErrorMsg: string, HeaderMsg: string, buttonText: string, callback: any, IsDelete: boolean, IsDefaultView: boolean,
  //   IsConfirmation: boolean, confirmationText: string) {
  //   const modalMsgRef = this.modalService.open(MessageComponent, { backdrop: 'static', windowClass: 'Confirm_popup' });
  //   const modalInstance: MessageComponent = modalMsgRef.componentInstance;
  //   modalInstance.Message = ErrorMsg;
  //   modalInstance.ButtonText = buttonText;
  //   modalInstance.MessageHeader = HeaderMsg;
  //   modalInstance.MessagePopup = modalMsgRef;
  //   modalInstance.IsConfirmation = IsConfirmation;
  //   modalInstance.CallBackMethod = callback;
  //   modalInstance.Caller = this;
  //   modalInstance.IsDelete = IsDelete;
  //   modalInstance.IsDefaultView = IsDefaultView;
  //   modalInstance.ConfirmationText = confirmationText;
  // }

  DownloadFileTemplate() {

    this.salesService.DownloadTemplateFile().subscribe(data => {
      saveAs(data, 'Sale_Yard_import_template.xlsx');
    }, error => {
      console.log(error);
    });
  }

  closeModal() {
    let isFormChange = 0;
    Object.keys(this.form.controls)
      .forEach(key => {
        const currentControl = this.form.controls[key];
        if (currentControl.dirty) {
          isFormChange++;
        }
      });
    if (isFormChange > 0) {
      this.msg.showMessage('Warning', {
        body: 'Are you sure to close this form?',
        btnText: 'Yes',
        checkboxText: 'Would you like to proceed?',
        isDelete: false,
        isConfirmation: true,
        callback: this.redirectionCloseConfirmation,
        caller: this,
      })
      // this.showErrorMessage('Are you sure to close this Form?', 'Warrning', 'Yes',
      //   this.redirectionCloseConfirmation, false, true, true, 'would you like to proceed?');
    } else {
      this.salesService.submitDataForCreateSale = null;
      this.activeModal.dismiss('Close');
    }
  }
  selectedItem(event, conjuctionForm) {
    const c = this.lotSearchService.vendorData.filter(x => x.dmocustmstrcustname1 === event.item);
    if (c.length > 0) {
      conjuctionForm.controls.agentid.patchValue(c[0].dmocustmstrsapno);
    }
  }

  async calcLotFeesChargesById(SaleTransactionID: string) {
    const bodyData = {
      SaleTransactionID,
      LotTransactionID: ''
    };

    await this.apiESaleyardService.post('crmlot/calcLotFeesChargesById', bodyData).toPromise();
  }

  async calcBuyerBranchRebate(SaleTransactionID: string) {
    const bodyData = {
      SaleTransactionID,
      LotTransactionID: ''
    };

    await this.apiESaleyardService.post('crmlot/calcBuyerBranchRebate', bodyData).toPromise();
  }

  async calcHandlingFee(SaleTransactionID: string) {
    const bodyData = {
      SaleTransactionID,
      LotTransactionID: ''
    };

    await this.apiESaleyardService.post('crmlot/calcHandlingFee', bodyData).toPromise();
  }
  getUserDateTime(value, format, zone) {
    try {
      const d = new Date(value); // val is in UTC
      const localOffset = zone * 60000;
      const localTime = d.getTime() - localOffset;
      d.setTime(localTime);
      return formatDate(d, format, 'en-US');
    } catch (error) {

      return '';
    }
  }
}
