import { Injectable } from '@angular/core';
import { ListviewService } from '@app/core';
import { Observable } from 'rxjs';
import { debounceTime, distinctUntilChanged, switchMap, map } from 'rxjs/operators';
import { ApiLmkService } from '@app/core/services/api-lmk.service';

@Injectable({
  providedIn: 'root'
})
export class AdjustmentService {

  agencySapNo = '';
  queryBody = {
    PageSize: 20,
    PageNumber: 0,
    SortColumn: '',
    SortOrder: 'Asc',
    ProcessName: '',
    TimeZone: 0,
    ColumnList: '',
    ViewName: 'View 1',
    GridFilters: [
      {
        GridConditions: [
          {
            Condition: 'CONTAINS',
            ConditionValue: ''
          }
        ],
        DataField: '',
        LogicalOperator: 'Or',
        FilterType: 'Column_Filter'
      }
    ]
  };
  constructor(private listviewService: ListviewService,
    private lmkservice: ApiLmkService) { }
  // --------------------------------Auto complete-----------------------------------------//
  saleIdSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());

    return debouncedText$.pipe(
      switchMap(term =>
        term !== '' || term.length > 2
          ? this.getSaleIds(term).pipe(
            map((res: any) => res.Data
            ))
          : []
      )
    );
  }

  agencySearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());

    return debouncedText$.pipe(
      switchMap(term =>
        term !== '' || term.length > 2
          ? this.getAgency(term).pipe(
            map((res: any) => res.Data
            ))
          : []
      )
    );
  }
  agentSearch = (text$: Observable<any>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());
    return debouncedText$.pipe(
      switchMap(term => {
        if (term !== '' && term.length > 2) {
          return this.GetAgentAgencyList(term);
        } else {
          return [];
        }
      }
      )
    );
  }
  branchSearch = (text$: Observable<any>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());
    return debouncedText$.pipe(
      switchMap(term =>
        term !== '' || term.length > 2
          ? this.getbranch(term).pipe(
            map((res: any) => res.Data
            ))
          : []
      )
    );
  }
  getSaleIds(term: any) {
    this.queryBody.SortColumn = 'dmocrmheaderinfsaleid';
    this.queryBody.ProcessName = 'LMKLivestockSales';
    this.queryBody.ColumnList = 'dmocrmheaderinfsaleid,dmocrmheaderinfsaledate';
    this.queryBody.GridFilters[0].DataField = 'dmocrmheaderinfsaleid';
    this.queryBody.GridFilters[0].GridConditions[0].ConditionValue = term;
    return this.listviewService.GridData(this.queryBody);
  }
  getAgency(term: any) {
    this.queryBody.SortColumn = 'dmoagencyagncsapno';
    this.queryBody.ProcessName = 'LMKMSTRAgency';
    this.queryBody.ColumnList = 'dmoagencyagncsapno,dmoagencyagncname1';
    this.queryBody.GridFilters[0].DataField = 'dmoagencyagncsapno-dmoagencyagncname1';
    this.queryBody.GridFilters[0].GridConditions[0].ConditionValue = term;
    return this.listviewService.GridData(this.queryBody);
  }
  getbranch(term: any) {
    const query = Object.assign({}, this.queryBody);
    query.SortColumn = 'dmobranchbrname';
    query.ProcessName = 'LMKMSTRBranch';
    query.ColumnList = 'dmobranchbrcode,dmobranchbrname';
    query.GridFilters[0].DataField = 'dmobranchbrcode';
    query.GridFilters[0].GridConditions[0].ConditionValue = term;

    // query['SeparatorCondition'] = 'or';
    // query.GridFilters.push({
    //   GridConditions: [
    //     {
    //       Condition: 'CONTAINS',
    //       ConditionValue: term
    //     }
    //   ],
    //   DataField: 'dmobranchbrname',
    //   LogicalOperator: 'Or',
    //   FilterType: 'Column_Filter'
    // });
    return this.listviewService.GridData(query, false);
  }
  GetAgentAgencyList(term: any) {
    const Type = 'Agent';
    return this.lmkservice.get(`crmlot/GetAgentAgencyList/${Type}/${term}/${this.agencySapNo}`, null);
  }
  getGLAccount() {
    const query = Object.assign({}, this.queryBody);
    query.SortColumn = 'dmoglcodegldscr';
    query.ProcessName = 'LMKMSTRGLCode';
    query.ColumnList = 'dmoglcodeglcode,dmoglcodegldscr';
    query.GridFilters = [];
    return this.listviewService.GridData(query);
  }
  getCustomer(agentCode: string, agencySap: string) {
    return this.lmkservice.get(`crmlot/getCustomerBasedOnAgent?Agentcode=${agentCode}&AgencySapNo=${agencySap}`, null);
  }
}
