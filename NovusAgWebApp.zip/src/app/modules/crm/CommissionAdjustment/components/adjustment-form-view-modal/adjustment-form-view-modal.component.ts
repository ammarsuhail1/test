import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormViewService, DmoControlService, ApplicationService, MessageService } from '@app/core';
import { Observable } from 'rxjs';
import { AdjustmentService } from '../../services/adjustment.service';
import { NgbActiveModal, NgbModalRef, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe, formatDate } from '@angular/common';
import { Router } from '@angular/router';
import { environment } from '@env/environment';
import { debounceTime, distinctUntilChanged, map, switchMap } from 'rxjs/operators';
import { UserDetail } from '@app/core/models/user-detail';

@Component({
  selector: 'app-adjustment-form-view-modal',
  providers: [DatePipe],
  templateUrl: './adjustment-form-view-modal.component.html',
  styleUrls: ['./adjustment-form-view-modal.component.scss']
})
export class AdjustmentFormViewModalComponent implements OnInit {

  form: FormGroup;
  processName: string;
  customerList:any;
  BMJSON: any = {};
  headerInformationdmos = [];
  headerInformationDmog: any;
  optionListGL = [];
  isDoneLoading = false;
  submitted = false;
  formatter = (x: any) => x.dmocrmheaderinfsaleid;
  formattersapno = (x: any) => x.dmoagencyagncsapno;
  formatteragencyname = (x: any) => x.dmoagencyagncname1;
  formatteragent = (x: any) => x.NAME;
  formatterbranch = (x: any) => x.dmobranchbrname;
  formattercustomersapno = (x: any) => x.SapNo;
  formattercustomername = (x: any) => x.CustomerName;
  constructor(
    private dmoControlService: DmoControlService,
    private formViewService: FormViewService,
    private adjustmentService: AdjustmentService,
    public activeModal: NgbActiveModal,
    private applicationService: ApplicationService,
    private datePipe: DatePipe,
    private navigate: Router,
    private modalService: NgbModal,
    private msg: MessageService,
    private userDetail:UserDetail
  ) { }

  ngOnInit() {
    this.isDoneLoading = false;
  //  this.currentUser = this.userDetail;
    this.processName = sessionStorage.getItem('AppName');

    this.formViewService.getBmWfJson(this.processName, 'Form').subscribe(async response => {
      this.BMJSON = response.BM.BusinessModelObjectGroup.Form;
      this.BMJSON.List.forEach(bmoGuid => {
        this.BMJSON.BusinessModelObjects[bmoGuid].List.forEach(dmogGuid => {
          if (this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].DisplayName === 'Commission Adjustment') {
            this.headerInformationDmog = this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid];
            this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].List.forEach(rowID => {
              this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].Rows[rowID].Columns.forEach(objCOLUMN => {
                objCOLUMN.List.forEach(dmoGUID => {
                  objCOLUMN.DataModelObjects[dmoGUID].DMOGuid = dmoGUID;
                  this.headerInformationdmos.push(objCOLUMN.DataModelObjects[dmoGUID]);
                });
              });
            });
          }
        });
      });
      const dmos = [...this.headerInformationdmos];
      this.form = this.dmoControlService.toFormViewGroup(dmos);
      this.populateDDLOptions();
      this.GetPlasmaId();
      this.isDoneLoading = true;
    });
  }
  GetPlasmaId() {
    this.headerInformationdmos.forEach((dmo: any) => {
      if (dmo.Type === 'ID') {
        this.dmoControlService.GetPlasmaId(dmo.Name).subscribe(value => {
          const chldCtrl = this.form.get(dmo.Name);
          chldCtrl.reset(value.PlasmaID);
          chldCtrl.updateValueAndValidity();
        });
      }
    });
    return;
  } 
  // Auto Complete ---------
  saleIdSearch = (text$: Observable<string>) => {
    return this.adjustmentService.saleIdSearch(text$);
  }
  agencySearch = (text$: Observable<string>) => {
    return this.adjustmentService.agencySearch(text$);
  }

  customerSearch1= (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());
    return debouncedText$.pipe(
      switchMap(term => {
        if (term !== '' && term.length > 2) {
          const c = this.customerList.filter(v => v.CustomerName.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10);
          
          return c;
        } else {
          return [];
        }
      }
      )
    );
  }

  customerSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());
    return debouncedText$.pipe(
      switchMap(term => {
        if (term !== '' && term.length > 2) {
          const c = [this.customerList.filter(v => v.CustomerName.toLowerCase().indexOf(term.toLowerCase()) > -1 ||
             v.SapNo.toLowerCase().indexOf(term.toLowerCase()) > -1).slice(0, 10)];
          
          return c;
        } else {
          return [];
        }
      }
      )
    );
  }
  agentSearch = (text$: Observable<string>) => {
    return this.adjustmentService.agentSearch(text$);
  }
  branchSearch = (text$: Observable<string>) => {
    return this.adjustmentService.branchSearch(text$);
  }
  selectitem(event: any, dmo: string) {
    if (dmo === 'dmocommadjsateid') {
      if (event.item && event.item.dmocrmheaderinfsaledate !== null
        && event.item.dmocrmheaderinfsaledate !== '') {
        const ddMMyyyy = this.datePipe.transform(new Date(event.item.dmocrmheaderinfsaledate), 'MM/dd/yyyy');
        this.form.get('DMOCommAdj_SaleDate').setValue(ddMMyyyy);
      }
    } else if (dmo === 'dmocommadjagencysapno') {
      this.form.get('DMOCommAdj_AgencyName').patchValue(event.item);
      this.adjustmentService.agencySapNo = event.item.dmoagencyagncsapno;
    } else if (dmo === 'dmocommadjagentname') {
      this.getCustomer(event.item.CODE, event.item.SAPNO);
    } else if (dmo === 'dmocommadjagencyname') {
      this.form.get('DMOCommAdj_AgencySapNo').patchValue(event.item);
      this.adjustmentService.agencySapNo = event.item.dmoagencyagncsapno;
    } else if (dmo === 'dmocommadjcustomerid') {
      this.form.get('DMOCommAdj_CustomerName').patchValue(event.item);
    } else if (dmo === 'dmocommadjcustomername') {
      this.form.get('DMOCommAdj_CustomerID').patchValue(event.item);
    }
  }
  populateDDLOptions() {
    this.adjustmentService.getGLAccount().subscribe(result => {
      this.optionListGL = result.Data;
    });
  }
  get f() { return this.form.controls; }
  onSubmit() {
    const loginUser = this.userDetail;
    this.submitted = true;
    if (this.form.valid) {
      let formValue: any = {};
      formValue = this.form.value;
      if (Object.keys(formValue).includes('DMOCommAdj_SateID')) {
        formValue.DMOCommAdj_SateID = formValue.DMOCommAdj_SateID.dmocrmheaderinfsaleid;
      }
      if (Object.keys(formValue).includes('DMOCommAdj_AgencySapNo')) {
        formValue.DMOCommAdj_AgencySapNo = formValue.DMOCommAdj_AgencySapNo.dmoagencyagncsapno;
      }
      if (Object.keys(formValue).includes('DMOCommAdj_AgentName')) {
        formValue.DMOCommAdj_AgentName = formValue.DMOCommAdj_AgentName.CODE;
      }
      if (Object.keys(formValue).includes('DMOCommAdj_Branch')) {
        formValue.DMOCommAdj_Branch = formValue.DMOCommAdj_Branch.ddOptionKey;
      }
      if (Object.keys(formValue).includes('DMOCommAdj_AgencyName')) {
        formValue.DMOCommAdj_AgencyName = formValue.DMOCommAdj_AgencyName.dmoagencyagncname1;
      }
      if (Object.keys(formValue).includes('DMOCommAdj_CustomerID')) {
        formValue.DMOCommAdj_CustomerID = formValue.DMOCommAdj_CustomerID.SapNo;
      }
      if (Object.keys(formValue).includes('DMOCommAdj_CustomerName')) {
        formValue.DMOCommAdj_CustomerName = formValue.DMOCommAdj_CustomerName.CustomerName;
      }
      if (environment.Setting.dateTimeFormat24 == true) {
        formValue.DMOCommAdj_SaleDate = this.getUserDateTime(formValue.DMOCommAdj_SaleDate, 'MM/dd/yyyy HH:mm:ss', loginUser.TimeZone);
      } else {
        formValue.DMOCommAdj_SaleDate = this.getUserDateTime(formValue.DMOCommAdj_SaleDate, 'MM/dd/yyyy h:mm:ss a', loginUser.TimeZone);
      }
      const submitData: any = {
        ProcessName: sessionStorage.AppName,
        UserName: this.userDetail.UserName,
        TriggerName: 'TRG_CommAdj_Submit',
        Data: [formValue]
      };
      this.applicationService.insertApplication(submitData).subscribe(async response => {
        this.activeModal.close(true);
        this.navigate.navigate(['/crm/commissionadjustment/LMKCRMCommissionAdjustment']);
      });

    } else {
      return ;
    }
  }
  getCustomer(agent: string, agency: string) {
    this.adjustmentService.getCustomer(agent, agency).subscribe(x => {
      if (x && x.length > 0) {
        this.customerList = x;
        this.form.get('DMOCommAdj_CustomerID').patchValue(x[0]);
        this.form.get('DMOCommAdj_CustomerName').patchValue(x[0]);
      }
    });
  }
  clearData(event) {
    if (event.target.value === '') {
      this.form.get('DMOCommAdj_AgencyName').patchValue('');
      this.form.get('DMOCommAdj_AgentName').patchValue('');
      this.form.get('DMOCommAdj_CustomerID').patchValue('');
      this.form.get('DMOCommAdj_CustomerName').patchValue('');
    }
    
  }
  closeModal() {
    let isFormChange = 0;
    Object.keys(this.form.controls)
      .forEach(key => {
        const currentControl = this.form.controls[key];
        if (currentControl.dirty) {
          isFormChange++;
        }
      });
    if (isFormChange > 0) {
      this.msg.showMessage('Warning', {
        body: 'Are you sure to close this form?',
        btnText: 'Yes',
        checkboxText: 'Would you like to proceed?',
        isConfirmation: true,
        isDelete: false,
        callback: this.redirectionCloseConfirmation,
        caller: this,
      })
      // this.showErrorMessage('Are you sure to close this Form?', 'Warrning', 'Yes',
      //   this.redirectionCloseConfirmation, false, true, true, 'would you like to proceed?');
    } else {
      this.activeModal.close(0);
    }
  }
  // showErrorMessage(ErrorMsg: string, HeaderMsg: string, buttonText: string, callback: any, IsDelete: boolean, IsDefaultView: boolean,
  //   IsConfirmation: boolean, confirmationText: string) {
  //   const modalMsgRef = this.modalService.open(MessageComponent, { backdrop: 'static', windowClass: 'Confirm_popup' });
  //   const modalInstance: MessageComponent = modalMsgRef.componentInstance;
  //   modalInstance.Message = ErrorMsg;
  //   modalInstance.ButtonText = buttonText;
  //   modalInstance.MessageHeader = HeaderMsg;
  //   modalInstance.MessagePopup = modalMsgRef;
  //   modalInstance.IsConfirmation = IsConfirmation;
  //   modalInstance.CallBackMethod = callback;
  //   modalInstance.Caller = this;
  //   modalInstance.IsDelete = IsDelete;
  //   modalInstance.IsDefaultView = IsDefaultView;
  //   modalInstance.ConfirmationText = confirmationText;
  // }

  redirectionCloseConfirmation(modelRef: NgbModalRef, Caller: AdjustmentFormViewModalComponent) {
    Caller.activeModal.close(0);
  }
  getUserDateTime(value, format, zone) {
    try {
      const d = new Date(value); // val is in UTC
      const localOffset = zone * 60000;
      const localTime = d.getTime() - localOffset;
      d.setTime(localTime);
      return formatDate(d, format, 'en-US');
    } catch (error) {

      return '';
    }
  }
}
