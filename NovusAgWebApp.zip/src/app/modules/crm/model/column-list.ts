export class ColumnList {
    LMKOPECESLot: string;
    constructor() {
        this.LMKOPECESLot = 'lmkoeelotdmobuyname,lmkoeelotdmobreed,lmkoeelotdmotweight,lmkoeelotdmolistgdesc,lmkoeelotdmovdombrch,lmkoeelotdmospaaccno,lmkoeelotdmolotid,lmkoeelotdmolotnumber,lmkoeelotdmoproductcat,lmkoeelotdmoproduct,lmkoeelotdmobuyerid,lmkoeelotdmobuybrch,lmkoeelotdmovendor,lmkoeelotdmosex,lmkoeelotdmopriceaud,lmkoeelotdmoquantity,WFODISPNAME,WFOSDISPNAME';
    }
}
