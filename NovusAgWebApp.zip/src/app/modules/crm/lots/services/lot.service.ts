import { Injectable } from '@angular/core';
import { ApiLmkService } from '@app/core/services/api-lmk.service';
import { BehaviorSubject } from 'rxjs/internal/BehaviorSubject';
import { element } from 'protractor';



@Injectable({
  providedIn: 'root'
})
export class LotService {

  private LotGuids: any[];
  constructor(private lmkservice: ApiLmkService) { 
    this.LotGuids = ['dmolotvinfovendorpic', 'dmolotbinfobuyerid', 'dmolotbinfobuyername', 'dmolotbinfobuyerpic', 'dmolotbinfoinvoiceref', 'dmolotlotinfosalenum',
    'dmolotlotinfoqnty', 'dmolotlotinfoprod', 'dmolotlotinfodesc', 'dmolotlotinfopricephd', 'dmolotlotinfopricecpkg', 'dmolotlotinfowtkg', 'dmolotlotinfoturnovaud'];
  }

  // Observable navItem source
  private _navItemSource = new BehaviorSubject<boolean>(false);
  // Observable navItem stream
  navItem$ = this._navItemSource.asObservable();

  // service command
  changeNav() {
    this._navItemSource.next(true);
  }
  public getAgentCommission(trnId) {
    return this.lmkservice.get(`crmlot/getLotAgentAgency?transactionID=${trnId}`, null);
  }
  public addLotAgentAgency(body: any) {
    return this.lmkservice.post('crmlot/addLotAgentAgency', body, null);
  }
  public addLotAgentAgencyShared(body: any) {
    return this.lmkservice.post('crmlot/addLotAgentAgencyShared', body, null);
  }
  public deleteLotAgentAgency(lotAgentCommissionId: any) {
    return this.lmkservice.post(`crmlot/deleteLotAgentAgency?lotAgentCommissionId=${lotAgentCommissionId}`, null);
  }
  public getSharedAgentAgency(body: any) {
    return this.lmkservice.post('crmlot/getSharedAgentAgency', body, null);
  }
  public saveAutoLotAgentAgency(body: any) {
    return this.lmkservice.post('crmlot/saveAutoLotAgentAgency', body, null);
  }
  public removeAgencyAssociation(TranId: any) {
    return this.lmkservice.post(`crmlot/bulkDeleteLotAgentAgency?lotsTranId=${TranId}`,  null);
  }
  public calculateFeeAndCharges(body: any) {
    return this.lmkservice.post(`crmlot/calcLotFeesChargesById`, body,  null);
  }
  public changeLotStatus(body: any) {
    return this.lmkservice.post(`crmlot/ChangeLotStatusById`, body,  null);
  }
  public getGstRate() {
    return this.lmkservice.get('crmlot/getGstRate', null);
  }
  isChangesOnLot(term: string) {
    return this.LotGuids.includes(term.toLowerCase());
  }
  public AddChangesLot(body: any) {
    return this.lmkservice.post(`crmlot/AddChangesLot`, body,  null);
  }
}
