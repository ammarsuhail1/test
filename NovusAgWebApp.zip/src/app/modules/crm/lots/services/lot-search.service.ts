import { Injectable } from '@angular/core';
import { Observable, Subject, merge } from 'rxjs';
import { debounceTime, distinctUntilChanged, map, switchMap, tap, take } from 'rxjs/operators';

import { ListviewService, ApiESaleyardService } from '@app/core';
import { FormGroup } from '@angular/forms';
import { analyzeAndValidateNgModules } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class LotSearchService {
  public currentLotId: any;
  public vendorData = [];
  public vendorPICData = [];
  public buyerPICData = [];
  public BranchData = [];
  queryVendorBody: any;
  queryCustomerBody = {
    PageSize: 20,
    PageNumber: 0,
    SortColumn: 'dmocustmstrsapno',
    SortOrder: 'Asc',
    ProcessName: 'LMKMSTRCustomer',
    TimeZone: 0,
    SeparatorCondition: 'or',
    ColumnList: 'dmocustmstrsapno,dmocustmstrcustname1',
    ViewName: 'View 1',
    GridFilters: [{
      DataField: 'dmocustmstrcustname1',
      FilterType: 'Column_Filter',
      LogicalOperator: 'Or',
      GridConditions: [{ Condition: 'CONTAINS', ConditionValue: '***input***' }]
    }]
  };

  queryBreadBody: any = {
    PageSize: 20,
    PageNumber: 0,
    SortColumn: 'dmoprodbrdprodbrdcode',
    SortOrder: 'Asc',
    ProcessName: 'LMKMSTRProductBreed',
    TimeZone: 0,
    SeparatorCondition: 'or',
    ColumnList: 'dmoprodbrdprodbrdcode,dmoprodbrdprodbrddscr',
    ViewName: 'View 1',
    GridFilters: []
  };
  queryProductBody: any = {
    PageSize: 20,
    PageNumber: 0,
    SortColumn: 'dmoproductprodcode',
    SortOrder: 'Asc',
    ProcessName: 'LMKMSTRProduct',
    TimeZone: 0,
    SeparatorCondition: 'or',
    ColumnList: 'dmoproductprodcode,dmoproductproddscr',
    ViewName: 'View 1',
    GridFilters: []
  };
  public customerData = [];
  public breadData = [];
  public ProductData = [];
  public buyerData = [];
  public productData = [];
  public conjuctionalAgentData = [];
  public conjuctionalAgent = new Subject<string>();
  sapNo: string;
  name: string;
  type: string;
  getVendorData(term: any, controlName: any) {
    this.queryVendorBody = {
      PageSize: 20,
      PageNumber: 0,
      SortColumn: 'dmocustmstrsapno',
      SortOrder: 'Asc',
      ProcessName: 'LMKMSTRCustomer',
      TimeZone: 0,
      ColumnList: 'dmocustmstrsapno,dmocustmstrcustname1,dmocustmstrlstkbranch,dmocustmstrgstflg,dmocustmstracttype,dmocustmstrcustdombranch',
      ViewName: 'View 1',
      GridFilters: [
        {
          GridConditions: [
            {
              Condition: 'CONTAINS',
              ConditionValue: 'Vendor'
            }
          ],
          DataField: 'dmocustmstrcusttype',
          LogicalOperator: 'Or',
          FilterType: 'Column_Filter'
        }, {
          GridConditions: [
            {
              Condition: 'CONTAINS',
              ConditionValue: term
            }
          ],
          DataField: controlName == "VendorId" ? 'dmocustmstrsapno' : 'dmocustmstrcustname1',
          LogicalOperator: 'Or',
          FilterType: 'Column_Filter'
        }
      ]
    };
    return this.listviewService.GridData(this.queryVendorBody);
  }
  getVendorPicData(term: any) {
    const queryVendorPiCBody = {
      PageSize: 20,
      PageNumber: 0,
      SortColumn: 'dmocuspiccustpic',
      SortOrder: 'Asc',
      ProcessName: 'LMKConfigCustomerPIC',
      TimeZone: 0,
      ColumnList: '',
      ViewName: 'View 1',
      GridFilters: [
       {
          GridConditions: [
            {
              Condition: 'CONTAINS',
              ConditionValue: term
            }
          ],
          DataField: 'dmocuspiccustpic',
          LogicalOperator: 'Or',
          FilterType: 'Column_Filter'
        }
      ]
    };
    return this.listviewService.GridData(queryVendorPiCBody);
  }
  getBranchData(term: any) {
    const queryBranchBody = {
      PageSize: 20,
      PageNumber: 0,
      SortColumn: 'dmobranchbrname',
      SortOrder: 'Asc',
      ProcessName: 'LMKMSTRBranch',
      TimeZone: 0,
      ColumnList: 'dmobranchbrcode,dmobranchbrname',
      ViewName: 'View 1',
      GridFilters: [
       {
          GridConditions: [
            {
              Condition: 'CONTAINS',
              ConditionValue: term
            }
          ],
          DataField: 'dmobranchbrname-dmobranchbrcode',
          LogicalOperator: 'Or',
          FilterType: 'Column_Filter'
        }
      ]
    };
    return this.listviewService.GridData(queryBranchBody);
  }
  getBuyerPicData(term: any) {
    const queryVendorPiCBody = {
      PageSize: 20,
      PageNumber: 0,
      SortColumn: 'dmocuspiccustpic',
      SortOrder: 'Asc',
      ProcessName: 'LMKConfigCustomerPIC',
      TimeZone: 0,
      ColumnList: 'dmocuspiccustpic',
      ViewName: 'View 1',
      GridFilters: [
       {
          GridConditions: [
            {
              Condition: 'CONTAINS',
              ConditionValue: term
            }
          ],
          DataField: 'dmocuspiccpicsapno',
          LogicalOperator: 'Or',
          FilterType: 'Column_Filter'
        }
      ]
    };
    return this.listviewService.GridData(queryVendorPiCBody);
  }

  getBuyerData(term: any, controlName: any) {
    this.queryVendorBody = {
      PageSize: 20,
      PageNumber: 0,
      SortColumn: 'dmocustmstrsapno',
      SortOrder: 'Asc',
      ProcessName: 'LMKMSTRCustomer',
      TimeZone: 0,
      ColumnList: 'dmocustmstrsapno,dmocustmstrcustname1,dmocustmstrlstkbranch,dmocustmstrgstflg,dmocustmstracttype,dmocustmstrcustdombranch',
      ViewName: 'View 1',
      GridFilters: [
        {
          GridConditions: [
            {
              Condition: 'CONTAINS',
              ConditionValue: 'Buyer'
            }
          ],
          DataField: 'dmocustmstrcusttype',
          LogicalOperator: 'Or',
          FilterType: 'Column_Filter'
        }, {
          GridConditions: [
            {
              Condition: 'CONTAINS',
              ConditionValue: term
            }
          ],
          DataField: controlName == "BuyerId" ? 'dmocustmstrsapno' : 'dmocustmstrcustname1',
          LogicalOperator: 'Or',
          FilterType: 'Column_Filter'
        }
      ]
    };
    return this.listviewService.GridData(this.queryVendorBody);
  }
  private getCongunctionBody(term: any) {
    this.queryCustomerBody = {
      PageSize: 20,
      PageNumber: 0,
      SortColumn: 'dmocustmstrsapno',
      SortOrder: 'Asc',
      ProcessName: 'LMKMSTRCustomer',
      TimeZone: 0,
      SeparatorCondition: 'or',
      ColumnList: 'dmocustmstrsapno,dmocustmstrcustname1',
      ViewName: 'View 1',
      GridFilters: [{
        DataField: 'dmocustmstrcustname1',
        FilterType: 'Column_Filter',
        LogicalOperator: 'Or',
        GridConditions: [{ Condition: 'CONTAINS', ConditionValue: term }]
      }]
    };
    return this.listviewService.GridData(this.queryCustomerBody);
  }



  customerSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());
    return debouncedText$.pipe(
      switchMap(term => {
        if (term === '' || term.length <= 2) {
          return [];
        } else {
          this.queryCustomerBody.GridFilters = [];
          this.queryCustomerBody.GridFilters = [{
            DataField: 'dmocustmstrcustname1',
            FilterType: 'Column_Filter',
            LogicalOperator: 'Or',
            GridConditions: [{ Condition: 'CONTAINS', ConditionValue: term }]
          },
          {
            DataField: 'dmocustmstrsapno',
            FilterType: 'Column_Filter',
            LogicalOperator: 'Or',
            GridConditions: [{ Condition: 'CONTAINS', ConditionValue: term }]
          }];
          return this.listviewService.GridDatalmk(this.queryCustomerBody)
            .pipe(
              tap(res => this.customerData = res.Data),
              map((res: any) => res.Data
                // .filter(v => v.dmocustmstrcustname1.toLowerCase().indexOf(term.toLowerCase()) > -1)
                .map(item => item.dmocustmstrcustname1)
              ));
        }
      }
      )
    );
  }

  breadSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());
    return debouncedText$.pipe(
      switchMap(term => {
        if (term === '' || term.length <= 1) {
          return [];
        } else {
          this.queryBreadBody.GridFilters = [];
          this.queryBreadBody.GridFilters = [{
            DataField: 'dmoprodbrdprodbrddscr',
            FilterType: 'Column_Filter',
            LogicalOperator: 'Or',
            GridConditions: [{ Condition: 'CONTAINS', ConditionValue: term }]
          },
          {
            DataField: 'dmoprodbrdprodbrdcode',
            FilterType: 'Column_Filter',
            LogicalOperator: 'Or',
            GridConditions: [{ Condition: 'CONTAINS', ConditionValue: term }]
          }];
          return this.listviewService.GridDatalmk(this.queryBreadBody)
            .pipe(
              tap(res => this.breadData = res.Data),
              map((res: any) => res.Data
                // .filter(v => v.dmoprodbrdprodbrddscr.toLowerCase().indexOf(term.toLowerCase()) > -1)
                .map(item => item.dmoprodbrdprodbrddscr)
              ));
        }
      }
      )
    );
  }

  ProductSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());
    return debouncedText$.pipe(
      switchMap(term => {
        if (term === '' || term.length <= 1) {
          return [];
        } else {
          this.queryProductBody.GridFilters = [];
          this.queryProductBody.GridFilters = [{
            DataField: 'dmoproductproddscr',
            FilterType: 'Column_Filter',
            LogicalOperator: 'Or',
            GridConditions: [{ Condition: 'CONTAINS', ConditionValue: term }]
          },
          {
            DataField: 'dmoproductprodcode',
            FilterType: 'Column_Filter',
            LogicalOperator: 'Or',
            GridConditions: [{ Condition: 'CONTAINS', ConditionValue: term }]
          }];
          return this.listviewService.GridDatalmk(this.queryProductBody)
            .pipe(
              tap(res => this.ProductData = res.Data),
              map((res: any) => res.Data
                // .filter(v => v.dmoproductproddscr.toLowerCase().indexOf(term.toLowerCase()) > -1)
                .map(item => item.dmoproductproddscr)
              ));
        }
      }
      )
    );
  }

  branchSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());
    return debouncedText$.pipe(
      switchMap(term => {
        if (term === '' || term.length <= 2) {
          return [];
        } else {
          return this.getBranchData(term)
            .pipe(
              tap(res => this.BranchData = res.Data),
              map((res: any) => res.Data
              ));
        }
      }
      )
    );
  }


  constructor(
    private listviewService: ListviewService,
    private apiESaleyardService: ApiESaleyardService
  ) { }

  vendorIdSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());

    return debouncedText$.pipe(
      switchMap(term =>
        term != '' || term.length > 2
          ? this.getVendorData(term, "VendorId")
            .pipe(
              tap(res => this.vendorData = res.Data),
              map((res: any) => res.Data
                .map(item => item.dmocustmstrsapno)
              ))
          : []
      )
    );
  }

  vendorNameSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());

    return debouncedText$.pipe(
      switchMap(term =>
        term === '' || term.length<=2
          ? []
          : this.getVendorData(term,"VendorName")
            .pipe(
              tap(res => this.vendorData = res.Data),
              map((res: any) => res.Data
                .filter(v => v.dmocustmstrcustname1.toLowerCase().indexOf(term.toLowerCase()) > -1)
                .map(item => item.dmocustmstrcustname1)
              ))
      )
    );
  }


  buyerIdSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());

    return debouncedText$.pipe(
      switchMap(term =>
        term === '' || term.length<=2
          ? []
          : this.getBuyerData(term,"BuyerId")
            .pipe(
              tap(res => this.buyerData = res.Data),
              map((res: any) => res.Data
                .filter(v => v.dmocustmstrsapno.toLowerCase().indexOf(term.toLowerCase()) > -1)
                .map(item => item.dmocustmstrsapno)
              ))
      )
    );
  }

  buyerNameSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());

    return debouncedText$.pipe(
      switchMap(term =>
        term === '' || term.length<=2
          ? []
          : this.getBuyerData(term,"BuyerName")
            .pipe(
              tap(res => this.buyerData = res.Data),
              map((res: any) => res.Data
                .filter(v => v.dmocustmstrcustname1.toLowerCase().indexOf(term.toLowerCase()) > -1)
                .map(item => item.dmocustmstrcustname1)
              ))
      )
    );
  }

  productSearch = (text$: Observable<string>, transactionId: string) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());

    return debouncedText$.pipe(
      switchMap(term =>
        term === '' || term.length<=0
          ? []
          : this.apiESaleyardService.post(`crmlot/lotProduct/${encodeURIComponent(transactionId)}`)
            .pipe(
              tap(res => this.productData = res.ProductMasterData),
              map((res: any) => res.ProductMasterData
                .filter(v => v.PMProductCode.toLowerCase().indexOf(term.toLowerCase()) > -1)
                .map(item => item.PMProductCode)
              ))
      )
    );
  }

  breedSearch = (text$: Observable<string>, transactionId: string) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());

    return debouncedText$.pipe(
      switchMap(term =>
        term === '' || term.length<=0
          ? []
          : this.apiESaleyardService.post(`crmlot/lotProduct/${encodeURIComponent(transactionId)}`)
            .pipe(
              map((res: any) => res.productBreedData
                .filter(v => v.PBProductBreedCode.toLowerCase().indexOf(term.toLowerCase()) > -1)
                .map(item => item.PBProductBreedCode)
              ))
      )
    );
  }
  vendorPicSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());

    return debouncedText$.pipe(
      switchMap(term =>
        term != '' || term.length > 2
          ? this.getVendorPicData(term)
            .pipe(
              tap(res => this.vendorPICData = res.Data),
              map((res: any) => res.Data
                .map(item => item.dmocuspiccustpic)
              ))
          : []
      )
    );
  }
  buyerPicSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());

    return debouncedText$.pipe(
      switchMap(term =>
        term != '' || term.length > 2
          ? this.getBuyerPicData(term)
            .pipe(
              tap(res => this.buyerPICData = res.Data),
              map((res: any) => res.Data
                .map(item => item.dmocuspiccustpic)
              ))
          : []
      )
    );
  }

  getVendorPIC(vendorId: string): Observable<any> {
    const queryBody = {
      PageSize: -1,
      PageNumber: -1,
      SortColumn: 'dmocuspiccustpic',
      SortOrder: 'Asc',
      ProcessName: 'LMKConfigCustomerPIC',
      TimeZone: 0,
      ColumnList: 'dmocuspiccustpic',
      ViewName: 'View 1',
      GridFilters: [
        {
          GridConditions: [
            {
              Condition: 'EQUAL',
              ConditionValue: vendorId
            }
          ],
          DataField: 'dmocuspiccpicsapno',
          LogicalOperator: 'Or',
          FilterType: 'Column_Filter'
        },{
          GridConditions: [{
            Condition: 'EQUAL',
            ConditionValue: 'Active'
          }],
          DataField: 'WFOSDISPNAME',
          LogicalOperator: 'Or',
          FilterType: 'Column_Filter',          
        }
      ]
    };

    return this.listviewService.GridData(queryBody)
      .pipe(
        map(res => res.Data)
      );
  }

  getBuyerPIC(buyerId: string): Observable<any> {
    const queryBody = {
      PageSize: -1,
      PageNumber: -1,
      SortColumn: 'dmocuspiccustpic',
      SortOrder: 'Asc',
      ProcessName: 'LMKConfigCustomerPIC',
      TimeZone: 0,
      ColumnList: 'dmocuspiccustpic',
      ViewName: 'View 1',
      GridFilters: [
        {
          GridConditions: [
            {
              Condition: 'EQUAL',
              ConditionValue: buyerId
            }
          ],
          DataField: 'dmocuspiccpicsapno',
          LogicalOperator: 'Or',
          FilterType: 'Column_Filter'
        }
      ]
    };

    return this.listviewService.GridData(queryBody)
      .pipe(
        map(res => res.Data)
      );
  }

  getFeesCharges() {
    return this.apiESaleyardService.post(`crmlot/getFeesCharges`);
  }

  getLotProduct(transactionId: string) {
    return this.apiESaleyardService.post(`crmlot/lotProduct/${encodeURIComponent(transactionId)}`);
  }
  lotNavigation(parentTransctionId: any, navigationNo: any) {
    return this.apiESaleyardService.post(`crmlot/lotNavigation/${parentTransctionId}/${navigationNo}`, null);
  }
  getsaleStageData(parentTransctionId: any) {
    return this.apiESaleyardService.get(`crmsales/GetLotStatusUsingParentTrnsctnID/${encodeURIComponent(parentTransctionId)}`);
  }
  conjuctionalAgentSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());

    return debouncedText$.pipe(
      switchMap(term =>
        term !='' || term.length>2          
          ? this.getCongunctionBody(term)
            .pipe(
              tap(res => this.vendorData = res.Data),
              map((res: any) => res.Data
                .map(item => item.dmocustmstrcustname1)
              ))
              : []
      )
    );
  }

  createNewAlias(alias:any,SAPNo:any,Saleyard:any){
    return this.apiESaleyardService.get(`crmlot/createNewAlias/${alias}/${SAPNo}/${Saleyard}`, null);
  }

  getSalyardCodeByName(SaleYardName:any){
    return this.apiESaleyardService.get(`crmlot/GetSaleYardCodeByName/${encodeURIComponent(SaleYardName)}`, null);
  }

  ValidateAlias(aliasType:any,SAPNo:any,alias:any,saleYardCode:any){
    return this.apiESaleyardService.get(`crmlot/ValidateAlias/${aliasType}/${SAPNo}/${alias}/${saleYardCode}`, null);
  }
   validateLotSummaryRecord(data)
  {
    return this.apiESaleyardService.post('crmlot/ValidateLotSummaryRecord', data);
  }

  getMaxLotIDBasedOnPrntTrnsctionId(parentTransctionId: any) {
    return this.apiESaleyardService.get(`crmlot/getMaxLotIDBasedOnPrntTrnsctionId/${encodeURIComponent(parentTransctionId)}`);
  }

 BulkUpdateVenderInformation(data) {    
    return this.apiESaleyardService.post('CRMLot/BulkUpdateVendorInformation', data);
  }

  BulkUpdateBuyerInformation(data) {    
    return this.apiESaleyardService.post('CRMLot/BulkUpdateBuyerInformation', data);
  }
  
  agencySearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());
    return debouncedText$.pipe(
      switchMap(term =>
        term !== '' && term.length > 2
          ? this.GetAgentAgencyList('Agency', term.toString(), this.sapNo)
          : []
      )
    );
  }

  agentSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(500), distinctUntilChanged());
    return debouncedText$.pipe(
      switchMap(term =>
        term !== '' && term.length > 2
          ? this.GetAgentAgencyList('Agent', term.toString(), this.sapNo)
          : []
      )
    );
  }

  GetAgentAgencyList(Type: any, term: any, AgentAgencySap: any) {
    if (AgentAgencySap === undefined) {
      AgentAgencySap = '';
    }
    return this.apiESaleyardService.get(`crmlot/GetAgentAgencyList/${Type}/${term}/${AgentAgencySap}`, null);
  }

  getBuyerRebateAgencyList(LotTransactionID: string) {
    const bodyData: any = {
      LotTransactionID
    };
    return this.apiESaleyardService.post('crmlot/getBuyerRebateAgencyList', bodyData);
  }

  getBuyerRebateAgentList(LotTransactionID: string, AgencySapNo: string = '') {
    const bodyData: any = {
      LotTransactionID,
      AgencySapNo
    };
    return this.apiESaleyardService.post('crmlot/getBuyerRebateAgentList', bodyData);
  }

  createDuplicateLot(TransctionId: any) {
    return this.apiESaleyardService.post(`crmlot/createDuplicateLot/${encodeURIComponent(TransctionId)}`);
  }

}
