import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-bulk-upload-lot',
  templateUrl: './bulk-upload-lot.component.html',
  styleUrls: ['./bulk-upload-lot.component.scss']
})
export class BulkUploadLotComponent implements OnInit {
  configLot = {
    transactionIds: [],
    selectedLots: [],
    saleId: '',
    processName: '',
    stage: '',
  }


  constructor(public activeModal: NgbActiveModal) { }

  ngOnInit() {}

}
