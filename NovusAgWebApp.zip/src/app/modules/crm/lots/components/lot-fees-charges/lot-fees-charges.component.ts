import { Component, Input, Output, EventEmitter, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable, of, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, map, switchMap, tap } from 'rxjs/operators';
import { NgbTypeaheadSelectItemEvent, NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { ApiESaleyardService, ListviewService, SaleStage } from '@app/core';
import { MessageComponent } from '@app/shared';

@Component({
  selector: 'app-lot-fees-charges',
  templateUrl: './lot-fees-charges.component.html',
  styleUrls: ['./lot-fees-charges.component.scss']
})
export class LotFeesChargesComponent implements AfterViewInit {

  @Input() stage: SaleStage;
  @Output() calcLotFeesChargesManual = new EventEmitter<any>();
  @ViewChild('rateInput', {static: false}) rateInput: ElementRef;

  @Input() forBulkUpdate = false;
  @Input() transactionId: string;
  feesChargesDDL = [];
  data = [];
  newFeesCharges = {
    FeeTransactionID: null,
    FeeCode: '',
    Description: '',
    ChargedTo: '',
    CalculationType: '',
    Rate: null,
    Cost: null,
    ThirdPartyAccount: '',
    ThirdPartyName: '',
    ReferenceText: '',
    DescriptionOverrideAllowed: 'Yes',
    BulkChangeAllowed: 'Yes',
    RateOverride: 'Yes',
    ValidFor3rdParty: 'Yes',
    IsManual: true,
    IsHidden: false
  };
  newRow = {...this.newFeesCharges};
  rateChanged$: Subject<any> = new Subject<any>();
  vendorData = [];
  submitted = false;

  get isReversal() {
    return this.stage === SaleStage.ReversalProcess;
  }

  get isFinalised() {
    return this.stage === SaleStage.Finalised || this.stage === SaleStage.ReversalCompleted;
  }

  constructor(
    private modalService: NgbModal,
    private route: ActivatedRoute,
    private apiESaleyardService: ApiESaleyardService,
    private listviewService: ListviewService
  ) { }

  ngAfterViewInit() {
    if (this.forBulkUpdate) {
      this.apiESaleyardService.post(`crmlot/getLotFeesCharges?transactionID=${this.transactionId}&forBulkChange=true`).subscribe(data => {
        this.data = data;
      });
      this.apiESaleyardService.post('crmlot/getFeesCharges?bulkChangeAllowed=yes').subscribe(data => {
        this.feesChargesDDL = data;
      });
    } else {
      this.route.paramMap.subscribe(params => {
        this.transactionId = params.get('id');
        if (this.transactionId !== 'new') {
          this.apiESaleyardService.post(`crmlot/getLotFeesCharges?transactionID=${this.transactionId}`).subscribe(data => {
            this.data = data;
          });
        }
      });
      this.apiESaleyardService.post('crmlot/getFeesCharges').subscribe(data => {
        this.feesChargesDDL = data;
      });
    }

    this.rateChanged$
      .pipe(
        debounceTime(500)
      ).subscribe((item: any) => {
        if (item.FeeTransactionID) {
          this.submitted = true;
          if (!this.forBulkUpdate) {
            this.calcManualFeesCharges(item);
          }
        }
      });
  }

  calcManualFeesCharges(item: any) {
    this.calcLotFeesChargesManual.emit({
      FeeTransactionID: item.FeeTransactionID,
      Rate: item.Rate
    });
  }

  feeChargesSearch = (text$: Observable<string>) =>
    text$.pipe(
      debounceTime(200),
      distinctUntilChanged(),
      map((term: string) => term === '' ? []
        : this.feesChargesDDL
          .map(item => item.Description)
          .filter(v => v.toLowerCase().indexOf(term.toLowerCase()) > -1))
    )

  setLotFeesChargesOption(event: NgbTypeaheadSelectItemEvent, row: any, isNew: boolean, index?: number) {
    row.IsManual = true;
    for (const item of this.feesChargesDDL) {
      if (item.Description === event.item) {
        if (isNew) {
          row.FeeTransactionID = item.FeeTransactionID;
          row.FeeCode = item.FeeCode;
          row.Description = item.Description;
          if (this.forBulkUpdate) {
            Object.assign(row, item);
          } else {
            this.calcManualFeesCharges(row);
          }
        } else {
          // create a new row and delete existing row
          const newRow: any = JSON.parse(JSON.stringify(row));
          newRow.FeeTransactionID = item.FeeTransactionID;
          newRow.FeeCode = item.FeeCode;
          newRow.Description = item.Description;
          this.data.splice(index, 0, newRow);

          row.IsDeleted = true;
        }
        return;
      }
    }
  }

  delete_item(item: any) {
    const modalMsgRef = this.modalService.open(MessageComponent, { backdrop: 'static', windowClass: 'Confirm_popup' });
    const modalInstance: MessageComponent = modalMsgRef.componentInstance;
    modalInstance.MessagePopup = modalMsgRef;
    modalInstance.IsConfirmation = true;
    modalInstance.Caller = this;
    modalInstance.MessageHeader = 'Confirmation Message';
    modalInstance.Message = 'Are you sure you want to delete this record?';
    modalInstance.ButtonText = 'Yes';
    modalInstance.IsDefaultView = true;
    modalInstance.CallBackMethod = () => {
      item.IsDeleted = true;
      item.IsManual = true;
    };
  }

  save_new_item() {
    if (this.newRow.Rate == null || parseFloat(this.newRow.Rate) === 0) {
      this.submitted = true;
    } else {
      this.newRow.DescriptionOverrideAllowed = 'No';
      this.newRow.RateOverride = 'No';
      this.newRow.ValidFor3rdParty = 'No';
      this.data.push(this.newRow);
      this.newRow = { ...this.newFeesCharges };
      this.submitted = false;
    }
  }

  rateChanged(item: any) {
    this.rateChanged$.next(item);
  }

  public onFocus(e: Event): void {
    e.stopPropagation();
    setTimeout(() => {
      const inputEvent: Event = new Event('input');
      e.target.dispatchEvent(inputEvent);
    }, 0);
  }

  getVendorData(term: any, column: string) {
    const queryVendorBody = {
      PageSize: 20,
      PageNumber: 0,
      SortColumn: column,
      SortOrder: 'Asc',
      ProcessName: 'LMKMSTRCustomer',
      TimeZone: 0,
      ColumnList: 'dmocustmstrsapno,dmocustmstrcustname1',
      ViewName: 'View 1',
      GridFilters: [
        {
          GridConditions: [
            {
              Condition: 'CONTAINS',
              ConditionValue: '3rd Party'
            }
          ],
          DataField: 'dmocustmstrcusttype',
          LogicalOperator: 'Or',
          FilterType: 'Column_Filter'
        }, {
          GridConditions: [
            {
              Condition: 'CONTAINS',
              ConditionValue: term
            }
          ],
          DataField: column,
          LogicalOperator: 'Or',
          FilterType: 'Column_Filter'
        }
      ]
    };
    return this.listviewService.GridData(queryVendorBody);
  }

  selectVendor(event: NgbTypeaheadSelectItemEvent, row: any, field: string) {
    row.IsManual = true;
    for (const vendor of this.vendorData) {
      if (vendor[field] === event.item) {
        row.ThirdPartyAccount = vendor.dmocustmstrsapno;
        row.ThirdPartyName = vendor.dmocustmstrcustname1;
        return;
      }
    }
  }

  thirdPartyAccountSearch = (text$: Observable<string>) => {
    return text$.pipe(
      debounceTime(500),
      distinctUntilChanged(),
      switchMap(term =>
        term !== '' &&  term.length > 2
          ? this.getVendorData(term, 'dmocustmstrsapno')
            .pipe(
              tap((res: any) => this.vendorData = res.Data),
              map((res: any) => res.Data.map(item => item.dmocustmstrsapno))
            )
          : of([])
      )
    );
  }

  thirdPartyAccountNameSearch = (text$: Observable<string>) => {
    return text$.pipe(
      debounceTime(500),
      distinctUntilChanged(),
      switchMap(term =>
        term !== '' &&  term.length > 2
          ? this.getVendorData(term, 'dmocustmstrcustname1')
            .pipe(
              tap((res: any) => this.vendorData = res.Data),
              map((res: any) => res.Data.map(item => item.dmocustmstrcustname1))
            )
          : of([])
      )
    );
  }

}
