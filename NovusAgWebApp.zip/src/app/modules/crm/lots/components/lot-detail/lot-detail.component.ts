import { Component, OnInit, Input, ChangeDetectorRef, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { NgbTypeaheadSelectItemEvent, NgbModal } from '@ng-bootstrap/ng-bootstrap';

import {
  ApplicationService,
  AuthenticationService,
  FormViewService,
  DmoControlService,
  ApiESaleyardService,
  MessageService,
  SaleStage
} from '@app/core';
import { MessageComponent } from '@app/shared';

import { LotSearchService } from '../../services/lot-search.service';
import { SalesService } from '@app/modules/crm/sales/services/sales.service';
import { LotService } from '../../services/lot.service';
import { LotFeesChargesComponent } from '../lot-fees-charges/lot-fees-charges.component';
import { IfStmt } from '@angular/compiler';
import { UserDetail } from '@app/core/models/user-detail';

@Component({
  selector: 'app-lot-detail',
  templateUrl: './lot-detail.component.html',
  styleUrls: ['./lot-detail.component.scss']
})
export class LotDetailComponent implements OnInit {

  @Input() processName: string;
  @Input() stage: SaleStage;
  @Input() parentData: any;

  @ViewChild('vendorName', { static: false }) vendorName: ElementRef;
  @ViewChild('vendorId', { static: false }) vendorId: ElementRef;
  @ViewChild('buyerId', { static: false }) buyerId: ElementRef;
  @ViewChild('buyerName', { static: false }) buyerName: ElementRef;

  @ViewChild('productName', { static: false }) productName: ElementRef;
  @ViewChild('productDescription', { static: false }) productDescription: ElementRef;
  @ViewChild('breedName', { static: false }) breedName: ElementRef;

  @ViewChild(LotFeesChargesComponent, { static: false })
  private lotFeesChargesGrid: LotFeesChargesComponent;

  lotDetailForm: FormGroup;
  parentId: string;
  transactionId: string;
  isNew = false;
  submitted = false;
  currentUser: any;
  BMJSON: any = {};
  applicationData: any = {};
  lotInformations: any = {};
  checkboxTypeControls = [
    'DMOLot_BInfo_SetIntBBReb',
    'DMOLot_LotInfo_HGP',
    'DMOLot_LotInfo_TransClaim'
  ];
  // for vendor fields
  vendorBranchOptions = [];
  vendorPICOptions = [];
  DMOLot_Qnty: any;
  DMOLot_PriceHead: any;
  DMOLOT_PriceKg: any;
  DMOLOT_Weight: any;
  DMOLOT_TURNOVER: any;
  GstRate = 10;
  // for buyer fields
  buyerBranchOptions = [];
  buyerPICOptions = [];
  isLotSubmit = false;
  Product: any;
  ValidateVendorIdMessage: string;
  ValidateVendorNameMessage: string;
  ValidateBuyerIdMessage: string;
  ValidateBuyerNameMessage: string;
  ValidateProductNameMessage: string;
  ValidateProductDescriptionMessage: string;
  ValidateBreedMessage: string;
  flag = false;
  isUnsoldLots = false;
  isFeesCalculated = false;
  isCalcFeesFieldsChanged = false;
  isCalcBuyerBranchRebate = false;
  originalQuantityValue: any;
  isDdl = false;
  isDdlBuyer = false;
  formatter = (x: any) => x.dmobranchbrname;

  get isReversal() {
    return this.stage === SaleStage.ReversalProcess;
  }

  get isFinalised() {
    return this.stage === SaleStage.Finalised || this.stage === SaleStage.ReversalCompleted;
  }

  constructor(
    private modalService: NgbModal,
    private cdr: ChangeDetectorRef,
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private toastrService: ToastrService,
    private authenticationService: AuthenticationService,
    private applicationService: ApplicationService,
    private formViewService: FormViewService,
    private lotservice: LotSearchService,
    private dmoControlService: DmoControlService,
    private lotSearchService: LotSearchService,
    private saleServices: SalesService,
    private lot: LotService,
    private apiESaleyardService: ApiESaleyardService,
    private msg: MessageService,
    private userDetail: UserDetail
  ) { }

  ngOnInit() {
    this.currentUser = this.userDetail;
    this.route.paramMap.subscribe(params => {
      this.parentId = params.get('sale_id');
      this.transactionId = params.get('id');
      if (this.transactionId === 'new') {
        this.isNew = true;
      } else {
        this.isNew = false;
      }
      this.initValues();
      this.lotDetailForm = this.fb.group({
        DMOLot_VInfo_VendorId: [null],
        DMOLot_VInfo_VendorNam: [null],
        DMOLot_VInfo_VendorBrc: [null],
        DMOLot_VInfo_VendorPic: [null],
        DMOLot_VInfo_GstReg: [null],
        DMOLot_VInfo_AcSaleRef: [null],
        DMOLot_BInfo_BuyerId: [null],
        DMOLot_BInfo_BuyerName: [null],
        DMOLot_BInfo_BuyerBrc: [null],
        DMOLot_BInfo_BuyerPic: [null],
        DMOLot_BInfo_InvoiceRef: [null],
        DMOLot_BInfo_SetIntBBReb: [false],
        DMOLot_BInfo_Rate: [null],
        DMOLot_LotInfo_LotNum: [null],
        DMOLot_LotInfo_Qnty: [null],
        DMOLot_LotInfo_Pdct: [null],
        DMOLot_LotInfo_ProdDesc: [null],
        DMOLot_LotInfo_Brd: [null],
        DMOLot_LotInfo_Price$PHd: [null],
        DMOLot_LotInfo_PriceCPKg: [null],
        DMOLot_LotInfo_WtKg: [null],
        DMOLot_LotInfo_TurnovAUD: [null],
        DMOLot_LotInfo_Sex: [null],
        DMOLot_LotInfo_PaintMk: [null],
        DMOLot_LotInfo_ContractId: [null],
        DMOLot_LotInfo_HGP: [false],
        DMOLot_LotInfo_TransClaim: [false],
        DMOLot_LotInfo_LotID: [null],
        DMOLot_LotInfo_GST: [null],
        DMOLot_LotInfo_TurnoverGs: [null],
        DMOLot_LotInfo_PriceType: [null],
        DMOLot_LotInfo_GSTRate: [null]
      });
      this.lotDetailForm.addControl('DMOLot_LotInfo_TransClaim', new FormControl(false));
      this.getGstRate();
      if (!this.isNew) {
        this.setValues();
      } else {
        this.onChanges();
      }

      if (this.isReversal) {
        this.lotDetailForm.disable();
        this.lotDetailForm.controls['DMOLot_VInfo_AcSaleRef'].enable();
        this.lotDetailForm.controls['DMOLot_BInfo_InvoiceRef'].enable();
        this.lotDetailForm.controls['DMOLot_LotInfo_Qnty'].enable();
        this.lotDetailForm.controls['DMOLot_LotInfo_ProdDesc'].enable();
      } else if (this.isFinalised) {
        this.lotDetailForm.disable();
      }
    });
  }

  initValues() {
    this.submitted = false;
    this.isLotSubmit = false;
    this.flag = false;
    this.isUnsoldLots = false;
    this.isFeesCalculated = false;
    this.isCalcFeesFieldsChanged = false;
    this.originalQuantityValue = null;
  }

  public onFocus(e: Event): void {
    e.stopPropagation();
    setTimeout(() => {
      const inputEvent: Event = new Event('input');
      e.target.dispatchEvent(inputEvent);
    }, 0);
  }


  vendorIdSearch = (text$: Observable<string>) => {
    return this.lotSearchService.vendorIdSearch(text$);
  }

  vendorNameSearch = (text$: Observable<string>) => {
    return this.lotSearchService.vendorNameSearch(text$);
  }

  selectVendor(event: NgbTypeaheadSelectItemEvent, field: string) {
    this.lotSearchService.vendorData.forEach(vendor => {
      if (vendor[field] === event.item) {
        this.lotDetailForm.get('DMOLot_VInfo_GstReg').patchValue(vendor.dmocustmstrgstflg);
        this.lotDetailForm.get('DMOLot_VInfo_VendorNam').patchValue(vendor.dmocustmstrcustname1);
        this.lotDetailForm.get('DMOLot_VInfo_VendorId').patchValue(vendor.dmocustmstrsapno);

        this.lotDetailForm.get('DMOLot_VInfo_VendorBrc').patchValue('');
        this.vendorBranchOptions = [];

        if (vendor.dmocustmstracttype === 'Livestock') {
          this.vendorBranchOptions.push({
            ValueField: vendor.dmocustmstrlstkbranch.substr(vendor.dmocustmstrlstkbranch.indexOf('(') + 1).replace(')', ''),
            TextField: vendor.dmocustmstrlstkbranch
          });
        } else {
          this.vendorBranchOptions.push({
            ValueField: vendor.dmocustmstrcustdombranch.substr(vendor.dmocustmstrcustdombranch.indexOf('(') + 1).replace(')', ''),
            TextField: vendor.dmocustmstrcustdombranch
          });
        }
        if (this.vendorBranchOptions.length < 1) {
          this.isDdl = false;
        } else {
          this.isDdl = true;
          this.lotDetailForm.get('DMOLot_VInfo_VendorBrc').patchValue(this.vendorBranchOptions[0].ValueField);
        }

        this.lotDetailForm.controls.DMOLot_VInfo_GstReg.markAsDirty();
        this.lotDetailForm.controls.DMOLot_VInfo_GstReg.markAsTouched();
        this.lotDetailForm.controls.DMOLot_VInfo_VendorNam.markAsDirty();
        this.lotDetailForm.controls.DMOLot_VInfo_VendorNam.markAsTouched();
        this.lotDetailForm.controls.DMOLot_VInfo_VendorId.markAsDirty();
        this.lotDetailForm.controls.DMOLot_VInfo_VendorId.markAsTouched();
        this.lotDetailForm.controls.DMOLot_VInfo_VendorBrc.markAsDirty();
        this.lotDetailForm.controls.DMOLot_VInfo_VendorBrc.markAsTouched();


        this.getVendorPIC(vendor.dmocustmstrsapno);
      }
    });
  }

  getVendorPIC(vendorId: string) {
    this.lotSearchService.getVendorPIC(vendorId).subscribe(response => {
      this.lotDetailForm.get('DMOLot_VInfo_VendorPic').patchValue('');
      this.vendorPICOptions = [];
      response.forEach(item => this.vendorPICOptions.push(item.dmocuspiccustpic));
      if (this.vendorPICOptions.length === 1) {
        this.lotDetailForm.get('DMOLot_VInfo_VendorPic').patchValue(this.vendorPICOptions[0]);
      }
      this.lotDetailForm.controls.DMOLot_VInfo_VendorPic.markAsDirty();
      this.lotDetailForm.controls.DMOLot_VInfo_VendorPic.markAsTouched();
    });
  }

  buyerIdSearch = (text$: Observable<string>) => {
    return this.lotSearchService.buyerIdSearch(text$);
  }

  buyerNameSearch = (text$: Observable<string>) => {
    return this.lotSearchService.buyerNameSearch(text$);
  }


  selectBuyer(event: NgbTypeaheadSelectItemEvent, field: string) {
    this.lotSearchService.buyerData.forEach(buyer => {
      if (buyer[field] === event.item) {
        this.lotDetailForm.get('DMOLot_BInfo_BuyerName').patchValue(buyer.dmocustmstrcustname1);
        this.lotDetailForm.get('DMOLot_BInfo_BuyerId').patchValue(buyer.dmocustmstrsapno);

        this.lotDetailForm.get('DMOLot_BInfo_BuyerBrc').patchValue('');
        this.buyerBranchOptions = [];

        if (buyer.dmocustmstracttype === 'Livestock') {
          this.buyerBranchOptions.push({
            ValueField: buyer.dmocustmstrlstkbranch.substr(buyer.dmocustmstrlstkbranch.indexOf('(') + 1).replace(')', ''),
            TextField: buyer.dmocustmstrlstkbranch
          });
        } else {
          this.buyerBranchOptions.push({
            ValueField: buyer.dmocustmstrcustdombranch.substr(buyer.dmocustmstrcustdombranch.indexOf('(') + 1).replace(')', ''),
            TextField: buyer.dmocustmstrcustdombranch
          });
        }
        if (this.buyerBranchOptions.length < 1) {
          this.isDdlBuyer = false;
        } else {
          this.isDdlBuyer = true;
          this.lotDetailForm.get('DMOLot_BInfo_BuyerBrc').patchValue(this.buyerBranchOptions[0].ValueField);
        }

        // if (buyer.dmocustmstracttype === 'Livestock') {
        //   this.buyerBranchOptions.push(buyer.dmocustmstrlstkbranch);
        // } else {
        //   this.buyerBranchOptions.push(buyer.dmocustmstrcustdombranch);
        // }
        // this.lotDetailForm.get('DMOLot_BInfo_BuyerBrc').patchValue(this.buyerBranchOptions[0]);

        this.lotDetailForm.controls.DMOLot_BInfo_BuyerName.markAsDirty();
        this.lotDetailForm.controls.DMOLot_BInfo_BuyerName.markAsTouched();
        this.lotDetailForm.controls.DMOLot_BInfo_BuyerId.markAsDirty();
        this.lotDetailForm.controls.DMOLot_BInfo_BuyerId.markAsTouched();
        this.lotDetailForm.controls.DMOLot_BInfo_BuyerBrc.markAsDirty();
        this.lotDetailForm.controls.DMOLot_BInfo_BuyerBrc.markAsTouched();

        this.getBuyerPIC(buyer.dmocustmstrsapno);
      }
    });
  }

  getBuyerPIC(buyerId: string) {
    this.lotSearchService.getBuyerPIC(buyerId).subscribe(response => {
      this.lotDetailForm.get('DMOLot_BInfo_BuyerPic').patchValue('');
      this.buyerPICOptions = [];
      response.forEach(item => this.buyerPICOptions.push(item.dmocuspiccustpic));
      if (this.buyerPICOptions.length === 1) {
        this.lotDetailForm.get('DMOLot_BInfo_BuyerPic').patchValue(this.buyerPICOptions[0]);
      }
      this.lotDetailForm.controls.DMOLot_BInfo_BuyerPic.markAsDirty();
      this.lotDetailForm.controls.DMOLot_BInfo_BuyerPic.markAsTouched();
    });
  }

  productSearch = (text$: Observable<string>) => {
    return this.lotSearchService.productSearch(text$, this.parentId);
  }

  breedSearch = (text$: Observable<string>) => {
    return this.lotSearchService.breedSearch(text$, this.parentId);
  }

  onChanges() {
    this.lotDetailForm.get('DMOLot_VInfo_VendorBrc').valueChanges
      .subscribe(val => {
        this.isCalcFeesFieldsChanged = true;
      });

    this.lotDetailForm.get('DMOLot_LotInfo_Pdct').valueChanges
      .subscribe(val => {
        this.isCalcFeesFieldsChanged = true;
      });

    this.lotDetailForm.get('DMOLot_LotInfo_TurnovAUD').valueChanges
      .subscribe(val => {
        this.isCalcFeesFieldsChanged = true;
      });


    this.lotDetailForm.get('DMOLot_LotInfo_Qnty').valueChanges
      .pipe(
        debounceTime(200),
        distinctUntilChanged()
      )
      .subscribe(val => {
        if (this.isReversal && +val > this.originalQuantityValue) {
          this.msg.showMessage('Warning', {body: 'The amount entered should not be greater than the original quantity'});
          // this.msg.showErrorMessage('The amount entered should not be greater than the original quantity.', 'Message', 'Ok', null, false, true, false, '');
          this.lotDetailForm.get('DMOLot_LotInfo_Qnty').patchValue(this.originalQuantityValue);
        } else {
          this.isCalcFeesFieldsChanged = true;
        }
      });

    this.lotDetailForm.get('DMOLot_LotInfo_WtKg').valueChanges
      .subscribe(val => {
        this.isCalcFeesFieldsChanged = true;
      });

    this.lotDetailForm.get('DMOLot_LotInfo_TransClaim').valueChanges
      .subscribe(checked => {
        if (checked) {
          this.lotDetailForm.addControl('DMOLot_LotInfo_TrnsClmBy', new FormControl(null, Validators.required));
          this.lotDetailForm.addControl('DMOLot_LotInfo_TrnsClmQnt', new FormControl(null, Validators.required));
          this.lotDetailForm.addControl('DMOLot_LotInfo_TrnsClmVal', new FormControl(null, Validators.required));
          this.lotDetailForm.addControl('DMOLot_LotInfo_TrnsClmRsn', new FormControl(null, Validators.required));
        } else {
          this.lotDetailForm.removeControl('DMOLot_LotInfo_TrnsClmBy');
          this.lotDetailForm.removeControl('DMOLot_LotInfo_TrnsClmQnt');
          this.lotDetailForm.removeControl('DMOLot_LotInfo_TrnsClmVal');
          this.lotDetailForm.removeControl('DMOLot_LotInfo_TrnsClmRsn');
        }
      });

    this.lotDetailForm.get('DMOLot_LotInfo_Price$PHd').valueChanges
      .pipe(
        debounceTime(200),
        distinctUntilChanged()
      )
      .subscribe(val => {
        if (val) {
          this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').markAsDirty();
          this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').clearValidators();
          this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').updateValueAndValidity();
        } else {
          this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').setValidators([Validators.required]);
          this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').updateValueAndValidity();
        }

        this.isCalcFeesFieldsChanged = true;
      });
    this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').valueChanges
      .pipe(
        debounceTime(200),
        distinctUntilChanged()
      )
      .subscribe(val => {
        if (val) {
          this.lotDetailForm.get('DMOLot_LotInfo_Price$PHd').markAsDirty();
          this.lotDetailForm.get('DMOLot_LotInfo_Price$PHd').clearValidators();
          this.lotDetailForm.get('DMOLot_LotInfo_Price$PHd').updateValueAndValidity();
        } else {
          this.lotDetailForm.get('DMOLot_LotInfo_Price$PHd').setValidators([Validators.required]);
          this.lotDetailForm.get('DMOLot_LotInfo_Price$PHd').updateValueAndValidity();
        }

        this.isCalcFeesFieldsChanged = true;
      });

    this.lotDetailForm.get('DMOLot_BInfo_SetIntBBReb').valueChanges
      .subscribe(val => {
        this.isCalcBuyerBranchRebate = true;
      });
    this.lotDetailForm.get('DMOLot_BInfo_Rate').valueChanges
      .subscribe(val => {
        this.isCalcBuyerBranchRebate = true;
      });
    this.lotDetailForm.get('DMOLot_VInfo_VendorId').valueChanges
      .subscribe(val => {
        this.isCalcBuyerBranchRebate = true;
      });
    this.lotDetailForm.get('DMOLot_VInfo_VendorNam').valueChanges
      .subscribe(val => {
        this.isCalcBuyerBranchRebate = true;
      });
    this.lotDetailForm.get('DMOLot_BInfo_BuyerId').valueChanges
      .subscribe(val => {
        this.isCalcBuyerBranchRebate = true;
      });
    this.lotDetailForm.get('DMOLot_BInfo_BuyerName').valueChanges
      .subscribe(val => {
        this.isCalcBuyerBranchRebate = true;
      });
    this.lotDetailForm.get('DMOLot_BInfo_BuyerBrc').valueChanges
      .subscribe(val => {
        this.isCalcBuyerBranchRebate = true;
      });
  }

  setValues() {
    this.formViewService.getBmWfJson(this.processName, 'AdminView', this.transactionId).subscribe(response => {
      this.BMJSON = response.BM.BusinessModelObjectGroup.AdminView;
      this.applicationService.getApplicationData(null, null, 'AdminView', this.transactionId).subscribe(data => {
        this.applicationData = data;
        this.Product = data.DataInformation.dmolotlotinfopdct != undefined && data.DataInformation.dmolotlotinfopdct.DMOVAL != "" ? data.DataInformation.dmolotlotinfopdct.DMOVAL : null;
        this.lotservice.currentLotId = this.applicationData.DataInformation.dmolotlotinfolotid != null ? this.applicationData.DataInformation.dmolotlotinfolotid.DMOVAL : null;
        this.BMJSON.List.forEach(bmoGuid => {
          if (this.BMJSON.BusinessModelObjects[bmoGuid].DisplayName === 'Lot Details') {
            this.BMJSON.BusinessModelObjects[bmoGuid].List.forEach(dmogGuid => {
              this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].List.forEach(rowID => {
                this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].Rows[rowID].Columns.forEach(objCOLUMN => {
                  objCOLUMN.List.forEach(dmoGUID => {
                    if (this.applicationData.DataInformation[dmoGUID]) {
                      this.lotInformations[objCOLUMN.DataModelObjects[dmoGUID].Name] = this.applicationData.DataInformation[dmoGUID].DMOVAL.indexOf('~~~') ? this.applicationData.DataInformation[dmoGUID].DMOVAL.split('~~~')[0] : this.applicationData.DataInformation[dmoGUID].DMOVAL;
                    }
                  });
                });
              });
            });
          }
        });

        Object.keys(this.lotInformations).forEach(name => {
          if (this.lotDetailForm.controls[name]) {
            if (this.checkboxTypeControls.includes(name)) {
              this.lotDetailForm.controls[name].patchValue(this.lotInformations[name] === 'true');
            } else {
              this.lotDetailForm.controls[name].patchValue(this.lotInformations[name]);
            }
          }
        });

        if (this.lotDetailForm.get('DMOLot_LotInfo_Pdct').value === 'PASC' ||
          this.lotDetailForm.get('DMOLot_LotInfo_Pdct').value === 'PASH' ||
          this.lotDetailForm.get('DMOLot_LotInfo_Pdct').value === 'PASS') {
          this.isUnsoldLots = true;
          this.f.DMOLot_BInfo_BuyerId.disable();
          this.f.DMOLot_BInfo_BuyerName.disable();
          this.f.DMOLot_BInfo_BuyerBrc.disable();
          this.f.DMOLot_BInfo_BuyerPic.disable();
        }

        if (this.isReversal) {
          this.originalQuantityValue = this.lotDetailForm.get('DMOLot_LotInfo_Qnty').value;
        }
        if (this.applicationData.DataInformation && this.applicationData.DataInformation.dmolotvinfovendorbrc !== null) {
          this.lotDetailForm.get('DMOLot_VInfo_VendorBrc').patchValue('');
          const branch = this.applicationData.DataInformation.dmolotvinfovendorbrc.DMOVAL.split('~~~');
          this.vendorBranchOptions = [];
          this.vendorBranchOptions.push({
            ValueField: branch[0],
            TextField: branch[1]
          });
          this.lotDetailForm.get('DMOLot_VInfo_VendorBrc').patchValue(this.vendorBranchOptions[0].ValueField);
          if (this.vendorBranchOptions[0].ValueField !== '') {
            this.isDdl = true;
          }
        }
        if (this.applicationData.DataInformation && this.applicationData.DataInformation.dmolotbinfobuyerbrc !== null) {
          this.lotDetailForm.get('DMOLot_BInfo_BuyerBrc').patchValue('');
          const branch = this.applicationData.DataInformation.dmolotbinfobuyerbrc.DMOVAL.split('~~~');
          this.buyerBranchOptions = [];
          this.buyerBranchOptions.push({
            ValueField: branch[0],
            TextField: branch[1]
          });
          if (this.buyerBranchOptions[0].ValueField !== '') {
            this.isDdlBuyer = true;
          }
          this.lotDetailForm.get('DMOLot_BInfo_BuyerBrc').patchValue(this.buyerBranchOptions[0].ValueField);
        }
        if (this.applicationData.DataInformation && this.applicationData.DataInformation.dmolotlotinfopricetype.DMOVAL == 'c/kg') {
          this.lotDetailForm.get('DMOLot_LotInfo_Price$PHd').disable();
        } else {
          this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').disable();
        }
        this.onChanges();
      });
    });
  }
  getGstRate() {
    this.lot.getGstRate().subscribe(result => {
      this.lotDetailForm.controls.DMOLot_LotInfo_GSTRate.patchValue(result.GSTRate);
    });
  }

  setProductDescription(event: NgbTypeaheadSelectItemEvent) {
    if (event.item === 'PASC' || event.item === 'PASH' || event.item === 'PASS') {
      this.handleUnsoldLots(true);
    } else {
      this.handleUnsoldLots(false);
    }
    this.lotSearchService.productData.forEach(product => {
      if (product.PMProductCode === event.item) {
        this.lotDetailForm.controls.DMOLot_LotInfo_ProdDesc.patchValue(product.PMProductDescription);
        this.lotDetailForm.controls.DMOLot_LotInfo_ProdDesc.markAsDirty();
        this.lotDetailForm.controls.DMOLot_LotInfo_ProdDesc.markAsTouched();
      }
    });
  }

  handleUnsoldLots(isUnsoldLots: boolean) {
    this.isUnsoldLots = isUnsoldLots;
    if (isUnsoldLots) {
      // disable buyer fields
      this.f.DMOLot_BInfo_BuyerId.disable();
      this.f.DMOLot_BInfo_BuyerName.disable();
      this.f.DMOLot_BInfo_BuyerBrc.disable();
      this.f.DMOLot_BInfo_BuyerPic.disable();

      this.f.DMOLot_BInfo_BuyerId.patchValue('');
      this.f.DMOLot_BInfo_BuyerName.patchValue('');
      this.f.DMOLot_BInfo_BuyerBrc.patchValue('');
      this.f.DMOLot_BInfo_BuyerPic.patchValue('');

      // set turnover fields as 0 value
      this.f.DMOLot_LotInfo_TurnovAUD.patchValue(0);
      this.f.DMOLot_LotInfo_GST.patchValue(0);
      this.f.DMOLot_LotInfo_TurnoverGs.patchValue(0);
    } else {
      this.f.DMOLot_BInfo_BuyerId.enable();
      this.f.DMOLot_BInfo_BuyerName.enable();
      this.f.DMOLot_BInfo_BuyerBrc.enable();
      this.f.DMOLot_BInfo_BuyerPic.enable();
    }

    this.f.DMOLot_BInfo_BuyerId.markAsTouched();
    this.f.DMOLot_BInfo_BuyerId.markAsDirty();

    this.f.DMOLot_BInfo_BuyerName.markAsTouched();
    this.f.DMOLot_BInfo_BuyerName.markAsDirty();

    this.f.DMOLot_BInfo_BuyerBrc.markAsTouched();
    this.f.DMOLot_BInfo_BuyerBrc.markAsDirty();

    this.f.DMOLot_BInfo_BuyerPic.markAsTouched();
    this.f.DMOLot_BInfo_BuyerPic.markAsDirty();

    this.f.DMOLot_LotInfo_TurnovAUD.markAsTouched();
    this.f.DMOLot_LotInfo_TurnovAUD.markAsDirty();

    this.f.DMOLot_LotInfo_GST.markAsTouched();
    this.f.DMOLot_LotInfo_GST.markAsDirty();

    this.f.DMOLot_LotInfo_TurnoverGs.markAsTouched();
    this.f.DMOLot_LotInfo_TurnoverGs.markAsDirty();
  }

  accept_only_zero(event) {
    if (this.isUnsoldLots) {
      return event.charCode === 48;
    }
  }

  ValidateAlphanumeric(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode > 47 && charCode < 58) || (charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123)) {
      return true;
    }
    return false;
  }

  getQuantity(event: NgbTypeaheadSelectItemEvent) {
    this.calculationWeightQuanityCKGPricesHead('quantity');
    this.cdr.detectChanges();
  }

  getPriceHead(event: NgbTypeaheadSelectItemEvent) {
    this.calculationWeightQuanityCKGPricesHead('priceperhead');
    this.cdr.detectChanges();
  }

  getPriceKg(event: NgbTypeaheadSelectItemEvent) {
    this.calculationWeightQuanityCKGPricesHead('ckg');
    this.cdr.detectChanges();
  }

  getWaightKg(event: NgbTypeaheadSelectItemEvent) {
    this.calculationWeightQuanityCKGPricesHead('weight');
    this.cdr.detectChanges();
  }
  getturnover(event: NgbTypeaheadSelectItemEvent) {
    this.calculationWeightQuanityCKGPricesHead('turnover');
    this.cdr.detectChanges();
  }

  get f() { return this.lotDetailForm.controls; }

  onSubmit() {
    this.ValidateVendorIdMessage = '';
    this.ValidateVendorNameMessage = '';
    this.ValidateBuyerIdMessage = '';
    this.ValidateBuyerNameMessage = '';
    this.ValidateProductNameMessage = '';
    this.ValidateProductDescriptionMessage = '';
    this.ValidateBreedMessage = '';
    this.submitted = true;

    if (this.isNew) {

      const validateLotData: any = {
        VendorId: this.vendorId.nativeElement.value,
        VendorName: this.vendorName.nativeElement.value,
        BuyerId: this.buyerId.nativeElement.value,
        BuyerName: this.buyerName.nativeElement.value,
        ProductName: this.productName.nativeElement.value,
        ProductDescription: this.productDescription.nativeElement.value,
        BreedName: this.breedName.nativeElement.value,
      }

      this.lotSearchService.validateLotSummaryRecord(validateLotData).subscribe(data => {
        this.flag = false;
        if (data[0].VendorIdMessage === 'VendorId is Not Exist') {
          this.flag = true;
          this.ValidateVendorIdMessage = 'Vendor Id is not exist';
        }
        if (data[0].VendorNameMessage === 'Vendor name is Not Exist') {
          this.flag = true;
          this.ValidateVendorNameMessage = 'Vendor name is not exist';
        }

        if (data[0].BuyerIdMessage === 'BuyerId is Not Exist') {
          this.flag = true;
          this.ValidateBuyerIdMessage = 'Buyer Id is not exist';
        }

        if (data[0].BuyerNameMessage === 'Buyer name is Not Exist') {
          this.flag = true;
          this.ValidateBuyerNameMessage = 'Buyer name is not exist';
        }

        if (data[0].ProductNameMessage === 'Product name is Not Exist') {
          this.flag = true;
          this.ValidateProductNameMessage = 'Product name is not exist';
        }
        if (data[0].BreedMessage === 'Breed name is Not Exist') {
          this.flag = true;
          this.ValidateBreedMessage = 'Breed name is not exist';
        }

        if (this.flag) {
          return false;
        }
        const formValue = this.lotDetailForm.getRawValue();

        Object.keys(formValue).forEach(key => {
          if (formValue[key] == null || formValue[key] === '') {
            delete formValue[key];
          }
        });
        if (formValue.DMOLot_VInfo_VendorBrc && formValue.DMOLot_VInfo_VendorBrc.dmobranchbrcode !== undefined) {
          formValue.DMOLot_VInfo_VendorBrc = formValue.DMOLot_VInfo_VendorBrc.dmobranchbrcode;
        }
        if (formValue.DMOLot_BInfo_BuyerBrc && formValue.DMOLot_BInfo_BuyerBrc.dmobranchbrcode !== undefined) {
          formValue.DMOLot_BInfo_BuyerBrc = formValue.DMOLot_BInfo_BuyerBrc.dmobranchbrcode;
        }
        const submitData: any = {
          ProcessName: this.processName,
          UserName: this.currentUser.UserName,
          TriggerName: 'TRGR_LotPreProcessing_Calculate',
          ParentTransactionID: this.parentId,
          Data: [formValue]
        };

        this.applicationService.insertApplication(submitData).subscribe(async response => {

          this.transactionId = response.result.transactionId;
          const bodyDataVendor = {
            SaleTransactionID: this.parentId,
            LotTransactionID: this.transactionId
          };
          this.saleServices.AddVendorTermsData(bodyDataVendor).subscribe(x => { });
          const cdata = {
            TransactionID: this.transactionId
          };
          this.lot.saveAutoLotAgentAgency(cdata).subscribe(x => { });

          if (!this.isFeesCalculated) {
            await this.calcLotFeesCharges();
          }

          await this.saveLotFeesCharges();
          await this.calcLotFeesChargesById();

          if (this.stage === 'Invoiced' && this.buyerId.nativeElement.value && Object.keys(formValue).some(x => this.lot.isChangesOnLot(x.replace(/_/gi, '')))) {
              this.lot.AddChangesLot({ LotTransactionID: this.transactionId, BuyerId: this.buyerId.nativeElement.value })
              .subscribe();
          }

          this.toastrService.success('Data saved successfully');
          this.router.navigate([`/crm/sales/${this.parentId}/lots`, this.transactionId]);
        });

      });

    } else {
      const formValue = this.dmoControlService.getDirtyValues(this.lotDetailForm);
      const valueData: any = {};
      Object.keys(formValue).forEach(key => {
        if (formValue[key] == null) {
          valueData[key] = '';
        } else {
          valueData[key] = formValue[key];
        }
      });
      if (valueData.DMOLot_VInfo_VendorBrc && valueData.DMOLot_VInfo_VendorBrc.dmobranchbrcode !== undefined) {
        valueData.DMOLot_VInfo_VendorBrc = valueData.DMOLot_VInfo_VendorBrc.dmobranchbrcode;
      }
      if (valueData.DMOLot_BInfo_BuyerBrc && valueData.DMOLot_BInfo_BuyerBrc.dmobranchbrcode !== undefined) {
        valueData.DMOLot_BInfo_BuyerBrc = valueData.DMOLot_BInfo_BuyerBrc.dmobranchbrcode;
      }
      const submitData: any = {
        Identifier: {
          Name: null,
          Value: null,
          TrnsctnID: this.transactionId
        },
        ProcessName: this.processName,
        TriggerName: 'TRGR_LotPreProcessing_Calculate',
        UserName: this.currentUser.UserName,
        ParentTransactionID: this.parentId,
        Data: [valueData]
      };
      this.applicationService.updateApplication(submitData).subscribe(async data => {
        if (!this.isReversal) {
          const bodyDataVendor = {
            SaleTransactionID: this.parentId,
            LotTransactionID: this.transactionId
          };
          this.saleServices.AddVendorTermsData(bodyDataVendor).subscribe(x => { });
          const cdata = {
            TransactionID: this.transactionId
          };
          this.lot.saveAutoLotAgentAgency(cdata).subscribe(x => { });
        }
        let isLotFeeChanges = false;
        if (this.isFeesCalculated || this.lotFeesChargesGrid.data.filter(row => row.IsManual === true).length > 0) {
          await this.saveLotFeesCharges();
          isLotFeeChanges = true;
        }
        if (this.isCalcFeesFieldsChanged) {
          await this.calcLotFeesChargesById();
        } else if (this.isCalcBuyerBranchRebate) {
          await this.calcBuyerBranchRebate();
        }
        if (this.stage === 'Invoiced' && (isLotFeeChanges || Object.keys(valueData).some(x => this.lot.isChangesOnLot(x.replace(/_/gi, ''))))) {
          if (this.applicationData.DataInformation['dmolotbinfobuyerid'] && this.applicationData.DataInformation['dmolotbinfobuyerid'].DMOVAL) {
            if(this.buyerId.nativeElement.value && this.buyerId.nativeElement.value !== this.applicationData.DataInformation['dmolotbinfobuyerid'].DMOVAL){
              this.lot.AddChangesLot({ LotTransactionID: this.transactionId, BuyerId: this.buyerId.nativeElement.value })
              .subscribe();
            }
            this.lot.AddChangesLot({ LotTransactionID: this.transactionId, BuyerId: this.applicationData.DataInformation['dmolotbinfobuyerid'].DMOVAL })
            .subscribe();
          }
        }

        this.toastrService.success('Data updated successfully');
        this.isLotSubmit = true;
        this.isCalcFeesFieldsChanged = false;
        this.isCalcBuyerBranchRebate = false;
      });

    }
  }

  isValid(val: any) {
    return val != null && val !== '';
  }

  calculationWeightQuanityCKGPricesHead(controlName: string) {
    switch (controlName) {
      case 'quantity':
      case 'priceperhead':
        this.DMOLot_PriceHead = this.lotDetailForm.get('DMOLot_LotInfo_Price$PHd').value;
        this.DMOLot_Qnty = this.lotDetailForm.get('DMOLot_LotInfo_Qnty').value;
        this.DMOLOT_PriceKg = this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').value;
        this.DMOLOT_Weight = this.lotDetailForm.get('DMOLot_LotInfo_WtKg').value;
        this.DMOLOT_TURNOVER = this.lotDetailForm.get('DMOLot_LotInfo_TurnovAUD').value;
        if (this.isValid(this.DMOLot_Qnty) && this.isValid(this.DMOLot_PriceHead)) {
          this.setValueAndMarkDarty('DMOLot_LotInfo_TurnovAUD', this.DMOLot_Qnty * this.DMOLot_PriceHead);
          this.DMOLOT_TURNOVER = this.lotDetailForm.get('DMOLot_LotInfo_TurnovAUD').value;
          if (this.isValid(this.DMOLOT_Weight) && !this.isValid(this.DMOLOT_PriceKg)) {
            this.setValueAndMarkDarty('DMOLot_LotInfo_PriceCPKg', (this.DMOLOT_TURNOVER * 100) / this.DMOLOT_Weight);
          }
          else if(this.isValid(this.DMOLOT_Weight) && controlName=='priceperhead'){
            this.setValueAndMarkDarty('DMOLot_LotInfo_PriceCPKg', (this.DMOLOT_TURNOVER * 100) / this.DMOLOT_Weight);
          }
          else if (this.isValid(this.DMOLOT_PriceKg)) {
            this.setValueAndMarkDarty('DMOLot_LotInfo_WtKg', this.DMOLOT_TURNOVER / (this.DMOLOT_PriceKg / 100));
          }
        } else if (this.isValid(this.DMOLOT_TURNOVER) && controlName != 'priceperhead') {
          this.setValueAndMarkDarty('DMOLot_LotInfo_Price$PHd', this.DMOLOT_TURNOVER / this.DMOLot_Qnty);
        } else if (this.isValid(this.DMOLot_PriceHead) && this.isValid(this.DMOLOT_TURNOVER) && controlName != 'quantity') {
          this.setValueAndMarkDarty('DMOLot_LotInfo_Qnty', this.DMOLOT_TURNOVER / this.DMOLot_PriceHead);
        }
        if (controlName == 'priceperhead') {
          if (this.lotDetailForm.get('DMOLot_LotInfo_Price$PHd').value != null && this.lotDetailForm.get('DMOLot_LotInfo_Price$PHd').value != '') {
            this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').disable();
            this.lotDetailForm.get('DMOLot_LotInfo_PriceType').reset('$/head');
            this.lotDetailForm.get('DMOLot_LotInfo_PriceType').markAsDirty();
            this.lotDetailForm.get('DMOLot_LotInfo_PriceType').updateValueAndValidity();
          } else {
            this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').enable();
          }
        }
        break;
      case 'ckg':
      case 'weight':
        this.DMOLot_PriceHead = this.lotDetailForm.get('DMOLot_LotInfo_Price$PHd').value;
        this.DMOLOT_PriceKg = this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').value;
        this.DMOLOT_Weight = this.lotDetailForm.get('DMOLot_LotInfo_WtKg').value;
        this.DMOLot_Qnty = this.lotDetailForm.get('DMOLot_LotInfo_Qnty').value;
        this.DMOLOT_TURNOVER = this.lotDetailForm.get('DMOLot_LotInfo_TurnovAUD').value;
        if (this.isValid(this.DMOLOT_PriceKg) && this.isValid(this.DMOLOT_Weight)) {
          this.setValueAndMarkDarty('DMOLot_LotInfo_TurnovAUD', (this.DMOLOT_PriceKg * this.DMOLOT_Weight) / 100);
          this.DMOLOT_TURNOVER = this.lotDetailForm.get('DMOLot_LotInfo_TurnovAUD').value;
          if (this.isValid(this.DMOLot_Qnty) && this.isValid(this.DMOLOT_TURNOVER) && !this.isValid(this.DMOLot_PriceHead)) {
            this.setValueAndMarkDarty('DMOLot_LotInfo_Price$PHd', this.DMOLOT_TURNOVER / this.DMOLot_Qnty);
          }else if(this.isValid(this.DMOLot_Qnty) && controlName=='ckg'){
            this.setValueAndMarkDarty('DMOLot_LotInfo_Price$PHd', this.DMOLOT_TURNOVER / this.DMOLot_Qnty);
          }
          // else if (this.isValid(this.DMOLot_PriceHead) && this.isValid(this.DMOLOT_TURNOVER)) {
          //   this.setValueAndMarkDarty('DMOLot_LotInfo_Qnty', this.DMOLOT_TURNOVER / this.DMOLot_PriceHead);
          // }
        } else if (this.isValid(this.DMOLOT_Weight) && this.isValid(this.DMOLOT_TURNOVER) && controlName != 'ckg') {
          this.setValueAndMarkDarty('DMOLot_LotInfo_PriceCPKg', (this.DMOLOT_TURNOVER * 100) / this.DMOLOT_Weight);
        } else if (this.isValid(this.DMOLOT_PriceKg) && this.isValid(this.DMOLOT_TURNOVER) && controlName != 'weight') {
          this.setValueAndMarkDarty('DMOLot_LotInfo_WtKg', this.DMOLOT_TURNOVER / (this.DMOLOT_PriceKg / 100));
        }
        if (controlName == 'ckg') {
          if (this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').value != null && this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').value != '') {
            this.lotDetailForm.get('DMOLot_LotInfo_Price$PHd').disable();
            this.lotDetailForm.get('DMOLot_LotInfo_PriceType').reset('c/kg');
            this.lotDetailForm.get('DMOLot_LotInfo_PriceType').markAsDirty();
            this.lotDetailForm.get('DMOLot_LotInfo_PriceType').updateValueAndValidity();
          } else {
            this.lotDetailForm.get('DMOLot_LotInfo_Price$PHd').enable();
          }
        }
        break;
      case 'turnover':

        this.DMOLOT_Weight = this.lotDetailForm.get('DMOLot_LotInfo_WtKg').value;
        this.DMOLOT_TURNOVER = this.lotDetailForm.get('DMOLot_LotInfo_TurnovAUD').value;
        this.DMOLot_PriceHead = this.lotDetailForm.get('DMOLot_LotInfo_Price$PHd').value;
        this.DMOLot_Qnty = this.lotDetailForm.get('DMOLot_LotInfo_Qnty').value;
        this.DMOLOT_PriceKg = this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').value;

        if (this.isValid(this.DMOLOT_Weight) && !this.isValid(this.DMOLOT_PriceKg)) {
          this.setValueAndMarkDarty('DMOLot_LotInfo_PriceCPKg', (this.DMOLOT_TURNOVER * 100) / this.DMOLOT_Weight);
        }
        else if (this.isValid(this.DMOLOT_PriceKg) && !this.isValid(this.DMOLOT_Weight)) {
          this.DMOLOT_PriceKg = this.lotDetailForm.get('DMOLot_LotInfo_PriceCPKg').value;
          this.setValueAndMarkDarty('DMOLot_LotInfo_WtKg', this.DMOLOT_TURNOVER / (this.DMOLOT_PriceKg / 100));
        }
        if (this.isValid(this.DMOLot_Qnty)) {
          this.setValueAndMarkDarty('DMOLot_LotInfo_Price$PHd', this.DMOLOT_TURNOVER / this.DMOLot_Qnty);
        }
        // else if (this.isValid(this.DMOLot_PriceHead) && !this.isValid(this.DMOLot_Qnty)) {
        //   this.setValueAndMarkDarty('DMOLot_LotInfo_Qnty', this.DMOLOT_TURNOVER / this.DMOLot_PriceHead);
        // }
        break;
    }

    this.DMOLOT_TURNOVER = this.lotDetailForm.get('DMOLot_LotInfo_TurnovAUD').value;
    if (this.DMOLOT_TURNOVER != null && this.DMOLOT_TURNOVER !== '' && this.DMOLOT_TURNOVER !== '0') {
      this.setValueAndMarkDarty('DMOLot_LotInfo_GST', (this.GstRate * Number(this.DMOLOT_TURNOVER) / 100));
      this.setValueAndMarkDarty('DMOLot_LotInfo_TurnoverGs', Number(this.DMOLOT_TURNOVER) + Number(this.lotDetailForm.get('DMOLot_LotInfo_GST').value));
    }
  }
  setValueAndMarkDarty(controlName: any, value: any) {
    if (value.toString().indexOf('.') > -1 && value.toString().split('.')[1].length > 2) {
      this.lotDetailForm.get(controlName).patchValue(value.toFixed(2));
    } else {
      this.lotDetailForm.get(controlName).patchValue(value);
    }
    this.lotDetailForm.get(controlName).markAsTouched();
    this.lotDetailForm.get(controlName).markAsDirty();
  }
  calcLotFeesChargesManual(ev: any) {
    const bodyData: any = {
      FeeTransactionID: ev.FeeTransactionID,
      Turnover: this.lotDetailForm.value.DMOLot_LotInfo_TurnovAUD ? this.lotDetailForm.value.DMOLot_LotInfo_TurnovAUD : 0,
      Quantity: this.lotDetailForm.value.DMOLot_LotInfo_Qnty ? this.lotDetailForm.value.DMOLot_LotInfo_Qnty : 0,
      Weight: this.lotDetailForm.value.DMOLot_LotInfo_WtKg ? this.lotDetailForm.value.DMOLot_LotInfo_WtKg : 0,
      Rate: ev.Rate ? ev.Rate : 0
    };
    this.apiESaleyardService.post('crmlot/calcLotFeesChargesManual', bodyData).subscribe(data => {
      if (this.lotFeesChargesGrid.newRow.FeeTransactionID === ev.FeeTransactionID) {
        this.lotFeesChargesGrid.newRow = data;
        return;
      }
      for (let i = 0; i < this.lotFeesChargesGrid.data.length; i++) {
        if (this.lotFeesChargesGrid.data[i].FeeTransactionID === ev.FeeTransactionID) {
          this.lotFeesChargesGrid.data[i] = data;
          return;
        }
      }
    });
  }

  async calcLotFeesCharges() {
    this.isFeesCalculated = true;
    const bodyData: any = {};
    bodyData.TransactionType = this.parentData.DataInformation.dmocrmheaderinftrantype ?
      this.parentData.DataInformation.dmocrmheaderinftrantype.DMOVAL.split('~~~')[0] : '';
    bodyData.SaleType = this.parentData.DataInformation.dmocrmheaderinfsaletype ?
      this.parentData.DataInformation.dmocrmheaderinfsaletype.DMOVAL.split('~~~')[0] : '';
    bodyData.Saleyard = this.parentData.DataInformation.dmocrmheaderinfsaleyard ?
      this.parentData.DataInformation.dmocrmheaderinfsaleyard.DMOVAL.split('~~~')[0] : '';
    bodyData.VendorBranch = this.lotDetailForm.value.DMOLot_VInfo_VendorBrc ? this.lotDetailForm.value.DMOLot_VInfo_VendorBrc : '';
    bodyData.VendorBranch = bodyData.VendorBranch.dmobranchbrcode ? bodyData.VendorBranch.dmobranchbrcode : bodyData.VendorBranch;
    bodyData.ProductCode = this.lotDetailForm.value.DMOLot_LotInfo_Pdct ? this.lotDetailForm.value.DMOLot_LotInfo_Pdct : '';
    bodyData.Turnover = this.lotDetailForm.value.DMOLot_LotInfo_TurnovAUD ? this.lotDetailForm.value.DMOLot_LotInfo_TurnovAUD : 0;
    bodyData.Quantity = this.lotDetailForm.value.DMOLot_LotInfo_Qnty ? this.lotDetailForm.value.DMOLot_LotInfo_Qnty : 0;
    bodyData.PriceHead = this.lotDetailForm.value.DMOLot_LotInfo_Price$PHd ? this.lotDetailForm.value.DMOLot_LotInfo_Price$PHd : 0;
    bodyData.PriceCKg = this.lotDetailForm.value.DMOLot_LotInfo_PriceCPKg ? this.lotDetailForm.value.DMOLot_LotInfo_PriceCPKg : 0;
    bodyData.Weight = this.lotDetailForm.value.DMOLot_LotInfo_WtKg ? this.lotDetailForm.value.DMOLot_LotInfo_WtKg : 0;
    const calculatedFees: any = await this.apiESaleyardService.post('crmlot/calcLotFeesCharges', bodyData).toPromise();
    const manualFees: any[] = this.lotFeesChargesGrid.data.filter(row => row.IsManual === true);
    this.lotFeesChargesGrid.data = calculatedFees.concat(manualFees);
  }

  async saveLotFeesCharges() {
    const bodyData: any = {
      TransactionID: this.transactionId,
      Items: [...this.lotFeesChargesGrid.data]
    };

    await this.apiESaleyardService.post('crmlot/saveLotFeesCharges', bodyData).toPromise();
    this.lotFeesChargesGrid.newRow = { ...this.lotFeesChargesGrid.newFeesCharges };
  }

  async calcLotFeesChargesById() {
    const bodyData = {
      SaleTransactionID: this.parentId,
      LotTransactionID: this.transactionId
    };

    if (this.isReversal) {
      delete bodyData.SaleTransactionID;
    }

    await this.apiESaleyardService.post('crmlot/calcLotFeesChargesById', bodyData).toPromise();
  }

  goBack() {
    if (this.lotDetailForm.pristine === false && this.isLotSubmit === false) {
      this.msg.showMessage('Warning', {
        header: 'Confirmation Message',
        body: 'There is unsaved data prior to directing them to the Lot detail data grid',
        btnText: 'Yes',
        isConfirmation: true,
        callback: () => this.router.navigate(['/crm/sales', this.parentId]),
        caller: this,
      })
      // const modalMsgRef = this.modalService.open(MessageComponent, { backdrop: 'static', windowClass: 'Confirm_popup' });
      // const modalInstance: MessageComponent = modalMsgRef.componentInstance;
      // modalInstance.MessagePopup = modalMsgRef;
      // modalInstance.IsConfirmation = true;
      // modalInstance.Caller = this;
      // modalInstance.MessageHeader = 'Confirmation Message';
      // modalInstance.Message = 'There is unsaved data prior to directing them to the Lot detail data grid.';
      // modalInstance.ButtonText = 'Yes';
      // modalInstance.IsDefaultView = true;
      // modalInstance.CallBackMethod = () => {
      //   this.router.navigate(['/crm/sales', this.parentId]);
      // };
    } else {
      this.router.navigate(['/crm/sales', this.parentId]);
    }
  }
  vendorBranchSearch = (text$: Observable<string>) => {
    return this.lotSearchService.branchSearch(text$);
  }
  branchSearch = (text$: Observable<string>) => {
    return this.lotSearchService.branchSearch(text$);
  }
  async calcBuyerBranchRebate() {
    const bodyData = {
      SaleTransactionID: this.parentId,
      LotTransactionID: this.transactionId
    };
    await this.apiESaleyardService.post('crmlot/calcBuyerBranchRebate', bodyData).toPromise();
  }
}
