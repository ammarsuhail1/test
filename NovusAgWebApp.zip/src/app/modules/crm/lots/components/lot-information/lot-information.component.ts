import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { LotSearchService } from '../../services/lot-search.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiESaleyardService, MessageService } from '@app/core';
import { LotFeesChargesComponent } from '../lot-fees-charges/lot-fees-charges.component';
import { ToastrService } from 'ngx-toastr';
import { LotService } from '../../services/lot.service';
import { ActivatedRoute } from '@angular/router';
import { UserDetail } from '@app/core/models/user-detail';

@Component({
  selector: 'app-lot-information',
  templateUrl: './lot-information.component.html',
  styleUrls: ['./lot-information.component.scss']
})
export class LotInformationComponent implements OnInit {

  @Input() transactionIds: any = [];
  @Input() selectedLots = [];
  @Input() saleId: string;
  @Input() processName: string;
  @Input() stage: string;

  @ViewChild(LotFeesChargesComponent, { static: false })
  private lotFeesChargesGrid: LotFeesChargesComponent;

  lotDetailForm: FormGroup;
  submitted = false;

  constructor(private fb: FormBuilder,
              private lotSearchService: LotSearchService,
              public activeModal: NgbActiveModal,
              private toastrService: ToastrService,
              private apiESaleyardService: ApiESaleyardService,
              private lotService: LotService,
              private route: ActivatedRoute,
              private msg: MessageService,
              private userDetail: UserDetail) { }

  ngOnInit() {
    this.lotDetailForm = this.fb.group({
      DMOLot_LInfo_Description: ['']
    });
  }

  async saveLotFeesCharges() {
    const bodyData: any = {
      TransactionID: this.transactionIds.join(','),
      ByBulkChange: true,
      Items: [...this.lotFeesChargesGrid.data]
    };
    if (this.lotFeesChargesGrid.data.length > 0) {
      const result = await this.apiESaleyardService.post('crmlot/saveLotFeesCharges', bodyData).toPromise();
      if (result === true) {
        const calcData = {
          SaleTransactionID: this.saleId,
          LotTransactionID: this.transactionIds.join(',')
        };
        await this.lotService.calculateFeeAndCharges(calcData).toPromise();
        if (this.stage === 'Invoiced') {
          this.selectedLots.forEach(async x => {
            if (x.dmolotbinfobuyerid) {
              await this.lotService.AddChangesLot({ LotTransactionID: x.TRNSCTNID, BuyerId: x.dmolotbinfobuyerid }).toPromise();
            }
          });
        }
      }
      this.lotFeesChargesGrid.newRow = { ...this.lotFeesChargesGrid.newFeesCharges };
    }
  }


  get f() { return this.lotDetailForm.controls; }

  async onSubmit() {
    if (this.lotFeesChargesGrid.newRow.FeeTransactionID !== null) {
      this.msg.showMessage('Warning', {body: 'Please save grid item data before updating lot information'});
      // this.msg.showErrorMessage('Please save grid item data before update lot information.', 'Error', 'Ok',
      // null, false, true, false, '');
      return ;
    }
    this.submitted = true;
    if (this.lotDetailForm.invalid) {
      return;
    }
    await this.saveLotFeesCharges();

    const des = this.lotDetailForm.get('DMOLot_LInfo_Description').value;
    if (des && des.length > 0) {
      const submitData: any = {
        description: des,
        processName: this.processName,
        LotTransactionId: this.transactionIds,
        ModfBy: this.userDetail.UserId.toString()
      };
      this.lotSearchService.BulkUpdateVenderInformation(submitData).subscribe(data => {
        this.toastrService.success('Data saved successfully');
        this.activeModal.close(true);
      });
    } else {
      this.toastrService.success('Data saved successfully');
      this.activeModal.close(true);
      return;
    }

  }

}
