import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators, ValidatorFn } from '@angular/forms';
import { Observable } from 'rxjs';
import { LotSearchService } from '../../services/lot-search.service';
import { NgbTypeaheadSelectItemEvent, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { LotService } from '../../services/lot.service';
import { UserDetail } from '@app/core/models/user-detail';

@Component({
  selector: 'app-vendor-information',
  templateUrl: './vendor-information.component.html',
  styleUrls: ['./vendor-information.component.scss']
})
export class VendorInformationComponent implements OnInit {

  @Input() processName: string;
  @Input() transactionIds: any = [];
  @Input() selectedLots = [];
  @Input() stage: string;
  lotDetailForm: FormGroup;
  submitted = false;
  vendorBranchOptions: any;
  vendoPic: any;
  isDdl = false;
  private vendorValidators = [
    Validators.required
  ];
  formatter = (x: any) => x.dmobranchbrname;
  constructor(
    private fb: FormBuilder,
    private lotSearchService: LotSearchService,
    private toastrService: ToastrService,
    public activeModal: NgbActiveModal,
    private lotService: LotService,
    private userDetail: UserDetail
    ) { }

  ngOnInit() {
    this.lotDetailForm = this.fb.group({
      DMOLot_VInfo_VendorId:  [''],
      DMOLot_VInfo_VendorNam: [''],
      DMOLot_VInfo_VendorBrc: [''],
      DMOLot_VInfo_VendorPic: [''],
      DMOLot_VInfo_AcSaleRef: ['']
    });
  }

  vendorIdSearch = (text$: Observable<string>) => {
    return this.lotSearchService.vendorIdSearch(text$);
  }
  vendorNameSearch = (text$: Observable<string>) => {
    return this.lotSearchService.vendorNameSearch(text$);
  }
  vendorPICSearch = (text$: Observable<string>) => {
    return this.lotSearchService.vendorPicSearch(text$);
  }
  vendorBranchSearch = (text$: Observable<string>) => {
    return this.lotSearchService.branchSearch(text$);
  }

  checkValue(event, dmo) {
    if (event.target.value === '') {
      if (dmo === 'dmolotvinfovendorpic') {
        this.lotDetailForm.get('DMOLot_VInfo_VendorPic').patchValue('');
      } else {
        this.lotDetailForm.get('DMOLot_VInfo_VendorId').patchValue('');
        this.lotDetailForm.get('DMOLot_VInfo_VendorNam').patchValue('');
        this.lotDetailForm.get('DMOLot_VInfo_VendorBrc').patchValue('');
      }
      if (this.lotDetailForm.get('DMOLot_VInfo_VendorId').value === '') {
        this.isDdl = false;
        this.vendoPic = [];
      }
    }
  }
  selectVendor(event: NgbTypeaheadSelectItemEvent, field: string) {

    const vendor = this.lotSearchService.vendorData.find(x => x[field] === event.item);
    if (vendor) {
      this.lotDetailForm.get('DMOLot_VInfo_VendorNam').patchValue(vendor.dmocustmstrcustname1);
      this.lotDetailForm.get('DMOLot_VInfo_VendorId').patchValue(vendor.dmocustmstrsapno);
      if (vendor.dmocustmstracttype === 'Livestock') {
        if (vendor.dmocustmstrlstkbranch && vendor.dmocustmstrlstkbranch.includes('(') > 0) {
          const brnch = vendor.dmocustmstrlstkbranch.split('(');
          this.lotDetailForm.get('DMOLot_VInfo_VendorBrc').patchValue({dmobranchbrname: brnch[0], dmobranchbrcode: brnch[1].replace(')','') });
        }
      } else {
        if (vendor.dmocustmstrcustdombranch && vendor.dmocustmstrcustdombranch.includes('(') > 0) {
          const brnch = vendor.dmocustmstrcustdombranch.split('(');
          this.lotDetailForm.get('DMOLot_VInfo_VendorBrc').patchValue({dmobranchbrname: brnch[0], dmobranchbrcode: brnch[1].replace(')','')});
        }
      }
      this.getVendorPIC(vendor.dmocustmstrsapno);
    }
  }

  getVendorPIC(vendorId: string) {
    this.lotSearchService.getVendorPIC(vendorId).subscribe(response => {
      this.lotDetailForm.get('DMOLot_VInfo_VendorPic').patchValue('');
      this.isDdl = true;
      this.vendoPic = response;
      if (response && response.length > 0) {
        this.lotDetailForm.get('DMOLot_VInfo_VendorPic').patchValue(response[0].dmocuspiccustpic);
      }
    });
  }

  get f() { return this.lotDetailForm.controls; }

  addValidation() {
    if (this.lotDetailForm.get('DMOLot_VInfo_VendorId').value !== '' || this.lotDetailForm.get('DMOLot_VInfo_VendorNam').value !== '') {
      this.lotDetailForm.get('DMOLot_VInfo_VendorBrc').setValidators(this.vendorValidators);
      this.lotDetailForm.get('DMOLot_VInfo_VendorBrc').updateValueAndValidity();
      // this.lotDetailForm.get('DMOLot_VInfo_VendorPic').setValidators(this.vendorValidators);
      // this.lotDetailForm.get('DMOLot_VInfo_VendorPic').updateValueAndValidity();
    }
  }

  onSubmit() {
    this.addValidation();
    this.submitted = true;
    if (this.lotDetailForm.invalid) {
      return;
    }

    const submitData: any = {
      vendorId: this.lotDetailForm.controls.DMOLot_VInfo_VendorId.value,
      vendorName: this.lotDetailForm.controls.DMOLot_VInfo_VendorNam.value,
      vendorbrc: this.lotDetailForm.controls.DMOLot_VInfo_VendorBrc.value ?
        this.lotDetailForm.controls.DMOLot_VInfo_VendorBrc.value.dmobranchbrcode : null,
      vendorpic: this.lotDetailForm.controls.DMOLot_VInfo_VendorPic.value,
      vinfoacsaleref: this.lotDetailForm.controls.DMOLot_VInfo_AcSaleRef.value
    };
    let flage = false;
    Object.keys(submitData).forEach(key => {
      if (submitData[key] != null && submitData[key] !== '') {
        flage = true;
      }
    });
    if (flage) {
      submitData.processName = this.processName;
      submitData.LotTransactionId = this.transactionIds;
      submitData.ModfBy = this.userDetail.UserId.toString();
      this.lotSearchService.BulkUpdateVenderInformation(submitData).subscribe(data => {
        this.updateStatus();
        if (this.stage === 'Invoiced' && submitData.vendorpic) {
          this.selectedLots.forEach(async x => {
            if (x.dmolotbinfobuyerid) {
              await this.lotService.AddChangesLot({ LotTransactionID: x.TRNSCTNID, BuyerId: x.dmolotbinfobuyerid }).toPromise();
            }
          });
        }
        this.toastrService.success('Data saved successfully');
        this.activeModal.close(true);
      });
    } else {
      return;
    }
  }
  async updateStatus() {
    const statusData = {
      TransactionID: this.transactionIds.join(',')
    };
    await this.lotService.changeLotStatus(statusData).toPromise();
  }

}

