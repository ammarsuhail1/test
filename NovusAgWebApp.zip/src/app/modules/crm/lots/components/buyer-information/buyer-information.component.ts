import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { LotSearchService } from '../../services/lot-search.service';
import { Observable } from 'rxjs';
import { NgbTypeaheadSelectItemEvent, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { LotService } from '../../services/lot.service';
import { UserDetail } from '@app/core/models/user-detail';

@Component({
  selector: 'app-buyer-information',
  templateUrl: './buyer-information.component.html',
  styleUrls: ['./buyer-information.component.scss']
})
export class BuyerInformationComponent implements OnInit {

  @Input() processName: string;
  @Input() transactionIds = [];
  @Input() selectedLots = [];
  @Input() stage: string;

  lotDetailForm: FormGroup;
  submitted = false;
  buyerPic: any;
  isDdl = false;
  private buyerValidators = [
    Validators.required
  ];
  formatter = (x: any) => x.dmobranchbrname;

  constructor(
    private fb: FormBuilder,
    private lotSearchService: LotSearchService,
    private toastrService: ToastrService,
    public activeModal: NgbActiveModal,
    private lotService: LotService,
    private userDetail: UserDetail) { }

  ngOnInit() {
    this.lotDetailForm = this.fb.group({
      DMOLot_BInfo_BuyerId: [''],
      DMOLot_BInfo_BuyerName: [''],
      DMOLot_BInfo_BuyerBrc: [''],
      DMOLot_BInfo_BuyerPic: [null],
      DMOLot_BInfo_InvoiceRef: [null],
      DMOLot_BInfo_SetIntBBReb: [false],
      DMOLot_BInfo_Rate: [null, [Validators.max(100)]],
    });
  }
  buyerIdSearch = (text$: Observable<string>) => {
    return this.lotSearchService.buyerIdSearch(text$);
  }
  buyerNameSearch = (text$: Observable<string>) => {
    return this.lotSearchService.buyerNameSearch(text$);
  }
  vendorPICSearch = (text$: Observable<string>) => {
    return this.lotSearchService.vendorPicSearch(text$);
  }
  branchSearch = (text$: Observable<string>) => {
    return this.lotSearchService.branchSearch(text$);
  }

  checkValue(event, dmo) {
    if (event.target.value === '') {
      if (dmo === 'dmolotbinfobuyerpic') {
        this.lotDetailForm.get('DMOLot_BInfo_BuyerPic').patchValue('');
      } else {
        this.lotDetailForm.get('DMOLot_BInfo_BuyerId').patchValue('');
        this.lotDetailForm.get('DMOLot_BInfo_BuyerName').patchValue('');
        this.lotDetailForm.get('DMOLot_BInfo_BuyerBrc').patchValue('');
      }
      if (this.lotDetailForm.get('DMOLot_BInfo_BuyerId').value === '') {
        this.isDdl = false;
      }
    }
  }



  selectBuyer(event: NgbTypeaheadSelectItemEvent, field: string) {
    const buyer = this.lotSearchService.buyerData.find(x => x[field] === event.item);
    if (buyer) {
      this.lotDetailForm.get('DMOLot_BInfo_BuyerName').patchValue(buyer.dmocustmstrcustname1);
      this.lotDetailForm.get('DMOLot_BInfo_BuyerId').patchValue(buyer.dmocustmstrsapno);
      if (buyer.dmocustmstracttype === 'Livestock') {
        if (buyer.dmocustmstrlstkbranch && buyer.dmocustmstrlstkbranch.includes('(') > 0) {
          const brnch = buyer.dmocustmstrlstkbranch.split('(');
          this.lotDetailForm.get('DMOLot_BInfo_BuyerBrc').patchValue({dmobranchbrname: brnch[0], dmobranchbrcode: brnch[1].replace(')','') });
        }
      } else {
        if (buyer.dmocustmstrcustdombranch && buyer.dmocustmstrcustdombranch.includes('(') > 0) {
          const brnch = buyer.dmocustmstrcustdombranch.split('(');
          this.lotDetailForm.get('DMOLot_BInfo_BuyerBrc').patchValue({dmobranchbrname: brnch[0], dmobranchbrcode: brnch[1].replace(')','')});
        }
      }
      this.getBuyerPIC(buyer.dmocustmstrsapno);
    }
  }

  getBuyerPIC(buyerId: string) {
    this.lotSearchService.getBuyerPIC(buyerId).subscribe(response => {
      this.isDdl = true;
      this.buyerPic = response;
      this.lotDetailForm.get('DMOLot_BInfo_BuyerPic').patchValue('');
      if (response && response.length > 0) {
        this.lotDetailForm.get('DMOLot_BInfo_BuyerPic').patchValue(response[0].dmocuspiccustpic);
      }
    });
  }

  get f() { return this.lotDetailForm.controls; }

  addValidation() {
    if (this.lotDetailForm.get('DMOLot_BInfo_BuyerId').value !== '' || this.lotDetailForm.get('DMOLot_BInfo_BuyerName').value !== '') {
      this.lotDetailForm.get('DMOLot_BInfo_BuyerBrc').setValidators(this.buyerValidators);
      this.lotDetailForm.get('DMOLot_BInfo_BuyerBrc').updateValueAndValidity();
      // this.lotDetailForm.get('DMOLot_BInfo_BuyerPic').setValidators(this.buyerValidators);
      // this.lotDetailForm.get('DMOLot_BInfo_BuyerPic').updateValueAndValidity();
    }
  }
  onSubmit() {
    this.addValidation();
    this.submitted = true;
    if (this.lotDetailForm.invalid) {
      return;
    }

    const submitData: any = {
      BInfoBuyerId: this.lotDetailForm.controls.DMOLot_BInfo_BuyerId.value,
      BInfoBuyerName: this.lotDetailForm.controls.DMOLot_BInfo_BuyerName.value,
      BInfoBuyerBrc: this.lotDetailForm.controls.DMOLot_BInfo_BuyerBrc.value ?
        this.lotDetailForm.controls.DMOLot_BInfo_BuyerBrc.value.dmobranchbrcode : null,
      BInfoBuyerPic: this.lotDetailForm.controls.DMOLot_BInfo_BuyerPic.value,
      BInfoInvoiceRef: this.lotDetailForm.controls.DMOLot_BInfo_InvoiceRef.value,
      BInfo_Rate: this.lotDetailForm.controls.DMOLot_BInfo_Rate.value
    };
    let flage = false;
    let IsChangesLotUpdate = false;
    Object.keys(submitData).forEach(key => {
      if (submitData[key] != null && submitData[key] !== '') {
        flage = true;
        if (key !== 'BInfo_Rate' && submitData[key]) {
          IsChangesLotUpdate = true;
        }
      }
    });
    if (flage) {
      submitData.processName = this.processName;
      submitData.LotTransactionId = this.transactionIds;
      submitData.ModfBy = this.userDetail.UserId.toString();
      this.lotSearchService.BulkUpdateBuyerInformation(submitData).subscribe(data => {
        this.updateStatus();
        if (this.stage === 'Invoiced' && IsChangesLotUpdate) {
          this.selectedLots.forEach(async x => {
            if (x.dmolotbinfobuyerid) {
              await this.lotService.AddChangesLot({ LotTransactionID: x.TRNSCTNID, BuyerId: x.dmolotbinfobuyerid }).toPromise();
            }
          });
          this.selectedLots.filter(rows=> rows.dmolotbinfobuyerid !== submitData.BInfoBuyerId).forEach(async x => {
            if (submitData.BInfoBuyerId) {
              await this.lotService.AddChangesLot({ LotTransactionID: x.TRNSCTNID, BuyerId: submitData.BInfoBuyerId }).toPromise();
            }
          });
        }
        this.toastrService.success('Data saved successfully');
        this.activeModal.close(true);
      });
    } else {
      return;
    }
  }
  async updateStatus() {
    const statusData = {
      TransactionID: this.transactionIds.join(',')
    };
    await this.lotService.changeLotStatus(statusData).toPromise();
  }

}
