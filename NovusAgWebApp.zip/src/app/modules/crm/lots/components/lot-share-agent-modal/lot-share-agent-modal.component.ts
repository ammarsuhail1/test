import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormArray, FormBuilder, Validators } from '@angular/forms';
import { LotService } from '../../services/lot.service';
import { Observable } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, map } from 'rxjs/operators';

@Component({
  selector: 'app-lot-share-agent-modal',
  templateUrl: './lot-share-agent-modal.component.html',
  styleUrls: ['./lot-share-agent-modal.component.scss']
})
export class LotShareAgentModalComponent implements OnInit {

  addForm = this.fb.group({
    agentName: ['', Validators.required],
    agencyName: ['', Validators.required],
    sharingRate: [0, [Validators.required, Validators.min(0), Validators.max(100)]]
  });
  Sap: any = {
    Rate: ''
  };
  AgentAgenyList: any;
  Pid: string;
  body = {
    Agency: '',
    Agent: '',
    TransactionID: ''
  };
  submitted = false;
  formatter = (x: {AgencySap: string, AgencyNAME: string}) => x.AgencyNAME;
  formatter1 = (x: {AgentCODE: string, AgentNAME: string}) => x.AgentNAME;
  constructor(
    public activeModal: NgbActiveModal,
    private fb: FormBuilder,
    private lotservice: LotService
  ) { }

  ngOnInit() {
    this.lotservice.getSharedAgentAgency(this.body).subscribe(x => {
      this.AgentAgenyList = x;
    });
  }

  get f() { return this.addForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (!this.addForm.valid) {
      return;
    }
    const submitdata = {
      TransactionID : this.body.TransactionID,
      LotAgentCommissionId: this.Pid,
      AgencySapNo: this.Sap.Agency.AgencySap,
      AgentCode: this.Sap.Agent.AgentCODE,
      Rate: this.Sap.Rate
    };
    this.lotservice.addLotAgentAgencyShared(submitdata).subscribe(x=> {
      this.activeModal.close(true);
    });
  }
  searchAgency = (text$: Observable<string>) => text$.pipe(
    debounceTime(200),
    distinctUntilChanged(),
    filter(term => term.length >= 1),
    map(term => this.Sap.Agent !== undefined && this.Sap.Agent.AgentCODE ?
       this.AgentAgenyList.filter(item => item.AgentCODE === this.Sap.Agent.AgentCODE &&
       new RegExp(term, 'mi').test(item.AgencyNAME)).slice(0, 10) :
       this.AgentAgenyList.filter(item => new RegExp(term, 'mi').test(item.AgencyNAME)).slice(0, 10))
  )
  searchAgent = (text$: Observable<string>) => text$.pipe(
    debounceTime(200),
    distinctUntilChanged(),
    filter(term => term.length >= 1),
    map(term => this.Sap.Agency !== undefined && this.Sap.Agency.AgencySap ?
      this.AgentAgenyList.filter(item => item.AgencySap === this.Sap.Agency.AgencySap &&
        new RegExp(term, 'mi').test(item.AgentNAME)).slice(0, 10) :
      this.AgentAgenyList.filter(item => new RegExp(term, 'mi').test(item.AgentNAME)).slice(0, 10))
  )
}
