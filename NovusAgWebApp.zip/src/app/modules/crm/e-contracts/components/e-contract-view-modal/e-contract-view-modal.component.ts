
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormArray, FormBuilder } from '@angular/forms';
import { Observable, Subject, merge } from 'rxjs';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';

import {
  ApplicationService,
  AuthenticationService,
  FormViewService,
  DmoControlService,
  ListviewService,
  NgbDateFRParserFormatter,
  ApiESaleyardService,
  IHeaderMap,
  MessageService
} from '@app/core';
import { ColumnList } from '@app/modules/crm/model/column-list';
import { EContractService } from '../../services/e-contract.service';
import { LotSearchService } from '@app/modules/crm/lots/services/lot-search.service';
import { MessageComponent } from '@app/shared';
import { SalesService } from '@app/modules/crm/sales/services/sales.service';
import { environment } from '@env/environment';
import { formatDate } from '@angular/common';
import { LotService } from '@app/modules/crm/lots/services/lot.service';
import { UserDetail } from '@app/core/models/user-detail';

@Component({
  selector: 'app-e-contract-view-modal',
  templateUrl: './e-contract-view-modal.component.html',
  styleUrls: ['./e-contract-view-modal.component.scss']
})
export class EContractViewModalComponent implements OnInit {

  form: FormGroup;
  data: any;
  submitted = false;
  currentUser: any;
  processName: string;
  isEdit = false;
  transactionId = null;
  BMJSON: any = {};
  optionList: any = {};
  headerInformationdmos = [];
  headerInformationDmog: any;
  createFromFileDmos = [];
  saleIdfocus$ = new Subject<string>();
  saleData = [];
  isSaleLotShowing = false;
  dataSource: any;
  itemsCount: number;
  SelectedRecordIds: any;
  ContractId: string;
  rateVale = 0;
  isCunjuction = false;
  isDateGraeter = false;
  allLotId = [];

  HeaderMap: IHeaderMap = {
    config: {
      header: {
        columns: [
          {
            objectKey: 'lmkopesecdmorecordid',
            displayName: 'Contract ID'
          },
          {
            objectKey: 'lmkoeelotdmolotnumber',
            displayName: 'Lot No'
          }, {
            objectKey: 'lmkoeelotdmospaaccno',
            displayName: 'Vendor ID'
          }, {
            objectKey: 'lmkoeelotdmotrdname',
            displayName: 'Vendor Name'
          }, {
            objectKey: 'lmkoeelotdmoproduct',
            displayName: 'Product'
          },
          {
            objectKey: 'lmkoeelotdmoquantity',
            displayName: 'Contract Qty'
          }, {
            objectKey: 'lmkoeelotdmoquantity',
            displayName: 'Invoice Qty'
          }, {
            objectKey: 'lmkoeelotdmobuyerid',
            displayName: 'Buyer ID'
          }, {
            objectKey: 'lmkoeelotdmobuyname',
            displayName: 'Buyer Name'
          }
          , {
            objectKey: 'LMKOEELotDMO_TurnOver',
            displayName: 'Total Value'
          }
        ],
        action: {
          Edit: false,
          Delete: false,
          Checkbox: true,
          DropDown: false
        },
        columnFilter: []
      },
      paging: false
    }
  };

  submitData = [];
  constructor(
    public activeModal: NgbActiveModal,
    private router: Router,
    private applicationService: ApplicationService,
    private authenticationService: AuthenticationService,
    private dmoControlService: DmoControlService,
    private ngbDateFRParserFormatter: NgbDateFRParserFormatter,
    private formViewService: FormViewService,
    private listviewService: ListviewService,
    private apiESaleyardService: ApiESaleyardService,
    private fb: FormBuilder,
    private econtract: EContractService,
    private lotSearchService: LotSearchService,
    private modalService: NgbModal,
    private salesService: SalesService,
    private msg: MessageService,
    private lot: LotService,
    private userDetail: UserDetail
  ) { }


  ngOnInit() {
    this.currentUser = this.userDetail;
    this.processName = 'LMKLivestockSales';
    sessionStorage.AppName = 'LMKLivestockSales';
    if (this.data) {
      this.isEdit = true;
    }
    this.formViewService.getBmWfJson(this.processName, 'Form').subscribe(response => {
      this.BMJSON = response.BM.BusinessModelObjectGroup.Form;
      this.BMJSON.List.forEach(bmoGuid => {
        this.BMJSON.BusinessModelObjects[bmoGuid].List.forEach(dmogGuid => {
          if (this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].DisplayName === 'Header Information') {
            this.headerInformationDmog = this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid];
            this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].List.forEach(rowID => {
              this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].Rows[rowID].Columns.forEach(objCOLUMN => {
                objCOLUMN.List.forEach(dmoGUID => {
                  objCOLUMN.DataModelObjects[dmoGUID].DMOGuid = dmoGUID;
                  this.headerInformationdmos.push(objCOLUMN.DataModelObjects[dmoGUID]);
                });
              });
            });
          }
          if (this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].DisplayName === 'Create From File') {
            this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].List.forEach(rowID => {
              this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].Rows[rowID].Columns.forEach(objCOLUMN => {
                objCOLUMN.List.forEach(dmoGUID => {
                  objCOLUMN.DataModelObjects[dmoGUID].DMOGuid = dmoGUID;
                  objCOLUMN.DataModelObjects[dmoGUID].dmoGUID = dmoGUID;
                  this.createFromFileDmos.push(objCOLUMN.DataModelObjects[dmoGUID]);
                });
              });
            });
          }
        });
        
      });
      const dmos = [...this.headerInformationdmos, ...this.createFromFileDmos];
      this.form = this.dmoControlService.toFormViewGroup(dmos);

      if (this.isEdit) {
        this.form = this.dmoControlService.toAdminViewFormGroup(dmos, this.data);
        if (this.data.DataInformation.dmocrmheaderinftrantype) {
          this.OnChangeTransactionType(this.data.DataInformation.dmocrmheaderinftrantype);
        }
        if (this.data.DataInformation.dmocrmheaderinfcndbrnc) {
          this.changeConductingBranch(this.data.DataInformation.dmocrmheaderinfcndbrnc);
        }
      } else {
        this.OnChangeTransactionType(undefined);
        this.GetPlasmaId();
        this.form.controls.DMOCRM_HeaderInf_SaleProc.patchValue(this.currentUser.UserId);
      }
      this.populateDDLOptions();
      if (!this.ContractId.includes(',')) {
        this.form.get('DMOCRM_HeaderInf_ContID').setValue(this.ContractId);
      }
      this.form.addControl('dmocrmconjagntsetconjag', new FormControl(false));
      this.form.addControl('conjunctionlAgents', new FormArray([]));
      this.form.addControl('enableBranchRebate', new FormControl(false));
      this.form.addControl('rebateRate', new FormControl());
      this.form.get('rebateRate').disable();
      this.onChanges();
      if (this.isEdit) {
        this.getConjunctionAgentData();
      }
      this.getSaleData();
    });
    
  }

  populateDDLOptions() {
    this.BMJSON.List.forEach(bmoGuid => {
      this.BMJSON.BusinessModelObjects[bmoGuid].List.forEach(dmogGuid => {
        if (this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].DisplayName === 'Header Information') {
          this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].List.forEach(rowID => {
            this.BMJSON.BusinessModelObjects[bmoGuid].DataModelObjectGroups[dmogGuid].Rows[rowID].Columns.forEach(objCOLUMN => {
              objCOLUMN.List.forEach(dmoGUID => {
                const dmo = objCOLUMN.DataModelObjects[dmoGUID];
                if ((dmo.Type === 'DropDownList' || dmo.Type === 'KeyValueSearchBox') && dmoGUID !== 'dmocrmheaderinfsaleyard' && dmoGUID !== 'dmocrmheaderinfsaletype') {
                  this.optionList[dmo.Name] = [];
                  if (dmo.DataSource === 'values') {
                    dmo.Options.split(',').forEach(item => {
                      this.optionList[dmo.Name] = [...this.optionList[dmo.Name], { ValueField: item, TextField: item }];
                    });
                  } else if (dmo.DataSource === 'json') {
                    this.optionList[dmo.Name] = JSON.parse(dmo.Options);
                  } else if (dmo.DataSource === 'c2miceapi') {
                    const callOption = dmo.Options.split('~~~');
                    const apiURL = callOption[0].toString();
                    const responseKey = callOption[callOption.length - 1];
                    this.listviewService.GetDataFromIceAPI(apiURL, 'text').subscribe(result => {
                      const parser = new DOMParser();
                      const xmlDoc = parser.parseFromString(result, 'text/xml');
                      const rowList = xmlDoc.getElementsByTagName('Table1');
                      let nodeIndex = -1;
                      for (const Index in rowList[0].childNodes) {
                        if (rowList[0].childNodes[Index].nodeName === responseKey) {
                          nodeIndex = parseInt(Index, 0);
                        }
                      }
                      if (nodeIndex > -1 && rowList.length > 0) {
                        let rowInex = 0;
                        while (rowInex < rowList.length) {
                          const optionValue = rowList[rowInex].childNodes[nodeIndex].childNodes[0].nodeValue;
                          this.optionList[dmo.Name] = [...this.optionList[dmo.Name], { ValueField: optionValue, TextField: optionValue }];
                          rowInex++;
                        }
                      }
                    });
                  } else if (dmo.DataSource === 'wfapigetdata') {
                    const callOption = dmo.Options.split('~~~');
                    const callParam = JSON.parse(callOption[1]);
                    const responseKey = callOption[0].toString().replace(/\s/g, '');
                    const responseParamss = responseKey.split('-');
                    let paramValue = '';
                    if (dmo.Name === 'DMOCRM_HeaderInf_TranType') {
                      callParam.GridFilters.push({
                        GridConditions: [
                          {
                            Condition: 'EQUAL',
                            ConditionValue: 'Private'
                          }
                        ],
                        DataField: 'dmotrnstyptranstypedscr',
                        LogicalOperator: 'or',
                        FilterType: 'Column_Filter'
                      });
                    }
                    this.listviewService.GridData(callParam).subscribe(result => {
                      result.Data.forEach(rowItem => {
                        if (responseParamss.length === 1) {
                          paramValue = rowItem[responseParamss[0]];
                          if (paramValue !== 'All') {
                            this.optionList[dmo.Name] = [...this.optionList[dmo.Name], { ValueField: paramValue, TextField: paramValue }];
                          }
                        } else if (responseParamss.length === 2) {
                          paramValue = `${rowItem[responseParamss[0]]}~${rowItem[responseParamss[1]]}`;
                          this.optionList[dmo.Name] = [...this.optionList[dmo.Name], { ValueField: paramValue, TextField: `${rowItem[responseParamss[1]]}` }];
                        }
                      });
                      this.form.get('DMOCRM_HeaderInf_TranType').setValue('Private');
                      //this.form.get('DMOCRM_HeaderInf_ContID').setValue(this.ContractId);
                    });
                  } else if (dmo.DataSource.toLowerCase().indexOf('wfapi')>-1) {
                    const responseKey = dmo.Key.toString().replace(/\s/g, '');
                    const responseValue = dmo.Value.toString().replace(/\s/g, '');
                    const callParam = JSON.parse(dmo.Model);
                    if (dmo.Name === 'DMOCRM_HeaderInf_TranType') {
                      callParam.GridFilters.push({
                        GridConditions: [
                          {
                            Condition: 'EQUAL',
                            ConditionValue: 'Private'
                          }
                        ],
                        DataField: 'dmotrnstyptranstypedscr',
                        LogicalOperator: 'or',
                        FilterType: 'Column_Filter'
                      });
                    }
                    this.listviewService.GridData(callParam).subscribe(result => {
                      result.Data.forEach(rowItem => {
                        this.optionList[dmo.Name] = [...this.optionList[dmo.Name], { ValueField: `${rowItem[responseKey]}`, TextField: `${rowItem[responseValue]}` }];
                      });
                      });
                  }
                }
              });
            });
          });
        }
      });
    });
  }

  changeConductingBranch(ev) {
    if (ev) {
      const branchName = ev.ValueField || ev.DMOVAL;
      this.apiESaleyardService.post(`crmsales/getSaleyardName/${branchName}`)
        .pipe(map(data => data.Data))
        .subscribe(data => {
          this.optionList.DMOCRM_HeaderInf_Saleyard = [];
          if (ev.ValueField) {
            this.form.get('DMOCRM_HeaderInf_Saleyard').patchValue('');
          }
          if (Array.isArray(data)) {
            data.forEach(item => {
              this.optionList.DMOCRM_HeaderInf_Saleyard =
                [...this.optionList.DMOCRM_HeaderInf_Saleyard, { ValueField: item.SALEYARDNAME, TextField: item.SALEYARDNAME }];
            });
          }
        });
    }
  }

  getConjunctionAgentData() {
    const params = {
      ProcessName: this.processName,
      TransactionID: this.transactionId,
      DmogGuid: 'dmgcrmconjagntgrid',
      Columns: 'dmocrmconjagntagent,dmocrmconjagntrate'
    };
    this.applicationService.getGridDmogData(params).subscribe(response => {
      if (response.length) {
        response.forEach(item => {
          this.form.get('dmocrmconjagntsetconjag').setValue(true);
          this.conjunctionlAgents.push(this.fb.group({
            DATAID: [item.DATAID],
            dmocrmconjagntagent: [item.dmocrmconjagntagent],
            dmocrmconjagntrate: [item.dmocrmconjagntrate]
          }));
        });
      }
    });
  }


  onChanges() {
    this.form.get('enableBranchRebate').valueChanges
    .subscribe(checked => {
      this.form.get('rebateRate').patchValue('');
      if (checked) {
        this.form.get('rebateRate').enable();
      } else {
        this.form.get('rebateRate').disable();
      }
    });
  }
  OnChangeTransactionType(ev) {
    let val: any;
    if (ev) {
      let trnsTypeName = ev.ValueField || ev.DMOVAL;
      trnsTypeName = trnsTypeName.indexOf('~~~') > -1 ? trnsTypeName.split('~~~')[0] : trnsTypeName;
      this.apiESaleyardService.post(`crmsales/getSaleType/${trnsTypeName}`)
        .pipe(map(data => data.Data))
        .subscribe(data => {
          this.optionList.DMOCRM_HeaderInf_SaleType = [];
          if (ev.ValueField) {
            this.form.get('DMOCRM_HeaderInf_SaleType').patchValue('');
          }
          if (Array.isArray(data)) {
            data.forEach(item => {
              this.optionList.DMOCRM_HeaderInf_SaleType = [...this.optionList.DMOCRM_HeaderInf_SaleType, { ValueField: item.SALECODE, TextField: item.SALETYPENAME }];
            });
          }
        });
    }
    if (ev != undefined) {
      val = ev.ValueField || ev.DMOVAL;
    } else {
      val = this.form.get('DMOCRM_HeaderInf_TranType').value;
    }
   
  }
  GetPlasmaId() {
    this.headerInformationdmos.forEach((dmo: any) => {
      if (dmo.Type === 'ID') {
        this.dmoControlService.GetPlasmaId(dmo.Name).subscribe(value => {
          const chldCtrl = this.form.get(dmo.Name);
          chldCtrl.reset(value.PlasmaID);
          chldCtrl.updateValueAndValidity();
        });
      }
    });
  }

  get f() { return this.form.controls; }

  get conjunctionlAgents() {
    return this.form.get('conjunctionlAgents') as FormArray;
  }

  addConjunctionalAgent() {
    this.isCunjuction = false;
    const control = this.form.controls.conjunctionlAgents as FormArray;
    control.push(
      this.fb.group({
        DATAID: [null],
        dmocrmconjagntagent: [null],
        dmocrmconjagntrate: [null]
      })

    );
  }

  deleteConjunctionalAgent(index: number) {
    this.rateVale = 0;
    const control = this.form.controls.conjunctionlAgents as FormArray;
    if (control.controls[index].value.DATAID) {
      this.applicationService.deleteGridDmogData(control.controls[index].value.DATAID).subscribe(data => {
        control.removeAt(index);
      });
    } else {
      control.removeAt(index);
    }
  }

  async saveConjunctionalAgent(conjunctionlAgents: any) {
    try {
      for (const item of conjunctionlAgents) {
        if (item.dmocrmconjagntagent !== '' && item.dmocrmconjagntagent != null &&
          item.dmocrmconjagntrate !== '' && item.dmocrmconjagntrate != null) {
          const params: any = {
            ProcessName: this.processName,
            TransactionID: this.transactionId,
            DmogGuid: 'dmgcrmconjagntgrid',
            ActionItemsData: {
              dmocrmconjagntagent: item.dmocrmconjagntagent,
              dmocrmconjagntrate: item.dmocrmconjagntrate
            },
            Columns: 'dmocrmconjagntagent,dmocrmconjagntrate'
          };

          if (item.DATAID) {
            params.DataID = item.DATAID;
          }

          await this.applicationService.insertUpdateGridDmogData(params).toPromise();
        }
      }
    } catch (err) {
      console.log(err);
    }
  }

  getSaleData() {
    const queryBody: any = {
      PageSize: -1,
      PageNumber: -1,
      SortColumn: 'dmocrmheaderinfsaleid',
      SortOrder: 'Asc',
      ProcessName: 'LMKLivestockSales',
      TimeZone: 0,
      ColumnList: 'dmocrmheaderinfsaleid',
      ViewName: 'View 1',
      GridFilters: []
    };
    this.listviewService.GridData(queryBody)
      .pipe(map(data => data.Data))
      .subscribe(response => {
        this.saleData = response;
      });
  }

  saleIdSearch = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
    const inputFocus$ = this.saleIdfocus$;

    return merge(debouncedText$, inputFocus$).pipe(
      map(term => (
        term === ''
          ? this.saleData
            .map(item => item.dmocrmheaderinfsaleid)
            .filter(id => id !== '' && id != null)
          : this.saleData
            .filter(v => v.dmocrmheaderinfsaleid.toLowerCase().indexOf(term.toLowerCase()) > -1)
            .map(item => item.dmocrmheaderinfsaleid)))
    );
  }


  onSubmit() {
    this.submitted = true;
    const loginUser = this.userDetail;
    if (!this.form.valid) {
      return;
    }

    let formValue: any = {};
    if (this.isEdit) {
      formValue = this.dmoControlService.getDirtyValues(this.form);
    } else {
      formValue = { ...this.form.value };
    }

    if (Object.keys(formValue).includes('DMOCRM_HeaderInf_SaleDate')) {
      if (formValue.DMOCRM_HeaderInf_SaleDate != null &&
        formValue.DMOCRM_HeaderInf_SaleDate !== '' &&
        formValue.DMOCRM_HeaderInf_SaleDate.hasOwnProperty('year') &&
        formValue.DMOCRM_HeaderInf_SaleDate.hasOwnProperty('month') &&
        formValue.DMOCRM_HeaderInf_SaleDate.hasOwnProperty('day')) {
              // formValue.DMOCRM_HeaderInf_SaleDate = this.ngbDateFRParserFormatter.format(formValue.DMOCRM_HeaderInf_SaleDate);
        const dateyyMMdd = ''.concat(formValue.DMOCRM_HeaderInf_SaleDate.year, '-', formValue.DMOCRM_HeaderInf_SaleDate.month, '-', formValue.DMOCRM_HeaderInf_SaleDate.day);
        formValue.DMOCRM_HeaderInf_SaleDate = dateyyMMdd;
        if (environment.Setting.dateTimeFormat24 === true) {
          formValue.DMOCRM_HeaderInf_SaleDate = this.getUserDateTime(formValue.DMOCRM_HeaderInf_SaleDate,
            'MM/dd/yyyy hh:mm:ss', loginUser.TimeZone);
        } else {
          formValue.DMOCRM_HeaderInf_SaleDate = this.getUserDateTime(formValue.DMOCRM_HeaderInf_SaleDate,
            'MM/dd/yyyy hh:mm:ss', loginUser.TimeZone);
        }
        
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const saledate = new Date(dateyyMMdd);
        saledate.setHours(0, 0, 0, 0);
        if (this.isDateGraeter === false && saledate > today) {
          this.msg.showMessage('Warning', {
            body: 'You have selected a future date. Would you like to proceed?',
            btnText: 'Yes',
            checkboxText: 'Proceed',
            isConfirmation: true,
            isDelete: false,
            callback: this.redirectionConfirmation,
            caller: this,
          })
          // this.showErrorMessage('You have selected a future date. would you like to proceed?', 'Warning', 'Yes',
          // this.redirectionConfirmation, false, true, true, 'would you like to proceed?');
          return;
        }
      } else {
        if (isNaN(Date.parse(formValue.DMOCRM_HeaderInf_SaleDate))) {
          formValue.DMOCRM_HeaderInf_SaleDate = null;
        }
        // formValue.DMOCRM_HeaderInf_SaleDate = null;
      }
    }

    let isRebate = false;
    const conjunctionalAgentsData = formValue.conjunctionlAgents;
    if (formValue.enableBranchRebate === true && formValue.rebateRate) {
      formValue.DMOCRM_IntBuyBrcReb_Rate = formValue.rebateRate;
      formValue.DMOCRM_IntBuyBrcReb_Enab = true;
    } else if (formValue.enableBranchRebate === true) {
      formValue.DMOCRM_IntBuyBrcReb_Enab = true;
    } else if (formValue.rebateRate) {
      formValue.DMOCRM_IntBuyBrcReb_Rate = formValue.rebateRate;
    } else if (this.isEdit === true && 
    this.data.DataInformation.dmocrmintbuybrcrebenab.RLTYPDMOVAL === 'true' && formValue.enableBranchRebate === false) {
      formValue.DMOCRM_IntBuyBrcReb_Rate = '';
      formValue.DMOCRM_IntBuyBrcReb_Enab = false;
      isRebate = true;
    }
    delete formValue.enableBranchRebate;
    delete formValue.rebateRate;
    delete formValue.dmocrmconjagntsetconjag;
    delete formValue.conjunctionlAgents;

    if (this.isEdit) {
      const submitData: any = {
        Identifier: {
          Name: null,
          Value: null,
          TrnsctnID: this.transactionId
        },
        ProcessName: this.processName,
        TriggerName: 'Save Data',
        UserName: this.currentUser.UserName,
        Data: [formValue]
      };

      this.applicationService.updateApplication(submitData).subscribe(async data => {
        if (conjunctionalAgentsData) {
          const conjData = [];
          Object.keys(conjunctionalAgentsData).forEach(key => {
            const control = this.form.controls.conjunctionlAgents as FormArray;
            conjData.push(control.controls[key].value);
          });
          await this.saveConjunctionalAgent(conjData);
        }
        this.activeModal.close(true);
      });

    } else {
      // this.form.get('DMOCRM_HeaderInf_TranType').enable();
      if(!this.form.get('DMOCRM_HeaderInf_ContID').value) {
        this.form.get('DMOCRM_HeaderInf_ContID').patchValue(this.ContractId);
      }
      Object.keys(formValue).forEach(key => {
        if (formValue[key] == null || formValue[key] === '' || formValue[key] === 'Select...') {
          delete formValue[key];
        }
      });
      // this.form.get('DMOCRM_HeaderInf_TranType').disable();
      const submitData: any = {
        ProcessName: this.processName,
        UserName: this.currentUser.UserName,
        TriggerName: 'TRGR_PreProcessing_Next',
        Data: [formValue]
      };

      if (this.isSaleLotShowing) {
        this.applicationService.insertApplication(submitData).subscribe(async response => {
          this.transactionId = response.result.transactionId;
          if (conjunctionalAgentsData.length) {
            await this.saveConjunctionalAgent(conjunctionalAgentsData);
          }
          const PId = this.form.get('DMOCRM_HeaderInf_SaleID');

          // Save Sale Contract Mapping
          this.SaleContract(PId.value);
          // Save lot Mapping
          this.SaleLot(PId.value);

          this.saveLotData(this.SelectedRecordIds);

          this.activeModal.close(true);
        });
      } else {
        this.GetLotConfig();
        this.isSaleLotShowing = true;
      }

    }

  }

  GetLotConfig() {
    const RequestBody = {
      ProcessName: 'LMKOPECESLot',
      PageSize: -1,
      PageNumber: '0',
      SortColumn: '-1',
      SortOrder: '-1',
      TimeZone: '-330',
      ColumnList: 'lmkoeelotdmolotnumber,lmkoeelotdmospaaccno,lmkoeelotdmotrdname,lmkoeelotdmoproduct,lmkoeelotdmoquantity,lmkoeelotdmobuyerid,lmkoeelotdmobuyname',
      GridFilters: [
      ],
      ParentTransactionId: this.SelectedRecordIds.join(','),
      ViewName: ''
    };
    this.GetLotData(RequestBody);
  }

  GetLotData(body) {
    this.econtract.GridData(body).subscribe(
      data => {
        this.dataSource = data.Data;
        this.itemsCount = data.RecordsCount;
      });
  }
  // savelotdatg function is use to map data and save on remote.
  saveLotData(parentId) {
    const cl = new ColumnList();
    const body = {
      ProcessName: 'LMKOPECESLot',
      PageSize: -1,
      PageNumber: '0',
      SortColumn: '-1',
      SortOrder: '-1',
      TimeZone: '-330',
      ColumnList: cl.LMKOPECESLot,
      GridFilters: [],
      ParentTransactionId: parentId.join(','),
      ViewName: 'View 1'
    };
    let lotId=0;
    this.econtract.GridData(body).subscribe(
      async data => {
        this.dataSource.filter(x => x.selected === true).forEach(SelectedElement => {
          const element = data.Data.filter(x => x.PTRNSCTNID === SelectedElement.PTRNSCTNID)[0];
          lotId=lotId+1;
          if (element) {
            this.submitData.push(
              {
                // Vendor Id
                DMOLot_VInfo_VendorId: element.lmkoeelotdmospaaccno,
                // Vendor Name
                DMOLot_VInfo_VendorNam: element.lmkoeelotdmovendor,
                // Vendor Branch
                DMOLot_VInfo_VendorBrc: element.lmkoeelotdmovdombrch,
                // Vendor Pic
                DMOLot_VInfo_VendorPic: element.dmolotvinfovendorpic,
                // GST
                DMOLot_VInfo_GstReg: element.dmolotvinfovendorgst,
                // Sale Ref
                DMOLot_VInfo_AcSaleRef: element.dmolotvinfoacsaleref,
                // Buyer Id
                DMOLot_BInfo_BuyerId: element.lmkoeelotdmobuyerid,
                // Buyer Name
                DMOLot_BInfo_BuyerName: element.lmkoeelotdmobuyname,
                // Buyer Branch
                DMOLot_BInfo_BuyerBrc: element.lmkoeelotdmobuybrch,
                // Buyer Pic
                DMOLot_BInfo_BuyerPic: element.dmolotbinfobuyerpic,
                // Invoice Reference
                DMOLot_BInfo_InvoiceRef: element.dmolotbinfoinvoiceref,
                // Bread
                DMOLot_BInfo_SetIntBBReb: element.dmolotbinfosetintbbreb,
                // Rate
                DMOLot_BInfo_Rate: element.dmolotbinfosetintbbreb,
                // Lot Number
                DMOLot_LotInfo_LotNum: element.lmkoeelotdmolotnumber,
                // Lot Quantity
                DMOLot_LotInfo_Qnty: element.lmkoeelotdmoquantity,
                // Product
                DMOLot_LotInfo_Pdct: element.lmkoeelotdmoproduct,
                // Product description
                DMOLot_LotInfo_ProdDesc: element.lmkoeelotdmolistgdesc,
                // Lot bread
                DMOLot_LotInfo_Brd: element.lmkoeelotdmobreed,
                // $/Head
                DMOLot_LotInfo_Price$PHd: element.lmkoeelotdmopriceaud,
                // Cost/Head
                DMOLot_LotInfo_PriceCPKg: element.dmolotlotinfopricecpkg,
                // Weight
                DMOLot_LotInfo_WtKg: element.lmkoeelotdmotweight,
                // turnover
                DMOLot_LotInfo_TurnovAUD: element.dmolotlotinfoturnovaud,
                // Sex
                DMOLot_LotInfo_Sex: element.lmkoeelotdmosex,

                DMOLot_LotInfo_PaintMk: element.dmolotlotinfopaintmk,

                DMOLot_LotInfo_ContractId: element.dmolotlotinfocontractid,
                DMOLot_LotInfo_HGP: element.dmolotlotinfohgp,
                DMOLot_LotInfo_TransClaim: element.dmolotlotinfotransclaim,
                DMOLot_LotInfo_LotID: lotId,
              }
            );
          }
        });
        this.submitData.forEach((ele, index) => {
          Object.keys(ele).forEach(key => {
            if (this.submitData[index][key] == null || this.submitData[index][key] === '' || this.submitData[index][key] === undefined) {
              delete this.submitData[index][key];
            }
          });
        });
      
        if (this.submitData.length > 0) {
          let ind = 0;
          this.submitData.forEach(element => {
            const submitData: any = {
              ProcessName: 'LMKLivestockLots',
              UserName: this.currentUser.UserName,
              TriggerName: 'TRGR_LotPreProcessing_Calculate',
              ParentTransactionID: this.transactionId,
              Data: [element]
            };
           this.applicationService.insertApplication(submitData).subscribe(async (x) => {
              
              await this.lot.saveAutoLotAgentAgency({TransactionID: x.result.transactionId}).toPromise();
           
              ind = ind + 1;
              if(this.submitData.length === ind){
                
                await this.salesService.AddVendorTermsData({SaleTransactionID: this.transactionId}).toPromise();
          
                await this.apiESaleyardService.post('crmlot/calcLotFeesChargesById', {SaleTransactionID: this.transactionId}).toPromise();

                this.router.navigate(['/crm/sales', this.transactionId]);
              }
              
              
              //   await this.calcLotFeesCharges();
            });
          });
          //

          

          
        } else {
          this.router.navigate(['/crm/sales', this.transactionId]);
        }
      });
  }
  SaleContract(Saleid) {
    const requestData: any = {
      ContractTransactionID: this.SelectedRecordIds.join(','),
      ContractID: '',
      SaleTransactionID: this.transactionId,
      SaleID: Saleid
    };
    this.econtract.saveSaleContract(requestData).toPromise();
  }
  SaleLot(Saleid) {
    const requestDataLot: any = {
      LotId: '0',
      LotTransactionId: this.dataSource.filter(x => x.selected === true).map(x => x.TRNSCTNID).join(','),
      SaleId: Saleid,
      SaleTransactionId: this.transactionId,
    };
    this.econtract.saveSaleLot(requestDataLot).toPromise();
  }
  conjuctionalAgentSearch = (text$: Observable<string>) => {
    return this.lotSearchService.conjuctionalAgentSearch(text$);
  }
  onSubmitRecord() {
    const control = this.form.controls.conjunctionlAgents as FormArray;
    this.rateVale = 0;
    control.controls.forEach(element => { this.rateVale += element.value.dmocrmconjagntrate; });
    if (this.rateVale > 100 && this.isCunjuction === false) {
      this.msg.showMessage('Warning', {
        header: 'Confirmation Message',
        body: 'Conjunctional commission exceeds 100%. Do you want to continue?',
        btnText: 'Yes',
        isConfirmation: true,
        callback: this.redirectionConfirmation,
        caller: this,
      })
      // const modalMsgRef = this.modalService.open(MessageComponent, { backdrop: 'static', windowClass: 'Confirm_popup' });
      // const modalInstance: MessageComponent = modalMsgRef.componentInstance;
      // modalInstance.MessagePopup = modalMsgRef;
      // modalInstance.IsConfirmation = true;
      // modalInstance.Caller = this;
      // modalInstance.MessageHeader = 'Confirmation Message';
      // modalInstance.Message = 'Conjunctional commission exceeds 100%. Do you want to continue.?';
      // modalInstance.ButtonText = 'Yes';
      // modalInstance.IsDefaultView = true;
      // modalInstance.CallBackMethod = this.redirectionConfirmation;
    } else {
      this.onSubmit();
    }

  }
  redirectionConfirmation(modelRef: NgbModalRef, Caller: EContractViewModalComponent) {
    Caller.isCunjuction = true;
    Caller.isDateGraeter = true;
    Caller.onSubmit();
  }
   /* ---------------------Open Confirmation Popup-------------- */
  //  showErrorMessage(ErrorMsg: string, HeaderMsg: string, buttonText: string, callback: any, IsDelete: boolean, IsDefaultView: boolean,
  //   IsConfirmation: boolean, confirmationText: string) {
  //   const modalMsgRef = this.modalService.open(MessageComponent, { backdrop: 'static', windowClass: 'Confirm_popup' });
  //   const modalInstance: MessageComponent = modalMsgRef.componentInstance;
  //   modalInstance.Message = ErrorMsg;
  //   modalInstance.ButtonText = buttonText;
  //   modalInstance.MessageHeader = HeaderMsg;
  //   modalInstance.MessagePopup = modalMsgRef;
  //   modalInstance.IsConfirmation = IsConfirmation;
  //   modalInstance.CallBackMethod = callback;
  //   modalInstance.Caller = this;
  //   modalInstance.IsDelete = IsDelete;
  //   modalInstance.IsDefaultView = IsDefaultView;
  //   modalInstance.ConfirmationText = confirmationText;
  // }
  getUserDateTime(value, format, zone) {
    try {
      const d = new Date(value); // val is in UTC
      const localOffset = zone * 60000;
      const localTime = d.getTime() - localOffset;
      d.setTime(localTime);
      return formatDate(d, format, 'en-US');
    } catch (error) {

      return '';
    }
  }
}
