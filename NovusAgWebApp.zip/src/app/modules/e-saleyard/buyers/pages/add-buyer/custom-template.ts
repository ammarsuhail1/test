import { environment } from '@env/environment';

export function getTemplate(webUrlRoot: string, name: string) {
  const links = environment.socialLinks;
  return `
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

  <head>

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link rel="icon" type="image/x-icon" href="msc-images/favicon.ico" />
    <link rel="apple-touch-icon" type="image/x-icon" href="msc-images/favicon.ico" />
    <title>NovusAg | E-SALEYARD</title>

  </head>
  <style>
    a {
      color: #000000;
    }

  </style>

  <body style="color:#5b5b5b;margin:0px;padding:20px;font-family:Arial, Helvetica, sans-serif;font-size:14px;line-height:20px;color:#333;">

    <table style="width:600px;border:0;color:#333;margin:auto;" cellpadding="0" cellspacing="0">
      <tr>
        <td style="width:556px;height:75px;padding:0px 20px;border:0;background-color:#000000; ">
          <table cellpadding="0" cellspacing="0" style="width:556px;border:0;">
            <tr>
              <td valign="middle" style="width:140px;">
                <a href="#"><img src="${webUrlRoot}/assets/styles/images/novus-logo.png" width="134" alt="NovusAg" title="NovusAg" border="0" /></a>              </td>
              <td valign="middle" style="width:20px;">
              </td>
              <td valign="middle" style="width:340px;">
                <font style="font-family:Arial, Helvetica, sans-serif;font-size:14px;color:#fff;"><strong>E-SALEYARD</strong></font>
              </td>
              <td align="right" valign="middle">
                <table cellpadding="0" cellspacing="0" style="border:0;">
                  <tr>
                    <td align="right" style="width:30px;">
                      <a href="${links.twitter}"><img src="${webUrlRoot}/assets/styles/images/twitter.gif" height="20" width="20" alt="twitter" title="twitter" border="0" /></a>
                    </td>
                    <td align="right" style="width:30px;">
                      <a href="${links.linkedIn}"><img src="${webUrlRoot}/assets/styles/images/linkedin.gif" height="20" width="20" alt="linkedin" title="linkedin" border="0" /></a>
                    </td>
                  </tr>
                </table>
              </td>
            </tr>
          </table>
        </td>
      </tr>
      <tr>
        <td style="width:556px; padding:22px; padding-bottom:0px;"></td>
      </tr>
      <tr>
        <td align="center">
          <table cellpadding="0" cellspacing="0" width="556">
            <tr>
              <td style="padding:10px 0px;">
                <font style="font-family:Arial, Helvetica, sans-serif;font-size:14px;">Hi <span style="text-transform: capitalize;">${name},</span></font>
              </td>
            </tr>
            <tr>
              <td style="padding:5px 0px;">
                <font style="font-family:Arial, Helvetica, sans-serif;font-size:14px;">
                Your NovusAg  account has been successfully created. You now have access to view all listing pricing and can save listings you're interested in to a personalized watchlist. If you want to add a NovusAg account number to your account, please add it from your <a href="https://lmkstaging2-wf.c2m.net/#/e-saleyard/add-buyer" style="color: '#226398'"> account page </a> or <a href="https://www.landmark.com.au/find-a-branch" style="text-decoration: underline; color: '#226398'"> get in touch with your local NovusAg branch </a> to begin placing bids! 
                </font>
              </td>
            </tr>

          </table>
        </td>
      </tr>
      <tr>
        <td align="left" style="padding:0px;margin:0px;padding-top:12px;padding-bottom:13px;padding-left:22px;padding-right:22px;">
          <font style="font-family:Arial, Helvetica, sans-serif;font-size:14px;">Thank you,<br /><strong>The NovusAg E-Saleyard Team</strong></font>
        </td>
      </tr>
      <tr>
        <td style="width:556px; padding:22px; padding-bottom:0px;"></td>
      </tr>
      <tr>
        <td style="width:556px;height:55px;padding:0px 22px;background-color:#333333;color:#fff;text-align:center;">
          <table cellpadding="0" cellspacing="0" width="556">
            <tr>
              <td align="left" style="padding:10px 0px;width:70%;">
                <font style="font-family:Arial, Helvetica, sans-serif;font-size:12px;color:#fff;">&copy; Copyright 2019 NovusAg Ag Solutions, Inc. All Rights Reserved.</font>
              </td>
              <td align="right" style="padding:10px 0px;width:30%;">
                <font style="font-family:Arial, Helvetica, sans-serif;font-size:12px;color:#fff;"><a href="https://www.esaleyard.NovusAgagsolutions.com.au" title="esaleyard.NovusAgagsolutions.com.au"
                     style="text-decoration:none;color:#fff;">esaleyard.NovusAgagsolutions.com.au</a></font>
              </td>
            </tr>
          </table>
        </td>
      </tr>
    </table>
  </body>

</html>

`;

}
