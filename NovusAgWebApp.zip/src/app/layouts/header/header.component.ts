import { Component, OnInit, HostBinding } from '@angular/core';
import { Router } from '@angular/router';
import { HeaderService, AuthenticationService } from '@app/core';
import { UserDetail } from '@app/core/models/user-detail';

import { environment } from '@env/environment';
import {Observable} from 'rxjs';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  public processName$: Observable<string>;
  public projectTitle = environment.projectTitle;
  UserFullName: string;
  UserMessage: string;
  flag: string = "unread";
  
  isOpen = false;
  NotificationList: any[];

  modalScrollDistance = 1;
  modalScrollThrottle = 500;
  pullNotificationsOnScrollDown = true;
  pageFrom = 0;

  showItemLoading = false;
  isMarkAsRead = false;
  constructor(public headerService: HeaderService,
    private authenticationService: AuthenticationService,
    private router: Router, 
    private userDetail: UserDetail) {
    this.authenticationService.currentUser.subscribe(user => {
      if (user) {
        this.UserFullName = user.FirstName + ' ' + user.LastName;
        this.UserMessage = this.UserFullName;
      } else {
        this.UserFullName = '';
        this.UserMessage = '';
      }
    });
  }

  ngOnInit() { 
    this.processName$ = this.headerService.processName;
    this.headerService.change.subscribe(Count => {
    });
    this.ShowHideHeaderIcon();
  }
  ShowHideIcon() {
    if (localStorage.getItem('AccessToken')) {
      return true;
    } else {
      return false;
    }
  }
  ShowHideHeaderIcon() {
    if (localStorage.getItem('AccessToken') && this.router.url !== '/app_list') {
      return true;
    } else {
      return false;
    }
  }
  toggle(flag) {
    this.showItemLoading = true;
    if (!this.NotificationList) {
      this.headerService.getNotification(flag, 0).subscribe(
        Result => {
          this.NotificationList = Result;
          this.isMarkAsRead = this.NotificationList.filter(x => x.ReadStatus == 0).length > 0;
          this.showItemLoading = false;
        }
      )
    } else {
      this.showItemLoading = false;
    }
    this.isOpen = !this.isOpen;
  }
  show(event) {
    this.showItemLoading = true;
    this.pullNotificationsOnScrollDown = true;
    if (event.currentTarget.innerHTML === "Show all") {
      event.currentTarget.innerHTML = "Show only unread";
      this.flag = "all";
      this.pageFrom = this.NotificationList ? 0 : this.NotificationList.length;
      this.headerService.getNotification(this.flag, this.pageFrom).subscribe(
        Result => {
          this.NotificationList = Result;
          this.showItemLoading = false;
        }
      )
    }
    else {
      event.currentTarget.innerHTML = "Show all";
      this.flag = "unread";
      this.pageFrom = this.NotificationList ? 0 : this.NotificationList.length;
      this.headerService.getNotification(this.flag, this.pageFrom).subscribe(
        Result => {
          this.NotificationList = Result;
          this.showItemLoading = false;
        }
      )
    }

  }
  CloseAnnouncement(Key, index) {
    this.headerService.readNotification(Key).subscribe(
      Result => {
        if (this.headerService.Count === 0) {
          this.isOpen = !this.isOpen;
        }
      }
    )
    //this.NotificationList.splice(index, 1);
    this.NotificationList = this.NotificationList.filter(item => item.ID !== Key);
  }
  OpenDetailPage(announcementId:any) {
    //this.router.navigate(['/announcement/showdetail',announcementId]);
    window.open('/announcement/showdetail/'+encodeURIComponent(announcementId), '_blank');
  }
  CloseAnnouncementAll() {
    const AllKey = this.NotificationList.filter(x => x.ReadStatus == 0).map(x => x.ID).join(',');
    this.NotificationList = [];
    // this.NotificationList.filter(x => x.ReadStatus == 0).map(x => x.ReadStatus = 1);

    this.headerService.readNotification(AllKey).subscribe(
      Result => {
        if (this.headerService.Count === 0) {
          this.isOpen = !this.isOpen;
        }
      }
    )
  }


  onModalScrollDown() {
    this.showItemLoading = true;
    this.headerService.getNotification(this.flag, this.NotificationList.length).subscribe(
      Result => {
        this.pullNotificationsOnScrollDown = Result.length > 0;
        Result.forEach(element => {
          this.NotificationList.push(element);
        });
        this.showItemLoading = false;
      }
    )
    
  }

  isUserLoggedIn() {
    return this.userDetail ? true : false;
  }

  logout() {
    this.authenticationService.logout();
    this.router.navigate(['/auth/login']);
  }
}
