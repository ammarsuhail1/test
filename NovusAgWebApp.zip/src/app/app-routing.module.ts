import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard, ProcessGuard } from '@app/core';
import { ListComponent } from './shared/components/Annoucement/list/list.component';
import { ShowDetailComponent } from './shared/components/Annoucement/show-detail/show-detail.component';
import { QuickMindComponent } from './shared/components/quick-mind/quick-mind.component';
import { ListingComponent } from './shared/components/quick-mind/admin/listing/listing.component';
import { QuickMindDetailComponent } from './shared/components/quick-mind-detail/quick-mind-detail.component';

const routes: Routes = [
  { path: '', redirectTo: '/auth/login', pathMatch: 'full'},
  {
    path: 'auth',
    loadChildren: () => import('./modules/auth/auth.module').then(m => m.AuthModule)
  },
  {
    path: 'app_list',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/app-list/app-list.module').then(m => m.AppListModule)
  },
  { path: 'process_control/:process_name',
    canActivate: [AuthGuard, ProcessGuard],
    loadChildren: () => import('./modules/process-control/process-control.module').then(m => m.ProcessControlModule)
  },
  // {
  //   path: 'content_manager',
  //   canActivate: [AuthGuard],
  //   loadChildren: () => import('./modules/content-manager/content-manager.module').then(m => m.ContentManagerModule)
  // },
  // {
  //   path: 'crm',
  //   canActivate: [AuthGuard],
  //   loadChildren: () => import('./modules/crm/crm.module').then(m => m.CrmModule)
  // },
  {
    path: 'announcement',
    canActivate: [AuthGuard],
    component: ListComponent
  },
  {
    path: 'announcement/showdetail/:ID',
    canActivate: [AuthGuard],
    component: ShowDetailComponent
  },
  {
    path: 'quickmind',
    canActivate: [AuthGuard],
    component: QuickMindComponent
  },
  {
    path: 'quickminddetail',
    canActivate: [AuthGuard],
    component: QuickMindDetailComponent
  },
  {
    path: 'quickmindlist',
    canActivate: [AuthGuard],
    component: ListingComponent
  },
  // {
  //   path: 'e-saleyard',
  //   canActivate: [AuthGuard],
  //   loadChildren: () => import('./modules/e-saleyard/e-saleyard.module').then(m => m.ESaleyardModule)
  // },
  // {
  //   path: 'insurance',
  //   canActivate: [AuthGuard],
  //   loadChildren: () => import('./modules/insurance/insurance.module').then(m => m.InsuranceModule)
  // },
  // {
  //   path: 'wool',
  //   canActivate: [AuthGuard],
  //   loadChildren: () => import('./modules/wool/wool.module').then(m => m.WoolModule)
  // },
   {
    path: 'users',
    canActivate: [AuthGuard],
    loadChildren: () => import('./modules/users/users.module').then(m => m.UsersModule)
  },
  {
    path: 'llc-view',
    // canActivate: [AuthGuard],
    loadChildren: () => import('./modules/llc-view/llc-view.module').then(m => m.LlcViewModule)
  },
  // {
  //   path: 'livestock',
  //   canActivate: [AuthGuard],
  //   loadChildren: () => import('./modules/livestock-search/livestock-search.module').then(m => m.LivestockSearchModule)
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { onSameUrlNavigation: 'reload' })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
